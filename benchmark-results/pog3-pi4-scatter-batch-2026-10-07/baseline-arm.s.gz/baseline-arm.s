	.arch armv8-a+crc
	.file	"scatter-baseline-pitch.cpp"
// GNU C++20 (Buildroot 2025.02.15) version 13.4.0 (aarch64-buildroot-linux-gnu)
//	compiled by GNU C version 13.3.0, GMP version 6.3.0, MPFR version 4.1.1, MPC version 1.3.1, isl version none
// GGC heuristics: --param ggc-min-expand=100 --param ggc-min-heapsize=131072
// options passed: -mcpu=cortex-a72 -mlittle-endian -mabi=lp64 -O3 -std=c++20 -fstack-protector-strong -fPIE
	.text
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED5Ev,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev:
.LFB13582:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:608:       ~_Sp_counted_ptr_inplace() noexcept { }
	ret	
	.cfi_endproc
.LFE13582:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev
	.set	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED5Ev,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev:
.LFB13589:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:608:       ~_Sp_counted_ptr_inplace() noexcept { }
	ret	
	.cfi_endproc
.LFE13589:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev
	.set	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED5Ev,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev:
.LFB13596:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:608:       ~_Sp_counted_ptr_inplace() noexcept { }
	ret	
	.cfi_endproc
.LFE13596:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev
	.set	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED2Ev
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv:
.LFB13599:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ret	
	.cfi_endproc
.LFE13599:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED5Ev,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev:
.LFB13598:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:608:       ~_Sp_counted_ptr_inplace() noexcept { }
	mov	x1, 49264	//,
	b	_ZdlPvm		//
	.cfi_endproc
.LFE13598:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED5Ev,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev:
.LFB13584:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:608:       ~_Sp_counted_ptr_inplace() noexcept { }
	mov	x1, 32824	//,
	b	_ZdlPvm		//
	.cfi_endproc
.LFE13584:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED5Ev,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev:
.LFB13591:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:608:       ~_Sp_counted_ptr_inplace() noexcept { }
	mov	x1, 144	//,
	b	_ZdlPvm		//
	.cfi_endproc
.LFE13591:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv:
.LFB13600:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x1, 49264	//,
	b	_ZdlPvm		//
	.cfi_endproc
.LFE13600:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info:
.LFB13601:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	adrp	x2, _ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag	// tmp99,
	add	x2, x2, :lo12:_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag	// tmp98, tmp99,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:631:       _M_get_deleter(const std::type_info& __ti) noexcept override
	mov	x29, sp	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	cmp	x1, x2	// __ti, tmp98
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:631:       _M_get_deleter(const std::type_info& __ti) noexcept override
	str	x19, [sp, 16]	//,
	.cfi_offset 19, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/aligned_buffer.h:106:         return static_cast<void*>(&_M_storage);
	add	x19, x0, 16	// <retval>, tmp108,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	beq	.L10		//,
	ldr	x0, [x1, 8]	// _7, MEM[(const char * *)__ti_5(D) + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:198:     if (__name == __arg.__name)
	adrp	x1, _ZTSSt19_Sp_make_shared_tag	// tmp101,
	add	x1, x1, :lo12:_ZTSSt19_Sp_make_shared_tag	// tmp100, tmp101,
	cmp	x0, x1	// _7, tmp100
	beq	.L10		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:206:     return __name[0] != '*' && __builtin_strcmp (__name, __arg.name()) == 0;
	ldrb	w2, [x0]	// *_7, *_7
	cmp	w2, 42	// *_7,
	beq	.L12		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:206:     return __name[0] != '*' && __builtin_strcmp (__name, __arg.name()) == 0;
	bl	strcmp		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:647: 	return nullptr;
	cmp	w0, 0	// tmp110,
	csel	x19, x19, xzr, eq	// <retval>, <retval>,,
.L10:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:648:       }
	mov	x0, x19	//, <retval>
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L12:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:647: 	return nullptr;
	mov	x19, 0	// <retval>,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:648:       }
	mov	x0, x19	//, <retval>
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.cfi_endproc
.LFE13601:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv:
.LFB13593:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x1, 144	//,
	b	_ZdlPvm		//
	.cfi_endproc
.LFE13593:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv:
.LFB13586:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x1, 32824	//,
	b	_ZdlPvm		//
	.cfi_endproc
.LFE13586:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info:
.LFB13594:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	adrp	x2, _ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag	// tmp99,
	add	x2, x2, :lo12:_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag	// tmp98, tmp99,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:631:       _M_get_deleter(const std::type_info& __ti) noexcept override
	mov	x29, sp	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	cmp	x1, x2	// __ti, tmp98
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:631:       _M_get_deleter(const std::type_info& __ti) noexcept override
	str	x19, [sp, 16]	//,
	.cfi_offset 19, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/aligned_buffer.h:106:         return static_cast<void*>(&_M_storage);
	add	x19, x0, 16	// <retval>, tmp108,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	beq	.L18		//,
	ldr	x0, [x1, 8]	// _7, MEM[(const char * *)__ti_5(D) + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:198:     if (__name == __arg.__name)
	adrp	x1, _ZTSSt19_Sp_make_shared_tag	// tmp101,
	add	x1, x1, :lo12:_ZTSSt19_Sp_make_shared_tag	// tmp100, tmp101,
	cmp	x0, x1	// _7, tmp100
	beq	.L18		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:206:     return __name[0] != '*' && __builtin_strcmp (__name, __arg.name()) == 0;
	ldrb	w2, [x0]	// *_7, *_7
	cmp	w2, 42	// *_7,
	beq	.L20		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:206:     return __name[0] != '*' && __builtin_strcmp (__name, __arg.name()) == 0;
	bl	strcmp		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:647: 	return nullptr;
	cmp	w0, 0	// tmp110,
	csel	x19, x19, xzr, eq	// <retval>, <retval>,,
.L18:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:648:       }
	mov	x0, x19	//, <retval>
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L20:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:647: 	return nullptr;
	mov	x19, 0	// <retval>,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:648:       }
	mov	x0, x19	//, <retval>
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.cfi_endproc
.LFE13594:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info:
.LFB13587:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	adrp	x2, _ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag	// tmp99,
	add	x2, x2, :lo12:_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag	// tmp98, tmp99,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:631:       _M_get_deleter(const std::type_info& __ti) noexcept override
	mov	x29, sp	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	cmp	x1, x2	// __ti, tmp98
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:631:       _M_get_deleter(const std::type_info& __ti) noexcept override
	str	x19, [sp, 16]	//,
	.cfi_offset 19, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/aligned_buffer.h:106:         return static_cast<void*>(&_M_storage);
	add	x19, x0, 16	// <retval>, tmp108,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:639: 	    ||
	beq	.L24		//,
	ldr	x0, [x1, 8]	// _7, MEM[(const char * *)__ti_5(D) + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:198:     if (__name == __arg.__name)
	adrp	x1, _ZTSSt19_Sp_make_shared_tag	// tmp101,
	add	x1, x1, :lo12:_ZTSSt19_Sp_make_shared_tag	// tmp100, tmp101,
	cmp	x0, x1	// _7, tmp100
	beq	.L24		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:206:     return __name[0] != '*' && __builtin_strcmp (__name, __arg.name()) == 0;
	ldrb	w2, [x0]	// *_7, *_7
	cmp	w2, 42	// *_7,
	beq	.L26		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/typeinfo:206:     return __name[0] != '*' && __builtin_strcmp (__name, __arg.name()) == 0;
	bl	strcmp		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:647: 	return nullptr;
	cmp	w0, 0	// tmp110,
	csel	x19, x19, xzr, eq	// <retval>, <retval>,,
.L24:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:648:       }
	mov	x0, x19	//, <retval>
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L26:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:647: 	return nullptr;
	mov	x19, 0	// <retval>,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:648:       }
	mov	x0, x19	//, <retval>
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.cfi_endproc
.LFE13587:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.text
	.align	2
	.p2align 4,,15
	.type	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_, %function
_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_:
.LFB11301:
	.cfi_startproc
	stp	x29, x30, [sp, -160]!	//,,,
	.cfi_def_cfa_offset 160
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	mov	x20, x0	// __first, tmp542
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	sub	x0, x1, x0	// _14, __last, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	cmp	x0, 384	// _14,
	ble	.L30		//,
	stp	x23, x24, [sp, 48]	//,,
	.cfi_offset 24, -104
	.cfi_offset 23, -112
	mov	x24, x2	// __depth_limit, tmp544
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	cbz	x2, .L99	// __depth_limit,
	mov	x6, x1	// __last, __last
	add	x23, sp, 136	// tmp537,,
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 22, -120
	.cfi_offset 21, -128
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x22, -6148914691236517206	// tmp412,
	mov	w21, w3	// __comp, tmp545
	movk	x22, 0xaaab, lsl 0	// tmp412,,
	str	x25, [sp, 64]	//,
	.cfi_offset 25, -96
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x25, x20, 24	// tmp540, __first,
.L33:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	asr	x0, x0, 3	// tmp410, _14,
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	ldrh	w3, [x25]	// _248, MEM[(const struct PitchRegion &)__first_302 + 24].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1929: 	  --__depth_limit;
	sub	x24, x24, #1	// __depth_limit, __depth_limit,
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	sub	x5, x6, #24	// tmp421, __last,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mul	x0, x0, x22	// tmp411, tmp410, tmp412
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	ldrh	w4, [x6, -24]	// pretmp_520, MEM[(const struct PitchRegion &)__last_16 + 18446744073709551592].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	and	x1, x0, -2	// tmp415, tmp411,
	add	x0, x1, x0, asr 1	// tmp416, tmp415, tmp411,
	lsl	x0, x0, 3	// tmp417, tmp416,
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	ldrh	w1, [x20, x0]	// _249, MEM[(const struct PitchRegion &)_225].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x2, x20, x0	// _225, __first, tmp417
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:88:       if (__comp(__a, __b))
	cmp	w3, w1	// _248, _249
	bcs	.L59		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:90: 	  if (__comp(__b, __c))
	cmp	w1, w4	// _249, pretmp_520
	bcc	.L65		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:92: 	  else if (__comp(__a, __c))
	cmp	w3, w4	// _248, pretmp_520
	bcc	.L97		//,
.L62:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x25]	// MEM[(struct PitchRegion &)__first_302 + 24], MEM[(struct PitchRegion &)__first_302 + 24]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x2, x3, [x20]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x20]	// MEM[(struct PitchRegion &)__first_302 + 24], *__first_302
	ldr	x1, [x25, 16]	// MEM[(struct PitchRegion &)__first_302 + 24], MEM[(struct PitchRegion &)__first_302 + 24]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x2, x3, [x23]	// *__first_302, MEM[(struct PitchRegion *)_273]
	ldr	x0, [x20, 16]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x20, 16]	// MEM[(struct PitchRegion &)__first_302 + 24], *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x2, x3, [x25]	// *__first_302, MEM[(struct PitchRegion *)__first_302 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x23, 16]	// *__first_302, MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	x0, [x25, 16]	// *__first_302, MEM[(struct PitchRegion *)__first_302 + 24B]
.L61:
	mov	x3, x6	// __last$_M_current, __last
	mov	x19, x25	// __first$_M_current, tmp540
	.p2align 3,,7
.L63:
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	ldrh	w4, [x20]	// _359, MEM[(const struct PitchRegion &)__first_302].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1877: 	  while (__comp(__first, __pivot))
	ldrh	w0, [x19]	// MEM[(const struct PitchRegion &)__first$_M_current_245].bin, MEM[(const struct PitchRegion &)__first$_M_current_245].bin
	cmp	w0, w4	// MEM[(const struct PitchRegion &)__first$_M_current_245].bin, _359
	bcs	.L66		//,
	add	x0, x19, 24	// ivtmp.1623, __first$_M_current,
	.p2align 3,,7
.L67:
	mov	x19, x0	// ivtmp.1623, ivtmp.1623
	ldrh	w1, [x0], 24	// MEM[(short unsigned int *)_282 + -24B], MEM[(short unsigned int *)_282 + -24B]
	cmp	w1, w4	// MEM[(short unsigned int *)_282 + -24B], _359
	bcc	.L67		//,
.L66:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1880: 	  while (__comp(__pivot, __last))
	ldrh	w0, [x3, -24]	// MEM[(const struct PitchRegion &)__last$_M_current_235 + 18446744073709551592].bin, MEM[(const struct PitchRegion &)__last$_M_current_235 + 18446744073709551592].bin
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	sub	x1, x3, #24	// tmp513, __last$_M_current,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1880: 	  while (__comp(__pivot, __last))
	cmp	w0, w4	// MEM[(const struct PitchRegion &)__last$_M_current_235 + 18446744073709551592].bin, _359
	bls	.L68		//,
	sub	x3, x3, #48	// ivtmp.1616, __last$_M_current,
	.p2align 3,,7
.L69:
	mov	x0, x3	// ivtmp.1616, ivtmp.1616
	ldrh	w5, [x3], -24	// MEM[(short unsigned int *)_475 + 24B], MEM[(short unsigned int *)_475 + 24B]
	cmp	w5, w4	// MEM[(short unsigned int *)_475 + 24B], _359
	bhi	.L69		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1125: 	--_M_current;
	mov	x3, x0	// __last$_M_current, ivtmp.1616
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1882: 	  if (!(__first < __last))
	cmp	x3, x19	// __last$_M_current, __first$_M_current
	bls	.L100		//,
.L71:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x3]	// *__last$_M_current_279, *__last$_M_current_279
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1111: 	++_M_current;
	add	x19, x19, 24	// __first$_M_current, __first$_M_current,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x4, x5, [x19, -24]	// *__first$_M_current_322, *__first$_M_current_322
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x19, -24]	// *__last$_M_current_279, *__first$_M_current_322
	ldr	x1, [x3, 16]	// *__last$_M_current_279, *__last$_M_current_279
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x4, x5, [x23]	// *__first$_M_current_322, MEM[(struct PitchRegion *)_273]
	ldr	x0, [x19, -8]	// *__first$_M_current_322, *__first$_M_current_322
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x19, -8]	// *__last$_M_current_279, *__first$_M_current_322
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x4, x5, [x3]	// *__first$_M_current_322, *__last$_M_current_279
	str	x0, [x3, 16]	// *__first$_M_current_322, *__last$_M_current_279
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x23, 16]	// *__first$_M_current_322, MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1112: 	return *this;
	b	.L63		//
.L59:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:97:       else if (__comp(__a, __c))
	cmp	w3, w4	// _248, pretmp_520
	bcc	.L62		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:99:       else if (__comp(__b, __c))
	cmp	w1, w4	// _249, pretmp_520
	bcs	.L65		//,
.L97:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x5]	// MEM[(struct PitchRegion &)__last_16 + 18446744073709551592], MEM[(struct PitchRegion &)__last_16 + 18446744073709551592]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x2, x3, [x20]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x20]	// MEM[(struct PitchRegion &)__last_16 + 18446744073709551592], *__first_302
	ldr	x1, [x5, 16]	// MEM[(struct PitchRegion &)__last_16 + 18446744073709551592], MEM[(struct PitchRegion &)__last_16 + 18446744073709551592]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x2, x3, [x23]	// *__first_302, MEM[(struct PitchRegion *)_273]
	ldr	x0, [x20, 16]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x20, 16]	// MEM[(struct PitchRegion &)__last_16 + 18446744073709551592], *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x2, x3, [x5]	// *__first_302, MEM[(struct PitchRegion *)__last_16 + -24B]
	str	x0, [x5, 16]	// *__first_302, MEM[(struct PitchRegion *)__last_16 + -24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x23, 16]	// *__first_302, MEM[(struct PitchRegion *)_273]
	b	.L61		//
	.p2align 2,,3
.L68:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1125: 	--_M_current;
	mov	x3, x1	// __last$_M_current, tmp513
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1882: 	  if (!(__first < __last))
	cmp	x3, x19	// __last$_M_current, __first$_M_current
	bhi	.L71		//,
	.p2align 3,,7
.L100:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1932: 	  std::__introsort_loop(__cut, __last, __depth_limit, __comp);
	mov	x0, x19	//, __first$_M_current
	mov	x1, x6	//, __last
	mov	w3, w21	//, __comp
	mov	x2, x24	//, __depth_limit
	bl	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	sub	x0, x19, x20	// _14, __first$_M_current, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	cmp	x0, 384	// _14,
	ble	.L101		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	cbz	x24, .L102	// __depth_limit,
	mov	x6, x19	// __last, __first$_M_current
	b	.L33		//
.L65:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x2]	// *_225, *_225
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x4, x5, [x20]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x20]	// *_225, *__first_302
	ldr	x1, [x2, 16]	// *_225, *_225
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x4, x5, [x23]	// *__first_302, MEM[(struct PitchRegion *)_273]
	ldr	x0, [x20, 16]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x20, 16]	// *_225, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x4, x5, [x2]	// *__first_302, *_225
	str	x0, [x2, 16]	// *__first_302, *_225
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x23, 16]	// *__first_302, MEM[(struct PitchRegion *)_273]
	b	.L61		//
.L107:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 25
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x8, -6148914691236517206	// tmp315,
	sub	x19, x19, #24	// ivtmp.1601, __first$_M_current,
	movk	x8, 0xaaab, lsl 0	// tmp315,,
	.p2align 3,,7
.L44:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	ldp	x0, x1, [x20]	// *__first_302, *__first_302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	sub	x9, x19, x20	// _161, ivtmp.1601, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	asr	x13, x9, 3	// tmp313, _161,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x9, 48	// _161,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	ldp	x2, x3, [x19]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion &)_23]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mul	x13, x13, x8	// _162, tmp313, tmp315
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	stp	x0, x1, [x19]	// *__first_302, MEM[(struct PitchRegion *)_23]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	sub	x0, x13, #1	// tmp320, _162,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	and	x15, x13, 1	// _516, _162,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	add	x0, x0, x0, lsr 63	// tmp322, tmp320, tmp320,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	ldr	x1, [x19, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion &)_23]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	asr	x14, x0, 1	// _403, tmp322,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	stp	x2, x3, [x7]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_203]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	ldr	x4, [x20, 16]	// *__first_302, *__first_302
	stp	x2, x3, [x6]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_418]
	str	x1, [x6, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_418]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	str	x1, [x7, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_203]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	str	x4, [x19, 16]	// *__first_302, MEM[(struct PitchRegion *)_23]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	ble	.L47		//,
	mov	x0, 0	// __holeIndex,
	.p2align 3,,7
.L51:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	add	x2, x0, 1	// tmp324, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x5, x0, x0, lsl 1	// tmp337, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x10, x2, 1	// __secondChild, tmp324,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	sub	x4, x10, #1	// _453, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x2, x10, x2, lsl 2	// tmp327, __secondChild, tmp324,
	add	x3, x4, x4, lsl 1	// tmp331, _453, _453,
	lsl	x2, x2, 3	// tmp328, tmp327,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x5, x20, x5, lsl 3	// tmp339, __first, tmp337,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	lsl	x3, x3, 3	// tmp332, tmp331,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	ldrh	w12, [x20, x2]	// MEM[(const struct PitchRegion &)_454].bin, MEM[(const struct PitchRegion &)_454].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x20, x2	// prephitmp_485, __first, tmp328
	add	x11, x20, x3	// _450, __first, tmp332
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	ldrh	w2, [x20, x3]	// MEM[(const struct PitchRegion &)_450].bin, MEM[(const struct PitchRegion &)_450].bin
	cmp	w2, w12	// MEM[(const struct PitchRegion &)_450].bin, MEM[(const struct PitchRegion &)_454].bin
	bls	.L48		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x0, x1, [x11]	// *_450, *_450
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x14, x4	// _403, _453
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:234: 	    __secondChild--;
	mov	x10, x4	// __secondChild, _453
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	stp	x0, x1, [x5]	// *_450, *_480
	ldr	x0, [x11, 16]	// *_450, *_450
	str	x0, [x5, 16]	// *_450, *_480
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bgt	.L49		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	mov	x0, x11	// prephitmp_485, _450
.L50:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cbnz	x15, .L96	// _516,
.L52:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	sub	x13, x13, #2	// tmp357, _162,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	add	x13, x13, x13, lsr 63	// tmp360, tmp357, tmp357,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	x10, x13, asr 1	// __secondChild, tmp360,
	beq	.L54		//,
.L96:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x1, x10, #1	// tmp362, __secondChild,
	ldp	x2, x3, [x6]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	add	x1, x1, x1, lsr 63	// tmp364, tmp362, tmp362,
	asr	x11, x1, 1	// prephitmp_478, tmp364,
	ldr	x1, [x6, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
	stp	x2, x3, [x23]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
	ldrh	w12, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_418].bin
	str	x1, [x23, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbnz	x10, .L57	// __secondChild,
	b	.L56		//
	.p2align 2,,3
.L104:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x4, x5, [x1]	// *_206, *_206
	stp	x4, x5, [x0]	// *_206, *_514
	ldr	x3, [x1, 16]	// *_206, *_206
	str	x3, [x0, 16]	// *_206, *_514
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	x11, .L103	// prephitmp_478,
	mov	x11, x2	// prephitmp_478, tmp399
.L57:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x1, x11, x11, lsl 1	// tmp386, prephitmp_478, prephitmp_478,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	sub	x2, x11, #1	// _212, prephitmp_478,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x10, x10, lsl 1	// tmp390, __secondChild, __secondChild,
	mov	x10, x11	// __secondChild, prephitmp_478
	lsl	x1, x1, 3	// tmp387, tmp386,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	add	x2, x2, x2, lsr 63	// tmp398, _212, _212,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	ldrh	w3, [x20, x1]	// MEM[(const struct PitchRegion &)_206].bin, MEM[(const struct PitchRegion &)_206].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x20, x0, lsl 3	// prephitmp_485, __first, tmp390,
	add	x1, x20, x1	// _206, __first, tmp387
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	asr	x2, x2, 1	// tmp399, tmp398,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	w3, w12	// MEM[(const struct PitchRegion &)_206].bin, __value$bin
	bcc	.L104		//,
.L56:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	ldr	x1, [x23, 16]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	cmp	x9, 24	// _161,
	sub	x19, x19, #24	// ivtmp.1601, ivtmp.1601,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	strh	w12, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_273].bin
	ldp	x2, x3, [x23]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	str	x1, [x0, 16]	// MEM[(struct PitchRegion *)_273], *prephitmp_511
	stp	x2, x3, [x0]	// MEM[(struct PitchRegion *)_273], *prephitmp_511
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	bgt	.L44		//,
.L109:
	ldp	x23, x24, [sp, 48]	//,,
	.cfi_restore 24
	.cfi_restore 23
.L30:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1935:     }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 160	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
.L101:
	.cfi_def_cfa_offset 160
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	.cfi_offset 21, -128
	.cfi_offset 22, -120
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 25, -96
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x21, x22, [sp, 32]	//,,
	.cfi_remember_state
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 48]	//,,
	.cfi_restore 24
	.cfi_restore 23
	ldr	x25, [sp, 64]	//,
	.cfi_restore 25
	ldp	x29, x30, [sp], 160	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
.L102:
	.cfi_restore_state
	ldp	x21, x22, [sp, 32]	//,,
	.cfi_restore 22
	.cfi_restore 21
	ldr	x25, [sp, 64]	//,
	.cfi_restore 25
.L73:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x1, -6148914691236517206	// tmp221,
	asr	x0, x0, 3	// tmp219, _14,
	movk	x1, 0xaaab, lsl 0	// tmp221,,
	add	x7, sp, 88	// tmp538,,
	add	x6, sp, 112	// tmp539,,
	mul	x0, x0, x1	// tmp220, tmp219, tmp221
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	sub	x1, x0, #2	// tmp222, tmp220,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	sub	x8, x0, #1	// tmp223, tmp220,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	asr	x10, x1, 1	// __parent, tmp222,
	and	x9, x1, -2	// tmp228, tmp222,
	add	x9, x9, x10	// tmp229, tmp228, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	mvn	x0, x0	// tmp224, tmp220
	add	x9, x20, x9, lsl 3	// ivtmp.1611, __first, tmp229,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	mov	x5, x10	// __parent, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	asr	x8, x8, 1	// _356, tmp223,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	and	w4, w0, 1	// _419, tmp224,
.L46:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x12, x13, [x9]	// MEM[(struct PitchRegion &)_41], MEM[(struct PitchRegion &)_41]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x5, x8	// __parent, _356
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	mov	x3, x9	// _426, ivtmp.1611
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldr	x0, [x9, 16]	// MEM[(struct PitchRegion &)_41], MEM[(struct PitchRegion &)_41]
	stp	x12, x13, [x7]	// MEM[(struct PitchRegion &)_41], MEM[(struct PitchRegion *)_203]
	stp	x12, x13, [x6]	// MEM[(struct PitchRegion &)_41], MEM[(struct PitchRegion *)_418]
	str	x0, [x6, 16]	// MEM[(struct PitchRegion &)_41], MEM[(struct PitchRegion *)_418]
	str	x0, [x7, 16]	// MEM[(struct PitchRegion &)_41], MEM[(struct PitchRegion *)_203]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L77		//,
	mov	x2, x5	// __holeIndex, __parent
	.p2align 3,,7
.L37:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	add	x0, x2, 1	// tmp239, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x3, x2, x2, lsl 1	// tmp252, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x11, x0, 1	// __secondChild, tmp239,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	sub	x12, x11, #1	// _425, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x11, x0, lsl 2	// tmp242, __secondChild, tmp239,
	add	x1, x12, x12, lsl 1	// tmp246, _425, _425,
	lsl	x0, x0, 3	// tmp243, tmp242,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x13, x20, x3, lsl 3	// tmp254, __first, tmp252,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	lsl	x1, x1, 3	// tmp247, tmp246,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	ldrh	w2, [x20, x0]	// MEM[(const struct PitchRegion &)_426].bin, MEM[(const struct PitchRegion &)_426].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x3, x20, x0	// _426, __first, tmp243
	add	x14, x20, x1	// _422, __first, tmp247
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	ldrh	w0, [x20, x1]	// MEM[(const struct PitchRegion &)_422].bin, MEM[(const struct PitchRegion &)_422].bin
	cmp	w0, w2	// MEM[(const struct PitchRegion &)_422].bin, MEM[(const struct PitchRegion &)_426].bin
	bls	.L35		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x0, x1, [x14]	// *_422, *_422
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x8, x12	// _356, _425
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:234: 	    __secondChild--;
	mov	x2, x12	// __holeIndex, _425
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	stp	x0, x1, [x13]	// *_422, *_157
	ldr	x0, [x14, 16]	// *_422, *_422
	str	x0, [x13, 16]	// *_422, *_157
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bgt	.L37		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	mov	x3, x14	// _426, _422
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:234: 	    __secondChild--;
	mov	x11, x12	// __secondChild, _425
.L34:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	w4, 0	// _419,
	ccmp	x10, x11, 0, ne	// __parent, __secondChild,,
	beq	.L38		//,
.L108:
	ldp	x0, x1, [x6]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x12, x11, #1	// _457, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x5, x11	// __parent, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	asr	x12, x12, 1	// __parent, _457,
	ldr	x2, [x6, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
	ldrh	w14, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_418].bin
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	blt	.L42		//,
	b	.L40		//
	.p2align 2,,3
.L106:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x2, x3, [x0]	// *_86, *_86
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x5, x12	// __parent, __parent
	mov	x12, x1	// __parent, tmp299
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	stp	x2, x3, [x13]	// *_86, *_519
	ldr	x1, [x0, 16]	// *_86, *_86
	str	x1, [x13, 16]	// *_86, *_519
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	bge	.L105		//,
.L42:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x12, x12, lsl 1	// tmp286, __parent, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	sub	x1, x12, #1	// _92, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x13, x11, x11, lsl 1	// tmp290, __secondChild, __secondChild,
	mov	x11, x12	// __secondChild, __parent
	lsl	x0, x0, 3	// tmp287, tmp286,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	add	x1, x1, x1, lsr 63	// tmp298, _92, _92,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	ldrh	w2, [x20, x0]	// MEM[(const struct PitchRegion &)_86].bin, MEM[(const struct PitchRegion &)_86].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x13, x20, x13, lsl 3	// prephitmp_471, __first, tmp290,
	add	x0, x20, x0	// _86, __first, tmp287
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	asr	x1, x1, 1	// tmp299, tmp298,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	w2, w14	// MEM[(const struct PitchRegion &)_86].bin, __value$bin
	bcc	.L106		//,
.L41:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	ldr	x2, [x23, 16]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	strh	w14, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_273].bin
	ldp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	str	x2, [x13, 16]	// MEM[(struct PitchRegion *)_273], *prephitmp_471
	stp	x0, x1, [x13]	// MEM[(struct PitchRegion *)_273], *prephitmp_471
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:358: 	  if (__parent == 0)
	cbz	x5, .L107	// __parent,
.L43:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:360: 	  __parent--;
	sub	x5, x5, #1	// __parent, __parent,
	sub	x9, x9, #24	// ivtmp.1611, ivtmp.1611,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:353:       while (true)
	b	.L46		//
	.p2align 2,,3
.L35:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x0, x1, [x3]	// *_426, *_426
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x8, x11	// _356, __secondChild
	mov	x2, x11	// __holeIndex, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	stp	x0, x1, [x13]	// *_426, *_412
	ldr	x0, [x3, 16]	// *_426, *_426
	str	x0, [x13, 16]	// *_426, *_412
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bgt	.L37		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	w4, 0	// _419,
	ccmp	x10, x11, 0, ne	// __parent, __secondChild,,
	bne	.L108		//,
.L38:
	lsl	x12, x11, 1	// _457, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x11, x12, 1	// __secondChild, _457,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	asr	x12, x12, 1	// __parent, _457,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x2, x11, x11, lsl 1	// tmp274, __secondChild, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x5, x11	// __parent, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x2, x20, x2, lsl 3	// _74, __first, tmp274,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	ldp	x0, x1, [x2]	// *_74, *_74
	stp	x0, x1, [x3]	// *_74, *prephitmp_444
	ldr	x0, [x2, 16]	// *_74, *_74
	ldrh	w14, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_418].bin
	str	x0, [x3, 16]	// *_74, *prephitmp_444
	mov	x3, x2	// _426, _74
	ldp	x0, x1, [x6]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
	ldr	x2, [x6, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	blt	.L42		//,
.L40:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	strh	w14, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_273].bin
	ldp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	str	x2, [x3, 16]	// MEM[(struct PitchRegion *)_418], *prephitmp_461
	stp	x0, x1, [x3]	// MEM[(struct PitchRegion *)_273], *prephitmp_461
	b	.L43		//
.L105:
	mov	x13, x0	// prephitmp_471, _86
	b	.L41		//
	.p2align 2,,3
.L48:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x2, x3, [x0]	// *_454, *_454
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x14, x10	// _403, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	stp	x2, x3, [x5]	// *_454, *_440
	ldr	x2, [x0, 16]	// *_454, *_454
	str	x2, [x5, 16]	// *_454, *_440
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	ble	.L50		//,
.L49:
	mov	x0, x10	// __holeIndex, __secondChild
	b	.L51		//
.L103:
	mov	x0, x1	// prephitmp_485, _206
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	ldr	x1, [x23, 16]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	cmp	x9, 24	// _161,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	strh	w12, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_273].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	sub	x19, x19, #24	// ivtmp.1601, ivtmp.1601,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	ldp	x2, x3, [x23]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	str	x1, [x0, 16]	// MEM[(struct PitchRegion *)_273], *prephitmp_511
	stp	x2, x3, [x0]	// MEM[(struct PitchRegion *)_273], *prephitmp_511
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	bgt	.L44		//,
	b	.L109		//
.L54:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	lsl	x1, x10, 1	// tmp366, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	mov	x11, x10	// prephitmp_478, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x1, x1, 1	// _191, tmp366,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x2, x1, x1, lsl 1	// tmp369, _191, _191,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:243: 	  __holeIndex = __secondChild - 1;
	mov	x10, x1	// __secondChild, _191
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x1, x20, x2, lsl 3	// tmp371, __first, tmp369,
	ldp	x2, x3, [x1]	// *_194, *_194
	stp	x2, x3, [x0]	// *_194, *prephitmp_485
	ldr	x1, [x1, 16]	// *_194, *_194
	ldrh	w12, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_418].bin
	str	x1, [x0, 16]	// *_194, *prephitmp_485
	ldp	x0, x1, [x6]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
	ldr	x2, [x6, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_418]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_418], MEM[(struct PitchRegion *)_273]
	b	.L57		//
.L47:
	ldrh	w12, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_418].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cbnz	x15, .L94	// _516,
	mov	x0, x20	// prephitmp_485, __first
	mov	x10, 0	// __secondChild,
	b	.L52		//
.L94:
	stp	x2, x3, [x23]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_273]
	mov	x0, x20	// prephitmp_485, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	cmp	x9, 24	// _161,
	sub	x19, x19, #24	// ivtmp.1601, ivtmp.1601,
	str	x1, [x23, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_273]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	ldr	x1, [x23, 16]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	strh	w12, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_273].bin
	ldp	x2, x3, [x23]	// MEM[(struct PitchRegion *)_273], MEM[(struct PitchRegion *)_273]
	str	x1, [x0, 16]	// MEM[(struct PitchRegion *)_273], *prephitmp_511
	stp	x2, x3, [x0]	// MEM[(struct PitchRegion *)_273], *prephitmp_511
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	bgt	.L44		//,
	b	.L109		//
	.p2align 2,,3
.L77:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	mov	x11, x5	// __secondChild, __parent
	b	.L34		//
.L99:
	mov	x19, x1	// __last, tmp543
	add	x23, sp, 136	// tmp537,,
	b	.L73		//
	.cfi_endproc
.LFE11301:
	.size	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_, .-_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_
	.align	2
	.p2align 4,,15
	.type	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E_EEEvSI_SI_SL_T1_, %function
_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E_EEEvSI_SI_SL_T1_:
.LFB11299:
	.cfi_startproc
	stp	x29, x30, [sp, -160]!	//,,,
	.cfi_def_cfa_offset 160
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	mov	x19, x0	// __first, tmp630
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	sub	x0, x1, x0	// _14, __last, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	cmp	x0, 384	// _14,
	ble	.L110		//,
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 22, -120
	.cfi_offset 21, -128
	stp	x23, x24, [sp, 48]	//,,
	.cfi_offset 24, -104
	.cfi_offset 23, -112
	mov	x24, x2	// __depth_limit, tmp632
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	cbz	x2, .L211	// __depth_limit,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x23, -6148914691236517206	// tmp426,
	mov	x5, x1	// __last, __last
	mov	w22, w3	// __comp, tmp633
	add	x20, sp, 136	// tmp623,,
	str	x25, [sp, 64]	//,
	.cfi_offset 25, -96
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	movk	x23, 0xaaab, lsl 0	// tmp426,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x25, x19, 24	// tmp625, __first,
.L113:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	asr	x0, x0, 3	// tmp424, _14,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s2, [x25, 20]	// _294, MEM[(const struct PitchRegion &)__first_15 + 24].magnitude
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1929: 	  --__depth_limit;
	sub	x24, x24, #1	// __depth_limit, __depth_limit,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mul	x0, x0, x23	// tmp425, tmp424, tmp426
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	and	x1, x0, -2	// tmp429, tmp425,
	add	x0, x1, x0, asr 1	// tmp430, tmp429, tmp425,
	lsl	x2, x0, 3	// tmp431, tmp430,
	add	x3, x19, x2	// _260, __first, tmp431
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x3, 20]	// _295, MEM[(const struct PitchRegion &)_260].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s2, s1	// _294, _295
	bne	.L142		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w1, [x25]	// MEM[(const struct PitchRegion &)__first_15 + 24].bin, MEM[(const struct PitchRegion &)__first_15 + 24].bin
	ldrh	w0, [x19, x2]	// MEM[(const struct PitchRegion &)_260].bin, MEM[(const struct PitchRegion &)_260].bin
	cmp	w1, w0	// MEM[(const struct PitchRegion &)__first_15 + 24].bin, MEM[(const struct PitchRegion &)_260].bin
	cset	w1, cc	// iftmp.111_167,
.L143:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x5, -4]	// pretmp_555, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].magnitude
	sub	x0, x5, #24	// tmp624, __last,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:88:       if (__comp(__a, __b))
	cbz	w1, .L212	// iftmp.111_167,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _295, pretmp_555
	bne	.L144		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w1, [x0]	// MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	ldrh	w2, [x19, x2]	// MEM[(const struct PitchRegion &)_260].bin, MEM[(const struct PitchRegion &)_260].bin
	cmp	w2, w1	// MEM[(const struct PitchRegion &)_260].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	cset	w1, cc	// iftmp.111_105,
.L145:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:90: 	  if (__comp(__b, __c))
	cbnz	w1, .L207	// iftmp.111_105,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s2, s0	// _294, pretmp_555
	bne	.L147		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:92: 	  else if (__comp(__a, __c))
	ldrh	w2, [x25]	// MEM[(const struct PitchRegion &)__first_15 + 24].bin, MEM[(const struct PitchRegion &)__first_15 + 24].bin
	ldrh	w1, [x0]	// MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	cmp	w2, w1	// MEM[(const struct PitchRegion &)__first_15 + 24].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	bcc	.L182		//,
.L149:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x25]	// MEM[(struct PitchRegion &)__first_15 + 24], MEM[(struct PitchRegion &)__first_15 + 24]
	mov	x4, x5	// __last$_M_current, __last
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x2, x3, [x19]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__first_15 + 24], *__first_15
	ldr	x1, [x25, 16]	// MEM[(struct PitchRegion &)__first_15 + 24], MEM[(struct PitchRegion &)__first_15 + 24]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x2, x3, [x20]	// *__first_15, MEM[(struct PitchRegion *)_424]
	ldr	x0, [x19, 16]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x19, 16]	// MEM[(struct PitchRegion &)__first_15 + 24], *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x2, x3, [x25]	// *__first_15, MEM[(struct PitchRegion *)__first_15 + 24B]
	mov	x3, x25	// _290, tmp625
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x20, 16]	// *__first_15, MEM[(struct PitchRegion *)_424]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	x0, [x25, 16]	// *__first_15, MEM[(struct PitchRegion *)__first_15 + 24B]
	.p2align 3,,7
.L151:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x19, 20]	// _269, MEM[(const struct PitchRegion &)__first_15].magnitude
	.p2align 3,,7
.L173:
	mov	x21, x3	// __last, ivtmp.1690
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x3, 20]	// _268, MEM[(float *)__first$_M_current_265 + 20B]
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _268, _269
	bne	.L156		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1877: 	  while (__comp(__first, __pivot))
	ldrh	w1, [x3]	// MEM[(short unsigned int *)__first$_M_current_265], MEM[(short unsigned int *)__first$_M_current_265]
	add	x3, x3, 24	// ivtmp.1690, ivtmp.1690,
	ldrh	w0, [x19]	// MEM[(const struct PitchRegion &)__first_15].bin, MEM[(const struct PitchRegion &)__first_15].bin
	cmp	w1, w0	// MEM[(short unsigned int *)__first$_M_current_265], MEM[(const struct PitchRegion &)__first_15].bin
	bcc	.L173		//,
.L158:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1125: 	--_M_current;
	sub	x3, x4, #24	// ivtmp.1674, __last$_M_current,
	.p2align 3,,7
.L172:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x3, 20]	// _279, MEM[(float *)__last$_M_current_277 + 20B]
	mov	x4, x3	// __last$_M_current, ivtmp.1674
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s0, s1	// _269, _279
	bne	.L159		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1880: 	  while (__comp(__pivot, __last))
	ldrh	w1, [x19]	// MEM[(const struct PitchRegion &)__first_15].bin, MEM[(const struct PitchRegion &)__first_15].bin
	sub	x3, x3, #24	// ivtmp.1674, ivtmp.1674,
	ldrh	w0, [x4]	// MEM[(short unsigned int *)__last$_M_current_277], MEM[(short unsigned int *)__last$_M_current_277]
	cmp	w1, w0	// MEM[(const struct PitchRegion &)__first_15].bin, MEM[(short unsigned int *)__last$_M_current_277]
	bcc	.L172		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1882: 	  if (!(__first < __last))
	cmp	x21, x4	// __last, __last$_M_current
	bcs	.L213		//,
.L162:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x4]	// *__last$_M_current_277, *__last$_M_current_277
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1111: 	++_M_current;
	add	x3, x21, 24	// _290, __last,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x6, x7, [x21]	// *__first$_M_current_265, *__first$_M_current_265
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x21]	// *__last$_M_current_277, *__first$_M_current_265
	ldr	x1, [x4, 16]	// *__last$_M_current_277, *__last$_M_current_277
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x6, x7, [x20]	// *__first$_M_current_265, MEM[(struct PitchRegion *)_424]
	ldr	x0, [x21, 16]	// *__first$_M_current_265, *__first$_M_current_265
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x21, 16]	// *__last$_M_current_277, *__first$_M_current_265
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x6, x7, [x4]	// *__first$_M_current_265, *__last$_M_current_277
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x20, 16]	// *__first$_M_current_265, MEM[(struct PitchRegion *)_424]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	x0, [x4, 16]	// *__first$_M_current_265, *__last$_M_current_277
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1112: 	return *this;
	b	.L151		//
.L212:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s2, s0	// _294, pretmp_555
	bne	.L152		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w1, [x0]	// MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	ldrh	w4, [x25]	// MEM[(const struct PitchRegion &)__first_15 + 24].bin, MEM[(const struct PitchRegion &)__first_15 + 24].bin
	cmp	w4, w1	// MEM[(const struct PitchRegion &)__first_15 + 24].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	cset	w1, cc	// iftmp.111_320,
.L153:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:97:       else if (__comp(__a, __c))
	cbnz	w1, .L149	// iftmp.111_320,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _295, pretmp_555
	bne	.L154		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w1, [x0]	// MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	ldrh	w2, [x19, x2]	// MEM[(const struct PitchRegion &)_260].bin, MEM[(const struct PitchRegion &)_260].bin
	cmp	w2, w1	// MEM[(const struct PitchRegion &)_260].bin, MEM[(const struct PitchRegion &)__last_434 + 18446744073709551592].bin
	cset	w1, cc	// iftmp.111_326,
.L155:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:99:       else if (__comp(__b, __c))
	cbz	w1, .L207	// iftmp.111_326,
.L182:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x2, x3, [x0]	// MEM[(struct PitchRegion &)__last_434 + 18446744073709551592], MEM[(struct PitchRegion &)__last_434 + 18446744073709551592]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x6, x7, [x19]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x2, x3, [x19]	// MEM[(struct PitchRegion &)__last_434 + 18446744073709551592], *__first_15
	ldr	x2, [x0, 16]	// MEM[(struct PitchRegion &)__last_434 + 18446744073709551592], MEM[(struct PitchRegion &)__last_434 + 18446744073709551592]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x6, x7, [x20]	// *__first_15, MEM[(struct PitchRegion *)_424]
	ldr	x1, [x19, 16]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x2, [x19, 16]	// MEM[(struct PitchRegion &)__last_434 + 18446744073709551592], *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x6, x7, [x0]	// *__first_15, MEM[(struct PitchRegion *)__last_434 + -24B]
	str	x1, [x0, 16]	// *__first_15, MEM[(struct PitchRegion *)__last_434 + -24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x1, [x20, 16]	// *__first_15, MEM[(struct PitchRegion *)_424]
	b	.L146		//
.L142:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s2, s1	// _294, _295
	cset	w1, gt	// iftmp.111_167,
	b	.L143		//
.L207:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x0, x1, [x3]	// *_260, *_260
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldp	x6, x7, [x19]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x0, x1, [x19]	// *_260, *__first_15
	ldr	x1, [x3, 16]	// *_260, *_260
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	stp	x6, x7, [x20]	// *__first_15, MEM[(struct PitchRegion *)_424]
	ldr	x0, [x19, 16]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	str	x1, [x19, 16]	// *_260, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	stp	x6, x7, [x3]	// *__first_15, *_260
	str	x0, [x3, 16]	// *__first_15, *_260
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	str	x0, [x20, 16]	// *__first_15, MEM[(struct PitchRegion *)_424]
.L146:
	mov	x4, x5	// __last$_M_current, __last
	mov	x3, x25	// _290, tmp625
	b	.L151		//
	.p2align 2,,3
.L159:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1880: 	  while (__comp(__pivot, __last))
	fcmpe	s0, s1	// _269, _279
	sub	x3, x3, #24	// ivtmp.1674, ivtmp.1674,
	bgt	.L172		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1882: 	  if (!(__first < __last))
	cmp	x21, x4	// __last, __last$_M_current
	bcc	.L162		//,
.L213:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1932: 	  std::__introsort_loop(__cut, __last, __depth_limit, __comp);
	mov	x0, x21	//, __last
	mov	x1, x5	//, __last
	mov	w3, w22	//, __comp
	mov	x2, x24	//, __depth_limit
	bl	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E_EEEvSI_SI_SL_T1_		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	sub	x0, x21, x19	// _14, __last, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	cmp	x0, 384	// _14,
	ble	.L214		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	cbz	x24, .L215	// __depth_limit,
	mov	x5, x21	// __last, __last
	b	.L113		//
	.p2align 2,,3
.L156:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1877: 	  while (__comp(__first, __pivot))
	fcmpe	s1, s0	// _268, _269
	add	x3, x3, 24	// ivtmp.1690, ivtmp.1690,
	bgt	.L173		//,
	b	.L158		//
.L222:
	.cfi_restore 25
	mov	x1, x11	// prephitmp_44, _236
.L137:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	strh	w12, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_424].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	cmp	x9, 24	// _186,
	sub	x3, x3, #24	// ivtmp.1658, ivtmp.1658,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	str	s1, [sp, 156]	// __value$magnitude, MEM[(struct PitchRegion *)_424].magnitude
	ldp	x4, x5, [x20]	// MEM[(struct PitchRegion *)_424], MEM[(struct PitchRegion *)_424]
	ldr	x0, [x20, 16]	// MEM[(struct PitchRegion *)_424], MEM[(struct PitchRegion *)_424]
	stp	x4, x5, [x1]	// MEM[(struct PitchRegion *)_424], *prephitmp_545
	str	x0, [x1, 16]	// MEM[(struct PitchRegion *)_424], *prephitmp_545
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	bgt	.L125		//,
	ldp	x21, x22, [sp, 32]	//,,
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 48]	//,,
	.cfi_restore 24
	.cfi_restore 23
.L110:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1935:     }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 160	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
.L152:
	.cfi_def_cfa_offset 160
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	.cfi_offset 21, -128
	.cfi_offset 22, -120
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 25, -96
	.cfi_offset 29, -160
	.cfi_offset 30, -152
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s2, s0	// _294, pretmp_555
	cset	w1, gt	// iftmp.111_320,
	b	.L153		//
.L144:
	fcmpe	s1, s0	// _295, pretmp_555
	cset	w1, gt	// iftmp.111_105,
	b	.L145		//
.L154:
	fcmpe	s1, s0	// _295, pretmp_555
	cset	w1, gt	// iftmp.111_326,
	b	.L155		//
.L147:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:92: 	  else if (__comp(__a, __c))
	fcmpe	s2, s0	// _294, pretmp_555
	bgt	.L182		//,
	b	.L149		//
.L214:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1935:     }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x21, x22, [sp, 32]	//,,
	.cfi_remember_state
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 48]	//,,
	.cfi_restore 24
	.cfi_restore 23
	ldr	x25, [sp, 64]	//,
	.cfi_restore 25
	ldp	x29, x30, [sp], 160	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
.L215:
	.cfi_restore_state
	ldr	x25, [sp, 64]	//,
	.cfi_restore 25
.L164:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x1, -6148914691236517206	// tmp245,
	asr	x0, x0, 3	// tmp243, _14,
	movk	x1, 0xaaab, lsl 0	// tmp245,,
	add	x7, sp, 88	// tmp626,,
	add	x6, sp, 112	// tmp627,,
	mul	x0, x0, x1	// tmp244, tmp243, tmp245
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	sub	x1, x0, #2	// tmp246, tmp244,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	sub	x8, x0, #1	// tmp247, tmp244,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	asr	x12, x1, 1	// __parent, tmp246,
	and	x11, x1, -2	// tmp252, tmp246,
	add	x11, x11, x12	// tmp253, tmp252, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	mvn	x0, x0	// tmp248, tmp244
	add	x11, x19, x11, lsl 3	// ivtmp.1667, __first, tmp253,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	mov	x9, x12	// __parent, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	asr	x8, x8, 1	// _427, tmp247,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	and	w10, w0, 1	// _263, tmp248,
.L127:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x2, x3, [x11]	// MEM[(struct PitchRegion &)_46], MEM[(struct PitchRegion &)_46]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x9, x8	// __parent, _427
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	mov	x13, x11	// _58, ivtmp.1667
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldr	x0, [x11, 16]	// MEM[(struct PitchRegion &)_46], MEM[(struct PitchRegion &)_46]
	stp	x2, x3, [x7]	// MEM[(struct PitchRegion &)_46], MEM[(struct PitchRegion *)_392]
	stp	x2, x3, [x6]	// MEM[(struct PitchRegion &)_46], MEM[(struct PitchRegion *)_189]
	str	x0, [x6, 16]	// MEM[(struct PitchRegion &)_46], MEM[(struct PitchRegion *)_189]
	str	x0, [x7, 16]	// MEM[(struct PitchRegion &)_46], MEM[(struct PitchRegion *)_392]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L187		//,
	mov	x1, x9	// __holeIndex, __parent
	.p2align 3,,7
.L117:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	add	x3, x1, 1	// tmp263, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x0, x3, 1	// __secondChild, tmp263,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	sub	x2, x0, #1	// __holeIndex, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x3, x0, x3, lsl 2	// tmp266, __secondChild, tmp263,
	add	x4, x2, x2, lsl 1	// tmp270, __holeIndex, __holeIndex,
	lsl	x3, x3, 3	// tmp267, tmp266,
	lsl	x4, x4, 3	// tmp271, tmp270,
	add	x14, x19, x3	// _54, __first, tmp267
	add	x13, x19, x4	// _58, __first, tmp271
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x14, 20]	// _59, MEM[(const struct PitchRegion &)_54].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x13, 20]	// _60, MEM[(const struct PitchRegion &)_58].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _59, _60
	bne	.L115		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w5, [x19, x3]	// MEM[(const struct PitchRegion &)_54].bin, MEM[(const struct PitchRegion &)_54].bin
	ldrh	w3, [x19, x4]	// MEM[(const struct PitchRegion &)_58].bin, MEM[(const struct PitchRegion &)_58].bin
	cmp	w5, w3	// MEM[(const struct PitchRegion &)_54].bin, MEM[(const struct PitchRegion &)_58].bin
	cset	w4, cc	// iftmp.111_63,
.L116:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x3, x1, x1, lsl 1	// tmp280, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x2, x8	// __holeIndex, _427
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	cbz	w4, .L216	// iftmp.111_63,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x4, x5, [x13]	// *_58, *_58
	add	x1, x19, x3, lsl 3	// tmp282, __first, tmp280,
	stp	x4, x5, [x1]	// *_58, *_72
	ldr	x0, [x13, 16]	// *_58, *_58
	str	x0, [x1, 16]	// *_58, *_72
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L114		//,
.L171:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	mov	x1, x2	// __holeIndex, __holeIndex
	b	.L117		//
.L187:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	mov	x2, x9	// __holeIndex, __parent
.L114:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	w10, 0	// _263,
	ccmp	x12, x2, 0, ne	// __parent, __holeIndex,,
	beq	.L118		//,
.L219:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x4, x2, #1	// _485, __holeIndex,
.L119:
	ldp	x0, x1, [x6]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_189]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x9, x2	// __parent, __holeIndex
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	asr	x4, x4, 1	// __parent, _485,
	ldr	x3, [x6, 16]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_189]
	stp	x0, x1, [x20]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_424]
	ldr	s1, [sp, 132]	// __value$magnitude, MEM[(struct PitchRegion *)_189].magnitude
	str	x3, [x20, 16]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_424]
	ldrh	w15, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_189].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	blt	.L123		//,
	b	.L120		//
	.p2align 2,,3
.L218:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w0, [x19, x0]	// MEM[(const struct PitchRegion &)_96].bin, MEM[(const struct PitchRegion &)_96].bin
	cmp	w0, w15	// MEM[(const struct PitchRegion &)_96].bin, __value$bin
	cset	w13, cc	// iftmp.111_102,
.L122:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x1, x2, x2, lsl 1	// tmp603, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	sub	x0, x4, #1	// _107, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x9, x4	// __parent, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	add	x3, x0, x0, lsr 63	// tmp317, _107, _107,
	mov	x2, x4	// __holeIndex, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x5, x19, x1, lsl 3	// prephitmp_500, __first, tmp603,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	w13, .L170	// iftmp.111_102,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x0, x1, [x14]	// *_96, *_96
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	asr	x4, x3, 1	// tmp318, tmp317,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	stp	x0, x1, [x5]	// *_96, *_554
	ldr	x0, [x14, 16]	// *_96, *_96
	str	x0, [x5, 16]	// *_96, *_554
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	bge	.L217		//,
.L123:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x4, x4, lsl 1	// tmp305, __parent, __parent,
	lsl	x0, x0, 3	// tmp306, tmp305,
	add	x14, x19, x0	// _96, __first, tmp306
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x14, 20]	// _97, MEM[(const struct PitchRegion &)_96].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s0, s1	// _97, __value$magnitude
	beq	.L218		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s0, s1	// _97, __value$magnitude
	cset	w13, gt	// iftmp.111_102,
	b	.L122		//
.L216:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x4, x5, [x14]	// *_54, *_54
	add	x1, x1, x1, lsl 1	// tmp608, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x0, x8	// __secondChild, _427
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	mov	x2, x0	// __holeIndex, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x1, x19, x1, lsl 3	// tmp610, __first, tmp608,
	stp	x4, x5, [x1]	// *_54, *_468
	ldr	x3, [x14, 16]	// *_54, *_54
	str	x3, [x1, 16]	// *_54, *_468
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	blt	.L171		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	w10, 0	// _263,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	mov	x13, x14	// _58, _54
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	ccmp	x12, x2, 0, ne	// __parent, __holeIndex,,
	bne	.L219		//,
.L118:
	lsl	x4, x2, 1	// _485, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x2, x4, 1	// __holeIndex, _485,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x3, x2, x2, lsl 1	// tmp293, __holeIndex, __holeIndex,
	add	x3, x19, x3, lsl 3	// _84, __first, tmp293,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	ldp	x0, x1, [x3]	// *_84, *_84
	stp	x0, x1, [x13]	// *_84, *prephitmp_218
	ldr	x0, [x3, 16]	// *_84, *_84
	str	x0, [x13, 16]	// *_84, *prephitmp_218
	mov	x13, x3	// _58, _84
	b	.L119		//
	.p2align 2,,3
.L115:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s1, s0	// _59, _60
	cset	w4, gt	// iftmp.111_63,
	b	.L116		//
.L217:
	mov	x5, x14	// prephitmp_500, _96
.L170:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	strh	w15, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_424].bin
	str	s1, [sp, 156]	// __value$magnitude, MEM[(struct PitchRegion *)_424].magnitude
	ldp	x0, x1, [x20]	// MEM[(struct PitchRegion *)_424], MEM[(struct PitchRegion *)_424]
	ldr	x2, [x20, 16]	// MEM[(struct PitchRegion *)_424], MEM[(struct PitchRegion *)_424]
	stp	x0, x1, [x5]	// MEM[(struct PitchRegion *)_424], *prephitmp_500
	str	x2, [x5, 16]	// MEM[(struct PitchRegion *)_424], *prephitmp_500
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:358: 	  if (__parent == 0)
	cbz	x9, .L220	// __parent,
.L124:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:360: 	  __parent--;
	sub	x9, x9, #1	// __parent, __parent,
	sub	x11, x11, #24	// ivtmp.1667, ivtmp.1667,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:353:       while (true)
	b	.L127		//
.L220:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x8, -6148914691236517206	// tmp334,
	sub	x3, x21, #24	// ivtmp.1658, __last,
	movk	x8, 0xaaab, lsl 0	// tmp334,,
	.p2align 3,,7
.L125:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	sub	x9, x3, x19	// _186, ivtmp.1658, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	ldp	x0, x1, [x19]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	asr	x14, x9, 3	// tmp332, _186,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x9, 48	// _186,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mul	x14, x14, x8	// _187, tmp332, tmp334
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	ldp	x4, x5, [x3]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion &)_23]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	stp	x0, x1, [x3]	// *__first_15, MEM[(struct PitchRegion *)_23]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	sub	x0, x14, #1	// tmp339, _187,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	and	x15, x14, 1	// _551, _187,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	add	x0, x0, x0, lsr 63	// tmp341, tmp339, tmp339,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	ldr	x1, [x19, 16]	// *__first_15, *__first_15
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	asr	x13, x0, 1	// _474, tmp341,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	stp	x4, x5, [x7]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_392]
	ldr	x0, [x3, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion &)_23]
	stp	x4, x5, [x6]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_189]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	str	x1, [x3, 16]	// *__first_15, MEM[(struct PitchRegion *)_23]
	str	x0, [x6, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_189]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	str	x0, [x7, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_392]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	ble	.L128		//,
	mov	x0, 0	// __holeIndex,
	.p2align 3,,7
.L132:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	add	x1, x0, 1	// tmp343, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x11, x1, 1	// __secondChild, tmp343,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	sub	x2, x11, #1	// __holeIndex, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x1, x11, x1, lsl 2	// tmp346, __secondChild, tmp343,
	add	x5, x2, x2, lsl 1	// tmp350, __holeIndex, __holeIndex,
	lsl	x4, x1, 3	// tmp347, tmp346,
	lsl	x5, x5, 3	// tmp351, tmp350,
	add	x12, x19, x4	// _194, __first, tmp347
	add	x1, x19, x5	// prephitmp_44, __first, tmp351
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x12, 20]	// _199, MEM[(const struct PitchRegion &)_194].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x1, 20]	// _200, MEM[(const struct PitchRegion &)_198].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _199, _200
	bne	.L129		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w10, [x19, x4]	// MEM[(const struct PitchRegion &)_194].bin, MEM[(const struct PitchRegion &)_194].bin
	ldrh	w4, [x19, x5]	// MEM[(const struct PitchRegion &)_198].bin, MEM[(const struct PitchRegion &)_198].bin
	cmp	w10, w4	// MEM[(const struct PitchRegion &)_194].bin, MEM[(const struct PitchRegion &)_198].bin
	cset	w4, cc	// iftmp.111_80,
.L130:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x10, x0, x0, lsl 1	// tmp360, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x2, x13	// __holeIndex, _474
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	cbz	w4, .L221	// iftmp.111_80,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x4, x5, [x1]	// *_198, *_198
	add	x0, x19, x10, lsl 3	// tmp362, __first, tmp360,
	stp	x4, x5, [x0]	// *_198, *_212
	ldr	x4, [x1, 16]	// *_198, *_198
	str	x4, [x0, 16]	// *_198, *_212
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L131		//,
.L168:
	mov	x0, x2	// __holeIndex, __holeIndex
	b	.L132		//
.L221:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x4, x5, [x12]	// *_194, *_194
	add	x0, x0, x0, lsl 1	// tmp589, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x11, x13	// __secondChild, _474
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	mov	x2, x11	// __holeIndex, __secondChild
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x0, x19, x0, lsl 3	// tmp591, __first, tmp589,
	stp	x4, x5, [x0]	// *_194, *_512
	ldr	x1, [x12, 16]	// *_194, *_194
	str	x1, [x0, 16]	// *_194, *_512
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	blt	.L168		//,
	mov	x1, x12	// prephitmp_44, _194
.L131:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cbnz	x15, .L210	// _551,
.L133:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	sub	x14, x14, #2	// tmp371, _187,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	add	x14, x14, x14, lsr 63	// tmp374, tmp371, tmp371,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	x2, x14, asr 1	// __holeIndex, tmp374,
	beq	.L135		//,
.L210:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x0, x2, #1	// tmp376, __holeIndex,
	ldp	x4, x5, [x6]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_189]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	add	x0, x0, x0, lsr 63	// tmp378, tmp376, tmp376,
	asr	x10, x0, 1	// __parent, tmp378,
	ldr	x0, [x6, 16]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_189]
	stp	x4, x5, [x20]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_424]
	ldr	s1, [sp, 132]	// __value$magnitude, MEM[(struct PitchRegion *)_189].magnitude
	str	x0, [x20, 16]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_424]
	ldrh	w12, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_189].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbnz	x2, .L140	// __holeIndex,
	b	.L137		//
	.p2align 2,,3
.L223:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w0, [x19, x0]	// MEM[(const struct PitchRegion &)_236].bin, MEM[(const struct PitchRegion &)_236].bin
	cmp	w0, w12	// MEM[(const struct PitchRegion &)_236].bin, __value$bin
	cset	w4, cc	// iftmp.111_242,
.L139:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x1, x2, x2, lsl 1	// tmp580, __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	sub	x0, x10, #1	// _247, __parent,
	mov	x2, x10	// __holeIndex, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	add	x0, x0, x0, lsr 63	// tmp412, _247, _247,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x1, x19, x1, lsl 3	// prephitmp_44, __first, tmp580,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	w4, .L137	// iftmp.111_242,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x4, x5, [x11]	// *_236, *_236
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	asr	x0, x0, 1	// tmp413, tmp412,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	stp	x4, x5, [x1]	// *_236, *_548
	ldr	x4, [x11, 16]	// *_236, *_236
	str	x4, [x1, 16]	// *_236, *_548
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	x10, .L222	// __parent,
	mov	x10, x0	// __parent, tmp413
.L140:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x0, x10, x10, lsl 1	// tmp400, __parent, __parent,
	lsl	x0, x0, 3	// tmp401, tmp400,
	add	x11, x19, x0	// _236, __first, tmp401
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x11, 20]	// _237, MEM[(const struct PitchRegion &)_236].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s0, s1	// _237, __value$magnitude
	beq	.L223		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s0, s1	// _237, __value$magnitude
	cset	w4, gt	// iftmp.111_242,
	b	.L139		//
	.p2align 2,,3
.L129:
	fcmpe	s1, s0	// _199, _200
	cset	w4, gt	// iftmp.111_80,
	b	.L130		//
.L135:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	lsl	x0, x2, 1	// tmp380, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	mov	x10, x2	// __parent, __holeIndex
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x0, x0, 1	// _221, tmp380,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x4, x0, x0, lsl 1	// tmp383, _221, _221,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:243: 	  __holeIndex = __secondChild - 1;
	mov	x2, x0	// __holeIndex, _221
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x0, x19, x4, lsl 3	// tmp385, __first, tmp383,
	ldp	x4, x5, [x0]	// *_224, *_224
	stp	x4, x5, [x1]	// *_224, *prephitmp_518
	ldr	x0, [x0, 16]	// *_224, *_224
	ldrh	w12, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_189].bin
	str	x0, [x1, 16]	// *_224, *prephitmp_518
	ldp	x0, x1, [x6]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_189]
	ldr	x4, [x6, 16]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_189]
	stp	x0, x1, [x20]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_424]
	ldr	s1, [sp, 132]	// __value$magnitude, MEM[(struct PitchRegion *)_189].magnitude
	str	x4, [x20, 16]	// MEM[(struct PitchRegion *)_189], MEM[(struct PitchRegion *)_424]
	b	.L140		//
.L128:
	ldr	s1, [sp, 132]	// __value$magnitude, MEM[(struct PitchRegion *)_189].magnitude
	ldrh	w12, [sp, 112]	// __value$bin, MEM[(struct PitchRegion *)_189].bin
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cbnz	x15, .L202	// _551,
	mov	x1, x19	// prephitmp_44, __first
	mov	x2, 0	// __holeIndex,
	b	.L133		//
.L202:
	mov	x1, x19	// prephitmp_44, __first
	stp	x4, x5, [x20]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_424]
	str	x0, [x20, 16]	// MEM[(struct PitchRegion &)_23], MEM[(struct PitchRegion *)_424]
	b	.L137		//
.L120:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	strh	w15, [sp, 136]	// __value$bin, MEM[(struct PitchRegion *)_424].bin
	str	s1, [sp, 156]	// __value$magnitude, MEM[(struct PitchRegion *)_424].magnitude
	ldp	x0, x1, [x20]	// MEM[(struct PitchRegion *)_424], MEM[(struct PitchRegion *)_424]
	stp	x0, x1, [x13]	// MEM[(struct PitchRegion *)_424], *prephitmp_489
	ldr	x0, [x20, 16]	// MEM[(struct PitchRegion *)_424], MEM[(struct PitchRegion *)_424]
	str	x0, [x13, 16]	// MEM[(struct PitchRegion *)_424], *prephitmp_489
	b	.L124		//
.L211:
	mov	x21, x1	// __last, tmp631
	add	x20, sp, 136	// tmp623,,
	b	.L164		//
	.cfi_endproc
.LFE11299:
	.size	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E_EEEvSI_SI_SL_T1_, .-_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E_EEEvSI_SI_SL_T1_
	.align	2
	.p2align 4,,15
	.type	_ZSt16__introsort_loopIPZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEE10PredictionlN9__gnu_cxx5__ops15_Iter_comp_iterIZNS2_6updateES7_EUlRKT_RKT0_E1_EEEvSD_SD_SG_T1_.isra.0, %function
_ZSt16__introsort_loopIPZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEE10PredictionlN9__gnu_cxx5__ops15_Iter_comp_iterIZNS2_6updateES7_EUlRKT_RKT0_E1_EEEvSD_SD_SG_T1_.isra.0:
.LFB13689:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!	//,,,
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -32
	.cfi_offset 20, -24
	mov	x19, x0	// __first, tmp386
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	sub	x0, x1, x0	// _7, __last, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	cmp	x0, 256	// _7,
	ble	.L224		//,
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 22, -8
	.cfi_offset 21, -16
	mov	x22, x2	// __depth_limit, tmp388
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1897:       std::__move_median_to_first(__first, __first + 1, __mid, __last - 1,
	add	x21, x19, 16	// _408, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	cbz	x2, .L322	// __depth_limit,
.L227:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1896:       _RandomAccessIterator __mid = __first + (__last - __first) / 2;
	asr	x0, x0, 5	// tmp327, _7,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1929: 	  --__depth_limit;
	sub	x22, x22, #1	// __depth_limit, __depth_limit,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1896:       _RandomAccessIterator __mid = __first + (__last - __first) / 2;
	lsl	x4, x0, 4	// tmp328, tmp327,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s2, [x19, 16]	// _268, MEM[(const struct Prediction &)__first_2(D) + 16].frequency
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1896:       _RandomAccessIterator __mid = __first + (__last - __first) / 2;
	add	x2, x19, x4	// __mid, __first, tmp328
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s3, [x19, x4]	// _269, MEM[(const struct Prediction &)__mid_237].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s2, s3	// _268, _269
	bne	.L258		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x0, [x2, 8]	// MEM[(const struct Prediction &)__mid_237].track, MEM[(const struct Prediction &)__mid_237].track
	ldr	x3, [x19, 24]	// MEM[(const struct Prediction &)__first_2(D) + 16].track, MEM[(const struct Prediction &)__first_2(D) + 16].track
	cmp	x3, x0	// MEM[(const struct Prediction &)__first_2(D) + 16].track, MEM[(const struct Prediction &)__mid_237].track
	cset	w0, cc	// iftmp.174_128,
.L259:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x1, -16]	// pretmp_553, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].frequency
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:88:       if (__comp(__a, __b))
	cbz	w0, .L323	// iftmp.174_128,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s3, s0	// _269, pretmp_553
	bne	.L260		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x0, [x1, -8]	// MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	ldr	x3, [x2, 8]	// MEM[(const struct Prediction &)__mid_237].track, MEM[(const struct Prediction &)__mid_237].track
	cmp	x3, x0	// MEM[(const struct Prediction &)__mid_237].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	cset	w0, cc	// iftmp.174_125,
.L261:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldr	s1, [x19]	// pretmp_547, MEM <float> [(struct Prediction &)__first_2(D)]
	ldr	x3, [x19, 8]	// pretmp_548, MEM <size_t> [(struct Prediction &)__first_2(D) + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:90: 	  if (__comp(__b, __c))
	cbnz	w0, .L284	// iftmp.174_125,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s2, s0	// _268, pretmp_553
	bne	.L263		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x0, [x1, -8]	// MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	ldr	x2, [x19, 24]	// MEM[(const struct Prediction &)__first_2(D) + 16].track, MEM[(const struct Prediction &)__first_2(D) + 16].track
	cmp	x2, x0	// MEM[(const struct Prediction &)__first_2(D) + 16].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	cset	w0, cc	// iftmp.174_285,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:92: 	  else if (__comp(__a, __c))
	cbnz	w0, .L296	// iftmp.174_285,
.L286:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x4, x5, [x19, 16]	// MEM[(struct Prediction &)__first_2(D) + 16], MEM[(struct Prediction &)__first_2(D) + 16]
	mov	x20, x21	// __last, _408
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	x3, [x19, 24]	// pretmp_552, MEM <size_t> [(struct Prediction *)__first_2(D) + 24B]
	mov	x3, x1	// __last, __last
	str	s1, [x19, 16]	// pretmp_551, MEM <float> [(struct Prediction *)__first_2(D) + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x4, x5, [x19]	// MEM[(struct Prediction &)__first_2(D) + 16], *__first_2(D)
	.p2align 3,,7
.L262:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x19]	// _244, MEM[(const struct Prediction &)__first_2(D)].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s1, [x20]	// _243, MEM[(float *)__first_241]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s1, s0	// _243, _244
	bne	.L271		//,
	.p2align 3,,7
.L324:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1877: 	  while (__comp(__first, __pivot))
	ldr	x0, [x19, 8]	// MEM[(const struct Prediction &)__first_2(D)].track, MEM[(const struct Prediction &)__first_2(D)].track
	ldr	x4, [x20, 8]	// MEM[(long unsigned int *)__first_241 + 8B], MEM[(long unsigned int *)__first_241 + 8B]
	cmp	x4, x0	// MEM[(long unsigned int *)__first_241 + 8B], MEM[(const struct Prediction &)__first_2(D)].track
	bcs	.L276		//,
.L272:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s1, [x20, 16]	// _243, MEM[(float *)__first_241]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1878: 	    ++__first;
	add	x20, x20, 16	// __last, __last,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s1, s0	// _243, _244
	beq	.L324		//,
.L271:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1877: 	  while (__comp(__first, __pivot))
	fcmpe	s1, s0	// _243, _244
	bmi	.L272		//,
	.p2align 3,,7
.L276:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s2, [x3, -16]	// _254, MEM[(float *)__last_252]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1881: 	    --__last;
	sub	x3, x3, #16	// __last, __last,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s0, s2	// _244, _254
	bne	.L275		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1880: 	  while (__comp(__pivot, __last))
	ldr	x0, [x3, 8]	// MEM[(long unsigned int *)__last_252 + 8B], MEM[(long unsigned int *)__last_252 + 8B]
	ldr	x4, [x19, 8]	// MEM[(const struct Prediction &)__first_2(D)].track, MEM[(const struct Prediction &)__first_2(D)].track
	cmp	x4, x0	// MEM[(const struct Prediction &)__first_2(D)].track, MEM[(long unsigned int *)__last_252 + 8B]
	bcc	.L276		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1882: 	  if (!(__first < __last))
	cmp	x20, x3	// __last, __last
	bcs	.L325		//,
.L278:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x4, x5, [x3]	// *__last_252, *__last_252
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldr	x0, [x20, 8]	// __tmp$track, MEM <size_t> [(struct Prediction &)__first_241 + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	stp	x4, x5, [x20], 16	// *__last_252, *__first_241
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	s1, [x3]	// _243, MEM <float> [(struct Prediction *)__last_252]
	str	x0, [x3, 8]	// __tmp$track, MEM <size_t> [(struct Prediction *)__last_252 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1877: 	  while (__comp(__first, __pivot))
	b	.L262		//
.L258:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmpe	s2, s3	// _268, _269
	cset	w0, mi	// iftmp.174_128,
	b	.L259		//
.L323:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s2, s0	// _268, pretmp_553
	bne	.L266		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x0, [x1, -8]	// MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	ldr	x3, [x19, 24]	// MEM[(const struct Prediction &)__first_2(D) + 16].track, MEM[(const struct Prediction &)__first_2(D) + 16].track
	cmp	x3, x0	// MEM[(const struct Prediction &)__first_2(D) + 16].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	cset	w0, cc	// iftmp.174_127,
.L267:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:197:       _Tp __tmp = _GLIBCXX_MOVE(__a);
	ldr	s1, [x19]	// pretmp_551, MEM <float> [(struct Prediction &)__first_2(D)]
	ldr	x3, [x19, 8]	// pretmp_552, MEM <size_t> [(struct Prediction &)__first_2(D) + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:97:       else if (__comp(__a, __c))
	cbnz	w0, .L286	// iftmp.174_127,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s3, s0	// _269, pretmp_553
	bne	.L268		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x0, [x1, -8]	// MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	ldr	x5, [x2, 8]	// MEM[(const struct Prediction &)__mid_237].track, MEM[(const struct Prediction &)__mid_237].track
	cmp	x5, x0	// MEM[(const struct Prediction &)__mid_237].track, MEM[(const struct Prediction &)__last_158 + 18446744073709551600].track
	cset	w0, cc	// iftmp.174_302,
.L269:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:99:       else if (__comp(__b, __c))
	cbz	w0, .L284	// iftmp.174_302,
.L296:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x4, x5, [x1, -16]	// MEM[(struct Prediction &)__last_158 + 18446744073709551600], MEM[(struct Prediction &)__last_158 + 18446744073709551600]
	stp	x4, x5, [x19]	// MEM[(struct Prediction &)__last_158 + 18446744073709551600], *__first_2(D)
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	s1, [x1, -16]	// pretmp_551, MEM <float> [(struct Prediction *)__last_158 + -16B]
	str	x3, [x1, -8]	// pretmp_552, MEM <size_t> [(struct Prediction *)__last_158 + -8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:187:     }
	b	.L265		//
.L284:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:198:       __a = _GLIBCXX_MOVE(__b);
	ldp	x6, x7, [x2]	// *__mid_237, *__mid_237
	stp	x6, x7, [x19]	// *__mid_237, *__first_2(D)
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/move.h:199:       __b = _GLIBCXX_MOVE(__tmp);
	str	s1, [x19, x4]	// pretmp_547, MEM <float> [(struct Prediction *)__mid_237]
	str	x3, [x2, 8]	// pretmp_548, MEM <size_t> [(struct Prediction *)__mid_237 + 8B]
.L265:
	mov	x3, x1	// __last, __last
	mov	x20, x21	// __last, _408
	b	.L262		//
	.p2align 2,,3
.L275:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1880: 	  while (__comp(__pivot, __last))
	fcmpe	s0, s2	// _244, _254
	bmi	.L276		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1882: 	  if (!(__first < __last))
	cmp	x20, x3	// __last, __last
	bcc	.L278		//,
.L325:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1932: 	  std::__introsort_loop(__cut, __last, __depth_limit, __comp);
	mov	x0, x20	//, __last
	mov	x2, x22	//, __depth_limit
	bl	_ZSt16__introsort_loopIPZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEE10PredictionlN9__gnu_cxx5__ops15_Iter_comp_iterIZNS2_6updateES7_EUlRKT_RKT0_E1_EEEvSD_SD_SG_T1_.isra.0		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	sub	x0, x20, x19	// _7, __last, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1922:       while (__last - __first > int(_S_threshold))
	cmp	x0, 256	// _7,
	ble	.L321		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	cbz	x22, .L280	// __depth_limit,
	mov	x1, x20	// __last, __last
	b	.L227		//
.L331:
	mov	x8, x9	// _174, _215
.L250:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	cmp	x7, 16	// _20,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	str	s2, [x8]	// __value$frequency, prephitmp_537->frequency
	str	x6, [x8, 8]	// __value$track, prephitmp_537->track
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:422:       while (__last - __first > 1)
	bgt	.L242		//,
.L321:
	ldp	x21, x22, [sp, 32]	//,,
	.cfi_restore 22
	.cfi_restore 21
.L224:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1935:     }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 48	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
.L260:
	.cfi_def_cfa_offset 48
	.cfi_offset 19, -32
	.cfi_offset 20, -24
	.cfi_offset 21, -16
	.cfi_offset 22, -8
	.cfi_offset 29, -48
	.cfi_offset 30, -40
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmpe	s3, s0	// _269, pretmp_553
	cset	w0, mi	// iftmp.174_125,
	b	.L261		//
.L266:
	fcmpe	s2, s0	// _268, pretmp_553
	cset	w0, mi	// iftmp.174_127,
	b	.L267		//
.L268:
	fcmpe	s3, s0	// _269, pretmp_553
	cset	w0, mi	// iftmp.174_302,
	b	.L269		//
.L263:
	fcmpe	s2, s0	// _268, pretmp_553
	cset	w0, mi	// iftmp.174_285,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:92: 	  else if (__comp(__a, __c))
	cbnz	w0, .L296	// iftmp.174_285,
	b	.L286		//
.L322:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1924: 	  if (__depth_limit == 0)
	mov	x20, x1	// __last, __last
.L280:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:351:       const _DistanceType __len = __last - __first;
	asr	x0, x0, 4	// tmp243, _7,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	sub	x11, x0, #2	// tmp244, tmp243,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	sub	x8, x0, #1	// tmp245, tmp243,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	asr	x11, x11, 1	// __parent, tmp244,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	asr	x8, x8, 1	// _324, tmp245,
	add	x10, x19, x11, lsl 4	// ivtmp.1736, __first, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	mov	x6, x11	// __parent, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	mvn	x0, x0	// tmp246, tmp243
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x6, x8	// __parent, _324
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	and	w7, w0, 1	// _437, tmp246,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldr	x9, [x10, 8]	// __value$track, MEM <const size_t> [(struct Prediction &)_41 + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	mov	x3, x10	// prephitmp_463, ivtmp.1736
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldr	s2, [x10]	// __value$frequency, MEM <const float> [(struct Prediction &)_41]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L299		//,
.L329:
	mov	x0, x6	// __holeIndex, __parent
	.p2align 3,,7
.L234:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	add	x2, x0, 1	// tmp250, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x5, x19, x0, lsl 4	// tmp256, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	lsl	x1, x2, 5	// _47, tmp250,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x2, x2, 1	// __holeIndex, tmp250,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:233: 		     __first + (__secondChild - 1)))
	sub	x4, x1, #16	// tmp251, _47,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	add	x3, x19, x1	// prephitmp_463, __first, _47
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s1, [x19, x1]	// _51, MEM[(const struct Prediction &)_48].frequency
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	add	x1, x19, x4	// _50, __first, tmp251
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x19, x4]	// _52, MEM[(const struct Prediction &)_50].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s1, s0	// _51, _52
	bne	.L229		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	ldr	x1, [x1, 8]	// MEM[(const struct Prediction &)_50].track, MEM[(const struct Prediction &)_50].track
	ldr	x4, [x3, 8]	// MEM[(const struct Prediction &)_48].track, MEM[(const struct Prediction &)_48].track
	cmp	x4, x1	// MEM[(const struct Prediction &)_48].track, MEM[(const struct Prediction &)_50].track
	bcs	.L231		//,
.L230:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:234: 	    __secondChild--;
	sub	x2, x2, #1	// __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x3, x19, x2, lsl 4	// prephitmp_463, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x2, x8	// __holeIndex, _324
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x0, x1, [x3]	// *_454, *_454
	stp	x0, x1, [x5]	// *_454, *_247
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L228		//,
.L233:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:352:       _DistanceType __parent = (__len - 2) / 2;
	mov	x0, x2	// __holeIndex, __holeIndex
	b	.L234		//
	.p2align 2,,3
.L229:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	fcmpe	s1, s0	// _51, _52
	bmi	.L230		//,
.L231:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x4, x5, [x3]	// *_48, *_48
	add	x0, x19, x0, lsl 4	// tmp259, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x2, x8	// __holeIndex, _324
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	stp	x4, x5, [x0]	// *_48, *_65
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	blt	.L233		//,
.L228:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	w7, 0	// _437,
	ccmp	x11, x2, 0, ne	// __parent, __holeIndex,,
	beq	.L326		//,
.L235:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x0, x2, #1	// tmp270, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x6, x2	// __parent, __holeIndex
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	asr	x0, x0, 1	// __parent, tmp270,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	blt	.L239		//,
	b	.L236		//
	.p2align 2,,3
.L328:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x1, [x12, 8]	// MEM[(const struct Prediction &)_89].track, MEM[(const struct Prediction &)_89].track
	cmp	x9, x1	// __value$track, MEM[(const struct Prediction &)_89].track
	cset	w4, hi	// iftmp.174_95,
.L238:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	sub	x1, x0, #1	// _100, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	add	x3, x19, x2, lsl 4	// prephitmp_492, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x6, x0	// __parent, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	add	x1, x1, x1, lsr 63	// tmp279, _100, _100,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	w4, .L240	// iftmp.174_95,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x4, x5, [x12]	// *_89, *_89
	mov	x2, x0	// __holeIndex, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	asr	x0, x1, 1	// tmp280, tmp279,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	stp	x4, x5, [x3]	// *_89, *_544
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	bge	.L327		//,
.L239:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	lsl	x1, x0, 4	// tmp271, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	add	x12, x19, x1	// _89, __first, tmp271
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x19, x1]	// _90, MEM[(const struct Prediction &)_89].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s2, s0	// __value$frequency, _90
	beq	.L328		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmpe	s2, s0	// __value$frequency, _90
	cset	w4, gt	// iftmp.174_95,
	b	.L238		//
.L327:
	mov	x3, x12	// prephitmp_492, _89
.L240:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	str	s2, [x3]	// __value$frequency, prephitmp_492->frequency
	str	x9, [x3, 8]	// __value$track, prephitmp_492->track
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:358: 	  if (__parent == 0)
	cbz	x6, .L242	// __parent,
.L241:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:360: 	  __parent--;
	sub	x6, x6, #1	// __parent, __parent,
	sub	x10, x10, #16	// ivtmp.1736, ivtmp.1736,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldr	s2, [x10]	// __value$frequency, MEM <const float> [(struct Prediction &)_41]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x6, x8	// __parent, _324
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	mov	x3, x10	// prephitmp_463, ivtmp.1736
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:355: 	  _ValueType __value = _GLIBCXX_MOVE(*(__first + __parent));
	ldr	x9, [x10, 8]	// __value$track, MEM <const size_t> [(struct Prediction &)_41 + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	blt	.L329		//,
.L299:
	mov	x2, x6	// __holeIndex, __parent
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	w7, 0	// _437,
	ccmp	x11, x2, 0, ne	// __parent, __holeIndex,,
	bne	.L235		//,
.L326:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:240: 	  __secondChild = 2 * (__secondChild + 1);
	add	x2, x2, 1	// tmp265, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x0, x19, x2, lsl 5	// tmp267, __first, tmp265,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:240: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x2, x2, 1	// __secondChild, tmp265,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:243: 	  __holeIndex = __secondChild - 1;
	sub	x2, x2, #1	// __holeIndex, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	ldp	x0, x1, [x0, -16]	// *_77, *_77
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cmp	x6, x2	// __parent, __holeIndex
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	stp	x0, x1, [x3]	// *_77, *prephitmp_463
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x0, x2, #1	// tmp270, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	add	x3, x19, x2, lsl 4	// prephitmp_463, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	asr	x0, x0, 1	// __parent, tmp270,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	blt	.L239		//,
.L236:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	str	s2, [x3]	// __value$frequency, prephitmp_481->frequency
	str	x9, [x3, 8]	// __value$track, prephitmp_481->track
	b	.L241		//
	.p2align 2,,3
.L252:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x1, x0, #1	// tmp377, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	add	x1, x1, x1, lsr 63	// tmp379, tmp377, tmp377,
	asr	x1, x1, 1	// __parent, tmp379,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbnz	x0, .L257	// __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:146:       *(__first + __holeIndex) = _GLIBCXX_MOVE(__value);
	str	s2, [x8]	// __value$frequency, prephitmp_516->frequency
	str	x6, [x8, 8]	// __value$track, prephitmp_516->track
	.p2align 3,,7
.L242:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	ldr	s2, [x20, -16]!	// __value$frequency, MEM <const float> [(struct Prediction &)__last_19]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	ldp	x0, x1, [x19]	// *__first_2(D), *__first_2(D)
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:265: 			 _DistanceType(__last - __first),
	sub	x7, x20, x19	// _20, __last, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:262:       _ValueType __value = _GLIBCXX_MOVE(*__result);
	ldr	x6, [x20, 8]	// __value$track, MEM <const size_t> [(struct Prediction &)__last_19 + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:265: 			 _DistanceType(__last - __first),
	asr	x10, x7, 4	// _21, _20,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:263:       *__result = _GLIBCXX_MOVE(*__first);
	stp	x0, x1, [x20]	// *__first_2(D), MEM[(struct Prediction *)__last_19]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x7, 32	// _20,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	sub	x0, x10, #1	// tmp283, _21,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	and	x11, x10, 1	// _541, _21,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	add	x9, x0, x0, lsr 63	// tmp285, tmp283, tmp283,
	asr	x9, x9, 1	// _311, tmp285,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	ble	.L244		//,
	mov	x1, 0	// __holeIndex,
	.p2align 3,,7
.L249:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	add	x0, x1, 1	// tmp287, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	lsl	x2, x0, 5	// _173, tmp287,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:231: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x0, x0, 1	// __holeIndex, tmp287,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:233: 		     __first + (__secondChild - 1)))
	sub	x3, x2, #16	// tmp288, _173,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	add	x8, x19, x2	// _174, __first, _173
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s1, [x19, x2]	// _177, MEM[(const struct Prediction &)_174].frequency
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	add	x2, x19, x3	// _176, __first, tmp288
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x19, x3]	// _178, MEM[(const struct Prediction &)_176].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s1, s0	// _177, _178
	bne	.L245		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x2, [x2, 8]	// MEM[(const struct Prediction &)_176].track, MEM[(const struct Prediction &)_176].track
	ldr	x3, [x8, 8]	// MEM[(const struct Prediction &)_174].track, MEM[(const struct Prediction &)_174].track
	cmp	x3, x2	// MEM[(const struct Prediction &)_174].track, MEM[(const struct Prediction &)_176].track
	cset	w2, cc	// iftmp.174_181,
.L246:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x3, x19, x1, lsl 4	// tmp297, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:232: 	  if (__comp(__first + __secondChild,
	cbz	w2, .L330	// iftmp.174_181,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:234: 	    __secondChild--;
	sub	x0, x0, #1	// __holeIndex, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	add	x8, x19, x0, lsl 4	// _174, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x0, x9	// __holeIndex, _311
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x4, x5, [x8]	// *_502, *_502
	stp	x4, x5, [x3]	// *_502, *_507
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	bge	.L248		//,
.L247:
	mov	x1, x0	// __holeIndex, __holeIndex
	b	.L249		//
.L330:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	ldp	x2, x3, [x8]	// *_174, *_174
	add	x1, x19, x1, lsl 4	// tmp300, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	cmp	x0, x9	// __holeIndex, _311
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:235: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __secondChild));
	stp	x2, x3, [x1]	// *_174, *_191
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:229:       while (__secondChild < (__len - 1) / 2)
	blt	.L247		//,
.L248:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cbnz	x11, .L252	// _541,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	sub	x10, x10, #2	// tmp303, _21,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	x0, x10, asr 1	// __holeIndex, tmp303,
	beq	.L251		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x1, x0, #1	// tmp310, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	add	x1, x1, x1, lsr 63	// tmp312, tmp310, tmp310,
	asr	x1, x1, 1	// __parent, tmp312,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbnz	x0, .L257	// __holeIndex,
	b	.L250		//
	.p2align 2,,3
.L332:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x2, [x9, 8]	// MEM[(const struct Prediction &)_215].track, MEM[(const struct Prediction &)_215].track
	cmp	x2, x6	// MEM[(const struct Prediction &)_215].track, __value$track
	cset	w3, cc	// iftmp.174_131,
.L256:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	add	x8, x19, x0, lsl 4	// _174, __first, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	sub	x2, x1, #1	// _226, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	w3, .L250	// iftmp.174_131,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	ldp	x4, x5, [x9]	// *_215, *_215
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:144: 	  __parent = (__holeIndex - 1) / 2;
	add	x2, x2, x2, lsr 63	// tmp322, _226, _226,
	mov	x0, x1	// __holeIndex, __parent
	asr	x1, x2, 1	// tmp323, tmp322,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:142: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first + __parent));
	stp	x4, x5, [x8]	// *_215, *_540
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	cbz	x0, .L331	// __holeIndex,
.L257:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	lsl	x2, x1, 4	// tmp314, __parent,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:140:       while (__holeIndex > __topIndex && __comp(__first + __parent, __value))
	add	x9, x19, x2	// _215, __first, tmp314
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x19, x2]	// _216, MEM[(const struct Prediction &)_215].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s0, s2	// _216, __value$frequency
	beq	.L332		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmpe	s0, s2	// _216, __value$frequency
	cset	w3, mi	// iftmp.174_131,
	b	.L256		//
	.p2align 2,,3
.L245:
	fcmpe	s1, s0	// _177, _178
	cset	w2, mi	// iftmp.174_181,
	b	.L246		//
.L244:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	mov	x8, x19	// _174, __first
	cbnz	x11, .L250	// _541,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:238:       if ((__len & 1) == 0 && __secondChild == (__len - 2) / 2)
	cmp	x0, 2	// tmp283,
	bhi	.L250		//,
	mov	x0, 0	// __holeIndex,
.L251:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:240: 	  __secondChild = 2 * (__secondChild + 1);
	add	x0, x0, 1	// tmp305, __holeIndex,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	add	x2, x19, x0, lsl 5	// tmp307, __first, tmp305,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:240: 	  __secondChild = 2 * (__secondChild + 1);
	lsl	x0, x0, 1	// __secondChild, tmp305,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	sub	x1, x0, #2	// tmp309, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:243: 	  __holeIndex = __secondChild - 1;
	sub	x0, x0, #1	// __holeIndex, __secondChild,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	ldp	x2, x3, [x2, -16]	// *_203, *_203
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:139:       _Distance __parent = (__holeIndex - 1) / 2;
	asr	x1, x1, 1	// __parent, tmp309,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_heap.h:241: 	  *(__first + __holeIndex) = _GLIBCXX_MOVE(*(__first
	stp	x2, x3, [x8]	// *_203, *prephitmp_326
	b	.L257		//
	.cfi_endproc
.LFE13689:
	.size	_ZSt16__introsort_loopIPZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEE10PredictionlN9__gnu_cxx5__ops15_Iter_comp_iterIZNS2_6updateES7_EUlRKT_RKT0_E1_EEEvSD_SD_SG_T1_.isra.0, .-_ZSt16__introsort_loopIPZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEE10PredictionlN9__gnu_cxx5__ops15_Iter_comp_iterIZNS2_6updateES7_EUlRKT_RKT0_E1_EEEvSD_SD_SG_T1_.isra.0
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog318PitchInterpolationC2Ev
	.type	_ZN5ardor4pog318PitchInterpolationC2Ev, %function
_ZN5ardor4pog318PitchInterpolationC2Ev:
.LFB9528:
	.cfi_startproc
	stp	x29, x30, [sp, -112]!	//,,,
	.cfi_def_cfa_offset 112
	.cfi_offset 29, -112
	.cfi_offset 30, -104
// /probe/scatter-baseline-pitch.cpp:31: PitchInterpolation::PitchInterpolation() {
	mov	w1, 0	//,
// /probe/scatter-baseline-pitch.cpp:31: PitchInterpolation::PitchInterpolation() {
	mov	x29, sp	//,
// /probe/scatter-baseline-pitch.cpp:31: PitchInterpolation::PitchInterpolation() {
	mov	x2, 49248	//,
// /probe/scatter-baseline-pitch.cpp:31: PitchInterpolation::PitchInterpolation() {
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -96
	.cfi_offset 20, -88
	add	x20, x0, 44	// ivtmp.1797, this,
	str	x21, [sp, 32]	//,
	.cfi_offset 21, -80
// /probe/scatter-baseline-pitch.cpp:35:   for (std::size_t p = 0; p <= kPhases; ++p) {
	mov	x21, 0	// p,
// /probe/scatter-baseline-pitch.cpp:31: PitchInterpolation::PitchInterpolation() {
	stp	d8, d9, [sp, 48]	//,,
	stp	d10, d11, [sp, 64]	//,,
	stp	d12, d13, [sp, 80]	//,,
	stp	d14, d15, [sp, 96]	//,,
	.cfi_offset 72, -64
	.cfi_offset 73, -56
	.cfi_offset 74, -48
	.cfi_offset 75, -40
	.cfi_offset 76, -32
	.cfi_offset 77, -24
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:31: PitchInterpolation::PitchInterpolation() {
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:36:     const double fraction = static_cast<double>(p) / kPhases;
	mov	x0, 4566650022153682944	// tmp166,
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	adrp	x1, .LC0	// tmp169,
// /probe/scatter-baseline-pitch.cpp:40:       const double weight = sinc(distance) * sinc(distance / kRadius);
	fmov	d12, 1.2e+1	// tmp159,
// /probe/scatter-baseline-pitch.cpp:36:     const double fraction = static_cast<double>(p) / kPhases;
	fmov	d13, x0	// tmp133, tmp166
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	ldr	d9, [x1, #:lo12:.LC0]	// tmp136,
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	adrp	x1, .LC1	// tmp170,
	ldr	d11, [x1, #:lo12:.LC1]	// tmp158,
	.p2align 3,,7
.L338:
// /probe/scatter-baseline-pitch.cpp:36:     const double fraction = static_cast<double>(p) / kPhases;
	scvtf	d10, x21	// tmp132, p
// /probe/scatter-baseline-pitch.cpp:37:     double sum = 0;
	movi	d15, #0	// sum
// /probe/scatter-baseline-pitch.cpp:36:     const double fraction = static_cast<double>(p) / kPhases;
	mov	x19, -11	// ivtmp.1784,
	fmul	d10, d10, d13	// fraction, tmp132, tmp133
	.p2align 3,,7
.L337:
// /probe/scatter-baseline-pitch.cpp:39:       const double distance = fraction - i;
	scvtf	d8, w19	// tmp134, ivtmp.1784
	fmov	s0, 1.0e+0	// _69,
	fmov	d14, 1.0e+0	// _66,
// /probe/scatter-baseline-pitch.cpp:39:       const double distance = fraction - i;
	fsub	d8, d10, d8	// distance, fraction, tmp134
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fabs	d1, d8	// tmp135, distance
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fcmpe	d1, d9	// tmp135, tmp136
	bmi	.L334		//,
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fmul	d14, d8, d11	// _41, distance, tmp158
	fmov	d0, d14	//, _41
	bl	sin		//
// /probe/scatter-baseline-pitch.cpp:40:       const double weight = sinc(distance) * sinc(distance / kRadius);
	fdiv	d8, d8, d12	// _3, distance, tmp159
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fdiv	d14, d0, d14	// _66, tmp164, _41
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fabs	d0, d8	// tmp139, _3
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fcmpe	d0, d9	// tmp139, tmp136
	bmi	.L345		//,
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fmul	d8, d8, d11	// _45, _3, tmp158
	fmov	d0, d8	//, _45
	bl	sin		//
// /probe/scatter-baseline-pitch.cpp:12: double sinc(double x) noexcept { return std::fabs(x) < 1e-12 ? 1 : std::sin(kPi * x) / (kPi * x); }
	fdiv	d0, d0, d8	// tmp142, tmp165, _45
// /probe/scatter-baseline-pitch.cpp:40:       const double weight = sinc(distance) * sinc(distance / kRadius);
	fmul	d14, d14, d0	// _66, _66, tmp142
.L345:
// /probe/scatter-baseline-pitch.cpp:41:       values_[p][i + kRadius - 1] = static_cast<float>(weight);
	fcvt	s0, d14	// _69, _66
.L334:
// /probe/scatter-baseline-pitch.cpp:41:       values_[p][i + kRadius - 1] = static_cast<float>(weight);
	str	s0, [x20, x19, lsl 2]	// _69, MEM[(value_type &)_56 + ivtmp.1784_27 * 4]
// /probe/scatter-baseline-pitch.cpp:38:     for (int i = 1 - kRadius; i <= kRadius; ++i) {
	add	x19, x19, 1	// ivtmp.1784, ivtmp.1784,
// /probe/scatter-baseline-pitch.cpp:42:       sum += weight;
	fadd	d15, d15, d14	// sum, sum, _66
// /probe/scatter-baseline-pitch.cpp:38:     for (int i = 1 - kRadius; i <= kRadius; ++i) {
	cmp	x19, 13	// ivtmp.1784,
	bne	.L337		//,
// /probe/scatter-baseline-pitch.cpp:44:     for (auto& weight : values_[p]) weight /= static_cast<float>(sum);
	fcvt	s15, d15	// _72, sum
// /probe/scatter-baseline-pitch.cpp:44:     for (auto& weight : values_[p]) weight /= static_cast<float>(sum);
	ldr	q5, [x20, -44]	// vect__8.1775, MEM <vector(4) float> [(float &)_56 + 18446744073709551572]
// /probe/scatter-baseline-pitch.cpp:35:   for (std::size_t p = 0; p <= kPhases; ++p) {
	add	x21, x21, 1	// p, p,
// /probe/scatter-baseline-pitch.cpp:35:   for (std::size_t p = 0; p <= kPhases; ++p) {
	cmp	x21, 513	// p,
	add	x20, x20, 96	// ivtmp.1797, ivtmp.1797,
// /probe/scatter-baseline-pitch.cpp:44:     for (auto& weight : values_[p]) weight /= static_cast<float>(sum);
	ldr	q4, [x20, -124]	// vect__8.1775, MEM <vector(4) float> [(float &)_56 + 18446744073709551588]
	ldr	q3, [x20, -108]	// vect__8.1775, MEM <vector(4) float> [(float &)_56 + 18446744073709551604]
	ldr	q2, [x20, -92]	// vect__8.1775, MEM <vector(4) float> [(float &)_56 + 4]
	dup	v15.4s, v15.s[0]	// tmp143, _72
	ldr	q1, [x20, -76]	// vect__8.1775, MEM <vector(4) float> [(float &)_56 + 20]
	ldr	q0, [x20, -60]	// vect__8.1775, MEM <vector(4) float> [(float &)_56 + 36]
	fdiv	v5.4s, v5.4s, v15.4s	// vect__10.1776, vect__8.1775, tmp143
	fdiv	v4.4s, v4.4s, v15.4s	// vect__10.1776, vect__8.1775, tmp143
	fdiv	v3.4s, v3.4s, v15.4s	// vect__10.1776, vect__8.1775, tmp143
	fdiv	v2.4s, v2.4s, v15.4s	// vect__10.1776, vect__8.1775, tmp143
	fdiv	v1.4s, v1.4s, v15.4s	// vect__10.1776, vect__8.1775, tmp143
	str	q5, [x20, -140]	// vect__10.1776, MEM <vector(4) float> [(float &)_56 + 18446744073709551572]
	str	q4, [x20, -124]	// vect__10.1776, MEM <vector(4) float> [(float &)_56 + 18446744073709551588]
	fdiv	v0.4s, v0.4s, v15.4s	// vect__10.1776, vect__8.1775, tmp143
	str	q3, [x20, -108]	// vect__10.1776, MEM <vector(4) float> [(float &)_56 + 18446744073709551604]
	str	q2, [x20, -92]	// vect__10.1776, MEM <vector(4) float> [(float &)_56 + 4]
	str	q1, [x20, -76]	// vect__10.1776, MEM <vector(4) float> [(float &)_56 + 20]
	str	q0, [x20, -60]	// vect__10.1776, MEM <vector(4) float> [(float &)_56 + 36]
// /probe/scatter-baseline-pitch.cpp:35:   for (std::size_t p = 0; p <= kPhases; ++p) {
	bne	.L338		//,
// /probe/scatter-baseline-pitch.cpp:46: }
	ldp	x19, x20, [sp, 16]	//,,
	ldr	x21, [sp, 32]	//,
	ldp	d8, d9, [sp, 48]	//,,
	ldp	d10, d11, [sp, 64]	//,,
	ldp	d12, d13, [sp, 80]	//,,
	ldp	d14, d15, [sp, 96]	//,,
	ldp	x29, x30, [sp], 112	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 21
	.cfi_restore 19
	.cfi_restore 20
	.cfi_restore 78
	.cfi_restore 79
	.cfi_restore 76
	.cfi_restore 77
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 72
	.cfi_restore 73
	.cfi_def_cfa_offset 0
	ret	
	.cfi_endproc
.LFE9528:
	.size	_ZN5ardor4pog318PitchInterpolationC2Ev, .-_ZN5ardor4pog318PitchInterpolationC2Ev
	.global	_ZN5ardor4pog318PitchInterpolationC1Ev
	.set	_ZN5ardor4pog318PitchInterpolationC1Ev,_ZN5ardor4pog318PitchInterpolationC2Ev
	.align	2
	.p2align 4,,15
	.global	_ZNK5ardor4pog39PitchPlan4lobeEf
	.type	_ZNK5ardor4pog39PitchPlan4lobeEf, %function
_ZNK5ardor4pog39PitchPlan4lobeEf:
.LFB9555:
	.cfi_startproc
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	mov	w1, 2139095039	// tmp138,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabs	s1, s0	// _15, tmp137
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v0.2s, #0	// <retval>
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fmov	s2, w1	// tmp111, tmp138
	fcmp	s1, s2	// _15, tmp111
	bhi	.L346		//,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	movi	v3.2s, 0x44, lsl 24	// tmp112
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	movi	v2.2s, 0x46, lsl 24	// tmp113
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v0.2s, #0	// <retval>
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	fmul	s1, s1, s3	// position, _15, tmp112
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	fcmpe	s1, s2	// position, tmp113
	bge	.L346		//,
// /probe/scatter-baseline-pitch.cpp:67:   const auto i = static_cast<std::size_t>(position);
	fcvtzu	x1, s1	// i, position
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x1, 8192	// i,
	beq	.L355		//,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ucvtf	s2, x1	// tmp124, i
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ubfiz	x2, x1, 4, 9	// tmp122, i,,
	add	x0, x0, 32	// tmp133, this,
	add	x2, x2, x1, lsr 9	// tmp123, tmp122, i,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	add	x1, x1, 1	// iftmp.24_20, i,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	ubfiz	x3, x1, 4, 9	// tmp126, iftmp.24_20,,
	cmp	x1, 8192	// iftmp.24_20,
	add	x3, x3, x1, lsr 9	// tmp135, tmp126, iftmp.24_20,
	csel	x1, x3, x1, ne	// iftmp.24_20, tmp135, iftmp.24_20,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ldr	s0, [x0, x2, lsl 2]	// first, MEM <const struct array> [(const value_type &)this_12(D) + 32]._M_elems[iftmp.24_24]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s1, s1, s2	// _31, position, tmp124
.L350:
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ldr	s2, [x0, x1, lsl 2]	// MEM <const struct array> [(const value_type &)this_12(D) + 32]._M_elems[iftmp.24_20], MEM <const struct array> [(const value_type &)this_12(D) + 32]._M_elems[iftmp.24_20]
	fsub	s2, s2, s0	// tmp130, MEM <const struct array> [(const value_type &)this_12(D) + 32]._M_elems[iftmp.24_20], first
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fmadd	s0, s2, s1, s0	// <retval>, tmp130, _31, first
.L346:
// /probe/scatter-baseline-pitch.cpp:70: }
	ret	
	.p2align 2,,3
.L355:
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x0, x0, 32	// tmp133, this,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s1, s1, s2	// _31, position, tmp113
	mov	x1, 32	// iftmp.24_20,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x2, x0, 32768	// tmp116, tmp133,
	ldr	s0, [x2]	// first, MEM <const struct array> [(const value_type &)this_12(D) + 32]._M_elems[8192]
	b	.L350		//
	.cfi_endproc
.LFE9555:
	.size	_ZNK5ardor4pog39PitchPlan4lobeEf, .-_ZNK5ardor4pog39PitchPlan4lobeEf
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog310PitchFrame5resetEv
	.type	_ZN5ardor4pog310PitchFrame5resetEv, %function
_ZN5ardor4pog310PitchFrame5resetEv:
.LFB9557:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -16
	.cfi_offset 20, -8
// /probe/scatter-baseline-pitch.cpp:85: void PitchFrame::reset() noexcept {
	mov	x19, x0	// this, tmp142
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldr	x0, [x0, 16]	// _18, MEM[(float * const &)this_1(D) + 16]
	ldr	x2, [x19, 24]	// _17, MEM[(float * const &)this_1(D) + 24]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:930:       for (; __first != __last; ++__first)
	cmp	x2, x0	// _17, _18
	beq	.L357		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	sub	x2, x2, x0	//, _17, _18
	mov	w1, 0	//,
	bl	memset		//
.L357:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x2, x4, [x19, 40]	// tmp.1810, _13, MEM[(struct complex * const &)this_1(D) + 40]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x2	// _13, tmp.1810
	beq	.L358		//,
	sub	x1, x4, #8	// tmp119, _13,
	mov	x0, x2	// ivtmp.1817, tmp.1810
	sub	x1, x1, x2	// _16, tmp119, tmp.1810
	cmp	x1, 16	// _16,
	lsr	x1, x1, 3	// tmp120, _16,
	add	x1, x1, 1	// niters.1807, tmp120,
	bls	.L359		//,
	lsr	x3, x1, 1	// bnd.1808, niters.1807,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	movi	v0.4s, 0	// tmp123
	add	x3, x2, x3, lsl 4	// _57, tmp.1810, bnd.1808,
	.p2align 3,,7
.L360:
	str	q0, [x0], 16	// tmp123, MEM <vector(4) float> [(float *)_42]
	cmp	x0, x3	// ivtmp.1817, _57
	bne	.L360		//,
	tbz	x1, 0, .L358	// niters.1807,,
	and	x1, x1, -2	// niters_vector_mult_vf.1809, niters.1807,
	add	x2, x2, x1, lsl 3	// tmp.1810, tmp.1810, niters_vector_mult_vf.1809,
.L359:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 8	// __first, tmp.1810,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2]	//, REALPART_EXPR <__first_45->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _13, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 4]	//, IMAGPART_EXPR <__first_45->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L358		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 16	// __first, tmp.1810,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_45 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _13, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_45 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L358		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_45 + 16B]._M_value>
.L358:
// /probe/scatter-baseline-pitch.cpp:88:   tracks_ = {};
	mov	x20, 6144	// tmp130,
	mov	x0, 6232	//,
	mov	x2, x20	//, tmp130
	mov	w1, 0	//,
	add	x0, x19, x0	//, this,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:89:   regions_ = {};
	mov	x2, x20	//, tmp130
	add	x0, x19, 88	//, this,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	add	x0, x19, 12288	// tmp141, this,
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x19, 12376]	//, this_1(D)->spectrum_._M_ptr
	str	xzr, [x19, 12384]	//, MEM <size_t> [(struct PitchFrame *)this_1(D) + 12384B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12392]	//, this_1(D)->count_
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12400]	//, this_1(D)->capacityEvents_
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12408]	//, this_1(D)->generation_
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	strb	wzr, [x0, 128]	//, this_1(D)->previous_
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12424]	//, this_1(D)->centerSamples_
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12432]	//, this_1(D)->samples_
// /probe/scatter-baseline-pitch.cpp:94: }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
	.cfi_endproc
.LFE9557:
	.size	_ZN5ardor4pog310PitchFrame5resetEv, .-_ZN5ardor4pog310PitchFrame5resetEv
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE
	.type	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE, %function
_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE:
.LFB9558:
	.cfi_startproc
	adrp	x3, :got:__stack_chk_guard	// tmp653,
	ldr	x3, [x3, :got_lo12:__stack_chk_guard]	// tmp653,
	mov	x13, 4416	//,
	stp	x29, x30, [sp, -160]!	//,,,
	.cfi_def_cfa_offset 160
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	mov	x20, x1	// spectrum, tmp1280
	stp	x25, x26, [sp, 64]	//,,
	sub	sp, sp, x13	//,,
	.cfi_def_cfa_offset 4576
	.cfi_offset 25, -96
	.cfi_offset 26, -88
	mov	x25, x0	// this, tmp1279
	ldr	x1, [x3]	// tmp1330,
	str	x1, [sp, 4408]	// tmp1330, D.329757
	mov	x1, 0	// tmp1330
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x0, [x0]	// _181, MEM[(const struct __shared_ptr *)this_160(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:98:   spectrum_ = {};
	str	xzr, [x25, 12376]	//, this_160(D)->spectrum_._M_ptr
	str	xzr, [x25, 12384]	//, MEM <size_t> [(struct PitchFrame *)this_160(D) + 12384B]
// /probe/scatter-baseline-pitch.cpp:97:   count_ = 0;
	str	xzr, [x25, 12392]	//, this_160(D)->count_
// /probe/scatter-baseline-pitch.cpp:99:   if (!plan_ || spectrum.size() != plan_->spectral->frameSize()) return;
	cbz	x0, .L367	// _181,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x0, [x0]	// _226, MEM[(const struct __shared_ptr *)_181]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x3, x1, [x0, 80]	// MEM[(const struct vector *)_226 + 80B].D.214282._M_impl.D.213625._M_start, MEM[(const struct vector *)_226 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_226 + 80B].D.214282._M_impl.D.213625._M_start
	sub	x1, x1, x3	// tmp661, MEM[(const struct vector *)_226 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_226 + 80B].D.214282._M_impl.D.213625._M_start
	asr	x1, x1, 2	// tmp665, tmp661,
// /probe/scatter-baseline-pitch.cpp:99:   if (!plan_ || spectrum.size() != plan_->spectral->frameSize()) return;
	cmp	x1, x2	// tmp665, spectrum
	bne	.L367		//,
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:24:   std::size_t hopSize() const noexcept { return hopSize_; }
	ldr	d6, [x0, 72]	// _205, MEM[(const struct SpectralPlan *)_226].hopSize_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x19, x0, [x25, 16]	// _808, _836, MEM[(const struct vector *)this_160(D) + 16B].D.214282._M_impl.D.213625._M_start
// /probe/scatter-baseline-pitch.cpp:100:   samples_ += static_cast<std::int64_t>(plan_->spectral->hopSize());
	fmov	x4, d6	// _205, _205
	ldr	x3, [x25, 12432]	// this_160(D)->samples_, this_160(D)->samples_
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	cmp	x19, x0	// _808, _836
	str	x21, [sp, 4448]	//,
	.cfi_offset 21, -128
// /probe/scatter-baseline-pitch.cpp:101:   centerSamples_ = samples_ - static_cast<std::int64_t>(spectrum.size() / 2);
	lsr	x21, x1, 1	// _3, tmp665,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x0, x0, x19	// tmp672, _836, _808
	str	x22, [sp, 4456]	//,
	.cfi_offset 22, -120
	str	x23, [sp, 4464]	//,
	.cfi_offset 23, -112
	str	x24, [sp, 4472]	//,
	.cfi_offset 24, -104
	str	x27, [sp, 4496]	//,
	.cfi_offset 27, -80
// /probe/scatter-baseline-pitch.cpp:100:   samples_ += static_cast<std::int64_t>(plan_->spectral->hopSize());
	add	x3, x4, x3	// _2, _205, this_160(D)->samples_
	str	x28, [sp, 4504]	//,
	.cfi_offset 28, -72
// /probe/scatter-baseline-pitch.cpp:101:   centerSamples_ = samples_ - static_cast<std::int64_t>(spectrum.size() / 2);
	sub	x4, x3, x21	// tmp667, _2, _3
	str	d8, [sp, 4512]	//,
	.cfi_offset 72, -64
	str	d9, [sp, 4520]	//,
	.cfi_offset 73, -56
// /probe/scatter-baseline-pitch.cpp:102:   spectrum_ = spectrum;
	str	x20, [x25, 12376]	// spectrum, MEM <const struct complex * const> [(struct PitchFrame *)this_160(D) + 12376B]
	str	x1, [x25, 12384]	// tmp665, MEM <const size_t> [(struct PitchFrame *)this_160(D) + 12384B]
// /probe/scatter-baseline-pitch.cpp:101:   centerSamples_ = samples_ - static_cast<std::int64_t>(spectrum.size() / 2);
	str	x4, [x25, 12424]	// tmp667, this_160(D)->centerSamples_
// /probe/scatter-baseline-pitch.cpp:100:   samples_ += static_cast<std::int64_t>(plan_->spectral->hopSize());
	str	x3, [x25, 12432]	// _2, this_160(D)->samples_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	asr	x3, x0, 2	// _785, tmp672,
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	beq	.L740		//,
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	mov	w1, 2139095039	// tmp1329,
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	movi	v4.2s, #0	// prephitmp_120
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	movi	v5.2s, 0x80, lsl 16	// tmp679
	mov	x4, x20	// ivtmp.2115, spectrum
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	mov	x0, x20	// ivtmp.2120, spectrum
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fmov	s3, w1	// tmp1278, tmp1329
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	mov	x1, 0	// k,
	.p2align 3,,7
.L377:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1385:       imag() const { return __imag__ _M_value; }
	ldp	s0, s1, [x0]	// _385, _387, MEM[(float *)_1059]
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmul	s2, s1, s1	// tmp678, _387, _387
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmadd	s2, s0, s0, s2	// squared, _385, _385, tmp678
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fcmpe	s2, s5	// squared, tmp679
	bge	.L637		//,
.L371:
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d1, s1	// imaginary, _387
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d0, s0	// real, _385
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmul	d1, d1, d1	// tmp681, imaginary, imaginary
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmadd	d0, d0, d0, d1	// _396, real, real, tmp681
	fsqrt	d0, d0	// _397, _396
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fcvt	s0, d0	// _398, _397
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabs	s1, s0	// prephitmp_614, _398
.L373:
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	fcmp	s1, s3	// prephitmp_614, tmp1278
// /probe/scatter-baseline-pitch.cpp:106:     magnitude_[k] = magnitude(spectrum[k]);
	str	s0, [x19, x1, lsl 2]	// _398, MEM[(value_type &)_808 + k_786 * 4]
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	bhi	.L638		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s4, s0	// prephitmp_120, _398
	bmi	.L601		//,
.L376:
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	add	x1, x1, 1	// k, k,
// /probe/scatter-baseline-pitch.cpp:105:   for (std::size_t k = 0; k < magnitude_.size(); ++k) {
	add	x0, x0, 8	// ivtmp.2120, ivtmp.2120,
	cmp	x1, x3	// k, _785
	bcc	.L377		//,
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	mov	w1, 50604	// tmp1327,
	movk	w1, 0x3727, lsl 16	// tmp1327,,
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	ucvtf	d9, d6	// tmp685, _205
	adrp	x0, .LC2	// tmp1356,
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	ucvtf	d0, x2	// tmp688, spectrum
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	ldr	x27, [x25, 12440]	// _658, this_160(D)->peakLimit_
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	fmov	s2, w1	// tmp684, tmp1327
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	ldr	d3, [x0, #:lo12:.LC2]	// tmp687,
	mov	w0, 49045	// tmp1328,
	movk	w0, 0x33d6, lsl 16	// tmp1328,,
	str	d10, [sp, 4528]	//,
	.cfi_offset 74, -48
	fmov	s1, w0	// tmp689, tmp1328
	str	d11, [sp, 4536]	//,
	.cfi_offset 75, -40
	str	d12, [sp, 4544]	//,
	.cfi_offset 76, -32
	str	d13, [sp, 4552]	//,
	.cfi_offset 77, -24
	fmul	d9, d9, d3	// tmp686, tmp685, tmp687
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	fmul	s8, s4, s2	// _479, prephitmp_120, tmp684
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	fdiv	d9, d9, d0	// step, tmp686, tmp688
	fcmpe	s8, s1	// _479, tmp689
	bgt	.L378		//,
.L370:
	cbz	x21, .L602	// _3,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	w0, 49045	// tmp1326,
	movk	w0, 0x33d6, lsl 16	// tmp1326,,
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	ldr	s10, [x19]	// _111, MEM[(value_type &)_808]
	add	x28, x27, 1	// tmp690, _658,
	mov	x23, x19	// ivtmp.2097, _808
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fmov	s0, w0	// tmp691, tmp1326
	cmp	x28, x21	// tmp690, _3
	csel	x28, x28, x21, ls	// _574, tmp690, _3,
	mov	x1, x20	// ivtmp.2099, spectrum
	fcmpe	s10, s0	// _111, tmp691
	bls	.L608		//,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	ldr	s0, [x19, 4]	// MEM[(value_type &)_808 + 4], MEM[(value_type &)_808 + 4]
	fcmpe	s10, s0	// _111, MEM[(value_type &)_808 + 4]
	bmi	.L608		//,
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	scvtf	s1, x21	// _865, _3
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x0, [x25, 64]	// _899, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
// /probe/scatter-baseline-pitch.cpp:117:     if (k == 0 || k == half) frequency = static_cast<float>(k);
	movi	v0.2s, #0	// _694
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	mov	x26, 1	// ivtmp.2088,
	mov	w2, 0	// _1106,
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	mov	x24, x26	// candidates, ivtmp.2088
	add	x22, x25, 12288	// tmp1249, this,
.L382:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcmpe	s0, s1	// _694, _865
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	strh	w2, [x0]	// _1106, _1170->bin
	strh	wzr, [x0, 2]	//, _1170->first
	str	wzr, [x0, 4]	//, MEM <unsigned int> [(short unsigned int *)_1170 + 4B]
	str	xzr, [x0, 8]	//, _1170->generation
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcsel	s1, s1, s0, gt	// _865, _865, _694,
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	cmp	x28, x26	// _574, ivtmp.2088
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	stp	s1, s10, [x0, 16]	// _865, _111, _1170->frequencyBins
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	bls	.L404		//,
.L748:
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	w0, 49045	// tmp1321,
	movk	w0, 0x33d6, lsl 16	// tmp1321,,
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	ldr	s10, [x23, 4]!	// _111, MEM[(value_type &)_834]
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	add	x1, x1, 8	// ivtmp.2099, ivtmp.2099,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	add	x3, x26, 1	// _562, ivtmp.2088,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fmov	s0, w0	// tmp730, tmp1321
	fcmpe	s10, s0	// _111, tmp730
	bls	.L609		//,
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	ldr	s0, [x23, -4]	// prephitmp_765, MEM[(value_type &)_834 + 18446744073709551612]
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	fcmpe	s10, s0	// _111, prephitmp_765
	bls	.L609		//,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	ldr	s12, [x23, 4]	// _428, MEM[(value_type &)_834 + 4]
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fcmpe	s10, s12	// _111, _428
	bmi	.L609		//,
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	ldrb	w0, [x22, 128]	// this_160(D)->previous_, this_160(D)->previous_
	tbnz	x0, 0, .L388	// this_160(D)->previous_,,
.L398:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1325,
	movk	w0, 0x1e3c, lsl 16	// tmp1325,,
	fmov	s1, w0	// tmp705, tmp1325
	fcmpe	s0, s1	// prephitmp_765, tmp705
	bmi	.L605		//,
.L389:
	stp	x3, x1, [sp, 8]	// _562, ivtmp.2099, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
	fmov	s11, s0	// tmp1282,
	fmov	s0, s10	//, _111
// /probe/scatter-baseline-pitch.cpp:122:       const double a = std::log(std::max(magnitude_[k - 1], 1e-20f));
	fcvt	d11, s11	// a, tmp1282
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1324,
	movk	w0, 0x1e3c, lsl 16	// tmp1324,,
	ldp	x3, x1, [sp, 8]	// _562, ivtmp.2099, %sfp
// /probe/scatter-baseline-pitch.cpp:123:       const double b = std::log(std::max(magnitude_[k], 1e-20f));
	fcvt	d8, s0	// b, tmp1283
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	s1, w0	// tmp706, tmp1324
	fcmpe	s12, s1	// _428, tmp706
	bmi	.L606		//,
.L390:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	fmov	s0, s12	//, _428
	stp	x3, x1, [sp, 8]	// _562, ivtmp.2099, %sfp
	bl	logf		//
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmov	d1, 2.0e+0	// tmp707,
// /probe/scatter-baseline-pitch.cpp:124:       const double c = std::log(std::max(magnitude_[k + 1], 1e-20f));
	fcvt	d0, s0	// c, tmp1284
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	ldp	x3, x1, [sp, 8]	// _562, ivtmp.2099, %sfp
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	scvtf	s3, x26	// _697, ivtmp.2088
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmsub	d1, d8, d1, d11	// _702, b, tmp707, a
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fadd	d1, d1, d0	// denominator, _702, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcmp	d1, #0.0	// denominator
	bne	.L391		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	movi	v0.2s, #0	// prephitmp_676
.L395:
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fadd	s0, s0, s3	// _694, prephitmp_676, _697
.L392:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x4, [x25, 64]	// MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x0, x24, x24, lsl 1	// tmp698, candidates, candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// _694
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	scvtf	s1, x21	// _865, _3
	and	w2, w26, 65535	// _1106, ivtmp.2088
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	add	x24, x24, 1	// candidates, candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x0, x4, x0, lsl 3	// _899, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, tmp698,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	bmi	.L639		//,
	mov	x26, x3	// ivtmp.2088, _562
	b	.L382		//
.L628:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	add	x28, sp, 328	// __i,,
	add	x5, sp, 568	// __i,,
	.p2align 3,,7
.L534:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s8, [x28]	// _619, MEM[(float *)__i_709]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [sp, 312]	// _620, MEM[(const struct Prediction &)&predictions].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s8, s0	// _619, _620
	bne	.L536		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x1, [x28, 8]	// MEM[(long unsigned int *)__i_709 + 8B], MEM[(long unsigned int *)__i_709 + 8B]
	ldr	x0, [sp, 320]	// MEM[(const struct Prediction &)&predictions].track, MEM[(const struct Prediction &)&predictions].track
	cmp	x1, x0	// MEM[(long unsigned int *)__i_709 + 8B], MEM[(const struct Prediction &)&predictions].track
	cset	w0, cc	// iftmp.174_623,
.L537:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	cbz	w0, .L741	// iftmp.174_623,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:746: 	  const ptrdiff_t _Num = __last - __first;
	sub	x2, x28, x27	// _640, __i, prediction
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldr	x4, [x28, 8]	// __val$track, MEM <size_t> [(struct Prediction &)__i_709 + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 16	// _640,
	ble	.L538		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x0, 16	// tmp1369,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x1, x27	//, prediction
	stp	x4, x5, [sp, 8]	// __val$track, __i, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	sub	x0, x0, x2	// tmp1087, tmp1369, _640
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	add	x0, x28, x0	//, __i, tmp1087
	bl	memmove		//
	ldp	x4, x5, [sp, 8]	// __val$track, __i, %sfp
.L539:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1824: 	      *__first = _GLIBCXX_MOVE(__val);
	str	s8, [sp, 312]	// _619, MEM <float> [(struct Prediction *)&predictions]
	str	x4, [sp, 320]	// __val$track, MEM <size_t> [(struct Prediction *)&predictions + 8B]
.L540:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1823: 	      _GLIBCXX_MOVE_BACKWARD3(__first, __i, __i + 1);
	add	x28, x28, 16	// __i, __i,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	cmp	x28, x5	// __i, __i
	bne	.L534		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	mov	x3, x28	// __i, __i
	.p2align 3,,7
.L549:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	s1, [x3]	// __val$frequency, MEM[(float *)__i_357]
	mov	x2, x3	// ivtmp.1911, __i
	ldr	x4, [x3, 8]	// __val$track, MEM[(long unsigned int *)__i_357 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	b	.L545		//
	.p2align 2,,3
.L742:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldr	x1, [x0, -8]	// MEM[(long unsigned int *)__last_608 + -8B], MEM[(long unsigned int *)__last_608 + -8B]
	sub	x2, x2, #16	// ivtmp.1911, ivtmp.1911,
	cmp	x4, x1	// __val$track, MEM[(long unsigned int *)__last_608 + -8B]
	bcs	.L548		//,
.L547:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x0, x1, [x2]	// MEM[(struct Prediction &)_1294], MEM[(struct Prediction &)_1294]
	stp	x0, x1, [x2, 16]	// MEM[(struct Prediction &)_1294], MEM[(struct Prediction *)_1294 + 16B]
.L545:
	mov	x0, x2	// __last, ivtmp.1911
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x2, -16]	// _610, MEM[(float *)__last_608 + -16B]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s1, s0	// __val$frequency, _610
	beq	.L742		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	fcmpe	s1, s0	// __val$frequency, _610
	sub	x2, x2, #16	// ivtmp.1911, ivtmp.1911,
	bmi	.L547		//,
.L548:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	add	x3, x3, 16	// __i, __i,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	str	s1, [x0]	// __val$frequency, __last_608->frequency
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	cmp	x23, x3	// _72, __i
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	str	x4, [x0, 8]	// __val$track, __last_608->track
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	bne	.L549		//,
.L533:
// /probe/scatter-baseline-pitch.cpp:151:   for (std::size_t p = 0; p < candidates; ++p) {
	cbz	x24, .L582	// candidates,
	ldr	x7, [x25, 64]	// ivtmp.1898, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
	add	x24, x24, x24, lsl 1	// tmp1120, candidates, candidates,
// /probe/scatter-baseline-pitch.cpp:156:       region.frequencyBins - 2, [](const auto& value, float frequency) { return value.frequency < frequency; });
	fmov	s4, 2.0e+0	// tmp1126,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	s5, -5.0e-1	// tmp1262,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s6, 5.0e-1	// tmp1263,
// /probe/scatter-baseline-pitch.cpp:174:     if (birth) { track = {}; track.generation = ++generation_; }
	mov	x0, 6232	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator_base_funcs.h:106:       return __last - __first;
	asr	x19, x19, 4	// _684, _71,
	add	x28, sp, 32	// tmp1246,,
// /probe/scatter-baseline-pitch.cpp:178:     used[match] = true;
	mov	w11, 1	// tmp1255,
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	add	x10, x25, 88	// tmp1256, this,
	mov	x12, 6240	// tmp1257,
// /probe/scatter-baseline-pitch.cpp:174:     if (birth) { track = {}; track.generation = ++generation_; }
	add	x8, x25, x0	// tmp1260, this,
	add	x9, x7, x24, lsl 3	// _1299, ivtmp.1898, tmp1120,
	.p2align 3,,7
.L578:
// /probe/scatter-baseline-pitch.cpp:152:     auto region = candidates_[p];
	ldr	s2, [x7, 16]	// region$frequencyBins, MEM[(float *)_1302 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1465:       _DistanceType __len = std::distance(__first, __last);
	mov	x1, x19	// __len, _684
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1467:       while (__len > 0)
	mov	x2, x27	// prediction, prediction
// /probe/scatter-baseline-pitch.cpp:152:     auto region = candidates_[p];
	ldp	x4, x5, [x7]	// MEM[(const struct PitchRegion &)_1302], MEM[(const struct PitchRegion &)_1302]
	ldr	x0, [x7, 16]	// MEM[(const struct PitchRegion &)_1302], MEM[(const struct PitchRegion &)_1302]
// /probe/scatter-baseline-pitch.cpp:156:       region.frequencyBins - 2, [](const auto& value, float frequency) { return value.frequency < frequency; });
	fsub	s1, s2, s4	// _74, region$frequencyBins, tmp1126
// /probe/scatter-baseline-pitch.cpp:152:     auto region = candidates_[p];
	stp	x4, x5, [x28]	// MEM[(const struct PitchRegion &)_1302], MEM[(struct PitchRegion *)_358]
	str	x0, [x28, 16]	// MEM[(const struct PitchRegion &)_1302], MEM[(struct PitchRegion *)_358]
	.p2align 3,,7
.L560:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1467:       while (__len > 0)
	cmp	x1, 0	// __len,
	ble	.L743		//,
.L562:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1469: 	  _DistanceType __half = __len >> 1;
	asr	x3, x1, 1	// __half, __len,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator_base_funcs.h:195: 	__i += __n;
	lsl	x4, x3, 4	// tmp1127, __half,
	add	x0, x2, x4	// _705, prediction, tmp1127
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1472: 	  if (__comp(__middle, __val))
	ldr	s0, [x2, x4]	// MEM[(const struct Prediction &)_705].frequency, MEM[(const struct Prediction &)_705].frequency
	fcmpe	s1, s0	// _74, MEM[(const struct Prediction &)_705].frequency
	bgt	.L650		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1479: 	    __len = __half;
	mov	x1, x3	// __len, __half
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1467:       while (__len > 0)
	cmp	x1, 0	// __len,
	bgt	.L562		//,
.L743:
// /probe/scatter-baseline-pitch.cpp:157:     for (; prediction != predictions.begin() + predicted && prediction->frequency < region.frequencyBins + 2; ++prediction) {
	cmp	x23, x2	// _72, prediction
	beq	.L563		//,
// /probe/scatter-baseline-pitch.cpp:157:     for (; prediction != predictions.begin() + predicted && prediction->frequency < region.frequencyBins + 2; ++prediction) {
	fadd	s3, s2, s4	// _901, region$frequencyBins, tmp1126
// /probe/scatter-baseline-pitch.cpp:154:     float distance = 2.0f;
	fmov	s1, 2.0e+0	// distance,
// /probe/scatter-baseline-pitch.cpp:153:     std::size_t match = tracks_.size();
	mov	x1, 256	// t,
	.p2align 3,,7
.L564:
// /probe/scatter-baseline-pitch.cpp:157:     for (; prediction != predictions.begin() + predicted && prediction->frequency < region.frequencyBins + 2; ++prediction) {
	ldr	s0, [x2]	// _77, MEM[(float *)prediction_710]
// /probe/scatter-baseline-pitch.cpp:157:     for (; prediction != predictions.begin() + predicted && prediction->frequency < region.frequencyBins + 2; ++prediction) {
	fcmpe	s0, s3	// _77, _901
	bmi	.L567		//,
// /probe/scatter-baseline-pitch.cpp:163:     if (birth) {
	cmp	x1, 256	// t,
	beq	.L563		//,
.L568:
// /probe/scatter-baseline-pitch.cpp:175:     track.velocity = birth ? 0 : std::clamp(region.frequencyBins - track.frequency, -.5f, .5f);
	lsl	x0, x1, 1	// tmp1250, t,
	add	x2, x0, x1	// tmp1153, tmp1250, t
	lsl	x2, x2, 3	// tmp1154, tmp1153,
// /probe/scatter-baseline-pitch.cpp:175:     track.velocity = birth ? 0 : std::clamp(region.frequencyBins - track.frequency, -.5f, .5f);
	ldr	s0, [x8, x2]	// MEM <struct array> [(struct Track &)this_160(D) + 6232]._M_elems[match_801].frequency, MEM <struct array> [(struct Track &)this_160(D) + 6232]._M_elems[match_801].frequency
	fsub	s0, s2, s0	// iftmp.94_135, region$frequencyBins, MEM <struct array> [(struct Track &)this_160(D) + 6232]._M_elems[match_801].frequency
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, s5	// iftmp.94_135, tmp1262
	bmi	.L634		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	s0, s6	// iftmp.94_135, tmp1263
	bgt	.L635		//,
	.p2align 3,,7
.L575:
// /probe/scatter-baseline-pitch.cpp:180:     region.generation = track.generation;
	add	x2, x0, x1	// tmp1188, tmp1250, t
	add	x2, x8, x2, lsl 3	// tmp1190, tmp1260, tmp1188,
	ldr	x2, [x2, 16]	// pretmp_615, MEM <struct array> [(struct Track &)this_160(D) + 6232]._M_elems[match_801].generation
.L577:
	add	x0, x0, x1	// tmp1193, tmp1250, t
// /probe/scatter-baseline-pitch.cpp:178:     used[match] = true;
	strb	w11, [x26, x1]	// tmp1255, MEM <struct array> [(value_type &)&used]._M_elems[match_527]
	add	x0, x25, x0, lsl 3	// _1030, this, tmp1193,
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	ldr	x4, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
// /probe/scatter-baseline-pitch.cpp:179:     region.track = static_cast<std::uint16_t>(match);
	strh	w1, [sp, 38]	// t, MEM[(struct PitchRegion *)_358].track
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	str	x2, [sp, 40]	// pretmp_615, MEM[(struct PitchRegion *)_358].generation
// /probe/scatter-baseline-pitch.cpp:176:     track.frequency = region.frequencyBins;
	str	s2, [x0, 6232]	// region$frequencyBins, MEM <float> [(struct Track &)_1030 + 6232]
// /probe/scatter-baseline-pitch.cpp:175:     track.velocity = birth ? 0 : std::clamp(region.frequencyBins - track.frequency, -.5f, .5f);
	str	s0, [x0, 6236]	// iftmp.94_135, MEM <float> [(struct Track &)_1030 + 6236]
// /probe/scatter-baseline-pitch.cpp:177:     track.missed = 0;
	str	wzr, [x0, 6240]	//, MEM <unsigned int> [(struct Track &)_1030 + 6240]
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	ldr	x0, [x25, 12392]	// _92, this_160(D)->count_
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	ldp	x2, x3, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	add	x1, x0, x0, lsl 1	// tmp1203, _92, _92,
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	add	x0, x0, 1	// tmp1197, _92,
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	add	x1, x10, x1, lsl 3	// tmp1205, tmp1256, tmp1203,
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	str	x0, [x25, 12392]	// tmp1197, this_160(D)->count_
// /probe/scatter-baseline-pitch.cpp:181:     regions_[count_++] = region;
	stp	x2, x3, [x1]	// MEM[(struct PitchRegion *)_358], MEM <struct array> [(struct value_type *)this_160(D) + 88B]._M_elems[_92]
	str	x4, [x1, 16]	// MEM[(struct PitchRegion *)_358], MEM <struct array> [(struct value_type *)this_160(D) + 88B]._M_elems[_92]
.L574:
// /probe/scatter-baseline-pitch.cpp:151:   for (std::size_t p = 0; p < candidates; ++p) {
	add	x7, x7, 24	// ivtmp.1898, ivtmp.1898,
	cmp	x9, x7	// _1299, ivtmp.1898
	bne	.L578		//,
.L582:
// /probe/scatter-baseline-pitch.cpp:185:   for (std::size_t p = 0; p < count_; ++p) {
	ldr	x3, [x25, 12392]	// this_160(D)->count_, this_160(D)->count_
	add	x0, x25, 64	// ivtmp.1865, this,
	mov	x2, 0	// p,
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	mov	w1, 0	// iftmp.95_136,
// /probe/scatter-baseline-pitch.cpp:185:   for (std::size_t p = 0; p < count_; ++p) {
	cbz	x3, .L580	// this_160(D)->count_,
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	strh	w1, [x0, 26]	// iftmp.95_136, MEM <uint16_t> [(struct value_type &)_1327 + 26]
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	add	x2, x2, 1	// p, p,
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	ldr	x1, [x25, 12392]	// this_160(D)->count_, this_160(D)->count_
	cmp	x2, x1	// p, this_160(D)->count_
	beq	.L586		//,
.L744:
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	ldrh	w1, [x0, 24]	// MEM <uint16_t> [(struct value_type &)_1327 + 24], MEM <uint16_t> [(struct value_type &)_1327 + 24]
// /probe/scatter-baseline-pitch.cpp:185:   for (std::size_t p = 0; p < count_; ++p) {
	add	x0, x0, 24	// ivtmp.1865, ivtmp.1865,
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	ldrh	w3, [x0, 24]	// MEM <uint16_t> [(struct value_type &)_1327 + 48], MEM <uint16_t> [(struct value_type &)_1327 + 48]
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	add	w1, w1, w3	// tmp1226, MEM <uint16_t> [(struct value_type &)_1327 + 24], MEM <uint16_t> [(struct value_type &)_1327 + 48]
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	asr	w1, w1, 1	// tmp1227, tmp1226,
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	strh	w1, [x0, 4]	// tmp1227, MEM <uint16_t> [(struct value_type &)_1327 + 28]
// /probe/scatter-baseline-pitch.cpp:185:   for (std::size_t p = 0; p < count_; ++p) {
	ldr	x1, [x25, 12392]	// this_160(D)->count_, this_160(D)->count_
	cmp	x2, x1	// p, this_160(D)->count_
	bcs	.L580		//,
.L587:
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	ldrh	w1, [x0]	// MEM <uint16_t> [(struct value_type &)_1330], MEM <uint16_t> [(struct value_type &)_1330]
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	add	x2, x2, 1	// p, p,
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	ldrh	w3, [x0, 24]	// MEM <uint16_t> [(struct value_type &)_1330 + 24], MEM <uint16_t> [(struct value_type &)_1330 + 24]
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	add	w1, w1, w3	// tmp1218, MEM <uint16_t> [(struct value_type &)_1330], MEM <uint16_t> [(struct value_type &)_1330 + 24]
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	asr	w1, w1, 1	// tmp1219, tmp1218,
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	add	w1, w1, 1	// tmp1221, tmp1219,
	and	w1, w1, 65535	// iftmp.95_136, tmp1221
// /probe/scatter-baseline-pitch.cpp:186:     regions_[p].first = p == 0 ? 0 : (regions_[p - 1].bin + regions_[p].bin) / 2 + 1;
	strh	w1, [x0, 26]	// iftmp.95_136, MEM <uint16_t> [(struct value_type &)_1327 + 26]
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	ldr	x1, [x25, 12392]	// this_160(D)->count_, this_160(D)->count_
	cmp	x2, x1	// p, this_160(D)->count_
	bne	.L744		//,
.L586:
// /probe/scatter-baseline-pitch.cpp:187:     regions_[p].last = p + 1 == count_ ? half : (regions_[p].bin + regions_[p + 1].bin) / 2;
	strh	w21, [x0, 28]	// _3, MEM <uint16_t> [(struct value_type &)_1327 + 28]
// /probe/scatter-baseline-pitch.cpp:185:   for (std::size_t p = 0; p < count_; ++p) {
	add	x0, x0, 24	// ivtmp.1865, ivtmp.1865,
	ldr	x1, [x25, 12392]	// this_160(D)->count_, this_160(D)->count_
	cmp	x2, x1	// p, this_160(D)->count_
	bcc	.L587		//,
.L580:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x0, [sp, 24]	// tmp1247, %sfp
	ldr	x1, [x0, 8]	// MEM[(const struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_finish, MEM[(const struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x0, [x25, 40]	// _354, MEM[(const struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:757:       if (__n2 <= 0)
	subs	x2, x1, x0	// _355, MEM[(const struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_finish, _354
	bne	.L745		//,
.L583:
// /probe/scatter-baseline-pitch.cpp:190:   previous_ = true;
	mov	w0, 1	// tmp1235,
	ldr	d8, [sp, 4512]	//,
	.cfi_restore 72
	ldr	d9, [sp, 4520]	//,
	.cfi_restore 73
	strb	w0, [x22, 128]	// tmp1235, this_160(D)->previous_
	ldr	d10, [sp, 4528]	//,
	.cfi_restore 74
	ldr	d11, [sp, 4536]	//,
	.cfi_restore 75
	ldr	d12, [sp, 4544]	//,
	.cfi_restore 76
	ldr	d13, [sp, 4552]	//,
	.cfi_restore 77
	ldr	x21, [sp, 4448]	//,
	.cfi_restore 21
	ldr	x22, [sp, 4456]	//,
	.cfi_restore 22
	ldr	x23, [sp, 4464]	//,
	.cfi_restore 23
	ldr	x24, [sp, 4472]	//,
	.cfi_restore 24
	ldr	x27, [sp, 4496]	//,
	.cfi_restore 27
	ldr	x28, [sp, 4504]	//,
	.cfi_restore 28
.L367:
// /probe/scatter-baseline-pitch.cpp:191: }
	adrp	x0, :got:__stack_chk_guard	// tmp1241,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp1241,
	ldr	x2, [sp, 4408]	// tmp1331, D.329757
	ldr	x1, [x0]	// tmp1332,
	subs	x2, x2, x1	// tmp1331, tmp1332
	mov	x1, 0	// tmp1332
	bne	.L746		//,
	mov	x13, 4416	//,
	add	sp, sp, x13	//,,
	.cfi_def_cfa_offset 160
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x25, x26, [sp, 64]	//,,
	ldp	x29, x30, [sp], 160	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L637:
	.cfi_def_cfa_offset 4576
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	.cfi_offset 21, -128
	.cfi_offset 22, -120
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 25, -96
	.cfi_offset 26, -88
	.cfi_offset 27, -80
	.cfi_offset 28, -72
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	.cfi_offset 72, -64
	.cfi_offset 73, -56
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fcmp	s2, s3	// squared, tmp1278
	bhi	.L371		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:439:   { return __builtin_sqrtf(__x); }
	fsqrt	s0, s2	// _398, squared
	fmov	s1, s0	// prephitmp_614, _398
	b	.L373		//
	.p2align 2,,3
.L601:
	fmov	s4, s0	// prephitmp_120, _398
	b	.L376		//
.L378:
	.cfi_offset 74, -48
	.cfi_offset 75, -40
	.cfi_offset 76, -32
	.cfi_offset 77, -24
	cbz	x21, .L613	// _3,
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	ldr	s13, [x19]	// _55, MEM[(value_type &)_808]
	add	x28, x27, 1	// tmp770, _658,
	mov	x23, x19	// ivtmp.2113, _808
	cmp	x28, x21	// tmp770, _3
	csel	x28, x28, x21, ls	// _1025, tmp770, _3,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fcmpe	s13, s8	// _55, _479
	bls	.L636		//,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	ldr	s0, [x19, 4]	// MEM[(value_type &)_808 + 4], MEM[(value_type &)_808 + 4]
	fcmpe	s13, s0	// _55, MEM[(value_type &)_808 + 4]
	bmi	.L636		//,
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	scvtf	s1, x21	// _57, _3
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x0, [x25, 64]	// _333, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
// /probe/scatter-baseline-pitch.cpp:117:     if (k == 0 || k == half) frequency = static_cast<float>(k);
	movi	v0.2s, #0	// _54
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	mov	x26, 1	// ivtmp.2103,
	mov	w2, 0	// _1067,
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	mov	x24, x26	// candidates, ivtmp.2103
	add	x22, x25, 12288	// tmp1249, this,
.L438:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcmpe	s0, s1	// _54, _57
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	strh	w2, [x0]	// _1067, _1189->bin
	strh	wzr, [x0, 2]	//, _1189->first
	str	wzr, [x0, 4]	//, MEM <unsigned int> [(short unsigned int *)_1189 + 4B]
	str	xzr, [x0, 8]	//, _1189->generation
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcsel	s1, s1, s0, gt	// _57, _57, _54,
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	stp	s1, s13, [x0, 16]	// _57, _55, _1189->frequencyBins
.L453:
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	cmp	x28, x26	// _1025, ivtmp.2103
	bhi	.L747		//,
	cmp	x27, x26	// _658, ivtmp.2103
	bcc	.L735		//,
	str	d14, [sp, 4560]	//,
	.cfi_remember_state
	.cfi_offset 78, -16
	str	d15, [sp, 4568]	//,
	.cfi_offset 79, -8
	b	.L433		//
.L608:
	.cfi_restore_state
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	x26, 1	// ivtmp.2088,
	mov	x24, 0	// candidates,
	add	x22, x25, 12288	// tmp1249, this,
.L405:
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	cmp	x28, x26	// _574, ivtmp.2088
	bhi	.L748		//,
.L404:
	cmp	x27, x26	// _658, ivtmp.2088
	bcc	.L735		//,
	str	d14, [sp, 4560]	//,
	.cfi_offset 78, -16
	str	d15, [sp, 4568]	//,
	.cfi_offset 79, -8
.L379:
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	w1, 49045	// tmp1319,
	movk	w1, 0x33d6, lsl 16	// tmp1319,,
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmov	d11, 2.0e+0	// tmp1273,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1320,
	movk	w0, 0x1e3c, lsl 16	// tmp1320,,
	add	x19, x19, x26, lsl 2	// ivtmp.2089, _808, ivtmp.2088,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fmov	s14, w1	// tmp733, tmp1319
	add	x28, x20, x26, lsl 3	// ivtmp.2091, spectrum, ivtmp.2088,
	add	x2, x25, 40	// tmp1247, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	s10, w0	// tmp1272, tmp1320
	str	x2, [sp, 24]	// tmp1247, %sfp
	.p2align 3,,7
.L431:
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	ldr	s8, [x19]	// _318, MEM[(value_type &)_1127]
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fcmpe	s8, s14	// _318, tmp733
	bls	.L407		//,
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	cbz	x26, .L749	// ivtmp.2088,
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	ldr	s0, [x19, -4]	// _258, MEM[(value_type &)_1127 + 18446744073709551612]
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	fcmpe	s0, s8	// _258, _318
	bge	.L407		//,
// /probe/scatter-baseline-pitch.cpp:117:     if (k == 0 || k == half) frequency = static_cast<float>(k);
	cmp	x21, x26	// _3, ivtmp.2088
	beq	.L428		//,
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	ldrb	w0, [x22, 128]	// this_160(D)->previous_, this_160(D)->previous_
	tbnz	x0, 0, .L414	// this_160(D)->previous_,,
.L424:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, s10	// _258, tmp1272
	bmi	.L610		//,
.L415:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
	fmov	s13, s0	// tmp1288,
	fmov	s0, s8	//, _318
// /probe/scatter-baseline-pitch.cpp:122:       const double a = std::log(std::max(magnitude_[k - 1], 1e-20f));
	fcvt	d13, s13	// a, tmp1288
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
// /probe/scatter-baseline-pitch.cpp:123:       const double b = std::log(std::max(magnitude_[k], 1e-20f));
	fcvt	d12, s0	// b, tmp1289
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	ldr	s0, [x19, 4]	// _162, MEM[(const float &)_1127 + 4]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, s10	// _162, tmp1272
	bmi	.L611		//,
.L416:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmsub	d12, d12, d11, d13	// _42, b, tmp1273, a
// /probe/scatter-baseline-pitch.cpp:124:       const double c = std::log(std::max(magnitude_[k + 1], 1e-20f));
	fcvt	d2, s0	// c, tmp1290
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	scvtf	s1, x26	// _53, ivtmp.2088
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fadd	d0, d12, d2	// denominator, _42, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcmp	d0, #0.0	// denominator
	bne	.L417		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	movi	v3.2s, #0	// iftmp.82_617
.L421:
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fadd	s0, s1, s3	// _492, _53, iftmp.82_617
.L418:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x2, [x25, 64]	// MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x1, x24, x24, lsl 1	// tmp738, candidates, candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// _492
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	scvtf	s1, x21	// _824, _3
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	add	x24, x24, 1	// candidates, candidates,
	and	w3, w26, 65535	// _1123, ivtmp.2088
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	lsl	x1, x1, 3	// tmp739, tmp738,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x0, x2, x1	// _380, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, tmp739
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	bmi	.L642		//,
.L410:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcmpe	s0, s1	// _492, _824
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	strh	w3, [x2, x1]	// _1123, _380->bin
	strh	wzr, [x0, 2]	//, _380->first
	str	wzr, [x0, 4]	//, MEM <unsigned int> [(short unsigned int *)_380 + 4B]
	str	xzr, [x0, 8]	//, _380->generation
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcsel	s1, s1, s0, gt	// _824, _824, _492,
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	stp	s1, s8, [x0, 16]	// _824, _318, _380->frequencyBins
.L407:
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	add	x26, x26, 1	// ivtmp.2088, ivtmp.2088,
	add	x19, x19, 4	// ivtmp.2089, ivtmp.2089,
	cmp	x27, x26	// _658, ivtmp.2088
	add	x28, x28, 8	// ivtmp.2091, ivtmp.2091,
	bcs	.L431		//,
.L734:
	ldr	d14, [sp, 4560]	//,
	.cfi_restore 78
	ldr	d15, [sp, 4568]	//,
	.cfi_restore 79
.L455:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x18, x24, x24, lsl 1	// tmp848, candidates, candidates,
// /probe/scatter-baseline-pitch.cpp:131:   if (candidates > regions_.size()) {
	cmp	x24, 256	// candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	lsl	x18, x18, 3	// tmp849, tmp848,
// /probe/scatter-baseline-pitch.cpp:131:   if (candidates > regions_.size()) {
	bhi	.L750		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldr	x23, [x25, 64]	// prephitmp_782, MEM[(struct PitchRegion * const &)this_160(D) + 64]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x27, x23, x18	// _778, prephitmp_782, tmp849
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1945:       if (__first != __last)
	cmp	x27, x23	// _778, prephitmp_782
	beq	.L516		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x0, -6148914691236517206	// tmp956,
	asr	x2, x18, 3	// tmp954, tmp849,
	movk	x0, 0xaaab, lsl 0	// tmp956,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1518:       return std::__bit_width(make_unsigned_t<_Tp>(__n)) - 1;
	mov	w5, 63	// tmp959,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	w3, 0	//,
	mov	x1, x27	//, _778
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mul	x2, x2, x0	// tmp955, tmp954, tmp956
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	x0, x23	//, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x19, x23, 24	// prephitmp_435, prephitmp_782,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bit:215: 	  return __builtin_clzl(__x) - __diff;
	clz	x2, x2	// tmp957, tmp955
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1518:       return std::__bit_width(make_unsigned_t<_Tp>(__n)) - 1;
	sub	w2, w5, w2	// tmp958, tmp959, tmp957
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	sbfiz	x2, x2, 1, 32	//, tmp958,,
	bl	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1857:       if (__last - __first > int(_S_threshold))
	cmp	x18, 384	// tmp849,
	bgt	.L751		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	cmp	x27, x19	// _778, prephitmp_435
	beq	.L516		//,
	add	x28, sp, 32	// tmp1246,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x26, 24	// tmp1271,
	b	.L526		//
	.p2align 2,,3
.L752:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion &)__i$_M_current_680]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:746: 	  const ptrdiff_t _Num = __last - __first;
	sub	x2, x19, x23	// _575, ivtmp.2021, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 24	// _575,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldr	x3, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion &)__i$_M_current_680]
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion *)_358]
	str	x3, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	ble	.L521		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	sub	x0, x26, x2	// tmp1017, tmp1271, _575
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x1, x23	//, prephitmp_782
	add	x0, x19, x0	//, ivtmp.2021, tmp1017
	bl	memmove		//
.L522:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1824: 	      *__first = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_358], *_342
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_358], *_342
.L523:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	add	x19, x19, 24	// ivtmp.2021, ivtmp.2021,
	cmp	x27, x19	// _778, ivtmp.2021
	beq	.L516		//,
.L526:
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	ldrh	w5, [x19]	// _571, MEM[(short unsigned int *)__i$_M_current_680]
	mov	x6, x19	// __i$_M_current, ivtmp.2021
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	ldrh	w0, [x23]	// MEM[(const struct PitchRegion &)_342].bin, MEM[(const struct PitchRegion &)_342].bin
	cmp	w0, w5	// MEM[(const struct PitchRegion &)_342].bin, _571
	bhi	.L752		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldp	x2, x3, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion &)__i$_M_current_680]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1125: 	--_M_current;
	sub	x0, x19, #24	// _590, ivtmp.2021,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x7, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion &)__i$_M_current_680]
	stp	x2, x3, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w1, [x19, -24]	// MEM[(short unsigned int *)__i$_M_current_680 + -24B], MEM[(short unsigned int *)__i$_M_current_680 + -24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	str	x7, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_680], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	cmp	w1, w5	// MEM[(short unsigned int *)__i$_M_current_680 + -24B], _571
	bls	.L524		//,
	mov	x1, x19	// ivtmp.2018, ivtmp.2021
	.p2align 3,,7
.L525:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x2, x3, [x0]	// MEM[(struct PitchRegion &)__next$_M_current_681], MEM[(struct PitchRegion &)__next$_M_current_681]
	mov	x6, x0	// __i$_M_current, _590
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	sub	x1, x1, #24	// ivtmp.2018, ivtmp.2018,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	stp	x2, x3, [x1, 24]	// MEM[(struct PitchRegion &)__next$_M_current_681], MEM[(struct PitchRegion *)_1225]
	ldr	x2, [x0, 16]	// MEM[(struct PitchRegion &)__next$_M_current_681], MEM[(struct PitchRegion &)__next$_M_current_681]
	str	x2, [x1, 40]	// MEM[(struct PitchRegion &)__next$_M_current_681], MEM[(struct PitchRegion *)_1225]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w2, [x0, -24]!	// MEM[(short unsigned int *)_590], MEM[(short unsigned int *)_590]
	cmp	w2, w5	// MEM[(short unsigned int *)_590], _571
	bhi	.L525		//,
.L524:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x6]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_356
	str	x2, [x6, 16]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_356
	b	.L523		//
.L639:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:263: 	return __b;
	movi	v0.2s, #0	// _694
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	x26, x3	// ivtmp.2088, _562
	b	.L382		//
.L761:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	cmp	x26, x27	// __i$_M_current, _778
	beq	.L516		//,
	.p2align 3,,7
.L515:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldp	x2, x3, [x26]	// MEM[(struct PitchRegion &)__i$_M_current_866], MEM[(struct PitchRegion &)__i$_M_current_866]
	mov	x1, x26	// ivtmp.1990, __i$_M_current
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1125: 	--_M_current;
	sub	x0, x26, #24	// _564, __i$_M_current,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x4, [x26, 16]	// MEM[(struct PitchRegion &)__i$_M_current_866], MEM[(struct PitchRegion &)__i$_M_current_866]
	stp	x2, x3, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_866], MEM[(struct PitchRegion *)_358]
	ldrh	w6, [x26]	// __val$bin, MEM[(short unsigned int *)__i$_M_current_866]
	str	x4, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_866], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w2, [x26, -24]	// MEM[(short unsigned int *)__i$_M_current_866 + -24B], MEM[(short unsigned int *)__i$_M_current_866 + -24B]
	cmp	w2, w6	// MEM[(short unsigned int *)__i$_M_current_866 + -24B], __val$bin
	bls	.L627		//,
	.p2align 3,,7
.L518:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x2, x3, [x0]	// MEM[(struct PitchRegion &)__next$_M_current_584], MEM[(struct PitchRegion &)__next$_M_current_584]
	mov	x4, x0	// __last$_M_current, _564
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	sub	x1, x1, #24	// ivtmp.1990, ivtmp.1990,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	stp	x2, x3, [x1, 24]	// MEM[(struct PitchRegion &)__next$_M_current_584], MEM[(struct PitchRegion *)_1246]
	ldr	x2, [x0, 16]	// MEM[(struct PitchRegion &)__next$_M_current_584], MEM[(struct PitchRegion &)__next$_M_current_584]
	str	x2, [x1, 40]	// MEM[(struct PitchRegion &)__next$_M_current_584], MEM[(struct PitchRegion *)_1246]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w2, [x0, -24]!	// MEM[(short unsigned int *)_564], MEM[(short unsigned int *)_564]
	cmp	w2, w6	// MEM[(short unsigned int *)_564], __val$bin
	bhi	.L518		//,
.L517:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1111: 	++_M_current;
	add	x26, x26, 24	// __i$_M_current, __i$_M_current,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	cmp	x26, x27	// __i$_M_current, _778
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x4]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_675
	str	x2, [x4, 16]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_675
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	bne	.L515		//,
.L516:
// /probe/scatter-baseline-pitch.cpp:140:   std::array<bool, kMaxPitchPartials> used{};
	movi	v0.4s, 0	// tmp1043
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	mov	x1, 6232	//,
	mov	x2, 6240	//,
	mov	x3, 12384	//,
// /probe/scatter-baseline-pitch.cpp:140:   std::array<bool, kMaxPitchPartials> used{};
	add	x26, sp, 56	// tmp1248,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x19, x25, x1	// _339, this,
	add	x2, x25, x2	// ivtmp.1982, this,
	add	x0, x25, x3	// _1251, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	mov	w4, 5	// tmp1267,
// /probe/scatter-baseline-pitch.cpp:140:   std::array<bool, kMaxPitchPartials> used{};
	stp	q0, q0, [x26]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 32]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 64]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 96]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 128]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 160]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 192]	// tmp1043, tmp1043, used
	stp	q0, q0, [x26, 224]	// tmp1043, tmp1043, used
	.p2align 3,,7
.L530:
// /probe/scatter-baseline-pitch.cpp:141:   for (auto& track : tracks_) if (track.generation) track.missed = std::min(track.missed + 1, 5U);
	ldr	x1, [x2, 8]	// MEM[(long unsigned int *)_1250 + 8B], MEM[(long unsigned int *)_1250 + 8B]
	cbz	x1, .L529	// MEM[(long unsigned int *)_1250 + 8B],
// /probe/scatter-baseline-pitch.cpp:141:   for (auto& track : tracks_) if (track.generation) track.missed = std::min(track.missed + 1, 5U);
	ldr	w3, [x2]	//, MEM[(unsigned int *)_1250]
	add	w3, w3, 1	// tmp1053, MEM[(unsigned int *)_1250],
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	cmp	w3, 5	// tmp1053,
	csel	w3, w3, w4, ls	// tmp1055, tmp1053, tmp1267,
// /probe/scatter-baseline-pitch.cpp:141:   for (auto& track : tracks_) if (track.generation) track.missed = std::min(track.missed + 1, 5U);
	str	w3, [x2]	// tmp1055, MEM[(unsigned int *)_1250]
.L529:
// /probe/scatter-baseline-pitch.cpp:141:   for (auto& track : tracks_) if (track.generation) track.missed = std::min(track.missed + 1, 5U);
	add	x2, x2, 24	// ivtmp.1982, ivtmp.1982,
	cmp	x0, x2	// _1251, ivtmp.1982
	bne	.L530		//,
// /probe/scatter-baseline-pitch.cpp:143:   std::array<Prediction, kMaxPitchPartials> predictions{};
	add	x27, sp, 312	// prediction,,
	mov	x2, 4096	//,
	mov	w1, 0	//,
	mov	x0, x27	//, prediction
	bl	memset		//
	mov	x2, x19	// ivtmp.1971, _339
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	add	x4, sp, 320	// tmp1266,,
// /probe/scatter-baseline-pitch.cpp:145:   for (std::size_t t = 0; t < tracks_.size(); ++t)
	mov	x1, 0	// t,
// /probe/scatter-baseline-pitch.cpp:144:   std::size_t predicted = 0;
	mov	x19, 0	// predicted,
	.p2align 3,,7
.L528:
// /probe/scatter-baseline-pitch.cpp:146:     if (tracks_[t].generation && tracks_[t].missed <= 4)
	ldr	x3, [x2, 16]	// MEM <uint64_t> [(struct value_type &)_1259 + 16], MEM <uint64_t> [(struct value_type &)_1259 + 16]
	cbz	x3, .L532	// MEM <uint64_t> [(struct value_type &)_1259 + 16],
	ldr	w0, [x2, 8]	//, MEM <unsigned int> [(struct value_type &)_1259 + 8]
	cmp	w0, 4	// MEM <unsigned int> [(struct value_type &)_1259 + 8],
	bhi	.L532		//,
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	ldp	s0, s1, [x2]	// MEM <float> [(struct value_type &)_1259], MEM <float> [(struct value_type &)_1259 + 4], MEM <float> [(struct value_type &)_1259]
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	lsl	x0, x19, 4	// tmp1059, predicted,
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	add	x19, x19, 1	// predicted, predicted,
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	str	x1, [x4, x0]	// t, MEM <struct array> [(struct value_type *)&predictions]._M_elems[predicted_728].track
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	fadd	s0, s0, s1	// tmp1061, MEM <float> [(struct value_type &)_1259], MEM <float> [(struct value_type &)_1259 + 4]
// /probe/scatter-baseline-pitch.cpp:147:       predictions[predicted++] = {tracks_[t].frequency + tracks_[t].velocity, t};
	str	s0, [x27, x0]	// tmp1061, MEM <struct array> [(struct value_type *)&predictions]._M_elems[predicted_728].frequency
.L532:
// /probe/scatter-baseline-pitch.cpp:145:   for (std::size_t t = 0; t < tracks_.size(); ++t)
	add	x1, x1, 1	// t, t,
// /probe/scatter-baseline-pitch.cpp:145:   for (std::size_t t = 0; t < tracks_.size(); ++t)
	add	x2, x2, 24	// ivtmp.1971, ivtmp.1971,
	cmp	x1, 256	// t,
	bne	.L528		//,
// /probe/scatter-baseline-pitch.cpp:148:   std::sort(predictions.begin(), predictions.begin() + predicted, [](const auto& a, const auto& b) {
	lsl	x19, x19, 4	// _71, predicted,
// /probe/scatter-baseline-pitch.cpp:148:   std::sort(predictions.begin(), predictions.begin() + predicted, [](const auto& a, const auto& b) {
	add	x23, x27, x19	// _72, prediction, _71
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1945:       if (__first != __last)
	cbz	x19, .L533	// _71,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1948: 				std::__lg(__last - __first) * 2,
	asr	x0, x19, 4	// tmp1068, _71,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1518:       return std::__bit_width(make_unsigned_t<_Tp>(__n)) - 1;
	mov	w2, 63	// tmp1071,
	clz	x0, x0	// tmp1069, tmp1068
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	x1, x23	//, _72
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1518:       return std::__bit_width(make_unsigned_t<_Tp>(__n)) - 1;
	sub	w2, w2, w0	// tmp1070, tmp1071, tmp1069
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	x0, x27	//, prediction
	sbfiz	x2, x2, 1, 32	//, tmp1070,,
	bl	_ZSt16__introsort_loopIPZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEE10PredictionlN9__gnu_cxx5__ops15_Iter_comp_iterIZNS2_6updateES7_EUlRKT_RKT0_E1_EEEvSD_SD_SG_T1_.isra.0		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1857:       if (__last - __first > int(_S_threshold))
	cmp	x19, 256	// _71,
	bgt	.L628		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	cmp	x19, 16	// _71,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	add	x28, sp, 328	// __i,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	beq	.L533		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s8, [x28]	// _652, MEM[(float *)__i_905]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [sp, 312]	// _653, MEM[(const struct Prediction &)&predictions].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s8, s0	// _652, _653
	bne	.L550		//,
	.p2align 3,,7
.L754:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	x1, [x28, 8]	// MEM[(long unsigned int *)__i_905 + 8B], MEM[(long unsigned int *)__i_905 + 8B]
	ldr	x0, [sp, 320]	// MEM[(const struct Prediction &)&predictions].track, MEM[(const struct Prediction &)&predictions].track
	cmp	x1, x0	// MEM[(long unsigned int *)__i_905 + 8B], MEM[(const struct Prediction &)&predictions].track
	cset	w0, cc	// iftmp.174_656,
.L551:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	cbz	w0, .L753	// iftmp.174_656,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:746: 	  const ptrdiff_t _Num = __last - __first;
	sub	x2, x28, x27	// _673, __i, prediction
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldr	x4, [x28, 8]	// __val$track, MEM <size_t> [(struct Prediction &)__i_905 + 8]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 16	// _673,
	ble	.L552		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x0, 16	// tmp1372,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x1, x27	//, prediction
	str	x4, [sp, 8]	// __val$track, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	sub	x0, x0, x2	// tmp1109, tmp1372, _673
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	add	x0, x28, x0	//, __i, tmp1109
	bl	memmove		//
	ldr	x4, [sp, 8]	// __val$track, %sfp
.L553:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1824: 	      *__first = _GLIBCXX_MOVE(__val);
	str	s8, [sp, 312]	// _652, MEM <float> [(struct Prediction *)&predictions]
	str	x4, [sp, 320]	// __val$track, MEM <size_t> [(struct Prediction *)&predictions + 8B]
.L554:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1823: 	      _GLIBCXX_MOVE_BACKWARD3(__first, __i, __i + 1);
	add	x28, x28, 16	// __i, __i,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	cmp	x23, x28	// _72, __i
	beq	.L533		//,
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s8, [x28]	// _652, MEM[(float *)__i_905]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [sp, 312]	// _653, MEM[(const struct Prediction &)&predictions].frequency
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s8, s0	// _652, _653
	beq	.L754		//,
.L550:
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmpe	s8, s0	// _652, _653
	cset	w0, mi	// iftmp.174_656,
	b	.L551		//
	.p2align 2,,3
.L567:
// /probe/scatter-baseline-pitch.cpp:158:       if (used[prediction->track]) continue;
	ldr	x3, [x2, 8]	// _75, MEM[(long unsigned int *)prediction_710 + 8B]
// /probe/scatter-baseline-pitch.cpp:158:       if (used[prediction->track]) continue;
	ldrb	w0, [x26, x3]	// MEM <struct array> [(value_type &)&used]._M_elems[_75], MEM <struct array> [(value_type &)&used]._M_elems[_75]
	tbnz	x0, 0, .L565	// MEM <struct array> [(value_type &)&used]._M_elems[_75],,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:235:   { return __builtin_fabsf(__x); }
	fabd	s0, s2, s0	// _349, region$frequencyBins, _77
// /probe/scatter-baseline-pitch.cpp:160:       if (d < distance || (d == distance && prediction->track < match)) { distance = d; match = prediction->track; }
	fcmpe	s0, s1	// _349, distance
	bmi	.L631		//,
// /probe/scatter-baseline-pitch.cpp:160:       if (d < distance || (d == distance && prediction->track < match)) { distance = d; match = prediction->track; }
	cmp	x3, x1	// _75, t
	fccmp	s0, s1, 0, cc	// _349, distance,,
	cset	w0, eq	// tmp1137,
// /probe/scatter-baseline-pitch.cpp:160:       if (d < distance || (d == distance && prediction->track < match)) { distance = d; match = prediction->track; }
	cmp	w0, 0	// tmp1137,
	csel	x1, x3, x1, ne	// t, _75, t,
	fcsel	s1, s0, s1, ne	// distance, _349, distance,
.L565:
// /probe/scatter-baseline-pitch.cpp:157:     for (; prediction != predictions.begin() + predicted && prediction->frequency < region.frequencyBins + 2; ++prediction) {
	add	x2, x2, 16	// prediction, prediction,
// /probe/scatter-baseline-pitch.cpp:157:     for (; prediction != predictions.begin() + predicted && prediction->frequency < region.frequencyBins + 2; ++prediction) {
	cmp	x23, x2	// _72, prediction
	bne	.L564		//,
// /probe/scatter-baseline-pitch.cpp:163:     if (birth) {
	cmp	x1, 256	// t,
	bne	.L568		//,
.L563:
	add	x5, x25, x12	// ivtmp.1875, this, tmp1257
	mov	x3, x26	// ivtmp.1874, tmp1248
// /probe/scatter-baseline-pitch.cpp:154:     float distance = 2.0f;
	mov	x2, x5	// ivtmp.1885, ivtmp.1875
	mov	x0, x26	// ivtmp.1884, tmp1248
	mov	x1, 0	// t,
	b	.L571		//
	.p2align 2,,3
.L756:
// /probe/scatter-baseline-pitch.cpp:165:         if (!used[t] && (!tracks_[t].generation || tracks_[t].missed > 4)) { match = t; break; }
	ldr	w4, [x2]	//, MEM <unsigned int> [(struct value_type &)_1306]
	cmp	w4, 4	// MEM <unsigned int> [(struct value_type &)_1306],
	bhi	.L570		//,
.L569:
// /probe/scatter-baseline-pitch.cpp:164:       for (std::size_t t = 0; t < tracks_.size(); ++t)
	add	x1, x1, 1	// t, t,
// /probe/scatter-baseline-pitch.cpp:164:       for (std::size_t t = 0; t < tracks_.size(); ++t)
	add	x0, x0, 1	// ivtmp.1884, ivtmp.1884,
	cmp	x1, 256	// t,
	add	x2, x2, 24	// ivtmp.1885, ivtmp.1885,
	beq	.L755		//,
.L571:
// /probe/scatter-baseline-pitch.cpp:165:         if (!used[t] && (!tracks_[t].generation || tracks_[t].missed > 4)) { match = t; break; }
	ldrb	w4, [x0]	// MEM[(value_type &)_1308], MEM[(value_type &)_1308]
	tbnz	x4, 0, .L569	// MEM[(value_type &)_1308],,
	ldr	x4, [x2, 8]	// MEM <uint64_t> [(struct value_type &)_1306 + 8], MEM <uint64_t> [(struct value_type &)_1306 + 8]
	cbnz	x4, .L756	// MEM <uint64_t> [(struct value_type &)_1306 + 8],
.L570:
	lsl	x0, x1, 1	// tmp1250, t,
// /probe/scatter-baseline-pitch.cpp:175:     track.velocity = birth ? 0 : std::clamp(region.frequencyBins - track.frequency, -.5f, .5f);
	movi	v0.2s, #0	// iftmp.94_135
	add	x3, x0, x1	// tmp1160, tmp1250, t
	lsl	x3, x3, 3	// tmp1161, tmp1160,
	add	x2, x25, x3	// _219, this, tmp1161
// /probe/scatter-baseline-pitch.cpp:174:     if (birth) { track = {}; track.generation = ++generation_; }
	add	x3, x8, x3	// tmp1170, tmp1260, tmp1161
	str	xzr, [x2, 6232]	//, MEM <unsigned long> [(struct Track *)_219 + 6232B]
	str	wzr, [x2, 6240]	//, MEM <unsigned int> [(struct Track *)_219 + 6240B]
	str	xzr, [x3, 16]	//, MEM <struct array> [(struct Track *)this_160(D) + 6232B]._M_elems[match_518].generation
// /probe/scatter-baseline-pitch.cpp:174:     if (birth) { track = {}; track.generation = ++generation_; }
	ldr	x2, [x25, 12408]	// this_160(D)->generation_, this_160(D)->generation_
	add	x2, x2, 1	// pretmp_615, this_160(D)->generation_,
// /probe/scatter-baseline-pitch.cpp:174:     if (birth) { track = {}; track.generation = ++generation_; }
	str	x2, [x25, 12408]	// pretmp_615, this_160(D)->generation_
	str	x2, [x3, 16]	// pretmp_615, MEM <struct array> [(struct Track &)this_160(D) + 6232]._M_elems[match_518].generation
	b	.L577		//
	.p2align 2,,3
.L650:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1476: 	      __len = __len - __half - 1;
	sub	x1, x1, x3	// _692, __len, __half
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1475: 	      ++__first;
	add	x2, x0, 16	// prediction, _705,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1476: 	      __len = __len - __half - 1;
	sub	x1, x1, #1	// __len, _692,
	b	.L560		//
	.p2align 2,,3
.L631:
// /probe/scatter-baseline-pitch.cpp:160:       if (d < distance || (d == distance && prediction->track < match)) { distance = d; match = prediction->track; }
	fmov	s1, s0	// distance, _349
// /probe/scatter-baseline-pitch.cpp:160:       if (d < distance || (d == distance && prediction->track < match)) { distance = d; match = prediction->track; }
	mov	x1, x3	// t, _75
	b	.L565		//
	.p2align 2,,3
.L635:
	fmov	s0, 5.0e-1	// iftmp.94_135,
	b	.L575		//
	.p2align 2,,3
.L634:
	fmov	s0, -5.0e-1	// iftmp.94_135,
	b	.L575		//
.L753:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x4, [x28, 8]	// __val$track, MEM[(long unsigned int *)__i_905 + 8B]
	mov	x2, x28	// ivtmp.1955, __i
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	b	.L555		//
	.p2align 2,,3
.L757:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldr	x1, [x0, -8]	// MEM[(long unsigned int *)__last_664 + -8B], MEM[(long unsigned int *)__last_664 + -8B]
	sub	x2, x2, #16	// ivtmp.1955, ivtmp.1955,
	cmp	x4, x1	// __val$track, MEM[(long unsigned int *)__last_664 + -8B]
	bcs	.L558		//,
.L557:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x0, x1, [x2]	// MEM[(struct Prediction &)_1273], MEM[(struct Prediction &)_1273]
	stp	x0, x1, [x2, 16]	// MEM[(struct Prediction &)_1273], MEM[(struct Prediction *)_1273 + 16B]
.L555:
	mov	x0, x2	// __last, ivtmp.1955
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x2, -16]	// _666, MEM[(float *)__last_664 + -16B]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s8, s0	// _652, _666
	beq	.L757		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	fcmpe	s8, s0	// _652, _666
	sub	x2, x2, #16	// ivtmp.1955, ivtmp.1955,
	bmi	.L557		//,
.L558:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	str	s8, [x0]	// _652, __last_664->frequency
	str	x4, [x0, 8]	// __val$track, __last_664->track
	b	.L554		//
.L638:
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 76
	.cfi_restore 77
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	add	x0, x25, 12288	// tmp683, this,
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	ldr	x21, [sp, 4448]	//,
	.cfi_restore 21
	ldr	x22, [sp, 4456]	//,
	.cfi_restore 22
	ldr	x23, [sp, 4464]	//,
	.cfi_restore 23
	ldr	x24, [sp, 4472]	//,
	.cfi_restore 24
	ldr	x27, [sp, 4496]	//,
	.cfi_restore 27
	ldr	x28, [sp, 4504]	//,
	.cfi_restore 28
	ldr	d8, [sp, 4512]	//,
	.cfi_restore 72
	ldr	d9, [sp, 4520]	//,
	.cfi_restore 73
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	str	xzr, [x25, 12376]	//, this_160(D)->spectrum_._M_ptr
	str	xzr, [x25, 12384]	//, MEM <size_t> [(struct PitchFrame *)this_160(D) + 12384B]
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	strb	wzr, [x0, 128]	//, this_160(D)->previous_
// /probe/scatter-baseline-pitch.cpp:107:     if (!std::isfinite(magnitude_[k])) { spectrum_ = {}; previous_ = false; return; }
	b	.L367		//
.L749:
	.cfi_offset 21, -128
	.cfi_offset 22, -120
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 27, -80
	.cfi_offset 28, -72
	.cfi_offset 72, -64
	.cfi_offset 73, -56
	.cfi_offset 74, -48
	.cfi_offset 75, -40
	.cfi_offset 76, -32
	.cfi_offset 77, -24
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	cbz	x21, .L428	// _3,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	ldr	s0, [x19, 4]	// MEM[(value_type &)_1127 + 4], MEM[(value_type &)_1127 + 4]
	fcmpe	s0, s8	// MEM[(value_type &)_1127 + 4], _318
	bgt	.L407		//,
.L428:
// /probe/scatter-baseline-pitch.cpp:117:     if (k == 0 || k == half) frequency = static_cast<float>(k);
	scvtf	s0, x26	// _492, ivtmp.2088
	b	.L418		//
.L609:
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	x26, x3	// ivtmp.2088, _562
	b	.L405		//
.L642:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:263: 	return __b;
	movi	v0.2s, #0	// _492
	b	.L410		//
	.p2align 2,,3
.L536:
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmpe	s8, s0	// _619, _620
	cset	w0, mi	// iftmp.174_623,
	b	.L537		//
.L741:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x4, [x28, 8]	// __val$track, MEM[(long unsigned int *)__i_709 + 8B]
	mov	x2, x28	// ivtmp.1932, __i
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	b	.L541		//
	.p2align 2,,3
.L758:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldr	x1, [x0, -8]	// MEM[(long unsigned int *)__last_631 + -8B], MEM[(long unsigned int *)__last_631 + -8B]
	sub	x2, x2, #16	// ivtmp.1932, ivtmp.1932,
	cmp	x4, x1	// __val$track, MEM[(long unsigned int *)__last_631 + -8B]
	bcs	.L544		//,
.L543:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x0, x1, [x2]	// MEM[(struct Prediction &)_1284], MEM[(struct Prediction &)_1284]
	stp	x0, x1, [x2, 16]	// MEM[(struct Prediction &)_1284], MEM[(struct Prediction *)_1284 + 16B]
.L541:
	mov	x0, x2	// __last, ivtmp.1932
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	ldr	s0, [x2, -16]	// _633, MEM[(float *)__last_631 + -16B]
// /probe/scatter-baseline-pitch.cpp:149:     return a.frequency == b.frequency ? a.track < b.track : a.frequency < b.frequency;
	fcmp	s8, s0	// _619, _633
	beq	.L758		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	fcmpe	s8, s0	// _619, _633
	sub	x2, x2, #16	// ivtmp.1932, ivtmp.1932,
	bmi	.L543		//,
.L544:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	str	s8, [x0]	// _619, __last_631->frequency
	str	x4, [x0, 8]	// __val$track, __last_631->track
	b	.L540		//
.L602:
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	x26, 0	// ivtmp.2088,
	mov	x24, 0	// candidates,
	str	d14, [sp, 4560]	//,
	.cfi_remember_state
	.cfi_offset 78, -16
	add	x22, x25, 12288	// tmp1249, this,
	str	d15, [sp, 4568]	//,
	.cfi_offset 79, -8
	b	.L379		//
.L750:
	.cfi_restore_state
// /probe/scatter-baseline-pitch.cpp:132:     ++capacityEvents_;
	ldr	x0, [x25, 12400]	// this_160(D)->capacityEvents_, this_160(D)->capacityEvents_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldr	x23, [x25, 64]	// prephitmp_782, MEM[(struct PitchRegion * const &)this_160(D) + 64]
// /probe/scatter-baseline-pitch.cpp:132:     ++capacityEvents_;
	add	x0, x0, 1	// tmp850, this_160(D)->capacityEvents_,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x26, x23, x18	// _335, prephitmp_782, tmp849
// /probe/scatter-baseline-pitch.cpp:132:     ++capacityEvents_;
	str	x0, [x25, 12400]	// tmp850, this_160(D)->capacityEvents_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x19, x23, 24	// prephitmp_435, prephitmp_782,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1945:       if (__first != __last)
	cmp	x26, x23	// _335, prephitmp_782
	beq	.L737		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mov	x0, -6148914691236517206	// tmp855,
	asr	x2, x18, 3	// tmp853, tmp849,
	movk	x0, 0xaaab, lsl 0	// tmp855,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1518:       return std::__bit_width(make_unsigned_t<_Tp>(__n)) - 1;
	mov	w5, 63	// tmp858,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	w3, 0	//,
	mov	x1, x26	//, _335
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1337:     { return __lhs.base() - __rhs.base(); }
	mul	x2, x2, x0	// tmp854, tmp853, tmp855
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	x0, x23	//, prephitmp_782
	clz	x2, x2	// tmp856, tmp854
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1518:       return std::__bit_width(make_unsigned_t<_Tp>(__n)) - 1;
	sub	w2, w5, w2	// tmp857, tmp858, tmp856
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	sbfiz	x2, x2, 1, 32	//, tmp857,,
	bl	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E_EEEvSI_SI_SL_T1_		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1857:       if (__last - __first > int(_S_threshold))
	cmp	x18, 384	// tmp849,
	ble	.L477		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x27, x23, 384	// _429, prephitmp_782,
	mov	x24, x23	// ivtmp.2062, prephitmp_782
	add	x28, sp, 32	// tmp1246,,
.L487:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x19, 20]	// _436, MEM[(float *)__i$_M_current_502 + 20B]
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x23, 20]	// _437, MEM[(const struct PitchRegion &)_337].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _436, _437
	bne	.L478		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w0, [x23]	// MEM[(const struct PitchRegion &)_337].bin, MEM[(const struct PitchRegion &)_337].bin
	ldrh	w1, [x19]	// MEM[(short unsigned int *)__i$_M_current_502], MEM[(short unsigned int *)__i$_M_current_502]
	cmp	w1, w0	// MEM[(short unsigned int *)__i$_M_current_502], MEM[(const struct PitchRegion &)_337].bin
	cset	w0, cc	// iftmp.111_214,
.L479:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	cbz	w0, .L759	// iftmp.111_214,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion &)__i$_M_current_502]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:746: 	  const ptrdiff_t _Num = __last - __first;
	sub	x2, x19, x23	// _445, ivtmp.2056, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 24	// _445,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldr	x3, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion &)__i$_M_current_502]
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion *)_358]
	str	x3, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	ble	.L480		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x0, 24	// tmp1367,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x1, x23	//, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	sub	x0, x0, x2	// tmp874, tmp1367, _445
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	add	x0, x19, x0	//, ivtmp.2056, tmp874
	bl	memmove		//
.L481:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1824: 	      *__first = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_358], *_337
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_358], *_337
.L482:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	add	x19, x19, 24	// ivtmp.2056, ivtmp.2056,
	add	x24, x24, 24	// ivtmp.2062, ivtmp.2062,
	cmp	x27, x19	// _429, ivtmp.2056
	bne	.L487		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	cmp	x26, x27	// _335, _429
	mov	x5, x27	// ivtmp.2036, _429
	add	x4, x23, 360	// ivtmp.2038, prephitmp_782,
	beq	.L736		//,
.L493:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldp	x2, x3, [x5]	// MEM[(struct PitchRegion &)_1195], MEM[(struct PitchRegion &)_1195]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1126: 	return *this;
	mov	x1, x5	// ivtmp.2031, ivtmp.2036
	mov	x0, x4	// ivtmp.2028, ivtmp.2038
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x6, [x5, 16]	// MEM[(struct PitchRegion &)_1195], MEM[(struct PitchRegion &)_1195]
	stp	x2, x3, [x28]	// MEM[(struct PitchRegion &)_1195], MEM[(struct PitchRegion *)_358]
	ldr	s1, [x5, 20]	// __val$magnitude, MEM[(float *)_1195 + 20B]
	str	x6, [x28, 16]	// MEM[(struct PitchRegion &)_1195], MEM[(struct PitchRegion *)_358]
	ldrh	w6, [x5]	// __val$bin, MEM[(short unsigned int *)_1195]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1126: 	return *this;
	b	.L489		//
	.p2align 2,,3
.L760:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w2, [x0]	// MEM[(short unsigned int *)_1204], MEM[(short unsigned int *)_1204]
	cmp	w2, w6	// MEM[(short unsigned int *)_1204], __val$bin
	bls	.L492		//,
.L491:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x2, x3, [x0]	// MEM[(struct PitchRegion &)_1204], MEM[(struct PitchRegion &)_1204]
	sub	x1, x1, #24	// ivtmp.2031, ivtmp.2031,
	sub	x0, x0, #24	// ivtmp.2028, ivtmp.2028,
	stp	x2, x3, [x1, 24]	// MEM[(struct PitchRegion &)_1204], MEM[(struct PitchRegion *)__last$_M_current_473]
	ldr	x2, [x0, 40]	// MEM[(struct PitchRegion &)_1204], MEM[(struct PitchRegion &)_1204]
	str	x2, [x1, 40]	// MEM[(struct PitchRegion &)_1204], MEM[(struct PitchRegion *)__last$_M_current_473]
.L489:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x0, 20]	// _475, MEM[(float *)_1204 + 20B]
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// __val$magnitude, _475
	beq	.L760		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	fcmpe	s1, s0	// __val$magnitude, _475
	bgt	.L491		//,
.L492:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldp	x2, x3, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	add	x5, x5, 24	// ivtmp.2036, ivtmp.2036,
	add	x4, x4, 24	// ivtmp.2038, ivtmp.2038,
	cmp	x26, x5	// _335, ivtmp.2036
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldr	x0, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x2, x3, [x1]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_473
	str	x0, [x1, 16]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_473
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1839:       for (_RandomAccessIterator __i = __first; __i != __last; ++__i)
	bne	.L493		//,
.L736:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldr	x23, [x25, 64]	// prephitmp_782, MEM[(struct PitchRegion * const &)this_160(D) + 64]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x19, x23, 24	// prephitmp_435, prephitmp_782,
.L476:
	mov	x4, 6144	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	w3, 0	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x27, x23, x4	// _778, prephitmp_782,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	mov	x2, 16	//,
	mov	x1, x27	//, _778
	mov	x0, x23	//, prephitmp_782
// /probe/scatter-baseline-pitch.cpp:136:     candidates = regions_.size();
	mov	x24, 256	// candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1947: 	  std::__introsort_loop(__first, __last,
	bl	_ZSt16__introsort_loopIN9__gnu_cxx17__normal_iteratorIPN5ardor4pog311PitchRegionESt6vectorIS4_SaIS4_EEEElNS0_5__ops15_Iter_comp_iterIZNS3_10PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EEEUlRKT_RKT0_E0_EEEvSI_SI_SL_T1_		//
.L505:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1148:       { return __normal_iterator(_M_current + __n); }
	add	x26, x23, 384	// __i$_M_current, prephitmp_782,
	b	.L514		//
	.p2align 2,,3
.L762:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldr	x3, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion &)__i$_M_current_576]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:746: 	  const ptrdiff_t _Num = __last - __first;
	sub	x2, x19, x23	// _541, ivtmp.2010, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 24	// _541,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion *)_358]
	str	x3, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	ble	.L509		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x0, 24	// tmp1368,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x1, x23	//, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	sub	x0, x0, x2	// tmp970, tmp1368, _541
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	add	x0, x19, x0	//, ivtmp.2010, tmp970
	bl	memmove		//
.L510:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1824: 	      *__first = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_358], *_1172
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_358], *_1172
.L511:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	add	x19, x19, 24	// ivtmp.2010, ivtmp.2010,
	cmp	x26, x19	// __i$_M_current, ivtmp.2010
	beq	.L761		//,
.L514:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	ldrh	w0, [x23]	// MEM[(const struct PitchRegion &)_1172].bin, MEM[(const struct PitchRegion &)_1172].bin
	mov	x7, x19	// __last$_M_current, ivtmp.2010
// /probe/scatter-baseline-pitch.cpp:139:             [](const auto& a, const auto& b) { return a.bin < b.bin; });
	ldrh	w6, [x19]	// _537, MEM[(short unsigned int *)__i$_M_current_576]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	cmp	w0, w6	// MEM[(const struct PitchRegion &)_1172].bin, _537
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion &)__i$_M_current_576]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	bhi	.L762		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1125: 	--_M_current;
	sub	x2, x19, #24	// _556, ivtmp.2010,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion *)_358]
	ldr	x3, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion &)__i$_M_current_576]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w0, [x19, -24]	// MEM[(short unsigned int *)__i$_M_current_576 + -24B], MEM[(short unsigned int *)__i$_M_current_576 + -24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	str	x3, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_576], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	cmp	w0, w6	// MEM[(short unsigned int *)__i$_M_current_576 + -24B], _537
	bls	.L512		//,
	mov	x3, x19	// ivtmp.2005, ivtmp.2010
	.p2align 3,,7
.L513:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x0, x1, [x2]	// MEM[(struct PitchRegion &)__next$_M_current_577], MEM[(struct PitchRegion &)__next$_M_current_577]
	mov	x7, x2	// __last$_M_current, _556
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	sub	x3, x3, #24	// ivtmp.2005, ivtmp.2005,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	stp	x0, x1, [x3, 24]	// MEM[(struct PitchRegion &)__next$_M_current_577], MEM[(struct PitchRegion *)_1239]
	ldr	x0, [x2, 16]	// MEM[(struct PitchRegion &)__next$_M_current_577], MEM[(struct PitchRegion &)__next$_M_current_577]
	str	x0, [x3, 40]	// MEM[(struct PitchRegion &)__next$_M_current_577], MEM[(struct PitchRegion *)_1239]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w0, [x2, -24]!	// MEM[(short unsigned int *)_556], MEM[(short unsigned int *)_556]
	cmp	w0, w6	// MEM[(short unsigned int *)_556], _537
	bhi	.L513		//,
.L512:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x7]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_583
	str	x2, [x7, 16]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_583
	b	.L511		//
.L745:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:436: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 8	// _355,
	ble	.L588		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:437: 	    __builtin_memmove(__result, __first, sizeof(_Tp) * _Num);
	mov	x1, x20	//, spectrum
	bl	memmove		//
	b	.L583		//
.L417:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fsub	d2, d13, d2	// tmp748, a, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmov	d4, 5.0e-1	// tmp750,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	d5, -5.0e-1	// tmp751,
	fmov	s3, -5.0e-1	// iftmp.82_617,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmul	d2, d2, d4	// tmp749, tmp748, tmp750
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fdiv	d0, d2, d0	// _171, tmp749, denominator
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	d0, d5	// _171, tmp751
	bmi	.L421		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	d0, d4	// _171, tmp750
	fmov	s3, 5.0e-1	// iftmp.82_617,
	bgt	.L421		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcvt	s3, d0	// iftmp.82_617, _171
	b	.L421		//
.L391:
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fsub	d2, d11, d0	// tmp708, a, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmov	d4, 5.0e-1	// tmp710,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	d5, -5.0e-1	// tmp711,
	fmov	s0, -5.0e-1	// prephitmp_676,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmul	d2, d2, d4	// tmp709, tmp708, tmp710
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fdiv	d1, d2, d1	// _683, tmp709, denominator
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	d1, d5	// _683, tmp711
	bmi	.L395		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	d1, d4	// _683, tmp710
	fmov	s0, 5.0e-1	// prephitmp_676,
	bgt	.L395		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcvt	s0, d1	// prephitmp_676, _683
	b	.L395		//
.L755:
	mov	x0, 0	// t,
	mov	w4, 0	// oldest,
	.p2align 3,,7
.L573:
// /probe/scatter-baseline-pitch.cpp:169:           if (!used[t] && tracks_[t].missed > oldest) { oldest = tracks_[t].missed; match = t; }
	ldrb	w2, [x3]	// MEM[(value_type &)_1317], MEM[(value_type &)_1317]
	tbnz	x2, 0, .L572	// MEM[(value_type &)_1317],,
// /probe/scatter-baseline-pitch.cpp:169:           if (!used[t] && tracks_[t].missed > oldest) { oldest = tracks_[t].missed; match = t; }
	ldr	w2, [x5]	//, MEM <unsigned int> [(struct value_type &)_1316]
// /probe/scatter-baseline-pitch.cpp:169:           if (!used[t] && tracks_[t].missed > oldest) { oldest = tracks_[t].missed; match = t; }
	cmp	w2, w4	// _83, oldest
	csel	x1, x0, x1, hi	// t, t, t,
	csel	w4, w2, w4, hi	// oldest, _83, oldest,
.L572:
// /probe/scatter-baseline-pitch.cpp:168:         for (std::size_t t = 0; t < tracks_.size(); ++t)
	add	x0, x0, 1	// t, t,
// /probe/scatter-baseline-pitch.cpp:168:         for (std::size_t t = 0; t < tracks_.size(); ++t)
	add	x3, x3, 1	// ivtmp.1874, ivtmp.1874,
	cmp	x0, 256	// t,
	add	x5, x5, 24	// ivtmp.1875, ivtmp.1875,
	bne	.L573		//,
// /probe/scatter-baseline-pitch.cpp:172:     if (match == tracks_.size()) { ++capacityEvents_; continue; }
	cmp	x1, 256	// t,
	bne	.L570		//,
// /probe/scatter-baseline-pitch.cpp:172:     if (match == tracks_.size()) { ++capacityEvents_; continue; }
	ldr	x0, [x25, 12400]	// this_160(D)->capacityEvents_, this_160(D)->capacityEvents_
	add	x0, x0, 1	// tmp1145, this_160(D)->capacityEvents_,
	str	x0, [x25, 12400]	// tmp1145, this_160(D)->capacityEvents_
	b	.L574		//
.L613:
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	mov	x26, 0	// ivtmp.2103,
	mov	x24, 0	// candidates,
	str	d14, [sp, 4560]	//,
	.cfi_offset 78, -16
	add	x22, x25, 12288	// tmp1249, this,
	str	d15, [sp, 4568]	//,
	.cfi_offset 79, -8
.L433:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1310,
	movk	w0, 0x1e3c, lsl 16	// tmp1310,,
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmov	d12, 2.0e+0	// tmp1277,
	add	x19, x19, x26, lsl 2	// ivtmp.2105, _808, ivtmp.2103,
	add	x1, x25, 40	// tmp1247, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	s11, w0	// tmp1276, tmp1310
	add	x28, x20, x26, lsl 3	// ivtmp.2107, spectrum, ivtmp.2103,
	str	x1, [sp, 24]	// tmp1247, %sfp
	.p2align 3,,7
.L472:
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	ldr	s10, [x19]	// _426, MEM[(value_type &)_1088]
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fcmpe	s10, s8	// _426, _479
	bls	.L456		//,
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	cbnz	x26, .L457	// ivtmp.2103,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	cbz	x21, .L458	// _3,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	ldr	s0, [x19, 4]	// MEM[(value_type &)_1088 + 4], MEM[(value_type &)_1088 + 4]
	fcmpe	s10, s0	// _426, MEM[(value_type &)_1088 + 4]
	bmi	.L456		//,
.L458:
// /probe/scatter-baseline-pitch.cpp:117:     if (k == 0 || k == half) frequency = static_cast<float>(k);
	scvtf	s0, x26	// frequency, ivtmp.2103
.L464:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x2, [x25, 64]	// MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x1, x24, x24, lsl 1	// tmp842, candidates, candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// frequency
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	scvtf	s1, x21	// _91, _3
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	add	x24, x24, 1	// candidates, candidates,
	and	w3, w26, 65535	// _1084, ivtmp.2103
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	lsl	x1, x1, 3	// tmp843, tmp842,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x0, x2, x1	// _639, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, tmp843
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	bmi	.L649		//,
.L469:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcmpe	s1, s0	// _91, frequency
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	strh	w3, [x2, x1]	// _1084, _639->bin
	strh	wzr, [x0, 2]	//, _639->first
	str	wzr, [x0, 4]	//, MEM <unsigned int> [(short unsigned int *)_639 + 4B]
	str	xzr, [x0, 8]	//, _639->generation
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcsel	s1, s1, s0, mi	// _91, _91, frequency,
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	stp	s1, s10, [x0, 16]	// _91, _426, _639->frequencyBins
.L456:
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	add	x26, x26, 1	// ivtmp.2103, ivtmp.2103,
	add	x19, x19, 4	// ivtmp.2105, ivtmp.2105,
	cmp	x27, x26	// _658, ivtmp.2103
	add	x28, x28, 8	// ivtmp.2107, ivtmp.2107,
	bcs	.L472		//,
	b	.L734		//
.L737:
	.cfi_restore 78
	.cfi_restore 79
	add	x28, sp, 32	// tmp1246,,
	b	.L476		//
.L747:
// /probe/scatter-baseline-pitch.cpp:113:     if (magnitude_[k] <= std::max(1e-7f, maximum * .00001f)
	ldr	s13, [x23, 4]!	// _55, MEM[(value_type &)_466]
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	add	x4, x4, 8	// ivtmp.2115, ivtmp.2115,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	add	x1, x26, 1	// _286, ivtmp.2103,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fcmpe	s13, s8	// _55, _479
	bls	.L621		//,
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	ldr	s0, [x23, -4]	// _22, MEM[(value_type &)_466 + 18446744073709551612]
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	fcmpe	s0, s13	// _22, _55
	bge	.L621		//,
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	ldr	s12, [x23, 4]	// _706, MEM[(value_type &)_466 + 4]
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	fcmpe	s13, s12	// _55, _706
	bmi	.L621		//,
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	ldrb	w0, [x22, 128]	// this_160(D)->previous_, this_160(D)->previous_
	tbnz	x0, 0, .L763	// this_160(D)->previous_,,
.L439:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1312,
	movk	w0, 0x1e3c, lsl 16	// tmp1312,,
	fmov	s1, w0	// tmp785, tmp1312
	fcmpe	s0, s1	// _22, tmp785
	bmi	.L615		//,
.L444:
	stp	x1, x4, [sp, 8]	// _286, ivtmp.2115, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
	fmov	s10, s0	// tmp1297,
	fmov	s0, s13	//, _55
// /probe/scatter-baseline-pitch.cpp:122:       const double a = std::log(std::max(magnitude_[k - 1], 1e-20f));
	fcvt	d10, s10	// a, tmp1297
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1311,
	movk	w0, 0x1e3c, lsl 16	// tmp1311,,
	ldp	x1, x4, [sp, 8]	// _286, ivtmp.2115, %sfp
// /probe/scatter-baseline-pitch.cpp:123:       const double b = std::log(std::max(magnitude_[k], 1e-20f));
	fcvt	d11, s0	// b, tmp1298
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	s1, w0	// tmp793, tmp1311
	fcmpe	s12, s1	// _706, tmp793
	bmi	.L616		//,
.L446:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	fmov	s0, s12	//, _706
	stp	x1, x4, [sp, 8]	// _286, ivtmp.2115, %sfp
	bl	logf		//
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmov	d2, 2.0e+0	// tmp794,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	ldp	x1, x4, [sp, 8]	// _286, ivtmp.2115, %sfp
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	scvtf	s1, x26	// _48, ivtmp.2103
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	movi	v3.2s, #0	// iftmp.82_134
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmsub	d11, d11, d2, d10	// _47, b, tmp794, a
// /probe/scatter-baseline-pitch.cpp:124:       const double c = std::log(std::max(magnitude_[k + 1], 1e-20f));
	fcvt	d2, s0	// c, tmp1299
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fadd	d0, d11, d2	// denominator, _47, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcmp	d0, #0.0	// denominator
	beq	.L447		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fsub	d2, d10, d2	// tmp795, a, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmov	d4, 5.0e-1	// tmp797,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	d5, -5.0e-1	// tmp798,
	fmov	s3, -5.0e-1	// iftmp.82_134,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmul	d2, d2, d4	// tmp796, tmp795, tmp797
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fdiv	d0, d2, d0	// _51, tmp796, denominator
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	d0, d5	// _51, tmp798
	bmi	.L447		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	d0, d4	// _51, tmp797
	fmov	s3, 5.0e-1	// iftmp.82_134,
	bgt	.L447		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcvt	s3, d0	// iftmp.82_134, _51
.L447:
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fadd	s0, s1, s3	// _54, _48, iftmp.82_134
.L445:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x3, [x25, 64]	// MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x0, x24, x24, lsl 1	// tmp804, candidates, candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// _54
// /probe/scatter-baseline-pitch.cpp:129:       std::clamp(frequency, 0.0f, static_cast<float>(half)), magnitude_[k]};
	scvtf	s1, x21	// _57, _3
	and	w2, w26, 65535	// _1067, ivtmp.2103
// /probe/scatter-baseline-pitch.cpp:128:     candidates_[candidates++] = {static_cast<std::uint16_t>(k), 0, 0, 0, 0,
	add	x24, x24, 1	// candidates, candidates,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x0, x3, x0, lsl 3	// _333, MEM[(struct vector *)this_160(D) + 64B].D.223596._M_impl.D.222934._M_start, tmp804,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	bmi	.L646		//,
	mov	x26, x1	// ivtmp.2103, _286
	b	.L438		//
.L457:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	ldr	s0, [x19, -4]	// _950, MEM[(value_type &)_1088 + 18446744073709551612]
// /probe/scatter-baseline-pitch.cpp:114:         || (k && magnitude_[k] <= magnitude_[k - 1])
	fcmpe	s10, s0	// _426, _950
	bls	.L456		//,
// /probe/scatter-baseline-pitch.cpp:117:     if (k == 0 || k == half) frequency = static_cast<float>(k);
	cmp	x21, x26	// _3, ivtmp.2103
	beq	.L458		//,
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	ldrb	w0, [x22, 128]	// this_160(D)->previous_, this_160(D)->previous_
	tbnz	x0, 0, .L764	// this_160(D)->previous_,,
.L459:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, s11	// _950, tmp1276
	bmi	.L622		//,
.L465:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
	fmov	s13, s0	// tmp1303,
	fmov	s0, s10	//, _426
// /probe/scatter-baseline-pitch.cpp:122:       const double a = std::log(std::max(magnitude_[k - 1], 1e-20f));
	fcvt	d13, s13	// a, tmp1303
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
// /probe/scatter-baseline-pitch.cpp:123:       const double b = std::log(std::max(magnitude_[k], 1e-20f));
	fcvt	d14, s0	// b, tmp1304
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	ldr	s0, [x19, 4]	// _964, MEM[(const float &)_1088 + 4]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, s11	// _964, tmp1276
	bmi	.L623		//,
.L466:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:323:   { return __builtin_logf(__x); }
	bl	logf		//
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fmsub	d14, d14, d12, d13	// _970, b, tmp1277, a
// /probe/scatter-baseline-pitch.cpp:124:       const double c = std::log(std::max(magnitude_[k + 1], 1e-20f));
	fcvt	d2, s0	// c, tmp1305
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	scvtf	s1, x26	// _973, ivtmp.2103
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	movi	v3.2s, #0	// iftmp.82_974
// /probe/scatter-baseline-pitch.cpp:125:       const double denominator = a - 2 * b + c;
	fadd	d0, d2, d14	// denominator, c, _970
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcmp	d0, #0.0	// denominator
	beq	.L467		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fsub	d2, d13, d2	// tmp833, a, c
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmov	d4, 5.0e-1	// tmp835,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	d5, -5.0e-1	// tmp836,
	fmov	s3, -5.0e-1	// iftmp.82_974,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fmul	d2, d2, d4	// tmp834, tmp833, tmp835
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fdiv	d0, d2, d0	// _978, tmp834, denominator
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	d0, d5	// _978, tmp836
	bmi	.L467		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	d0, d4	// _978, tmp835
	fmov	s3, 5.0e-1	// iftmp.82_974,
	bgt	.L467		//,
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fcvt	s3, d0	// iftmp.82_974, _978
.L467:
// /probe/scatter-baseline-pitch.cpp:126:       frequency = k + static_cast<float>(denominator == 0 ? 0 : std::clamp(.5 * (a - c) / denominator, -.5, .5));
	fadd	s0, s1, s3	// frequency, _973, iftmp.82_974
	b	.L464		//
.L478:
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s1, s0	// _436, _437
	cset	w0, gt	// iftmp.111_214,
	b	.L479		//
.L759:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion &)__i$_M_current_502]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1126: 	return *this;
	mov	x3, x19	// ivtmp.2053, ivtmp.2056
	mov	x2, x24	// ivtmp.2047, ivtmp.2062
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x7, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion &)__i$_M_current_502]
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion *)_358]
	ldrh	w5, [x19]	// __val$bin, MEM[(short unsigned int *)__i$_M_current_502]
	str	x7, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_502], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1126: 	return *this;
	b	.L483		//
	.p2align 2,,3
.L765:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w0, [x2]	// MEM[(short unsigned int *)_1181], MEM[(short unsigned int *)_1181]
	cmp	w0, w5	// MEM[(short unsigned int *)_1181], __val$bin
	bls	.L486		//,
.L485:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x0, x1, [x2]	// MEM[(struct PitchRegion &)_1181], MEM[(struct PitchRegion &)_1181]
	sub	x3, x3, #24	// ivtmp.2053, ivtmp.2053,
	sub	x2, x2, #24	// ivtmp.2047, ivtmp.2047,
	stp	x0, x1, [x3, 24]	// MEM[(struct PitchRegion &)_1181], MEM[(struct PitchRegion *)__last$_M_current_460]
	ldr	x0, [x2, 40]	// MEM[(struct PitchRegion &)_1181], MEM[(struct PitchRegion &)_1181]
	str	x0, [x3, 40]	// MEM[(struct PitchRegion &)_1181], MEM[(struct PitchRegion *)__last$_M_current_460]
.L483:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x2, 20]	// _462, MEM[(float *)_1181 + 20B]
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _436, _462
	beq	.L765		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	fcmpe	s1, s0	// _436, _462
	bgt	.L485		//,
.L486:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x3]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_460
	str	x2, [x3, 16]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_460
	b	.L482		//
.L621:
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	x26, x1	// ivtmp.2103, _286
	b	.L453		//
.L627:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	mov	x4, x26	// __last$_M_current, __i$_M_current
	b	.L517		//
.L646:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:263: 	return __b;
	movi	v0.2s, #0	// _54
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	x26, x1	// ivtmp.2103, _286
	b	.L438		//
.L649:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:263: 	return __b;
	movi	v0.2s, #0	// frequency
	b	.L469		//
.L388:
	.cfi_restore 78
	.cfi_restore 79
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x2, [x25, 40]	// MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start
	lsl	x0, x26, 3	// tmp715, ivtmp.2088,
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	movi	v2.2s, 0x80, lsl 16	// tmp718
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x4, x2, x0	// _643, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, tmp715
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1381:       real() const { return __real__ _M_value; }
	ldr	s11, [x2, x0]	// _637, MEM[(const struct complex &)_643]._M_value
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1385:       imag() const { return __imag__ _M_value; }
	ldr	s8, [x4, 4]	// _618, MEM[(const struct complex &)_643]._M_value
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmul	s1, s8, s8	// tmp717, _618, _618
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmadd	s1, s11, s11, s1	// squared, _637, _637, tmp717
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fcmpe	s1, s2	// squared, tmp718
	bge	.L397		//,
.L400:
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d2, s8	// imaginary, _618
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d1, s11	// real, _637
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmul	d2, d2, d2	// tmp719, imaginary, imaginary
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmadd	d1, d1, d1, d2	// _566, real, real, tmp719
	fsqrt	d1, d1	// _559, _566
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fcvt	s1, d1	// _554, _559
.L401:
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	mov	w0, 49045	// tmp1323,
	movk	w0, 0x33d6, lsl 16	// tmp1323,,
	fmov	s2, w0	// tmp720, tmp1323
	fcmpe	s1, s2	// _554, tmp720
	bgt	.L641		//,
	b	.L398		//
.L641:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:903:   __complex_arg(__complex__ float __z) { return __builtin_cargf(__z); }
	ldp	s1, s0, [x1]	//,, MEM[(float *)_1105]
	stp	x1, x3, [sp, 8]	// ivtmp.2099, _562, %sfp
	bl	atan2f		//
	fmov	s2, s0	// tmp1285,
	fmov	s0, s8	//, _618
	fmov	s1, s11	//, _637
	fmov	s8, s2	// _534, tmp1285
	bl	atan2f		//
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fsub	s0, s8, s0	// tmp723, _534, tmp1286
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	scvtf	d8, x26	// _481, ivtmp.2088
	adrp	x0, .LC2	// tmp1357,
	ldr	d1, [x0, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fcvt	d0, s0	// tmp724, tmp723
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmsub	d0, d9, d8, d0	//, step, _481, tmp724
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fdiv	d0, d0, d9	// tmp726, tmp1287, step
	ldp	x1, x3, [sp, 8]	// ivtmp.2099, _562, %sfp
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fadd	d0, d0, d8	// tmp727, tmp726, _481
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fcvt	s0, d0	// _694, tmp727
	b	.L392		//
.L414:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x0, [sp, 24]	// tmp1247, %sfp
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	movi	v2.2s, 0x80, lsl 16	// tmp758
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x1, [x0]	// MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start
	lsl	x0, x26, 3	// tmp755, ivtmp.2088,
	add	x2, x1, x0	// _243, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, tmp755
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1381:       real() const { return __real__ _M_value; }
	ldr	s13, [x1, x0]	// _238, MEM[(const struct complex &)_243]._M_value
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1385:       imag() const { return __imag__ _M_value; }
	ldr	s12, [x2, 4]	// _204, MEM[(const struct complex &)_243]._M_value
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmul	s1, s12, s12	// tmp757, _204, _204
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmadd	s1, s13, s13, s1	// squared, _238, _238, tmp757
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fcmpe	s1, s2	// squared, tmp758
	bge	.L423		//,
.L426:
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d2, s12	// imaginary, _204
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d1, s13	// real, _238
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmul	d2, d2, d2	// tmp759, imaginary, imaginary
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmadd	d1, d1, d1, d2	// _297, real, real, tmp759
	fsqrt	d1, d1	// _433, _297
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fcvt	s1, d1	// _139, _433
.L427:
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	mov	w0, 49045	// tmp1316,
	movk	w0, 0x33d6, lsl 16	// tmp1316,,
	fmov	s2, w0	// tmp760, tmp1316
	fcmpe	s1, s2	// _139, tmp760
	bgt	.L644		//,
	b	.L424		//
.L644:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:903:   __complex_arg(__complex__ float __z) { return __builtin_cargf(__z); }
	ldp	s1, s0, [x28]	//,, MEM[(float *)_1122]
	bl	atan2f		//
	fmov	s2, s0	// tmp1291,
	fmov	s0, s12	//, _204
	fmov	s1, s13	//, _238
	fmov	s12, s2	// _43, tmp1291
	bl	atan2f		//
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fsub	s0, s12, s0	// tmp763, _43, tmp1292
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	scvtf	d12, x26	// _115, ivtmp.2088
	adrp	x0, .LC2	// tmp1360,
	ldr	d1, [x0, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fcvt	d0, s0	// tmp764, tmp763
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmsub	d0, d9, d12, d0	//, step, _115, tmp764
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fdiv	d0, d0, d9	// tmp766, tmp1293, step
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fadd	d0, d0, d12	// tmp767, tmp766, _115
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fcvt	s0, d0	// _492, tmp767
	b	.L418		//
.L636:
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:115:         || (k < half && magnitude_[k] < magnitude_[k + 1])) continue;
	mov	x26, 1	// ivtmp.2103,
	mov	x24, 0	// candidates,
	add	x22, x25, 12288	// tmp1249, this,
	b	.L453		//
.L611:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1317,
	movk	w0, 0x1e3c, lsl 16	// tmp1317,,
	fmov	s0, w0	// _162, tmp1317
	b	.L416		//
.L610:
	mov	w0, 58632	// tmp1318,
	movk	w0, 0x1e3c, lsl 16	// tmp1318,,
	fmov	s0, w0	// _258, tmp1318
	b	.L415		//
.L606:
	.cfi_restore 78
	.cfi_restore 79
	fmov	s12, s1	// _428, tmp706
	b	.L390		//
.L605:
	fmov	s0, s1	// prephitmp_765, tmp705
	b	.L389		//
.L735:
	add	x0, x25, 40	// tmp1247, this,
	str	x0, [sp, 24]	// tmp1247, %sfp
	b	.L455		//
.L423:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	mov	w0, 2139095039	// tmp1315,
	fmov	s2, w0	// tmp768, tmp1315
	fcmp	s1, s2	// squared, tmp768
	bhi	.L426		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:439:   { return __builtin_sqrtf(__x); }
	fsqrt	s1, s1	// _139, squared
	b	.L427		//
.L397:
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	mov	w0, 2139095039	// tmp1322,
	fmov	s2, w0	// tmp728, tmp1322
	fcmp	s1, s2	// squared, tmp728
	bhi	.L400		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:439:   { return __builtin_sqrtf(__x); }
	fsqrt	s1, s1	// _554, squared
	b	.L401		//
.L538:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:749: 	  else if (_Num == 1)
	bne	.L539		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	add	x0, sp, 544	// tmp1371,,
	ldp	x0, x1, [x0, -232]	// MEM[(struct Prediction &)&predictions], MEM[(struct Prediction &)&predictions]
	stp	x0, x1, [x28]	// MEM[(struct Prediction &)&predictions], MEM[(struct Prediction *)__i_709]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	b	.L539		//
.L552:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:749: 	  else if (_Num == 1)
	bne	.L553		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	add	x0, sp, 544	// tmp1374,,
	ldp	x0, x1, [x0, -232]	// MEM[(struct Prediction &)&predictions], MEM[(struct Prediction &)&predictions]
	stp	x0, x1, [x28]	// MEM[(struct Prediction &)&predictions], MEM[(struct Prediction *)__i_905]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	b	.L553		//
.L477:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	cmp	x26, x19	// _335, prephitmp_435
	mov	x27, x23	// ivtmp.2082, prephitmp_782
	add	x28, sp, 32	// tmp1246,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x24, 24	// tmp1270,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	beq	.L737		//,
.L504:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s1, [x19, 20]	// _485, MEM[(float *)__i$_M_current_503 + 20B]
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x23, 20]	// _486, MEM[(const struct PitchRegion &)_337].magnitude
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _485, _486
	bne	.L495		//,
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldrh	w0, [x23]	// MEM[(const struct PitchRegion &)_337].bin, MEM[(const struct PitchRegion &)_337].bin
	ldrh	w1, [x19]	// MEM[(short unsigned int *)__i$_M_current_503], MEM[(short unsigned int *)__i$_M_current_503]
	cmp	w1, w0	// MEM[(short unsigned int *)__i$_M_current_503], MEM[(const struct PitchRegion &)_337].bin
	cset	w0, cc	// iftmp.111_489,
.L496:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1819: 	  if (__comp(__i, __first))
	cbz	w0, .L766	// iftmp.111_489,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion &)__i$_M_current_503]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:746: 	  const ptrdiff_t _Num = __last - __first;
	sub	x2, x19, x23	// _494, ivtmp.2081, prephitmp_782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	cmp	x2, 24	// _494,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1822: 		__val = _GLIBCXX_MOVE(*__i);
	ldr	x3, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion &)__i$_M_current_503]
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion *)_358]
	str	x3, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:747: 	  if (__builtin_expect(_Num > 1, true))
	ble	.L497		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	sub	x0, x24, x2	// tmp924, tmp1270, _494
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:748: 	    __builtin_memmove(__result - _Num, __first, sizeof(_Tp) * _Num);
	mov	x1, x23	//, prephitmp_782
	add	x0, x19, x0	//, ivtmp.2081, tmp924
	bl	memmove		//
.L498:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1824: 	      *__first = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x23]	// MEM[(struct PitchRegion *)_358], *_337
	str	x2, [x23, 16]	// MEM[(struct PitchRegion *)_358], *_337
.L499:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1817:       for (_RandomAccessIterator __i = __first + 1; __i != __last; ++__i)
	add	x19, x19, 24	// ivtmp.2081, ivtmp.2081,
	add	x27, x27, 24	// ivtmp.2082, ivtmp.2082,
	cmp	x26, x19	// _335, ivtmp.2081
	bne	.L504		//,
	b	.L736		//
.L495:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmpe	s1, s0	// _485, _486
	cset	w0, gt	// iftmp.111_489,
	b	.L496		//
.L766:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldp	x0, x1, [x19]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion &)__i$_M_current_503]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1126: 	return *this;
	mov	x3, x19	// ivtmp.2076, ivtmp.2081
	mov	x2, x27	// ivtmp.2070, ivtmp.2082
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1796: 	__val = _GLIBCXX_MOVE(*__last);
	ldr	x6, [x19, 16]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion &)__i$_M_current_503]
	stp	x0, x1, [x28]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion *)_358]
	ldrh	w5, [x19]	// __val$bin, MEM[(short unsigned int *)__i$_M_current_503]
	str	x6, [x28, 16]	// MEM[(struct PitchRegion &)__i$_M_current_503], MEM[(struct PitchRegion *)_358]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1126: 	return *this;
	b	.L500		//
	.p2align 2,,3
.L767:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	ldrh	w0, [x2]	// MEM[(short unsigned int *)_1155], MEM[(short unsigned int *)_1155]
	cmp	w0, w5	// MEM[(short unsigned int *)_1155], __val$bin
	bls	.L503		//,
.L502:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1801: 	  *__last = _GLIBCXX_MOVE(*__next);
	ldp	x0, x1, [x2]	// MEM[(struct PitchRegion &)_1155], MEM[(struct PitchRegion &)_1155]
	sub	x3, x3, #24	// ivtmp.2076, ivtmp.2076,
	sub	x2, x2, #24	// ivtmp.2070, ivtmp.2070,
	stp	x0, x1, [x3, 24]	// MEM[(struct PitchRegion &)_1155], MEM[(struct PitchRegion *)__last$_M_current_509]
	ldr	x0, [x2, 40]	// MEM[(struct PitchRegion &)_1155], MEM[(struct PitchRegion &)_1155]
	str	x0, [x3, 40]	// MEM[(struct PitchRegion &)_1155], MEM[(struct PitchRegion *)__last$_M_current_509]
.L500:
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	ldr	s0, [x2, 20]	// _511, MEM[(float *)_1155 + 20B]
// /probe/scatter-baseline-pitch.cpp:134:       return a.magnitude == b.magnitude ? a.bin < b.bin : a.magnitude > b.magnitude;
	fcmp	s1, s0	// _485, _511
	beq	.L767		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1799:       while (__comp(__val, __next))
	fcmpe	s1, s0	// _485, _511
	bgt	.L502		//,
.L503:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algo.h:1805:       *__last = _GLIBCXX_MOVE(__val);
	ldp	x0, x1, [x28]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	ldr	x2, [x28, 16]	// MEM[(struct PitchRegion *)_358], MEM[(struct PitchRegion *)_358]
	stp	x0, x1, [x3]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_509
	str	x2, [x3, 16]	// MEM[(struct PitchRegion *)_358], *__last$_M_current_509
	b	.L499		//
.L509:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:749: 	  else if (_Num == 1)
	bne	.L510		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	ldp	x0, x1, [x23]	// *_1172, *_1172
	stp	x0, x1, [x19]	// *_1172, MEM[(struct PitchRegion *)__i$_M_current_576]
	ldr	x0, [x23, 16]	// *_1172, *_1172
	str	x0, [x19, 16]	// *_1172, MEM[(struct PitchRegion *)__i$_M_current_576]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	b	.L510		//
.L521:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:749: 	  else if (_Num == 1)
	bne	.L522		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	ldp	x0, x1, [x23]	// *_342, *_342
	stp	x0, x1, [x19]	// *_342, MEM[(struct PitchRegion *)__i$_M_current_680]
	ldr	x0, [x23, 16]	// *_342, *_342
	str	x0, [x19, 16]	// *_342, MEM[(struct PitchRegion *)__i$_M_current_680]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	b	.L522		//
.L740:
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 76
	.cfi_restore 77
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	adrp	x0, .LC2	// tmp1355,
	ucvtf	d9, d6	// tmp674, _205
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	ucvtf	d0, x1	// tmp677, tmp665
// /probe/scatter-baseline-pitch.cpp:112:   for (std::size_t k = 0; k <= peakLimit_; ++k) {
	ldr	x27, [x25, 12440]	// _658, this_160(D)->peakLimit_
	str	d10, [sp, 4528]	//,
	.cfi_offset 74, -48
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	ldr	d1, [x0, #:lo12:.LC2]	// tmp676,
	str	d11, [sp, 4536]	//,
	.cfi_offset 75, -40
	str	d12, [sp, 4544]	//,
	.cfi_offset 76, -32
	str	d13, [sp, 4552]	//,
	.cfi_offset 77, -24
	fmul	d9, d9, d1	// tmp675, tmp674, tmp676
// /probe/scatter-baseline-pitch.cpp:111:   const double step = kTwoPi * plan_->spectral->hopSize() / spectrum.size();
	fdiv	d9, d9, d0	// step, tmp675, tmp677
	b	.L370		//
.L763:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x2, [x25, 40]	// MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start
	lsl	x0, x26, 3	// tmp778, ivtmp.2103,
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	movi	v2.2s, 0x80, lsl 16	// tmp781
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x3, x2, x0	// _165, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, tmp778
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1385:       imag() const { return __imag__ _M_value; }
	ldr	s11, [x3, 4]	// _403, MEM[(const struct complex &)_165]._M_value
	str	d14, [sp, 4560]	//,
	.cfi_offset 78, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1381:       real() const { return __real__ _M_value; }
	ldr	s14, [x2, x0]	// _401, MEM[(const struct complex &)_165]._M_value
	str	d15, [sp, 4568]	//,
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmul	s1, s11, s11	// tmp780, _403, _403
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmadd	s1, s14, s14, s1	// squared, _401, _401, tmp780
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fcmpe	s1, s2	// squared, tmp781
	bge	.L645		//,
.L440:
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d2, s11	// imaginary, _403
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d1, s14	// real, _401
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmul	d2, d2, d2	// tmp783, imaginary, imaginary
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmadd	d1, d1, d1, d2	// _412, real, real, tmp783
	fsqrt	d1, d1	// _413, _412
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fcvt	s1, d1	// _414, _413
.L442:
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	mov	w0, 49045	// tmp1313,
	movk	w0, 0x33d6, lsl 16	// tmp1313,,
	fmov	s2, w0	// tmp784, tmp1313
	fcmpe	s1, s2	// _414, tmp784
	bgt	.L443		//,
	ldr	d14, [sp, 4560]	//,
	.cfi_remember_state
	.cfi_restore 78
	ldr	d15, [sp, 4568]	//,
	.cfi_restore 79
	b	.L439		//
.L764:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x0, [sp, 24]	// tmp1247, %sfp
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	movi	v2.2s, 0x80, lsl 16	// tmp819
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x1, [x0]	// MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start
	lsl	x0, x26, 3	// tmp816, ivtmp.2103,
	add	x2, x1, x0	// _983, MEM[(struct vector *)this_160(D) + 40B].D.212165._M_impl.D.211503._M_start, tmp816
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1381:       real() const { return __real__ _M_value; }
	ldr	s15, [x1, x0]	// _984, MEM[(const struct complex &)_983]._M_value
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1385:       imag() const { return __imag__ _M_value; }
	ldr	s14, [x2, 4]	// _985, MEM[(const struct complex &)_983]._M_value
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmul	s1, s14, s14	// tmp818, _985, _985
// /probe/scatter-baseline-pitch.cpp:17:   const float squared = value.real() * value.real() + value.imag() * value.imag();
	fmadd	s1, s15, s15, s1	// squared, _984, _984, tmp818
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	fcmpe	s1, s2	// squared, tmp819
	bge	.L647		//,
.L460:
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d2, s14	// imaginary, _985
// /probe/scatter-baseline-pitch.cpp:20:   const double real = value.real(), imaginary = value.imag();
	fcvt	d1, s15	// real, _984
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmul	d2, d2, d2	// tmp821, imaginary, imaginary
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fmadd	d1, d1, d1, d2	// _1012, real, real, tmp821
	fsqrt	d1, d1	// _1013, _1012
// /probe/scatter-baseline-pitch.cpp:21:   return static_cast<float>(std::sqrt(real * real + imaginary * imaginary));
	fcvt	s1, d1	// _989, _1013
.L462:
// /probe/scatter-baseline-pitch.cpp:118:     else if (previous_ && magnitude(previousSpectrum_[k]) > 1e-7f) {
	mov	w0, 49045	// tmp1308,
	movk	w0, 0x33d6, lsl 16	// tmp1308,,
	fmov	s2, w0	// tmp822, tmp1308
	fcmpe	s1, s2	// _989, tmp822
	bgt	.L648		//,
	b	.L459		//
.L648:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:903:   __complex_arg(__complex__ float __z) { return __builtin_cargf(__z); }
	ldp	s1, s0, [x28]	//,, MEM[(float *)_1083]
	bl	atan2f		//
	fmov	s13, s0	// tmp1300,
	fmov	s1, s15	//, _984
	fmov	s0, s14	//, _985
	bl	atan2f		//
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fsub	s0, s13, s0	// tmp825, _994, tmp1301
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	scvtf	d13, x26	// _1000, ivtmp.2103
	adrp	x0, .LC2	// tmp1365,
	ldr	d1, [x0, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fcvt	d0, s0	// tmp826, tmp825
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmsub	d0, d9, d13, d0	//, step, _1000, tmp826
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fdiv	d0, d0, d9	// tmp828, tmp1302, step
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fadd	d0, d0, d13	// tmp829, tmp828, _1000
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fcvt	s0, d0	// frequency, tmp829
	b	.L464		//
.L622:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	mov	w0, 58632	// tmp1307,
	movk	w0, 0x1e3c, lsl 16	// tmp1307,,
	fmov	s0, w0	// _950, tmp1307
	b	.L465		//
.L623:
	mov	w0, 58632	// tmp1306,
	movk	w0, 0x1e3c, lsl 16	// tmp1306,,
	fmov	s0, w0	// _964, tmp1306
	b	.L466		//
.L616:
	.cfi_restore 78
	.cfi_restore 79
	fmov	s12, s1	// _706, tmp793
	b	.L446		//
.L615:
	fmov	s0, s1	// _22, tmp785
	b	.L444		//
.L647:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	mov	w0, 2139095039	// tmp1309,
	fmov	s2, w0	// tmp820, tmp1309
	fcmp	s1, s2	// squared, tmp820
	bhi	.L460		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:439:   { return __builtin_sqrtf(__x); }
	fsqrt	s1, s1	// _989, squared
	b	.L462		//
.L645:
// /probe/scatter-baseline-pitch.cpp:18:   if (squared >= std::numeric_limits<float>::min() && std::isfinite(squared))
	mov	w0, 2139095039	// tmp1314,
	fmov	s2, w0	// tmp782, tmp1314
	fcmp	s1, s2	// squared, tmp782
	bhi	.L440		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:439:   { return __builtin_sqrtf(__x); }
	fsqrt	s1, s1	// _414, squared
	b	.L442		//
.L480:
	.cfi_restore 78
	.cfi_restore 79
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:749: 	  else if (_Num == 1)
	bne	.L481		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	ldp	x0, x1, [x23]	// *_337, *_337
	stp	x0, x1, [x19]	// *_337, MEM[(struct PitchRegion *)__i$_M_current_502]
	ldr	x0, [x23, 16]	// *_337, *_337
	str	x0, [x19, 16]	// *_337, MEM[(struct PitchRegion *)__i$_M_current_502]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	b	.L481		//
.L497:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:749: 	  else if (_Num == 1)
	bne	.L498		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	ldp	x0, x1, [x23]	// *_337, *_337
	stp	x0, x1, [x19]	// *_337, MEM[(struct PitchRegion *)__i$_M_current_503]
	ldr	x0, [x23, 16]	// *_337, *_337
	str	x0, [x19, 16]	// *_337, MEM[(struct PitchRegion *)__i$_M_current_503]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:423: 	{ *__to = std::move(*__from); }
	b	.L498		//
.L443:
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:903:   __complex_arg(__complex__ float __z) { return __builtin_cargf(__z); }
	ldp	s1, s0, [x4]	//,, MEM[(float *)_1065]
	stp	x4, x1, [sp, 8]	// ivtmp.2115, _286, %sfp
	bl	atan2f		//
	fmov	s10, s0	// tmp1294,
	fmov	s1, s14	//, _401
	fmov	s0, s11	//, _403
	bl	atan2f		//
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fsub	s0, s10, s0	// tmp788, _310, tmp1295
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	scvtf	d10, x26	// _35, ivtmp.2103
	adrp	x0, .LC2	// tmp1361,
	ldr	d1, [x0, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:119:       const double delta = principal(std::arg(spectrum[k]) - std::arg(previousSpectrum_[k]) - k * step);
	fcvt	d0, s0	// tmp789, tmp788
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmsub	d0, d10, d9, d0	//, _35, step, tmp789
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fdiv	d0, d0, d9	// tmp791, tmp1296, step
	ldp	x4, x1, [sp, 8]	// ivtmp.2115, _286, %sfp
	ldr	d14, [sp, 4560]	//,
	.cfi_restore 78
	ldr	d15, [sp, 4568]	//,
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fadd	d0, d0, d10	// tmp792, tmp791, _35
// /probe/scatter-baseline-pitch.cpp:120:       frequency = static_cast<float>(k + delta / step);
	fcvt	s0, d0	// _54, tmp792
	b	.L445		//
.L588:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:438: 	  else if (_Num == 1)
	bne	.L583		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:398: 	{ *__to = *__from; }
	ldr	s0, [x20]	// *spectrum$_M_ptr_152, *spectrum$_M_ptr_152
	str	s0, [x0]	// *spectrum$_M_ptr_152, *_354
	ldr	s0, [x20, 4]	// *spectrum$_M_ptr_152, *spectrum$_M_ptr_152
	str	s0, [x0, 4]	// *spectrum$_M_ptr_152, *_354
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:398: 	{ *__to = *__from; }
	b	.L583		//
.L751:
	add	x28, sp, 32	// tmp1246,,
	b	.L505		//
.L746:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 72
	.cfi_restore 73
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 76
	.cfi_restore 77
	str	x21, [sp, 4448]	//,
	.cfi_offset 21, -128
	str	x22, [sp, 4456]	//,
	.cfi_offset 22, -120
	str	x23, [sp, 4464]	//,
	.cfi_offset 23, -112
	str	x24, [sp, 4472]	//,
	.cfi_offset 24, -104
	str	x27, [sp, 4496]	//,
	.cfi_offset 27, -80
	str	x28, [sp, 4504]	//,
	.cfi_offset 28, -72
	str	d8, [sp, 4512]	//,
	.cfi_offset 72, -64
	str	d9, [sp, 4520]	//,
	.cfi_offset 73, -56
	str	d10, [sp, 4528]	//,
	.cfi_offset 74, -48
	str	d11, [sp, 4536]	//,
	.cfi_offset 75, -40
	str	d12, [sp, 4544]	//,
	.cfi_offset 76, -32
	str	d13, [sp, 4552]	//,
	.cfi_offset 77, -24
	str	d14, [sp, 4560]	//,
	.cfi_offset 78, -16
	str	d15, [sp, 4568]	//,
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:191: }
	bl	__stack_chk_fail		//
	.cfi_endproc
.LFE9558:
	.size	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE, .-_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog313PitchRenderer5resetEv
	.type	_ZN5ardor4pog313PitchRenderer5resetEv, %function
_ZN5ardor4pog313PitchRenderer5resetEv:
.LFB9585:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!	//,,,
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -32
	.cfi_offset 20, -24
	mov	x19, x0	// this, tmp166
// /probe/scatter-baseline-pitch.cpp:203:   synthesis_.reset();
	add	x0, x0, 16	//, this,
// /probe/scatter-baseline-pitch.cpp:202: void PitchRenderer::reset() noexcept {
	str	d8, [sp, 32]	//,
	.cfi_offset 72, -16
// /probe/scatter-baseline-pitch.cpp:203:   synthesis_.reset();
	bl	_ZN5ardor4pog317SpectralSynthesis5resetEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x2, x4, [x19, 96]	// tmp.2134, _20, MEM[(struct complex * const &)this_6(D) + 96]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x2	// _20, tmp.2134
	beq	.L769		//,
	sub	x1, x4, #8	// tmp123, _20,
	mov	x0, x2	// ivtmp.2164, tmp.2134
	sub	x1, x1, x2	// _18, tmp123, tmp.2134
	cmp	x1, 16	// _18,
	lsr	x1, x1, 3	// tmp124, _18,
	add	x1, x1, 1	// niters.2131, tmp124,
	bls	.L770		//,
	lsr	x3, x1, 1	// bnd.2132, niters.2131,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	movi	v0.4s, 0	// tmp127
	add	x3, x2, x3, lsl 4	// _90, tmp.2134, bnd.2132,
	.p2align 3,,7
.L771:
	str	q0, [x0], 16	// tmp127, MEM <vector(4) float> [(float *)_87]
	cmp	x0, x3	// ivtmp.2164, _90
	bne	.L771		//,
	tbz	x1, 0, .L769	// niters.2131,,
	and	x1, x1, -2	// niters_vector_mult_vf.2133, niters.2131,
	add	x2, x2, x1, lsl 3	// tmp.2134, tmp.2134, niters_vector_mult_vf.2133,
.L770:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 8	// __first, tmp.2134,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2]	//, REALPART_EXPR <__first_62->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _20, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 4]	//, IMAGPART_EXPR <__first_62->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L769		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 16	// __first, tmp.2134,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_62 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _20, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_62 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L769		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_62 + 16B]._M_value>
.L769:
// /probe/scatter-baseline-pitch.cpp:205:   phases_ = {};
	mov	x2, 8192	//,
	mov	w1, 0	//,
	add	x0, x19, 120	//, this,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:205:   phases_ = {};
	fmov	s8, 1.0e+0	// tmp138,
	mov	x6, 8340	//,
	add	x1, x19, 180	// ivtmp.2159, this,
	add	x2, x19, x6	// _83, this,
	str	s8, [x19, 148]	// tmp138, this_6(D)->phases_._M_elems[0].ratio
	.p2align 3,,7
.L773:
	str	s8, [x1], 32	// tmp138, MEM[(float *)_81]
	cmp	x1, x2	// ivtmp.2159, _83
	bne	.L773		//,
// /probe/scatter-baseline-pitch.cpp:206:   lowPhases_ = {};
	mov	x3, 8312	//,
	mov	x2, 8192	//,
	mov	w1, 0	//,
	add	x0, x19, x3	//, this,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:206:   lowPhases_ = {};
	fmov	s0, 1.0e+0	// tmp150,
	mov	x4, 8372	//,
	mov	x5, 16532	//,
	add	x1, x19, x4	// ivtmp.2150, this,
	add	x2, x19, x5	// _74, this,
	str	s8, [x19, 8340]	// tmp138, this_6(D)->lowPhases_._M_elems[0].ratio
	.p2align 3,,7
.L774:
	str	s0, [x1], 32	// tmp150, MEM[(float *)_60]
	cmp	x1, x2	// ivtmp.2150, _74
	bne	.L774		//,
// /probe/scatter-baseline-pitch.cpp:207:   phaseAges_ = {};
	add	x20, x19, 16384	// tmp165, this,
	mov	x2, 512	//,
	mov	w1, 0	//,
	add	x0, x20, 120	//, tmp165,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:208:   lowCarriers_ = {};
	mov	x0, 17016	//,
	mov	w1, 0	//,
	add	x0, x19, x0	//, this,
	mov	x2, 2048	//,
	bl	memset		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldr	x1, [x19, 19064]	// __first, MEM[(struct HeldPhase * const &)this_6(D) + 19064]
	ldr	x0, [x19, 19072]	// _24, MEM[(struct HeldPhase * const &)this_6(D) + 19072]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x0, x1	// _24, __first
	beq	.L775		//,
	.p2align 3,,7
.L776:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x1, x1, 32	// __first, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	xzr, [x1, -32]	//, MEM <uint64_t> [(struct HeldPhase *)__first_50]
	str	xzr, [x1, -24]	//, MEM <double> [(struct HeldPhase *)__first_50 + 8B]
	str	xzr, [x1, -16]	//, MEM <int64_t> [(struct HeldPhase *)__first_50 + 16B]
	str	wzr, [x1, -8]	//, MEM <float> [(struct HeldPhase *)__first_50 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x1, x0	// __first, _24
	bne	.L776		//,
.L775:
// /probe/scatter-baseline-pitch.cpp:211: }
	ldr	d8, [sp, 32]	//,
// /probe/scatter-baseline-pitch.cpp:210:   shifted_ = false;
	strb	wzr, [x20, 2704]	//, this_6(D)->shifted_
// /probe/scatter-baseline-pitch.cpp:211: }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 48	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_restore 72
	.cfi_def_cfa_offset 0
	ret	
	.cfi_endproc
.LFE9585:
	.size	_ZN5ardor4pog313PitchRenderer5resetEv, .-_ZN5ardor4pog313PitchRenderer5resetEv
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_
	.type	_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_, %function
_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_:
.LFB9596:
	.cfi_startproc
	stp	x29, x30, [sp, -208]!	//,,,
	.cfi_def_cfa_offset 208
	.cfi_offset 29, -208
	.cfi_offset 30, -200
	mov	x29, sp	//,
	stp	x23, x24, [sp, 48]	//,,
	stp	x25, x26, [sp, 64]	//,,
	.cfi_offset 23, -160
	.cfi_offset 24, -152
	.cfi_offset 25, -144
	.cfi_offset 26, -136
	mov	x25, x0	// this, tmp455
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x23, x0, [x0, 96]	// _132, MEM[(const struct vector *)this_90(D) + 96B].D.212165._M_impl.D.211503._M_finish, MEM[(const struct vector *)this_90(D) + 96B].D.212165._M_impl.D.211503._M_start
// /probe/scatter-baseline-pitch.cpp:384:                               const PitchRenderer* reference) noexcept {
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -192
	.cfi_offset 20, -184
	mov	x20, x3	// center, tmp459
	mov	x19, x1	// band, tmp456
	and	w1, w2, 255	// low, low
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x3, x0, x23	// tmp274, MEM[(const struct vector *)this_90(D) + 96B].D.212165._M_impl.D.211503._M_finish, _132
	asr	x0, x3, 3	// _129, tmp274,
// /probe/scatter-baseline-pitch.cpp:384:                               const PitchRenderer* reference) noexcept {
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 21, -176
	.cfi_offset 22, -168
// /probe/scatter-baseline-pitch.cpp:385:   const int half = static_cast<int>(spectrum_.size() / 2);
	ubfx	x21, x3, 4, 32	// half, tmp274,,
// /probe/scatter-baseline-pitch.cpp:386:   for (std::size_t i = 0; i < band.count; ++i) {
	ldr	x22, [x19, 10240]	// _196, band_95(D)->count
// /probe/scatter-baseline-pitch.cpp:384:                               const PitchRenderer* reference) noexcept {
	str	w1, [sp, 160]	// low, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	stp	x4, x0, [sp, 176]	// tmp460, _129, %sfp
// /probe/scatter-baseline-pitch.cpp:386:   for (std::size_t i = 0; i < band.count; ++i) {
	cbz	x22, .L785	// _196,
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	adrp	x0, .LC1	// tmp478,
	stp	d10, d11, [sp, 112]	//,,
	.cfi_offset 75, -88
	.cfi_offset 74, -96
	ldr	d11, [x0, #:lo12:.LC1]	// tmp453,
	mov	x0, x1	// tmp479, low
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	mov	x1, 19064	//,
	stp	x27, x28, [sp, 80]	//,,
	.cfi_offset 28, -120
	.cfi_offset 27, -128
	ubfiz	x27, x0, 13, 8	// ivtmp.2203, tmp479,,
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	adrp	x0, .LC2	// tmp480,
// /probe/scatter-baseline-pitch.cpp:386:   for (std::size_t i = 0; i < band.count; ++i) {
	mov	x28, 0	// i,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x24, x25, x1	// tmp452, this,
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	ldr	d10, [x0, #:lo12:.LC2]	// tmp454,
	stp	d8, d9, [sp, 96]	//,,
	.cfi_offset 73, -104
	.cfi_offset 72, -112
	fmov	s8, s0	// ratio, tmp457
	fmov	s9, s1	// gain, tmp458
	stp	d12, d13, [sp, 128]	//,,
	.cfi_offset 77, -72
	.cfi_offset 76, -80
	str	d14, [sp, 144]	//,
	.cfi_offset 78, -64
	.p2align 3,,7
.L788:
// /probe/scatter-baseline-pitch.cpp:388:     if (!p.id) continue;
	ldr	x4, [x19, 8]	// _3, MEM <const uint64_t> [(const struct FrozenPartial &)_171 + 8]
// /probe/scatter-baseline-pitch.cpp:388:     if (!p.id) continue;
	cbz	x4, .L796	// _3,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ldr	x26, [x24]	// MEM[(struct vector *)this_90(D) + 19064B].D.226303._M_impl.D.225641._M_start, MEM[(struct vector *)this_90(D) + 19064B].D.226303._M_impl.D.225641._M_start
// /probe/scatter-baseline-pitch.cpp:390:     const float outputHz = p.frequency * ratio;
	ldr	s13, [x19, 24]	// _5, MEM <const float> [(const struct FrozenPartial &)_171 + 24]
// /probe/scatter-baseline-pitch.cpp:391:     if (phase.id != p.id) {
	ldr	x0, [x26, x27]	// MEM[(struct HeldPhase &)_124].id, MEM[(struct HeldPhase &)_124].id
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x26, x26, x27	// _124, MEM[(struct vector *)this_90(D) + 19064B].D.226303._M_impl.D.225641._M_start, ivtmp.2203
// /probe/scatter-baseline-pitch.cpp:390:     const float outputHz = p.frequency * ratio;
	fmul	s12, s13, s8	// outputHz, _5, ratio
// /probe/scatter-baseline-pitch.cpp:391:     if (phase.id != p.id) {
	cmp	x4, x0	// _3, MEM[(struct HeldPhase &)_124].id
	beq	.L790		//,
	ldrh	w1, [x19, 36]	// MEM <uint16_t> [(const struct FrozenPartial &)_171 + 36], MEM <uint16_t> [(const struct FrozenPartial &)_171 + 36]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:213: 	return _M_elems[__n];
	mov	x0, 8312	//,
// /probe/scatter-baseline-pitch.cpp:392:       double offset = 0;
	movi	d0, #0	// offset
// /probe/scatter-baseline-pitch.cpp:393:       const auto* seed = p.referenceLeft && reference ? reference : this;
	ldr	x3, [sp, 176]	// reference, %sfp
	ldrb	w8, [x19, 38]	//, MEM <const bool> [(const struct FrozenPartial &)_171 + 38]
	lsl	x1, x1, 5	// _374, MEM <uint16_t> [(const struct FrozenPartial &)_171 + 36],
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:213: 	return _M_elems[__n];
	add	x0, x1, x0	// tmp296, _374,
	add	x2, x1, 120	// tmp298, _374,
// /probe/scatter-baseline-pitch.cpp:395:       if (live.generation == p.liveGeneration) offset = live.offset;
	ldr	x7, [x19, 16]	// MEM <const uint64_t> [(const struct FrozenPartial &)_171 + 16], MEM <const uint64_t> [(const struct FrozenPartial &)_171 + 16]
// /probe/scatter-baseline-pitch.cpp:393:       const auto* seed = p.referenceLeft && reference ? reference : this;
	cmp	x3, 0	// reference,
	cset	w9, ne	// tmp287,
// /probe/scatter-baseline-pitch.cpp:393:       const auto* seed = p.referenceLeft && reference ? reference : this;
	tst	w9, w8	// tmp287, MEM <const bool> [(const struct FrozenPartial &)_171 + 38]
	csel	x1, x25, x3, eq	// iftmp.259_78, this, reference,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:213: 	return _M_elems[__n];
	ldr	x3, [sp, 160]	// tmp483, %sfp
	add	x0, x1, x0	// tmp439, iftmp.259_78, tmp296
	add	x1, x1, x2	// tmp440, iftmp.259_78, tmp298
	tst	x3, 1	// tmp483,
	csel	x1, x1, x0, eq	// iftmp.260_79, tmp440, tmp439,
// /probe/scatter-baseline-pitch.cpp:395:       if (live.generation == p.liveGeneration) offset = live.offset;
	ldr	x0, [x1]	// MEM[(const struct Phase &)iftmp.260_79].generation, MEM[(const struct Phase &)iftmp.260_79].generation
	cmp	x0, x7	// MEM[(const struct Phase &)iftmp.260_79].generation, MEM <const uint64_t> [(const struct FrozenPartial &)_171 + 16]
	bne	.L794		//,
// /probe/scatter-baseline-pitch.cpp:395:       if (live.generation == p.liveGeneration) offset = live.offset;
	ldr	d0, [x1, 8]	// offset, MEM[(const struct Phase &)iftmp.260_79].offset
.L794:
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	adrp	x1, .LC2	// tmp484,
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	fcvt	d5, s13	// tmp305, _5
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	mov	x0, 123145302310912	// tmp470,
	movk	x0, 0x40e7, lsl 48	// tmp470,,
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	ldr	s3, [x19, 32]	// MEM <const float> [(const struct FrozenPartial &)_171 + 32], MEM <const float> [(const struct FrozenPartial &)_171 + 32]
	str	x4, [sp, 168]	// _3, %sfp
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	ldr	d1, [x1, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	fmov	d4, x0	// tmp310, tmp470
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	ldr	x1, [x19]	// MEM <const int64_t> [(const struct FrozenPartial &)_171], MEM <const int64_t> [(const struct FrozenPartial &)_171]
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	fmul	d5, d5, d10	// tmp306, tmp305, tmp454
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	fcvt	d3, s3	// tmp311, MEM <const float> [(const struct FrozenPartial &)_171 + 32]
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	sub	x1, x20, x1	// tmp302, center, MEM <const int64_t> [(const struct FrozenPartial &)_171]
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	scvtf	d2, x1	// tmp304, tmp302
	fmul	d2, d2, d5	// tmp308, tmp304, tmp306
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	fdiv	d2, d2, d4	// tmp309, tmp308, tmp310
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	fadd	d2, d2, d3	// tmp313, tmp309, tmp311
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fadd	d0, d2, d0	//, tmp313, offset
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:396:       phase = {p.id, principal(p.phase + kTwoPi * p.frequency * (center - p.center) / kSampleRate + offset), center, outputHz};
	ldr	x4, [sp, 168]	// _3, %sfp
	str	d0, [x26, 8]	// _112,
	str	x20, [x26, 16]	// center,
	str	s12, [x26, 24]	// outputHz,
	str	x4, [x26]	// _3, MEM <uint64_t> [(struct HeldPhase *)_124]
.L795:
// /probe/scatter-baseline-pitch.cpp:401:     if (outputHz >= kSampleRate / 2) continue;
	mov	w0, 32768	// tmp468,
	movk	w0, 0x46bb, lsl 16	// tmp468,,
	fmov	s1, w0	// tmp329, tmp468
	fcmpe	s12, s1	// outputHz, tmp329
	bge	.L796		//,
// /probe/scatter-baseline-pitch.cpp:402:     const float destination = outputHz * spectrum_.size() / kSampleRate;
	ldr	x0, [sp, 184]	// _129, %sfp
// /probe/scatter-baseline-pitch.cpp:403:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fmov	s3, 2.0e+0	// tmp335,
// /probe/scatter-baseline-pitch.cpp:403:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fmov	s2, 6.0e+0	// tmp336,
// /probe/scatter-baseline-pitch.cpp:402:     const float destination = outputHz * spectrum_.size() / kSampleRate;
	ucvtf	s14, x0	// _38, _129
// /probe/scatter-baseline-pitch.cpp:402:     const float destination = outputHz * spectrum_.size() / kSampleRate;
	mov	w0, 32768	// tmp467,
	movk	w0, 0x473b, lsl 16	// tmp467,,
	fmov	s1, w0	// tmp331, tmp467
// /probe/scatter-baseline-pitch.cpp:402:     const float destination = outputHz * spectrum_.size() / kSampleRate;
	fmul	s12, s14, s12	// tmp330, _38, outputHz
// /probe/scatter-baseline-pitch.cpp:402:     const float destination = outputHz * spectrum_.size() / kSampleRate;
	fdiv	s12, s12, s1	// destination, tmp330, tmp331
// /probe/scatter-baseline-pitch.cpp:403:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	scvtf	s1, w21	// tmp332, half
	fsub	s1, s1, s12	// tmp333, tmp332, destination
// /probe/scatter-baseline-pitch.cpp:403:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fsub	s1, s1, s3	// tmp334, tmp333, tmp335
// /probe/scatter-baseline-pitch.cpp:403:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fdiv	s1, s1, s2	// edge, tmp334, tmp336
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s1, #0.0	// edge
	bmi	.L823		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s2, 1.0e+0	// tmp337,
	fcmpe	s1, s2	// edge, tmp337
	bgt	.L824		//,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w1, 1128792064	// tmp465,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w0, 1120403456	// tmp466,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s2, w1	// tmp339, tmp465
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s3, w0	// tmp340, tmp466
// /probe/scatter-baseline-pitch.cpp:404:     const float weight = low ? 1 - highWeight(p.frequency) : highWeight(p.frequency);
	ldr	x0, [sp, 160]	// tmp486, %sfp
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fsub	s2, s13, s2	// tmp338, _5, tmp339
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fdiv	s2, s2, s3	// _371, tmp338, tmp340
// /probe/scatter-baseline-pitch.cpp:404:     const float weight = low ? 1 - highWeight(p.frequency) : highWeight(p.frequency);
	tbnz	x0, 0, .L844	// tmp486,,
	.p2align 3,,7
.L798:
	movi	v13.2s, #0	// iftmp.261_80
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s2, #0.0	// _371
	bmi	.L800		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s13, 1.0e+0	// iftmp.261_80,
	fcmpe	s2, s13	// _371, iftmp.261_80
	bgt	.L800		//,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmov	s4, 2.0e+0	// tmp347,
	fmov	s3, 3.0e+0	// tmp348,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmul	s13, s2, s2	// _299, _371, _371
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmsub	s2, s2, s4, s3	// _303, _371, tmp347, tmp348
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmul	s13, s13, s2	// iftmp.261_80, _299, _303
	.p2align 3,,7
.L800:
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	ldr	s2, [x19, 28]	// MEM <const float> [(const struct FrozenPartial &)_171 + 28], MEM <const float> [(const struct FrozenPartial &)_171 + 28]
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmov	s3, 1.0e+0	// tmp351,
	fcmp	s8, s3	// ratio, tmp351
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmul	s13, s13, s2	// tmp349, iftmp.261_80, MEM <const float> [(const struct FrozenPartial &)_171 + 28]
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmul	s13, s13, s9	// _47, tmp349, gain
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	beq	.L802		//,
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmov	s4, 2.0e+0	// tmp352,
	fmov	s3, 3.0e+0	// tmp353,
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmul	s2, s1, s1	// _48, edge, edge
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmsub	s1, s1, s4, s3	// _50, edge, tmp352, tmp353
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmul	s1, s2, s1	// tmp354, _48, _50
// /probe/scatter-baseline-pitch.cpp:405:     const float amplitude = p.magnitude * weight * gain * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge));
	fmul	s13, s13, s1	// _47, _47, tmp354
.L802:
// /probe/scatter-baseline-pitch.cpp:408:     if (amplitude == 0) continue;
	fcmp	s13, #0.0	// _47
	bne	.L845		//,
.L796:
// /probe/scatter-baseline-pitch.cpp:386:   for (std::size_t i = 0; i < band.count; ++i) {
	add	x28, x28, 1	// i, i,
// /probe/scatter-baseline-pitch.cpp:386:   for (std::size_t i = 0; i < band.count; ++i) {
	add	x19, x19, 40	// ivtmp.2202, ivtmp.2202,
	cmp	x28, x22	// i, _196
	add	x27, x27, 32	// ivtmp.2203, ivtmp.2203,
	bne	.L788		//,
	ldp	d8, d9, [sp, 96]	//,,
	.cfi_restore 73
	.cfi_restore 72
	ldp	x27, x28, [sp, 80]	//,,
	.cfi_restore 28
	.cfi_restore 27
	ldp	d10, d11, [sp, 112]	//,,
	.cfi_restore 75
	.cfi_restore 74
	ldp	d12, d13, [sp, 128]	//,,
	.cfi_restore 77
	.cfi_restore 76
	ldr	d14, [sp, 144]	//,
	.cfi_restore 78
.L785:
// /probe/scatter-baseline-pitch.cpp:422: }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x21, x22, [sp, 32]	//,,
	ldp	x23, x24, [sp, 48]	//,,
	ldp	x25, x26, [sp, 64]	//,,
	ldp	x29, x30, [sp], 208	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L824:
	.cfi_def_cfa_offset 208
	.cfi_offset 19, -192
	.cfi_offset 20, -184
	.cfi_offset 21, -176
	.cfi_offset 22, -168
	.cfi_offset 23, -160
	.cfi_offset 24, -152
	.cfi_offset 25, -144
	.cfi_offset 26, -136
	.cfi_offset 27, -128
	.cfi_offset 28, -120
	.cfi_offset 29, -208
	.cfi_offset 30, -200
	.cfi_offset 72, -112
	.cfi_offset 73, -104
	.cfi_offset 74, -96
	.cfi_offset 75, -88
	.cfi_offset 76, -80
	.cfi_offset 77, -72
	.cfi_offset 78, -64
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:239: 	return __b;
	fmov	s1, s2	// edge, tmp337
.L797:
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w1, 1128792064	// tmp465,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w0, 1120403456	// tmp466,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s2, w1	// tmp339, tmp465
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s3, w0	// tmp340, tmp466
// /probe/scatter-baseline-pitch.cpp:404:     const float weight = low ? 1 - highWeight(p.frequency) : highWeight(p.frequency);
	ldr	x0, [sp, 160]	// tmp486, %sfp
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fsub	s2, s13, s2	// tmp338, _5, tmp339
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fdiv	s2, s2, s3	// _371, tmp338, tmp340
// /probe/scatter-baseline-pitch.cpp:404:     const float weight = low ? 1 - highWeight(p.frequency) : highWeight(p.frequency);
	tbz	x0, 0, .L798	// tmp486,,
.L844:
	fmov	s13, 1.0e+0	// iftmp.261_80,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s2, #0.0	// _371
	bmi	.L800		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s3, s13	// tmp342, iftmp.261_80
	movi	v13.2s, #0	// iftmp.261_80
	fcmpe	s2, s3	// _371, tmp342
	bgt	.L800		//,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmov	s5, 2.0e+0	// tmp343,
	fmov	s4, 3.0e+0	// tmp344,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmul	s13, s2, s2	// _307, _371, _371
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmsub	s2, s2, s5, s4	// _311, _371, tmp343, tmp344
// /probe/scatter-baseline-pitch.cpp:404:     const float weight = low ? 1 - highWeight(p.frequency) : highWeight(p.frequency);
	fmsub	s13, s13, s2, s3	// iftmp.261_80, _307, _311, tmp342
	b	.L800		//
	.p2align 2,,3
.L845:
	add	x1, sp, 192	//,,
	add	x0, sp, 200	//,,
	bl	sincos		//
	ldp	d3, d4, [sp, 192]	// sincostmp_263, sincostmp_263,
// /probe/scatter-baseline-pitch.cpp:411:     const int first = static_cast<int>(std::floor(destination)) - 16;
	fcvtms	w2, s12	// tmp359, destination
// /probe/scatter-baseline-pitch.cpp:412:     const int last = static_cast<int>(std::ceil(destination)) + 16;
	fcvtps	w4, s12	// _59, destination
// /probe/scatter-baseline-pitch.cpp:409:     const std::complex<float> carrier{static_cast<float>(std::cos(phase.phase)) * amplitude,
	fcvt	s3, d3	// tmp357, sincostmp_263
// /probe/scatter-baseline-pitch.cpp:410:                                       static_cast<float>(std::sin(phase.phase)) * amplitude};
	fcvt	s4, d4	// tmp358, sincostmp_263
// /probe/scatter-baseline-pitch.cpp:411:     const int first = static_cast<int>(std::floor(destination)) - 16;
	sub	w2, w2, #16	// first, tmp359,
// /probe/scatter-baseline-pitch.cpp:412:     const int last = static_cast<int>(std::ceil(destination)) + 16;
	add	w7, w4, 16	// last, _59,
// /probe/scatter-baseline-pitch.cpp:413:     for (int j = first; j <= last; ++j) {
	cmp	w2, w7	// first, last
// /probe/scatter-baseline-pitch.cpp:410:                                       static_cast<float>(std::sin(phase.phase)) * amplitude};
	fmul	s3, s3, s13	// _54, tmp357, _47
// /probe/scatter-baseline-pitch.cpp:410:                                       static_cast<float>(std::sin(phase.phase)) * amplitude};
	fmul	s4, s4, s13	// _57, tmp358, _47
// /probe/scatter-baseline-pitch.cpp:413:     for (int j = first; j <= last; ++j) {
	bgt	.L796		//,
	tbnz	w2, #31, .L846	// first,
.L803:
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	mov	w1, 2139095039	// tmp463,
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v17.2s, #0	// _292
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmov	s16, 2.0e+0	// tmp443,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	movi	v13.2s, 0x44, lsl 24	// tmp444
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	movi	v7.2s, 0x46, lsl 24	// tmp445
	add	x0, x23, w2, sxtw 3	// ivtmp.2181, _132, first,
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fmov	s6, w1	// tmp441, tmp463
	b	.L819		//
	.p2align 2,,3
.L848:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s1, s1	// _323, _323
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s0, s0	// _322, _322
.L817:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldp	s2, s5, [x0]	// MEM[(float *)_243], MEM[(float *)_243 + 4B], MEM[(float *)_243]
	fadd	s1, s2, s1	// tmp430, MEM[(float *)_243], _323
	fadd	s0, s0, s5	// _345, _322, MEM[(float *)_243 + 4B]
	stp	s1, s0, [x0]	// tmp430, _345, MEM[(float *)_243]
.L811:
// /probe/scatter-baseline-pitch.cpp:413:     for (int j = first; j <= last; ++j) {
	add	w2, w2, 1	// first, first,
// /probe/scatter-baseline-pitch.cpp:413:     for (int j = first; j <= last; ++j) {
	add	x0, x0, 8	// ivtmp.2181, ivtmp.2181,
	cmp	w7, w2	// last, first
	blt	.L796		//,
.L819:
// /probe/scatter-baseline-pitch.cpp:414:       if (std::abs(j) >= half) continue;
	cmp	w2, 0	// first,
	csneg	w1, w2, w2, ge	// tmp394, first, first,
// /probe/scatter-baseline-pitch.cpp:414:       if (std::abs(j) >= half) continue;
	cmp	w1, w21	// tmp394, half
	bge	.L811		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	scvtf	s1, w2	// tmp395, first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x4, [x25]	// _181, MEM[(const struct __shared_ptr *)this_90(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v0.2s, #0	// _292
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabd	s1, s1, s12	// _367, tmp395, destination
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fcmp	s1, s6	// _367, tmp441
	bhi	.L812		//,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	fmul	s1, s1, s13	// position, _367, tmp444
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	fcmpe	s1, s7	// position, tmp445
	bge	.L812		//,
// /probe/scatter-baseline-pitch.cpp:67:   const auto i = static_cast<std::size_t>(position);
	fcvtzu	x1, s1	// i, position
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x1, 8192	// i,
	beq	.L847		//,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ucvtf	s2, x1	// tmp410, i
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ubfiz	x8, x1, 4, 9	// tmp408, i,,
	add	x4, x4, 32	// tmp433, _181,
	add	x8, x8, x1, lsr 9	// tmp409, tmp408, i,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	add	x1, x1, 1	// prephitmp_289, i,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	ubfiz	x9, x1, 4, 9	// tmp412, prephitmp_289,,
	cmp	x1, 8192	// prephitmp_289,
	add	x9, x9, x1, lsr 9	// tmp438, tmp412, prephitmp_289,
	csel	x1, x9, x1, ne	// prephitmp_289, tmp438, prephitmp_289,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ldr	s0, [x4, x8, lsl 2]	// first, MEM <const struct array> [(const value_type &)_181 + 32]._M_elems[iftmp.24_285]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s1, s1, s2	// _290, position, tmp410
.L815:
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ldr	s2, [x4, x1, lsl 2]	// MEM <const struct array> [(const value_type &)_181 + 32]._M_elems[iftmp.24_317], MEM <const struct array> [(const value_type &)_181 + 32]._M_elems[iftmp.24_317]
	fsub	s2, s2, s0	// tmp416, MEM <const struct array> [(const value_type &)_181 + 32]._M_elems[iftmp.24_317], first
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fmadd	s0, s2, s1, s0	// _292, tmp416, _290, first
.L812:
// /probe/scatter-baseline-pitch.cpp:415:       auto value = carrier * (plan_->lobe(j - destination) * spectrum_.size());
	fmul	s0, s14, s0	// _365, _38, _292
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s1, s3, s0	// _323, _54, _365
	fmul	s0, s4, s0	// _322, _57, _365
// /probe/scatter-baseline-pitch.cpp:416:       if (j & 1) value = -value;
	tbnz	x2, 0, .L848	// first,,
// /probe/scatter-baseline-pitch.cpp:417:       if (j < 0) spectrum_[-j] += std::conj(value);
	cmp	w2, 0	// first,
	blt	.L818		//,
// /probe/scatter-baseline-pitch.cpp:418:       else if (j == 0) spectrum_[0] += std::complex<float>{2 * value.real(), 0};
	bne	.L817		//,
	ldp	s0, s2, [x23]	// _132->_M_value, _328, _132->_M_value
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmadd	s0, s1, s16, s0	// _327, _323, tmp443, _132->_M_value
	fadd	s1, s2, s17	// tmp421, _328, _292
	stp	s0, s1, [x23]	// _327, tmp421, REALPART_EXPR <_132->_M_value>
	b	.L811		//
	.p2align 2,,3
.L818:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	neg	w1, w2	// tmp424, first
	lsl	x1, x1, 3	// tmp425, tmp424,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x4, x23, x1	// _337, _132, tmp425
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldr	s5, [x23, x1]	// MEM[(struct complex *)_337]._M_value, MEM[(struct complex *)_337]._M_value
	ldr	s2, [x4, 4]	// MEM[(struct complex *)_337]._M_value, MEM[(struct complex *)_337]._M_value
	fadd	s1, s5, s1	// tmp427, MEM[(struct complex *)_337]._M_value, _323
	fsub	s0, s2, s0	// _333, MEM[(struct complex *)_337]._M_value, _322
	str	s1, [x23, x1]	// tmp427, REALPART_EXPR <MEM[(struct complex *)_337]._M_value>
	str	s0, [x4, 4]	// _333, IMAGPART_EXPR <MEM[(struct complex *)_337]._M_value>
	b	.L811		//
	.p2align 2,,3
.L823:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	movi	v1.2s, #0	// edge
	b	.L797		//
	.p2align 2,,3
.L790:
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	ldr	s0, [x26, 24]	// MEM[(struct HeldPhase &)_124].frequency, MEM[(struct HeldPhase &)_124].frequency
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	mov	x1, 123145302310912	// tmp469,
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmov	d1, d10	//, tmp454
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	movk	x1, 0x40e7, lsl 48	// tmp469,,
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	ldr	x0, [x26, 16]	// MEM[(struct HeldPhase &)_124].center, MEM[(struct HeldPhase &)_124].center
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	fmov	d3, x1	// tmp326, tmp469
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	ldr	d4, [x26, 8]	// MEM[(struct HeldPhase &)_124].phase, MEM[(struct HeldPhase &)_124].phase
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	fadd	s0, s12, s0	// tmp316, outputHz, MEM[(struct HeldPhase &)_124].frequency
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	sub	x0, x20, x0	// tmp321, center, MEM[(struct HeldPhase &)_124].center
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	scvtf	d2, x0	// tmp323, tmp321
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	fcvt	d0, s0	// tmp318, tmp316
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	fmul	d0, d0, d11	// tmp319, tmp318, tmp453
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	fmul	d0, d0, d2	// tmp324, tmp319, tmp323
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	fdiv	d0, d0, d3	// tmp325, tmp324, tmp326
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fadd	d0, d0, d4	//, tmp325, MEM[(struct HeldPhase &)_124].phase
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:398:       phase.phase = principal(phase.phase + .5 * kTwoPi * (phase.frequency + outputHz) * (center - phase.center) / kSampleRate);
	str	d0, [x26, 8]	// _112,
// /probe/scatter-baseline-pitch.cpp:399:       phase.center = center; phase.frequency = outputHz;
	str	x20, [x26, 16]	// center,
// /probe/scatter-baseline-pitch.cpp:399:       phase.center = center; phase.frequency = outputHz;
	str	s12, [x26, 24]	// outputHz,
	b	.L795		//
	.p2align 2,,3
.L846:
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	mov	w0, 2139095039	// tmp464,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	movi	v13.2s, 0x44, lsl 24	// tmp448
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	movi	v7.2s, 0x46, lsl 24	// tmp449
	add	w4, w4, 17	// _265, _59,
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fmov	s6, w0	// tmp446, tmp464
	cmp	w4, 0	// _265,
	csel	w4, w4, wzr, le	// _265, _265,,
.L810:
// /probe/scatter-baseline-pitch.cpp:414:       if (std::abs(j) >= half) continue;
	neg	w0, w2	// tmp434, first
// /probe/scatter-baseline-pitch.cpp:414:       if (std::abs(j) >= half) continue;
	cmp	w0, w21	// tmp434, half
	bge	.L804		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	scvtf	s0, w2	// tmp362, first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x8, [x25]	// _162, MEM[(const struct __shared_ptr *)this_90(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v1.2s, #0	// _227
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabd	s0, s0, s12	// _207, tmp362, destination
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fcmp	s0, s6	// _207, tmp446
	bhi	.L805		//,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	fmul	s0, s0, s13	// position, _207, tmp448
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	fcmpe	s0, s7	// position, tmp449
	bge	.L805		//,
// /probe/scatter-baseline-pitch.cpp:67:   const auto i = static_cast<std::size_t>(position);
	fcvtzu	x1, s0	// i, position
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x1, 8192	// i,
	beq	.L849		//,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ucvtf	s2, x1	// tmp377, i
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ubfiz	x9, x1, 4, 9	// tmp375, i,,
	add	x8, x8, 32	// tmp432, _162,
	add	x9, x9, x1, lsr 9	// tmp376, tmp375, i,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	add	x1, x1, 1	// iftmp.24_223, i,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	ubfiz	x10, x1, 4, 9	// tmp379, iftmp.24_223,,
	cmp	x1, 8192	// iftmp.24_223,
	add	x10, x10, x1, lsr 9	// tmp436, tmp379, iftmp.24_223,
	csel	x1, x10, x1, ne	// iftmp.24_223, tmp436, iftmp.24_223,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ldr	s1, [x8, x9, lsl 2]	// first, MEM <const struct array> [(const value_type &)_162 + 32]._M_elems[iftmp.24_213]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s0, s0, s2	// _1, position, tmp377
.L808:
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ldr	s2, [x8, x1, lsl 2]	// MEM <const struct array> [(const value_type &)_162 + 32]._M_elems[iftmp.24_223], MEM <const struct array> [(const value_type &)_162 + 32]._M_elems[iftmp.24_223]
	fsub	s2, s2, s1	// tmp383, MEM <const struct array> [(const value_type &)_162 + 32]._M_elems[iftmp.24_223], first
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fmadd	s1, s0, s2, s1	// _227, _1, tmp383, first
.L805:
// /probe/scatter-baseline-pitch.cpp:415:       auto value = carrier * (plan_->lobe(j - destination) * spectrum_.size());
	fmul	s0, s14, s1	// _66, _38, _227
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s1, s3, s0	// value$_M_value$real, _54, _66
	fmul	s0, s4, s0	// value$_M_value$imag, _57, _66
// /probe/scatter-baseline-pitch.cpp:416:       if (j & 1) value = -value;
	tbz	x2, 0, .L809	// first,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s1, s1	// value$_M_value$real, value$_M_value$real
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s0, s0	// value$_M_value$imag, value$_M_value$imag
.L809:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ubfiz	x0, x0, 3, 32	// tmp388, tmp434,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x1, x23, x0	// _170, _132, tmp388
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldr	s5, [x23, x0]	// MEM[(struct complex *)_170]._M_value, MEM[(struct complex *)_170]._M_value
	ldr	s2, [x1, 4]	// MEM[(struct complex *)_170]._M_value, MEM[(struct complex *)_170]._M_value
	fadd	s1, s5, s1	// tmp390, MEM[(struct complex *)_170]._M_value, value$_M_value$real
	fsub	s0, s2, s0	// _255, MEM[(struct complex *)_170]._M_value, value$_M_value$imag
	str	s1, [x23, x0]	// tmp390, REALPART_EXPR <MEM[(struct complex *)_170]._M_value>
	str	s0, [x1, 4]	// _255, IMAGPART_EXPR <MEM[(struct complex *)_170]._M_value>
.L804:
// /probe/scatter-baseline-pitch.cpp:413:     for (int j = first; j <= last; ++j) {
	add	w2, w2, 1	// first, first,
// /probe/scatter-baseline-pitch.cpp:413:     for (int j = first; j <= last; ++j) {
	cmp	w2, w4	// first, _265
	blt	.L810		//,
	cmp	w7, w2	// last, first
	bge	.L803		//,
	b	.L796		//
	.p2align 2,,3
.L847:
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x4, x4, 32	// tmp433, _181,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s1, s1, s7	// _290, position, tmp445
	mov	x1, 32	// prephitmp_289,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x8, x4, 32768	// tmp402, tmp433,
	ldr	s0, [x8]	// first, MEM <const struct array> [(const value_type &)_181 + 32]._M_elems[8192]
	b	.L815		//
	.p2align 2,,3
.L849:
	add	x8, x8, 32	// tmp432, _162,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s0, s0, s7	// _1, position, tmp449
	mov	x1, 32	// iftmp.24_223,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x9, x8, 32768	// tmp369, tmp432,
	ldr	s1, [x9]	// first, MEM <const struct array> [(const value_type &)_162 + 32]._M_elems[8192]
	b	.L808		//
	.cfi_endproc
.LFE9596:
	.size	_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_, .-_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_
	.type	_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_, %function
_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_:
.LFB9586:
	.cfi_startproc
	sub	sp, sp, #496	//,,
	.cfi_def_cfa_offset 496
	adrp	x10, :got:__stack_chk_guard	// tmp761,
	ldr	x10, [x10, :got_lo12:__stack_chk_guard]	// tmp761,
	stp	x29, x30, [sp, 336]	//,,
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	add	x29, sp, 336	//,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x9, [x0]	// _390, MEM[(const struct __shared_ptr *)this_291(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:216:                            float heldMix, float heldGain, const PitchRenderer* heldReference) noexcept {
	stp	x19, x20, [sp, 352]	//,,
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	mov	x20, x0	// this, tmp1504
	ldr	x0, [sp, 496]	// heldLow, heldLow
	str	x0, [sp, 64]	// heldLow, %sfp
	ldr	x0, [x10]	// tmp1548,
	str	x0, [sp, 328]	// tmp1548, D.330101
	mov	x0, 0	// tmp1548
	ldr	x0, [sp, 504]	// heldReference, heldReference
	str	x3, [sp, 48]	// tmp1508, %sfp
	str	x0, [sp, 72]	// heldReference, %sfp
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	cbz	x9, .L977	// _390,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	add	x0, x20, 96	// tmp1444, this,
	stp	x23, x24, [sp, 384]	//,,
	.cfi_offset 24, -104
	.cfi_offset 23, -112
	mov	x12, x1	// frame, tmp1505
	stp	x27, x28, [sp, 416]	//,,
	.cfi_offset 28, -72
	.cfi_offset 27, -80
	ldp	x24, x28, [x20, 96]	// _381, _388, MEM[(const struct vector *)this_291(D) + 96B].D.212165._M_impl.D.211503._M_start
	str	x0, [sp, 80]	// tmp1444, %sfp
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	ldr	x0, [x1, 12384]	// MEM <const size_t> [(const struct PitchFrame *)frame_293(D) + 12384B], MEM <const size_t> [(const struct PitchFrame *)frame_293(D) + 12384B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x13, x28, x24	// tmp766, _388, _381
	asr	x8, x13, 3	// _374, tmp766,
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	cmp	x0, x8	// MEM <const size_t> [(const struct PitchFrame *)frame_293(D) + 12384B], _374
	beq	.L1078		//,
	ldp	x23, x24, [sp, 384]	//,,
	.cfi_restore 24
	.cfi_restore 23
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	mov	w0, 0	// _240,
	ldp	x27, x28, [sp, 416]	//,,
	.cfi_restore 28
	.cfi_restore 27
.L851:
// /probe/scatter-baseline-pitch.cpp:381: }
	adrp	x1, :got:__stack_chk_guard	// tmp1437,
	ldr	x1, [x1, :got_lo12:__stack_chk_guard]	// tmp1437,
	ldr	x3, [sp, 328]	// tmp1551, D.330101
	ldr	x2, [x1]	// tmp1552,
	subs	x3, x3, x2	// tmp1551, tmp1552
	mov	x2, 0	// tmp1552
	bne	.L1079		//,
	ldp	x29, x30, [sp, 336]	//,,
	ldp	x19, x20, [sp, 352]	//,,
	add	sp, sp, 496	//,,
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1078:
	.cfi_def_cfa_offset 496
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 27, -80
	.cfi_offset 28, -72
	.cfi_offset 29, -160
	.cfi_offset 30, -152
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	mov	w0, 2139095039	// tmp1547,
	stp	d8, d9, [sp, 432]	//,,
	.cfi_offset 73, -56
	.cfi_offset 72, -64
	fmov	s8, s1	// heldMix, tmp1512
	fmov	s9, s2	// heldGain, tmp1513
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabs	s2, s0	// tmp769, semitones
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	fmov	s1, w0	// tmp770, tmp1547
	fcmp	s2, s1	// tmp769, tmp770
	bhi	.L979		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fmov	s1, -2.4e+1	// tmp771,
	stp	x21, x22, [sp, 368]	//,,
	.cfi_offset 22, -120
	.cfi_offset 21, -128
	mov	x19, x4	// gains, tmp1509
	mov	x21, x7	// held, tmp1511
	stp	x25, x26, [sp, 400]	//,,
	.cfi_offset 26, -88
	.cfi_offset 25, -96
	mov	x25, x2	// lowAnalysis, tmp1507
	mov	x26, x5	// lowGains, tmp1510
	fcmpe	s0, s1	// semitones, tmp771
	stp	d10, d11, [sp, 448]	//,,
	.cfi_offset 75, -40
	.cfi_offset 74, -48
	stp	d12, d13, [sp, 464]	//,,
	.cfi_offset 77, -24
	.cfi_offset 76, -32
	stp	d14, d15, [sp, 480]	//,,
	.cfi_offset 79, -8
	.cfi_offset 78, -16
	bmi	.L980		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s2, 2.4e+1	// tmp772,
	fmov	s1, 2.0e+0	// prephitmp_1150,
	fcmpe	s0, s2	// semitones, tmp772
	bgt	.L852		//,
// /probe/scatter-baseline-pitch.cpp:218:   const float ratio = std::exp2(std::clamp(semitones, -24.0f, 24.0f) / 12);
	fmov	s1, 1.2e+1	// tmp774,
	and	w23, w6, 255	// partialProcessing, partialProcessing
	stp	x8, x9, [sp]	// _374, _390, %sfp
	str	x1, [sp, 16]	// frame, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:2149:   { return __builtin_exp2f(__x); }
	fdiv	s0, s0, s1	//, semitones, tmp774
	bl	exp2f		//
// /probe/scatter-baseline-pitch.cpp:219:   if (ratio != 1) shifted_ = true;
	fmov	s1, 1.0e+0	// tmp775,
	ldp	x8, x9, [sp]	// _374, _390, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:2149:   { return __builtin_exp2f(__x); }
	fmov	s12, s0	// _348, tmp1514
// /probe/scatter-baseline-pitch.cpp:219:   if (ratio != 1) shifted_ = true;
	fcmp	s0, s1	// _348, tmp775
	ldr	x12, [sp, 16]	// frame, %sfp
	bne	.L975		//,
// /probe/scatter-baseline-pitch.cpp:223:   if (!shifted_ && !partialProcessing) lowAnalysis = nullptr;
	add	x22, x20, 16384	// tmp1448, this,
// /probe/scatter-baseline-pitch.cpp:223:   if (!shifted_ && !partialProcessing) lowAnalysis = nullptr;
	ldrb	w0, [x22, 2704]	// tmp780, this_291(D)->shifted_
	orr	w0, w0, w23	// tmp782, tmp780, partialProcessing
// /probe/scatter-baseline-pitch.cpp:223:   if (!shifted_ && !partialProcessing) lowAnalysis = nullptr;
	tst	x0, 1	// tmp782,
	csel	x25, x25, xzr, ne	// lowAnalysis, lowAnalysis,,
.L854:
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:24:   std::size_t hopSize() const noexcept { return hopSize_; }
	ldr	x0, [x9]	// MEM[(const struct __shared_ptr *)_390]._M_ptr, MEM[(const struct __shared_ptr *)_390]._M_ptr
// /probe/scatter-baseline-pitch.cpp:226:   const double hopPhase = kTwoPi * plan_->spectral->hopSize() / spectrum_.size();
	adrp	x1, .LC2	// tmp1736,
// /probe/scatter-baseline-pitch.cpp:226:   const double hopPhase = kTwoPi * plan_->spectral->hopSize() / spectrum_.size();
	ucvtf	d15, x8	// _18, _374
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x24, x28	// _381, _388
// /probe/scatter-baseline-pitch.cpp:226:   const double hopPhase = kTwoPi * plan_->spectral->hopSize() / spectrum_.size();
	ldr	d0, [x1, #:lo12:.LC2]	// tmp788,
// /probe/scatter-baseline-pitch.cpp:225:   const int half = static_cast<int>(spectrum_.size() / 2);
	lsr	x1, x8, 1	// _12, _374,
// /probe/scatter-baseline-pitch.cpp:225:   const int half = static_cast<int>(spectrum_.size() / 2);
	mov	w27, w1	// _13, _12
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:69:   std::span<const std::complex<float>> spectrum() const noexcept { return spectrum_; }
	ldr	x2, [x12, 12376]	// SR.761, MEM <const struct complex *> [(const struct PitchFrame *)frame_293(D) + 12376B]
// /probe/scatter-baseline-pitch.cpp:226:   const double hopPhase = kTwoPi * plan_->spectral->hopSize() / spectrum_.size();
	ldr	d10, [x0, 72]	// MEM[(const struct SpectralPlan *)_455].hopSize_, MEM[(const struct SpectralPlan *)_455].hopSize_
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:69:   std::span<const std::complex<float>> spectrum() const noexcept { return spectrum_; }
	stp	x1, x2, [sp, 88]	// _12, SR.761, %sfp
// /probe/scatter-baseline-pitch.cpp:226:   const double hopPhase = kTwoPi * plan_->spectral->hopSize() / spectrum_.size();
	ucvtf	d10, d10	// tmp785, MEM[(const struct SpectralPlan *)_455].hopSize_
	fmul	d10, d10, d0	// tmp787, tmp785, tmp788
// /probe/scatter-baseline-pitch.cpp:226:   const double hopPhase = kTwoPi * plan_->spectral->hopSize() / spectrum_.size();
	fdiv	d0, d10, d15	// hopPhase, tmp787, _18
	str	d0, [sp, 56]	// hopPhase, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L861		//,
	sub	x0, x28, #8	// tmp796, _388,
	mov	x1, x24	// ivtmp.2414, _381
	sub	x0, x0, x24	// _1098, tmp796, _381
	cmp	x0, 16	// _1098,
	lsr	x0, x0, 3	// tmp797, _1098,
	add	x0, x0, 1	// niters.2275, tmp797,
	bls	.L982		//,
	lsr	x2, x0, 1	// bnd.2276, niters.2275,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	movi	v0.4s, 0	// tmp800
	add	x2, x24, x2, lsl 4	// _1109, _381, bnd.2276,
	.p2align 3,,7
.L859:
	str	q0, [x1], 16	// tmp800, MEM <vector(4) float> [(float *)_1058]
	cmp	x2, x1	// _1109, ivtmp.2414
	bne	.L859		//,
	tbz	x0, 0, .L861	// niters.2275,,
	and	x0, x0, -2	// niters_vector_mult_vf.2277, niters.2275,
	add	x0, x24, x0, lsl 3	// tmp.2278, _381, niters_vector_mult_vf.2277,
.L858:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x1, x0, 8	// __first, tmp.2278,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x0]	//, REALPART_EXPR <__first_1086->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x28, x1	// _388, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x0, 4]	//, IMAGPART_EXPR <__first_1086->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L861		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x1, x0, 16	// __first, tmp.2278,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x0, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_1086 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x28, x1	// _388, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x0, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_1086 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L861		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x0, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_1086 + 16B]._M_value>
.L861:
// /probe/scatter-baseline-pitch.cpp:228:   const bool fullyHeld = held && heldMix == 1 && !heldPhases_.empty();
	fmov	s0, 1.0e+0	// tmp792,
// /probe/scatter-baseline-pitch.cpp:228:   const bool fullyHeld = held && heldMix == 1 && !heldPhases_.empty();
	cmp	x21, 0	// held,
	cset	w1, ne	// tmp790,
// /probe/scatter-baseline-pitch.cpp:228:   const bool fullyHeld = held && heldMix == 1 && !heldPhases_.empty();
	fcmp	s8, s0	// heldMix, tmp792
	cset	w0, eq	// tmp793,
// /probe/scatter-baseline-pitch.cpp:228:   const bool fullyHeld = held && heldMix == 1 && !heldPhases_.empty();
	and	w2, w1, w0	// _21, tmp790, tmp793
	str	w2, [sp, 8]	// _21, %sfp
// /probe/scatter-baseline-pitch.cpp:228:   const bool fullyHeld = held && heldMix == 1 && !heldPhases_.empty();
	tst	w1, w0	// tmp790, tmp793
	beq	.L857		//,
// /probe/scatter-baseline-pitch.cpp:228:   const bool fullyHeld = held && heldMix == 1 && !heldPhases_.empty();
	ldr	x0, [x20, 19064]	// MEM[(const struct HeldPhase * const &)this_291(D) + 19064], MEM[(const struct HeldPhase * const &)this_291(D) + 19064]
	ldr	x1, [x20, 19072]	// MEM[(const struct HeldPhase * const &)this_291(D) + 19072], MEM[(const struct HeldPhase * const &)this_291(D) + 19072]
	cmp	x1, x0	// MEM[(const struct HeldPhase * const &)this_291(D) + 19072], MEM[(const struct HeldPhase * const &)this_291(D) + 19064]
	cset	w0, ne	// _21,
	str	w0, [sp, 8]	// _21, %sfp
.L857:
// /probe/scatter-baseline-pitch.cpp:229:   lowCarriers_ = {};
	mov	x3, 17408	//,
	mov	x2, 2048	//,
	str	x8, [sp]	// _374, %sfp
	add	x0, x20, x3	// tmp1443, this,
	mov	w1, 0	//,
	stp	x9, x12, [sp, 16]	// _390, frame, %sfp
	str	x0, [sp, 160]	// tmp1443, %sfp
	sub	x0, x0, #392	//, tmp1443,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:230:   if (lowAnalysis && !lowAnalysis->spectrum().empty()) {
	ldr	x8, [sp]	// _374, %sfp
	ldp	x9, x12, [sp, 16]	// _390, frame, %sfp
	cbz	x25, .L863	// lowAnalysis,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:69:   std::span<const std::complex<float>> spectrum() const noexcept { return spectrum_; }
	ldr	x1, [x25, 12384]	// SR.766, MEM <const size_t> [(const struct PitchFrame *)lowAnalysis_226 + 12384B]
// /probe/scatter-baseline-pitch.cpp:230:   if (lowAnalysis && !lowAnalysis->spectrum().empty()) {
	cbz	x1, .L867	// SR.766,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	ldr	x0, [x25, 12392]	// lowAnalysis_226->count_, lowAnalysis_226->count_
// /probe/scatter-baseline-pitch.cpp:232:     const double scale = static_cast<double>(spectrum_.size()) / lowInput.size();
	ucvtf	d4, x1	// _23, SR.766
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:282:       { return static_cast<const_pointer>(_M_elems); }
	add	x2, x25, 88	// _440, lowAnalysis,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	add	x0, x0, x0, lsl 1	// tmp825, lowAnalysis_226->count_, lowAnalysis_226->count_,
// /probe/scatter-baseline-pitch.cpp:232:     const double scale = static_cast<double>(spectrum_.size()) / lowInput.size();
	fdiv	d14, d15, d4	// scale, _18, _23
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	lsl	x0, x0, 3	// tmp826, tmp825,
	add	x4, x2, x0	// _434, _440, tmp826
// /probe/scatter-baseline-pitch.cpp:233:     for (const auto& region : lowAnalysis->regions()) {
	cbz	x0, .L867	// tmp826,
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	mov	w0, 1137180672	// tmp1546,
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	mov	w3, 32768	// tmp1545,
	movk	w3, 0x473b, lsl 16	// tmp1545,,
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	ucvtf	s13, x8	// tmp1441, _374
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	str	w27, [sp, 16]	// _13, %sfp
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	fmov	s11, w0	// tmp833, tmp1546
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	mov	x27, x4	// _434, _434
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:69:   std::span<const std::complex<float>> spectrum() const noexcept { return spectrum_; }
	ldr	x0, [x25, 12376]	// SR.765, MEM <const struct complex *> [(const struct PitchFrame *)lowAnalysis_226 + 12376B]
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	fmov	s10, w3	// tmp831, tmp1545
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	str	d15, [sp, 24]	// _18, %sfp
	fmov	d15, d4	// _23, _23
	stp	x8, x24, [sp, 32]	// _374, _381, %sfp
	mov	x24, x20	// this, this
	mov	x20, x12	// frame, frame
	mov	x23, x0	// SR.765, SR.765
	stp	x28, x9, [sp, 104]	// _388, _390, %sfp
	stp	x19, x26, [sp, 120]	// gains, lowGains, %sfp
	mov	x19, x1	// SR.766, SR.766
	str	x21, [sp, 136]	// held, %sfp
	mov	x21, x2	// ivtmp.2407, ivtmp.2407
	str	s8, [sp, 144]	// heldMix, %sfp
	str	s9, [sp, 152]	// heldGain, %sfp
	b	.L882		//
.L1083:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s9, s9	// amplitude$_M_value$real, amplitude$_M_value$real
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s8, s8	// amplitude$_M_value$imag, amplitude$_M_value$imag
.L879:
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	adrp	x1, .LC2	// tmp1753,
// /probe/scatter-baseline-pitch.cpp:258:         * (frame.centerSamples() - lowAnalysis->centerSamples()) / lowInput.size();
	ldr	x0, [x20, 12424]	// frame_293(D)->centerSamples_, frame_293(D)->centerSamples_
// /probe/scatter-baseline-pitch.cpp:257:       const double extrapolation = kTwoPi * region.frequencyBins
	fcvt	d2, s2	// tmp930, _55
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	ldr	d1, [x1, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:258:         * (frame.centerSamples() - lowAnalysis->centerSamples()) / lowInput.size();
	ldr	x1, [x25, 12424]	// lowAnalysis_226->centerSamples_, lowAnalysis_226->centerSamples_
// /probe/scatter-baseline-pitch.cpp:259:       const double angle = principal(phase.offset + extrapolation);
	ldr	d3, [x28, 8320]	// MEM <double> [(struct Phase &)_635 + 8320], MEM <double> [(struct Phase &)_635 + 8320]
// /probe/scatter-baseline-pitch.cpp:257:       const double extrapolation = kTwoPi * region.frequencyBins
	fmul	d2, d2, d1	// tmp931, tmp930, tmp1754
// /probe/scatter-baseline-pitch.cpp:258:         * (frame.centerSamples() - lowAnalysis->centerSamples()) / lowInput.size();
	sub	x0, x0, x1	// tmp926, frame_293(D)->centerSamples_, lowAnalysis_226->centerSamples_
// /probe/scatter-baseline-pitch.cpp:258:         * (frame.centerSamples() - lowAnalysis->centerSamples()) / lowInput.size();
	scvtf	d0, x0	// tmp929, tmp926
	fmul	d0, d0, d2	// tmp933, tmp929, tmp931
// /probe/scatter-baseline-pitch.cpp:258:         * (frame.centerSamples() - lowAnalysis->centerSamples()) / lowInput.size();
	fdiv	d0, d0, d15	// extrapolation, tmp933, _23
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fadd	d0, d0, d3	//, extrapolation, MEM <double> [(struct Phase &)_635 + 8320]
	bl	remainder		//
	add	x1, sp, 208	//,,
	add	x0, sp, 216	//,,
	bl	sincos		//
	ldp	d2, d3, [sp, 208]	// sincostmp_1091, sincostmp_1091,
// /probe/scatter-baseline-pitch.cpp:261:         * std::complex<float>{static_cast<float>(std::cos(angle)), static_cast<float>(std::sin(angle))}
	fcvt	s2, d2	// _70, sincostmp_1091
// /probe/scatter-baseline-pitch.cpp:261:         * std::complex<float>{static_cast<float>(std::cos(angle)), static_cast<float>(std::sin(angle))}
	fcvt	s3, d3	// _72, sincostmp_1091
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1479: 	  _M_value *= __t;
	fmul	s1, s2, s8	// _237, _70, amplitude$_M_value$imag
	fmul	s6, s3, s8	// tmp939, _72, amplitude$_M_value$imag
	fmadd	s1, s3, s9, s1	// _286, _72, amplitude$_M_value$real, _237
	fnmsub	s6, s2, s9, s6	// _247, _70, amplitude$_M_value$real, tmp939
	fcmp	s6, s1	// _247, _286
	bvs	.L1080		//,
.L880:
// /probe/scatter-baseline-pitch.cpp:262:         * std::min(age * .5f, 1.0f);
	scvtf	s0, w26, #1	// _75, _49,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s2, 1.0e+0	// tmp944,
	fcmpe	s0, s2	// _75, tmp944
	bgt	.L881		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s6, s6, s0	// _247, _247, _75
	fmul	s1, s1, s0	// _286, _286, _75
.L881:
	ldrh	w0, [x21, 6]	// MEM[(short unsigned int *)_1185 + 6B], MEM[(short unsigned int *)_1185 + 6B]
	add	x0, x24, x0, lsl 3	// _938, this, MEM[(short unsigned int *)_1185 + 6B],
// /probe/scatter-baseline-pitch.cpp:260:       lowCarriers_[region.track] = amplitude
	add	x0, x0, 16384	// tmp948, _938,
	str	s6, [x0, 632]	// _247, MEM <float> [(struct value_type *)_938 + 17016B]
	str	s1, [x0, 636]	// _286, MEM <float> [(struct value_type *)_938 + 17020B]
.L870:
// /probe/scatter-baseline-pitch.cpp:233:     for (const auto& region : lowAnalysis->regions()) {
	add	x21, x21, 24	// ivtmp.2407, ivtmp.2407,
	cmp	x27, x21	// _434, ivtmp.2407
	beq	.L1081		//,
.L882:
// /probe/scatter-baseline-pitch.cpp:234:       const float frequency = static_cast<float>(region.frequencyBins * scale);
	ldr	s0, [x21, 16]	// MEM[(float *)_1185 + 16B], MEM[(float *)_1185 + 16B]
	fcvt	d0, s0	// tmp827, MEM[(float *)_1185 + 16B]
// /probe/scatter-baseline-pitch.cpp:234:       const float frequency = static_cast<float>(region.frequencyBins * scale);
	fmul	d0, d0, d14	// tmp829, tmp827, scale
// /probe/scatter-baseline-pitch.cpp:234:       const float frequency = static_cast<float>(region.frequencyBins * scale);
	fcvt	s8, d0	// frequency, tmp829
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	fmul	s0, s8, s10	// tmp830, frequency, tmp831
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	fdiv	s0, s0, s13	// tmp832, tmp830, tmp1441
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	fcmpe	s0, s11	// tmp832, tmp833
	bge	.L870		//,
// /probe/scatter-baseline-pitch.cpp:236:       auto& phase = lowPhases_[region.track];
	ldrh	w0, [x21, 6]	// _31, MEM[(short unsigned int *)_1185 + 6B]
// /probe/scatter-baseline-pitch.cpp:238:       if (phase.generation != region.generation) {
	ldr	x3, [x21, 8]	// _34, MEM[(long unsigned int *)_1185 + 8B]
	lsl	x1, x0, 5	// tmp835, _31,
// /probe/scatter-baseline-pitch.cpp:237:       auto& age = phaseAges_[kMaxPitchPartials + region.track];
	add	x7, x0, 256	// _32, _31,
	add	x28, x24, x1	// _635, this, tmp835
// /probe/scatter-baseline-pitch.cpp:238:       if (phase.generation != region.generation) {
	ldr	x0, [x28, 8312]	// MEM <uint64_t> [(struct Phase &)_635 + 8312], MEM <uint64_t> [(struct Phase &)_635 + 8312]
	cmp	x0, x3	// MEM <uint64_t> [(struct Phase &)_635 + 8312], _34
	beq	.L871		//,
// /probe/scatter-baseline-pitch.cpp:241:         phase = {.generation = region.generation, .frequency = frequency, .ratio = ratio}; age = 0;
	mov	x2, 8312	//,
	mov	w26, 1	// _49,
	str	x3, [x28, 8312]	// _34, MEM <uint64_t> [(struct Phase *)_635 + 8312B]
	add	x0, x24, x2	// tmp839, this,
	str	xzr, [x28, 8320]	//, MEM <double> [(struct Phase *)_635 + 8320B]
	add	x0, x0, x1	// tmp841, tmp839, tmp835
	mov	w1, w26	// prephitmp_1173, _49
	str	xzr, [x0, 16]	//, MEM <struct array> [(struct Phase *)this_291(D) + 8312B]._M_elems[_31].alignment
	stp	s8, s12, [x0, 24]	// frequency, _348, MEM <struct array> [(struct Phase *)this_291(D) + 8312B]._M_elems[_31].frequency
.L872:
// /probe/scatter-baseline-pitch.cpp:248:       age = std::min<unsigned>(age + 1, 2);
	add	x0, x22, 120	// tmp888, tmp1448,
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	mov	w8, 2139095039	// tmp1544,
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v1.2s, #0	// _732
// /probe/scatter-baseline-pitch.cpp:248:       age = std::min<unsigned>(age + 1, 2);
	strb	w1, [x0, x7]	// prephitmp_1173, MEM <struct array> [(unsigned char &)this_291(D) + 16504]._M_elems[_32]
// /probe/scatter-baseline-pitch.cpp:249:       const float windowGain = lowAnalysis->lobe(static_cast<float>(region.bin) - region.frequencyBins)
	ldrh	w1, [x21]	// _53, MEM[(short unsigned int *)_1185]
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fmov	s3, w8	// tmp892, tmp1544
// /probe/scatter-baseline-pitch.cpp:249:       const float windowGain = lowAnalysis->lobe(static_cast<float>(region.bin) - region.frequencyBins)
	ldr	s2, [x21, 16]	// _55, MEM[(float *)_1185 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x7, [x25]	// _345, MEM[(const struct __shared_ptr *)lowAnalysis_226]._M_ptr
// /probe/scatter-baseline-pitch.cpp:249:       const float windowGain = lowAnalysis->lobe(static_cast<float>(region.bin) - region.frequencyBins)
	ucvtf	s0, w1	// tmp890, _53
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabd	s0, s0, s2	// _712, tmp890, _55
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fcmp	s0, s3	// _712, tmp892
	bhi	.L873		//,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	movi	v3.2s, 0x44, lsl 24	// tmp1750
	fmul	s0, s0, s3	// position, _712, tmp1750
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	movi	v3.2s, 0x46, lsl 24	// tmp1751
	fcmpe	s0, s3	// position, tmp1751
	bge	.L873		//,
// /probe/scatter-baseline-pitch.cpp:67:   const auto i = static_cast<std::size_t>(position);
	fcvtzu	x0, s0	// i, position
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x0, 8192	// i,
	beq	.L1082		//,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ucvtf	s3, x0	// tmp905, i
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ubfiz	x8, x0, 4, 9	// tmp903, i,,
	add	x7, x7, 32	// tmp1446, _345,
	add	x8, x8, x0, lsr 9	// tmp904, tmp903, i,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	add	x0, x0, 1	// iftmp.24_728, i,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	ubfiz	x9, x0, 4, 9	// tmp907, iftmp.24_728,,
	cmp	x0, 8192	// iftmp.24_728,
	add	x9, x9, x0, lsr 9	// tmp1451, tmp907, iftmp.24_728,
	csel	x0, x9, x0, ne	// iftmp.24_728, tmp1451, iftmp.24_728,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ldr	s1, [x7, x8, lsl 2]	// first, MEM <const struct array> [(const value_type &)_345 + 32]._M_elems[iftmp.24_718]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s0, s0, s3	// _266, position, tmp905
.L876:
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ldr	s3, [x7, x0, lsl 2]	// MEM <const struct array> [(const value_type &)_345 + 32]._M_elems[iftmp.24_728], MEM <const struct array> [(const value_type &)_345 + 32]._M_elems[iftmp.24_728]
	fsub	s3, s3, s1	// tmp911, MEM <const struct array> [(const value_type &)_345 + 32]._M_elems[iftmp.24_728], first
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fmadd	s1, s0, s3, s1	// _732, _266, tmp911, first
.L873:
// /probe/scatter-baseline-pitch.cpp:250:         * lowInput.size();
	ucvtf	s3, x19	// _57, SR.766
// /probe/scatter-baseline-pitch.cpp:253:       if (windowGain < .25f * lowInput.size()) continue;
	fmov	s6, 2.5e-1	// tmp914,
// /probe/scatter-baseline-pitch.cpp:250:         * lowInput.size();
	fmul	s0, s3, s1	// _58, _57, _732
// /probe/scatter-baseline-pitch.cpp:253:       if (windowGain < .25f * lowInput.size()) continue;
	fmul	s3, s3, s6	// tmp913, _57, tmp914
// /probe/scatter-baseline-pitch.cpp:253:       if (windowGain < .25f * lowInput.size()) continue;
	fcmpe	s0, s3	// _58, tmp913
	bmi	.L870		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:289: 	return *(this->_M_ptr + __idx);
	ubfiz	x0, x1, 3, 16	// tmp916, _53,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:289: 	return *(this->_M_ptr + __idx);
	add	x7, x23, x0	// _319, SR.765, tmp916
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1439: 	_M_value /= __f;
	ldr	s3, [x23, x0]	// MEM[(const struct complex &)_319]._M_value, MEM[(const struct complex &)_319]._M_value
	ldr	s1, [x7, 4]	// MEM[(const struct complex &)_319]._M_value, MEM[(const struct complex &)_319]._M_value
	fdiv	s9, s3, s0	// amplitude$_M_value$real, MEM[(const struct complex &)_319]._M_value, _58
	fdiv	s8, s1, s0	// amplitude$_M_value$imag, MEM[(const struct complex &)_319]._M_value, _58
// /probe/scatter-baseline-pitch.cpp:255:       if (region.bin & 1) amplitude = -amplitude;
	tbnz	x1, 0, .L1083	// _53,,
// /probe/scatter-baseline-pitch.cpp:256:       if (region.bin == 0) amplitude *= .5f;
	cbnz	w1, .L879	// _53,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmov	s0, 5.0e-1	// tmp923,
	fmul	s9, s9, s0	// amplitude$_M_value$real, amplitude$_M_value$real, tmp923
	fmul	s8, s8, s0	// amplitude$_M_value$imag, amplitude$_M_value$imag, tmp923
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1433: 	return *this;
	b	.L879		//
.L980:
	fmov	s1, -2.0e+0	// prephitmp_1150,
.L852:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:2149:   { return __builtin_exp2f(__x); }
	fmov	s0, s1	//, prephitmp_1150
	stp	x8, x9, [sp]	// _374, _390, %sfp
	str	x12, [sp, 16]	// frame, %sfp
	bl	exp2f		//
	ldp	x8, x9, [sp]	// _374, _390, %sfp
	fmov	s12, s0	// _348, tmp1526
	ldr	x12, [sp, 16]	// frame, %sfp
.L975:
// /probe/scatter-baseline-pitch.cpp:219:   if (ratio != 1) shifted_ = true;
	add	x22, x20, 16384	// tmp1448, this,
	mov	w0, 1	// tmp777,
	strb	w0, [x22, 2704]	// tmp777, this_291(D)->shifted_
	b	.L854		//
.L1081:
	ldr	d15, [sp, 24]	// _18, %sfp
	mov	x12, x20	// frame, frame
	mov	x20, x24	// this, this
	ldp	x8, x24, [sp, 32]	// _374, _381, %sfp
	ldp	x28, x9, [sp, 104]	// _388, _390, %sfp
	ldp	x19, x26, [sp, 120]	// gains, lowGains, %sfp
	ldr	s8, [sp, 144]	// heldMix, %sfp
	ldr	s9, [sp, 152]	// heldGain, %sfp
	ldr	x21, [sp, 136]	// held, %sfp
	ldr	w27, [sp, 16]	//, %sfp
.L867:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:282:       { return static_cast<const_pointer>(_M_elems); }
	add	x2, x12, 88	// _489, frame,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	ldr	x0, [x12, 12392]	// frame_293(D)->count_, frame_293(D)->count_
	add	x0, x0, x0, lsl 1	// tmp820, frame_293(D)->count_, frame_293(D)->count_,
	lsl	x0, x0, 3	// tmp821, tmp820,
	add	x1, x2, x0	// _488, _489, tmp821
	str	x1, [sp]	// _488, %sfp
// /probe/scatter-baseline-pitch.cpp:265:   for (const auto& region : frame.regions()) {
	cbz	x0, .L866	// tmp821,
.L865:
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	fmov	s11, 1.0e+0	// tmp958,
	scvtf	s10, w27	// _1395, _13
	add	x0, x20, 120	// tmp1445, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmov	s13, 2.0e+0	// tmp1498,
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	mov	x23, x8	// _374, _374
	str	x9, [sp, 104]	// _390, %sfp
	str	d15, [sp, 112]	// _18, %sfp
	stp	x28, x12, [sp, 120]	// _388, frame, %sfp
	mov	x28, x25	// lowAnalysis, lowAnalysis
	mov	w25, w27	// _13, _13
	fsub	s11, s12, s11	// _1191, _348, tmp958
	mov	x27, x2	// ivtmp.2402, ivtmp.2402
	stp	x26, x21, [sp, 136]	// lowGains, held, %sfp
	mov	x26, x24	// _381, _381
	mov	x21, x19	// gains, gains
	mov	x24, x22	// tmp1448, tmp1448
	mov	x19, x0	// tmp1445, tmp1445
	stp	s8, s9, [sp, 152]	// heldMix, heldGain, %sfp
	str	s11, [sp, 16]	// _1191, %sfp
	fmov	s11, s10	// _1395, _1395
	b	.L937		//
	.p2align 2,,3
.L1088:
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fsub	s0, s11, s0	// tmp1007, _1395, destination
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fmov	s2, 6.0e+0	// tmp1010,
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fsub	s0, s0, s13	// tmp1008, tmp1007, tmp1498
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fdiv	s0, s0, s2	// edge, tmp1008, tmp1010
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// edge
	bmi	.L987		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	s0, s1	// edge, tmp1006
	bgt	.L1000		//,
.L888:
// /probe/scatter-baseline-pitch.cpp:282:     const float fade = ratio == 1 ? 1 : std::min(age * .5f, 1.0f);
	fmov	s8, s12	// gain, _348
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	cbz	x28, .L1084	// lowAnalysis,
.L893:
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	mov	w0, 32768	// tmp1541,
	movk	w0, 0x473b, lsl 16	// tmp1541,,
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	ucvtf	s4, x23	// tmp1441, _374
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w2, 1128792064	// tmp1542,
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	fmov	s1, w0	// tmp1020, tmp1541
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w0, 1120403456	// tmp1543,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s3, w2	// tmp1024, tmp1542
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s2, w0	// tmp1025, tmp1543
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	fmul	s1, s15, s1	// tmp1019, _105, tmp1020
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	fdiv	s1, s1, s4	// tmp1022, tmp1019, tmp1441
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fsub	s1, s1, s3	// tmp1023, tmp1022, tmp1024
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fdiv	s1, s1, s2	// _498, tmp1023, tmp1025
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s1, #0.0	// _498
	bmi	.L1003		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s2, 1.0e+0	// tmp1027,
	fcmpe	s1, s2	// _498, tmp1027
	bgt	.L901		//,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmov	s3, 3.0e+0	// tmp1029,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmul	s2, s1, s1	// _1208, _498, _498
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmsub	s1, s1, s13, s3	// _1212, _498, tmp1498, tmp1029
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmul	s1, s2, s1	// tmp1030, _1208, _1212
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmul	s8, s8, s1	// gain, gain, tmp1030
	.p2align 3,,7
.L901:
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmov	s1, 1.0e+0	// tmp1031,
	fcmp	s12, s1	// _348, tmp1031
	bne	.L898		//,
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	cbz	x21, .L1085	// gains,
.L902:
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	ldrh	w0, [x27, 6]	// MEM[(short unsigned int *)_696 + 6B], MEM[(short unsigned int *)_696 + 6B]
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	ldr	s0, [x21, x0, lsl 2]	// MEM <const struct array> [(const value_type &)gains_422(D)]._M_elems[_124], MEM <const struct array> [(const value_type &)gains_422(D)]._M_elems[_124]
	fmul	s8, s8, s0	// gain, gain, MEM <const struct array> [(const value_type &)gains_422(D)]._M_elems[_124]
.L904:
// /probe/scatter-baseline-pitch.cpp:286:     if (gain == 0) continue;
	fcmp	s8, #0.0	// gain
	beq	.L936		//,
// /probe/scatter-baseline-pitch.cpp:287:     double rotationPhase = phase.offset;
	ldr	d3, [x1, 128]	// rotationPhase, MEM <double> [(struct Phase &)_1377 + 128]
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	cbz	x28, .L895	// lowAnalysis,
	ucvtf	s4, x23	// tmp1441, _374
.L903:
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	mov	w1, 32768	// tmp1539,
	movk	w1, 0x473b, lsl 16	// tmp1539,,
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	mov	w0, 1137180672	// tmp1540,
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	fmov	s0, w1	// tmp1038, tmp1539
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	fmov	s1, w0	// tmp1040, tmp1540
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	fmul	s0, s15, s0	// tmp1037, _105, tmp1038
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	fdiv	s9, s0, s4	// _127, tmp1037, tmp1441
// /probe/scatter-baseline-pitch.cpp:288:     if (lowAnalysis && region.frequencyBins * kSampleRate / spectrum_.size() < 400.0f) {
	fcmpe	s9, s1	// _127, tmp1040
	bmi	.L1004		//,
.L895:
// /probe/scatter-baseline-pitch.cpp:308:     if (fullyHeld) continue;
	ldr	w0, [sp, 8]	//, %sfp
	cbz	w0, .L1086	// _21,
.L936:
// /probe/scatter-baseline-pitch.cpp:265:   for (const auto& region : frame.regions()) {
	ldr	x0, [sp]	// _488, %sfp
	add	x27, x27, 24	// ivtmp.2402, ivtmp.2402,
	cmp	x0, x27	// _488, ivtmp.2402
	beq	.L1087		//,
.L937:
// /probe/scatter-baseline-pitch.cpp:266:     auto& phase = phases_[region.track];
	ldrh	w4, [x27, 6]	// _79, MEM[(short unsigned int *)_696 + 6B]
// /probe/scatter-baseline-pitch.cpp:268:     if (phase.generation != region.generation) {
	ldr	x0, [x27, 8]	// _82, MEM[(long unsigned int *)_696 + 8B]
// /probe/scatter-baseline-pitch.cpp:269:       phase = {.generation = region.generation, .frequency = region.frequencyBins, .ratio = ratio}; age = 0;
	ldr	s14, [x27, 16]	// pretmp_1397, MEM[(float *)_696 + 16B]
	ubfiz	x22, x4, 5, 16	// tmp1442, _79,,
	add	x1, x20, x22	// _1377, this, tmp1442
// /probe/scatter-baseline-pitch.cpp:268:     if (phase.generation != region.generation) {
	ldr	x2, [x1, 120]	// MEM <uint64_t> [(struct Phase &)_1377 + 120], MEM <uint64_t> [(struct Phase &)_1377 + 120]
	cmp	x2, x0	// MEM <uint64_t> [(struct Phase &)_1377 + 120], _82
	beq	.L885		//,
// /probe/scatter-baseline-pitch.cpp:269:       phase = {.generation = region.generation, .frequency = region.frequencyBins, .ratio = ratio}; age = 0;
	stp	x0, xzr, [x1, 120]	// _82,, MEM <uint64_t> [(struct Phase *)_1377 + 120B]
	mov	w0, 1	// _99,
	add	x2, x19, x22	// tmp965, tmp1445, tmp1442
	mov	w6, w0	// prephitmp_1205, _99
	str	xzr, [x2, 16]	//, MEM <struct array> [(struct Phase *)this_291(D) + 120B]._M_elems[_80].alignment
	stp	s14, s12, [x2, 24]	// pretmp_1397, _348, MEM <struct array> [(struct Phase *)this_291(D) + 120B]._M_elems[_80].frequency
.L886:
// /probe/scatter-baseline-pitch.cpp:276:     age = std::min<unsigned>(age + 1, 2);
	add	x2, x24, 120	// tmp1004, tmp1448,
// /probe/scatter-baseline-pitch.cpp:279:     if (ratio != 1 && destination >= half) continue; // Drop the entire aliased region.
	fmov	s1, 1.0e+0	// tmp1006,
// /probe/scatter-baseline-pitch.cpp:276:     age = std::min<unsigned>(age + 1, 2);
	strb	w6, [x2, w4, uxtw]	// prephitmp_1205, MEM <struct array> [(unsigned char &)this_291(D) + 16504]._M_elems[_80]
// /probe/scatter-baseline-pitch.cpp:277:     const float shift = (ratio - 1) * region.frequencyBins;
	ldr	s15, [x27, 16]	// _105, MEM[(float *)_696 + 16B]
// /probe/scatter-baseline-pitch.cpp:279:     if (ratio != 1 && destination >= half) continue; // Drop the entire aliased region.
	fcmp	s12, s1	// _348, tmp1006
// /probe/scatter-baseline-pitch.cpp:278:     const float destination = ratio * region.frequencyBins;
	fmul	s0, s15, s12	// destination, _105, _348
// /probe/scatter-baseline-pitch.cpp:279:     if (ratio != 1 && destination >= half) continue; // Drop the entire aliased region.
	beq	.L1088		//,
// /probe/scatter-baseline-pitch.cpp:279:     if (ratio != 1 && destination >= half) continue; // Drop the entire aliased region.
	fcmpe	s0, s11	// destination, _1395
	bge	.L936		//,
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fsub	s0, s11, s0	// tmp1011, _1395, destination
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fmov	s2, 6.0e+0	// tmp1014,
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fsub	s0, s0, s13	// tmp1012, tmp1011, tmp1498
// /probe/scatter-baseline-pitch.cpp:281:     const float edge = std::clamp((half - destination - 2) / 6, 0.0f, 1.0f);
	fdiv	s0, s0, s2	// edge, tmp1012, tmp1014
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// edge
	bmi	.L988		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	s0, s1	// edge, tmp1006
	bgt	.L1001		//,
	.p2align 3,,7
.L891:
// /probe/scatter-baseline-pitch.cpp:282:     const float fade = ratio == 1 ? 1 : std::min(age * .5f, 1.0f);
	scvtf	s8, w0, #1	// gain, _99,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s1, 1.0e+0	// tmp1018,
	fcmpe	s8, s1	// gain, tmp1018
	bgt	.L1002		//,
.L896:
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	cbnz	x28, .L893	// lowAnalysis,
.L898:
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmov	s2, 3.0e+0	// tmp1033,
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmul	s1, s0, s0	// _119, edge, edge
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmsub	s0, s0, s13, s2	// _121, edge, tmp1498, tmp1033
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmul	s0, s1, s0	// tmp1034, _119, _121
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	fmul	s8, s8, s0	// gain, gain, tmp1034
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	cbnz	x21, .L902	// gains,
	b	.L904		//
.L1002:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:239: 	return __b;
	fmov	s8, s1	// gain, tmp1018
	b	.L896		//
	.p2align 2,,3
.L885:
// /probe/scatter-baseline-pitch.cpp:272:         * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * region.frequencyBins));
	add	x0, x19, x22	// tmp978, tmp1445, tmp1442
// /probe/scatter-baseline-pitch.cpp:272:         * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * region.frequencyBins));
	ldr	s0, [sp, 16]	// _1191, %sfp
// /probe/scatter-baseline-pitch.cpp:272:         * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * region.frequencyBins));
	fmov	s17, 1.0e+0	// tmp981,
	str	w4, [sp, 40]	// _79, %sfp
	ldp	s7, s3, [x0, 24]	// MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].frequency, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].ratio, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].frequency
// /probe/scatter-baseline-pitch.cpp:271:       phase.offset = principal(phase.offset + .5 * hopPhase
	stp	x0, x1, [sp, 24]	// tmp978, _1377, %sfp
// /probe/scatter-baseline-pitch.cpp:272:         * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * region.frequencyBins));
	fmul	s2, s0, s14	// tmp986, _1191, pretmp_1397
// /probe/scatter-baseline-pitch.cpp:271:       phase.offset = principal(phase.offset + .5 * hopPhase
	ldr	d5, [sp, 56]	// hopPhase, %sfp
	fmov	d0, 5.0e-1	// tmp974,
// /probe/scatter-baseline-pitch.cpp:272:         * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * region.frequencyBins));
	fsub	s3, s3, s17	// tmp979, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].ratio, tmp981
// /probe/scatter-baseline-pitch.cpp:271:       phase.offset = principal(phase.offset + .5 * hopPhase
	ldr	d4, [x1, 128]	// _84, MEM <double> [(struct Phase &)_1377 + 128]
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	adrp	x1, .LC2	// tmp1760,
	ldr	d1, [x1, #:lo12:.LC2]	// tmp1759,
// /probe/scatter-baseline-pitch.cpp:271:       phase.offset = principal(phase.offset + .5 * hopPhase
	fmul	d0, d5, d0	// _85, hopPhase, tmp974
// /probe/scatter-baseline-pitch.cpp:272:         * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * region.frequencyBins));
	fmadd	s2, s3, s7, s2	// _93, tmp979, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].frequency, tmp986
	fcvt	d2, s2	// tmp988, _93
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmadd	d0, d0, d2, d4	//, _85, tmp988, _84
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:271:       phase.offset = principal(phase.offset + .5 * hopPhase
	ldp	x0, x1, [sp, 24]	// tmp978, _1377, %sfp
// /probe/scatter-baseline-pitch.cpp:276:     age = std::min<unsigned>(age + 1, 2);
	add	x2, x24, 120	// tmp1000, tmp1448,
	ldr	w4, [sp, 40]	//, %sfp
// /probe/scatter-baseline-pitch.cpp:271:       phase.offset = principal(phase.offset + .5 * hopPhase
	str	d0, [x1, 128]	// tmp1518, MEM <double> [(struct Phase &)_1377 + 128]
// /probe/scatter-baseline-pitch.cpp:274:       phase.ratio = ratio;
	stp	s14, s12, [x0, 24]	// pretmp_1397, _348, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].frequency
// /probe/scatter-baseline-pitch.cpp:276:     age = std::min<unsigned>(age + 1, 2);
	ldrb	w0, [x2, w4, uxtw]	// _97, MEM <struct array> [(unsigned char &)this_291(D) + 16504]._M_elems[_80]
// /probe/scatter-baseline-pitch.cpp:276:     age = std::min<unsigned>(age + 1, 2);
	add	w0, w0, 1	// _99, _97,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	cmp	w0, 2	// _99,
// /probe/scatter-baseline-pitch.cpp:276:     age = std::min<unsigned>(age + 1, 2);
	and	w6, w0, 255	// prephitmp_1205, _99
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	ble	.L886		//,
	mov	w0, 2	// _99,
	mov	w6, w0	// prephitmp_1205, _99
	b	.L886		//
	.p2align 2,,3
.L1086:
	fmov	d0, d3	//, rotationPhase
	add	x0, sp, 216	//,,
	add	x1, sp, 208	//,,
	bl	sincos		//
// /probe/scatter-baseline-pitch.cpp:277:     const float shift = (ratio - 1) * region.frequencyBins;
	ldr	s0, [sp, 16]	// _1191, %sfp
// /probe/scatter-baseline-pitch.cpp:315:     PitchPlan::Weights weights{};
	add	x0, sp, 224	// tmp1131,,
	ldp	d14, d3, [sp, 208]	// sincostmp_740, sincostmp_740,
// /probe/scatter-baseline-pitch.cpp:277:     const float shift = (ratio - 1) * region.frequencyBins;
	fmul	s1, s15, s0	// shift, _105, _1191
// /probe/scatter-baseline-pitch.cpp:315:     PitchPlan::Weights weights{};
	movi	v0.4s, 0	// tmp1132
// /probe/scatter-baseline-pitch.cpp:309:     const std::complex<float> rotation{static_cast<float>(std::cos(rotationPhase)) * gain,
	fcvt	s14, d14	// tmp1126, sincostmp_740
// /probe/scatter-baseline-pitch.cpp:310:                                        static_cast<float>(std::sin(rotationPhase)) * gain};
	fcvt	s3, d3	// tmp1127, sincostmp_740
// /probe/scatter-baseline-pitch.cpp:315:     PitchPlan::Weights weights{};
	stp	q0, q0, [x0]	// tmp1132, tmp1132, weights
// /probe/scatter-baseline-pitch.cpp:311:     const int shiftCeil = static_cast<int>(std::ceil(shift));
	fcvtps	w6, s1	// shiftCeil, shift
// /probe/scatter-baseline-pitch.cpp:315:     PitchPlan::Weights weights{};
	stp	q0, q0, [x0, 32]	// tmp1132, tmp1132, weights
	stp	q0, q0, [x0, 64]	// tmp1132, tmp1132, weights
// /probe/scatter-baseline-pitch.cpp:312:     const float position = (shiftCeil - shift) * PitchPlan::kPhases;
	movi	v0.2s, 0x44, lsl 24	// tmp1771
// /probe/scatter-baseline-pitch.cpp:310:                                        static_cast<float>(std::sin(rotationPhase)) * gain};
	fmul	s14, s14, s8	// _157, tmp1126, gain
// /probe/scatter-baseline-pitch.cpp:312:     const float position = (shiftCeil - shift) * PitchPlan::kPhases;
	scvtf	s7, w6	// tmp1128, shiftCeil
// /probe/scatter-baseline-pitch.cpp:310:                                        static_cast<float>(std::sin(rotationPhase)) * gain};
	fmul	s3, s3, s8	// _160, tmp1127, gain
// /probe/scatter-baseline-pitch.cpp:312:     const float position = (shiftCeil - shift) * PitchPlan::kPhases;
	fsub	s7, s7, s1	// tmp1129, tmp1128, shift
// /probe/scatter-baseline-pitch.cpp:312:     const float position = (shiftCeil - shift) * PitchPlan::kPhases;
	fmul	s7, s7, s0	// position, tmp1129, tmp1771
// /probe/scatter-baseline-pitch.cpp:316:     if (position != 0) for (int i = 1 - PitchPlan::kRadius; i <= PitchPlan::kRadius; ++i) {
	fcmp	s7, #0.0	// position
	bne	.L917		//,
.L920:
// /probe/scatter-baseline-pitch.cpp:334:     for (int k = static_cast<int>(region.first); k <= static_cast<int>(region.last); ++k) {
	ldrh	w7, [x27, 2]	// _177, MEM[(short unsigned int *)_696 + 2B]
// /probe/scatter-baseline-pitch.cpp:334:     for (int k = static_cast<int>(region.first); k <= static_cast<int>(region.last); ++k) {
	ldrh	w0, [x27, 4]	// _414, MEM[(short unsigned int *)_696 + 4B]
// /probe/scatter-baseline-pitch.cpp:334:     for (int k = static_cast<int>(region.first); k <= static_cast<int>(region.last); ++k) {
	cmp	w7, w0	// _177, _414
	bhi	.L936		//,
	add	w0, w0, 1	// tmp1254, _414,
	add	w18, w6, w7	// ivtmp.2372, shiftCeil, _177
// /probe/scatter-baseline-pitch.cpp:335:       const float endpoint = k == 0 || k == half ? .5f : 1;
	fmov	s19, 5.0e-1	// tmp1452,
	sxtw	x8, w6	// shiftCeil, shiftCeil
	add	w14, w0, w6	// _646, tmp1254, shiftCeil
	ldr	x0, [sp, 96]	// SR.761, %sfp
	add	x8, x8, w7, uxth	// tmp1250, shiftCeil, _177
	fmov	s18, 1.0e+0	// tmp1453,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	movi	v17.2s, #0	// tmp1489
// /probe/scatter-baseline-pitch.cpp:325:       if (j <= -half || j > half) return;
	fmov	s9, s3	// _160, _160
	fmov	s8, s7	// position, position
	add	x8, x26, x8, lsl 3	// ivtmp.2366, _381, tmp1250,
	sub	w4, w18, #13	// ivtmp.2371, ivtmp.2372,
// /probe/scatter-baseline-pitch.cpp:338:         accumulate(k + shiftCeil, (shiftCeil & 1) ? -value : value);
	and	w15, w6, 1	// _180, shiftCeil,
	add	x7, x0, w7, uxth 3	// ivtmp.2375, SR.761, _177,,
// /probe/scatter-baseline-pitch.cpp:325:       if (j <= -half || j > half) return;
	neg	w22, w25	// _1261, _13
	b	.L935		//
	.p2align 2,,3
.L1091:
// /probe/scatter-baseline-pitch.cpp:338:         accumulate(k + shiftCeil, (shiftCeil & 1) ? -value : value);
	cbz	w15, .L925	// _180,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s4, s4	// _557, _550
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s0, s0	// _558, _551
.L925:
// /probe/scatter-baseline-pitch.cpp:325:       if (j <= -half || j > half) return;
	cmp	w22, w18	// _1261, ivtmp.2372
	ccmp	w25, w18, 1, lt	// _13, ivtmp.2372,,
	bge	.L1089		//,
.L929:
// /probe/scatter-baseline-pitch.cpp:334:     for (int k = static_cast<int>(region.first); k <= static_cast<int>(region.last); ++k) {
	add	w18, w18, 1	// ivtmp.2372, ivtmp.2372,
	add	x8, x8, 8	// ivtmp.2366, ivtmp.2366,
	cmp	w18, w14	// ivtmp.2372, _646
	add	w4, w4, 1	// ivtmp.2371, ivtmp.2371,
	add	x7, x7, 8	// ivtmp.2375, ivtmp.2375,
	beq	.L936		//,
.L935:
	ldp	s0, s1, [x7]	// __r$_M_value$real, __r$_M_value$imag, MEM[(float *)_661]
// /probe/scatter-baseline-pitch.cpp:335:       const float endpoint = k == 0 || k == half ? .5f : 1;
	subs	w0, w18, w6	// k, ivtmp.2372, shiftCeil
// /probe/scatter-baseline-pitch.cpp:335:       const float endpoint = k == 0 || k == half ? .5f : 1;
	ccmp	w25, w0, 4, ne	// _13, k,,
	fcsel	s20, s19, s18, eq	// iftmp.237_250, tmp1452, tmp1453,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1479: 	  _M_value *= __t;
	fmul	s2, s14, s1	// _768, _157, __r$_M_value$imag
	fmul	s4, s9, s1	// tmp1259, _160, __r$_M_value$imag
	fmadd	s2, s9, s0, s2	// _232, _160, __r$_M_value$real, _768
	fnmsub	s4, s14, s0, s4	// _229, _157, __r$_M_value$real, tmp1259
	fcmp	s2, s4	// _232, _229
	bvs	.L1090		//,
.L922:
// /probe/scatter-baseline-pitch.cpp:337:       if (position == 0) {
	fcmp	s8, #0.0	// position
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s4, s4, s20	// _550, _229, iftmp.237_250
	fmul	s0, s20, s2	// _551, iftmp.237_250, _232
// /probe/scatter-baseline-pitch.cpp:337:       if (position == 0) {
	beq	.L1091		//,
// /probe/scatter-baseline-pitch.cpp:339:       } else if (k + shiftCeil > PitchPlan::kRadius
	cmp	w18, 12	// ivtmp.2372,
// /probe/scatter-baseline-pitch.cpp:340:                  && k + shiftCeil + PitchPlan::kRadius - 1 < half) {
	add	w0, w18, 11	// ivtmp.2347, ivtmp.2372,
// /probe/scatter-baseline-pitch.cpp:339:       } else if (k + shiftCeil > PitchPlan::kRadius
	ble	.L930		//,
// /probe/scatter-baseline-pitch.cpp:340:                  && k + shiftCeil + PitchPlan::kRadius - 1 < half) {
	cmp	w25, w0	// _13, ivtmp.2347
	ble	.L930		//,
	sub	x5, x8, #96	// vectp.2248, ivtmp.2366,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:407:       __r *= __y;
	ldp	q1, q26, [sp, 224]	// vect__561.2244, vect__561.2244, MEM <vector(4) float> [(const float &)&weights]
// /probe/scatter-baseline-pitch.cpp:345:         for (int tap = 0; tap < 2 * PitchPlan::kRadius; ++tap)
	sub	x3, x8, #64	// vectp.2247, ivtmp.2366,
	sub	x2, x8, #32	// vectp.2247, ivtmp.2366,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	mov	x1, x8	// vectp.2247, ivtmp.2366
	ld2	{v22.4s - v23.4s}, [x5]	// vect_array.2249, MEM <float[8]> [(float *)vectp.2248_1196]
// /probe/scatter-baseline-pitch.cpp:345:         for (int tap = 0; tap < 2 * PitchPlan::kRadius; ++tap)
	add	x0, x8, 64	// vectp.2247, ivtmp.2366,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:407:       __r *= __y;
	ldp	q25, q24, [sp, 256]	// vect__561.2244, vect__561.2244, MEM <vector(4) float> [(const float &)&weights + 32]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	mov	v2.16b, v22.16b	// tmp1781, vect_array.2249
	fmla	v2.4s, v1.4s, v4.s[0]	// tmp1781, vect__561.2244, _550
	mov	v20.16b, v2.16b	// vect_array.2256, tmp1781
	mov	v2.16b, v23.16b	// tmp1782, vect_array.2249
	fmla	v2.4s, v1.4s, v0.s[0]	// tmp1782, vect__561.2244, _551
	mov	v21.16b, v2.16b	// vect_array.2256, tmp1782
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:407:       __r *= __y;
	ldp	q2, q1, [sp, 288]	// vect__561.2244, vect__561.2244, MEM <vector(4) float> [(const float &)&weights + 64]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	st2	{v20.4s - v21.4s}, [x5]	// vect_array.2256, MEM <float[8]> [(float *)vectp.2248_1196]
	ld2	{v22.4s - v23.4s}, [x3]	// vect_array.2249, MEM <float[8]> [(float *)vectp.2247_453]
	mov	v3.16b, v22.16b	// tmp1783, vect_array.2249
	fmla	v3.4s, v26.4s, v4.s[0]	// tmp1783, vect__561.2244, _550
	mov	v20.16b, v3.16b	// vect_array.2256, tmp1783
	mov	v3.16b, v23.16b	// tmp1784, vect_array.2249
	fmla	v3.4s, v26.4s, v0.s[0]	// tmp1784, vect__561.2244, _551
	mov	v21.16b, v3.16b	// vect_array.2256, tmp1784
	st2	{v20.4s - v21.4s}, [x3]	// vect_array.2256, MEM <float[8]> [(float *)vectp.2247_453]
	ld2	{v22.4s - v23.4s}, [x2]	// vect_array.2249, MEM <float[8]> [(float *)vectp.2247_342]
	mov	v3.16b, v22.16b	// tmp1785, vect_array.2249
	fmla	v3.4s, v25.4s, v4.s[0]	// tmp1785, vect__561.2244, _550
	mov	v20.16b, v3.16b	// vect_array.2256, tmp1785
	mov	v3.16b, v23.16b	// tmp1786, vect_array.2249
	fmla	v3.4s, v25.4s, v0.s[0]	// tmp1786, vect__561.2244, _551
	mov	v21.16b, v3.16b	// vect_array.2256, tmp1786
	st2	{v20.4s - v21.4s}, [x2]	// vect_array.2256, MEM <float[8]> [(float *)vectp.2247_342]
	ld2	{v22.4s - v23.4s}, [x8]	// vect_array.2249, MEM <float[8]> [(float *)vectp.2247_1132]
	mov	v3.16b, v22.16b	// tmp1787, vect_array.2249
	fmla	v3.4s, v24.4s, v4.s[0]	// tmp1787, vect__561.2244, _550
	mov	v20.16b, v3.16b	// vect_array.2256, tmp1787
	mov	v3.16b, v23.16b	// tmp1788, vect_array.2249
	fmla	v3.4s, v24.4s, v0.s[0]	// tmp1788, vect__561.2244, _551
	mov	v21.16b, v3.16b	// vect_array.2256, tmp1788
	st2	{v20.4s - v21.4s}, [x1], 32	// vect_array.2256, MEM <float[8]> [(float *)vectp.2247_1132]
	ld2	{v22.4s - v23.4s}, [x1]	// vect_array.2249, MEM <float[8]> [(float *)vectp.2247_709]
	mov	v3.16b, v22.16b	// tmp1789, vect_array.2249
	fmla	v3.4s, v2.4s, v4.s[0]	// tmp1789, vect__561.2244, _550
	mov	v20.16b, v3.16b	// vect_array.2256, tmp1789
	mov	v3.16b, v23.16b	// tmp1790, vect_array.2249
	fmla	v3.4s, v2.4s, v0.s[0]	// tmp1790, vect__561.2244, _551
	mov	v21.16b, v3.16b	// vect_array.2256, tmp1790
	st2	{v20.4s - v21.4s}, [x1]	// vect_array.2256, MEM <float[8]> [(float *)vectp.2247_709]
	ld2	{v22.4s - v23.4s}, [x0]	// vect_array.2249, MEM <float[8]> [(float *)vectp.2247_1059]
	mov	v2.16b, v22.16b	// tmp1791, vect_array.2249
	fmla	v2.4s, v1.4s, v4.s[0]	// tmp1791, vect__561.2244, _550
	mov	v20.16b, v2.16b	// vect_array.2256, tmp1791
	mov	v2.16b, v23.16b	// tmp1792, vect_array.2249
	fmla	v2.4s, v1.4s, v0.s[0]	// tmp1792, vect__561.2244, _551
	mov	v21.16b, v2.16b	// vect_array.2256, tmp1792
	st2	{v20.4s - v21.4s}, [x0]	// vect_array.2256, MEM <float[8]> [(float *)vectp.2247_1059]
	b	.L929		//
	.p2align 2,,3
.L930:
	add	x1, x8, 88	// ivtmp.2349, ivtmp.2366,
	add	x2, sp, 316	// ivtmp.2353,,
	b	.L934		//
	.p2align 2,,3
.L931:
// /probe/scatter-baseline-pitch.cpp:348:         for (int i = 1 - PitchPlan::kRadius; i <= PitchPlan::kRadius; ++i)
	sub	w0, w0, #1	// ivtmp.2347, ivtmp.2347,
	sub	x1, x1, #8	// ivtmp.2349, ivtmp.2349,
	cmp	w0, w4	// ivtmp.2347, ivtmp.2371
	sub	x2, x2, #4	// ivtmp.2353, ivtmp.2353,
	beq	.L929		//,
.L934:
// /probe/scatter-baseline-pitch.cpp:325:       if (j <= -half || j > half) return;
	cmp	w0, w22	// ivtmp.2347, _1261
	ccmp	w25, w0, 1, gt	// _13, ivtmp.2347,,
	blt	.L931		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:407:       __r *= __y;
	ldr	s1, [x2]	// _564, MEM[(const float &)_463]
// /probe/scatter-baseline-pitch.cpp:327:       if (j < 0) spectrum_[-j] += std::conj(value);
	cmp	w0, 0	// ivtmp.2347,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s5, s4, s1	// _565, _550, _564
	fmul	s1, s0, s1	// _566, _551, _564
// /probe/scatter-baseline-pitch.cpp:327:       if (j < 0) spectrum_[-j] += std::conj(value);
	blt	.L1092		//,
// /probe/scatter-baseline-pitch.cpp:328:       else if (j == 0 || j == half) spectrum_[j] += std::complex<float>{2 * value.real(), 0};
	ccmp	w25, w0, 4, ne	// _13, ivtmp.2347,,
	ldp	s7, s6, [x1]	// pretmp_1387, pretmp_1388, MEM[(float *)_428]
	bne	.L933		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmadd	s7, s5, s13, s7	// _944, _565, tmp1498, pretmp_1387
	fadd	s6, s6, s17	// tmp1304, pretmp_1388, tmp1489
	stp	s7, s6, [x1]	// _944, tmp1304, MEM[(float *)_428]
// /probe/scatter-baseline-pitch.cpp:328:       else if (j == 0 || j == half) spectrum_[j] += std::complex<float>{2 * value.real(), 0};
	b	.L931		//
	.p2align 2,,3
.L1092:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	neg	w3, w0	// tmp1294, ivtmp.2347
	lsl	x3, x3, 3	// tmp1295, tmp1294,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x5, x26, x3	// _780, _381, tmp1295
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldr	s7, [x26, x3]	// MEM[(struct complex *)_780]._M_value, MEM[(struct complex *)_780]._M_value
	ldr	s6, [x5, 4]	// MEM[(struct complex *)_780]._M_value, MEM[(struct complex *)_780]._M_value
	fadd	s5, s7, s5	// tmp1297, MEM[(struct complex *)_780]._M_value, _565
	fsub	s1, s6, s1	// _981, MEM[(struct complex *)_780]._M_value, _566
	str	s5, [x26, x3]	// tmp1297, REALPART_EXPR <MEM[(struct complex *)_780]._M_value>
	str	s1, [x5, 4]	// _981, IMAGPART_EXPR <MEM[(struct complex *)_780]._M_value>
	b	.L931		//
	.p2align 2,,3
.L933:
	fadd	s5, s5, s7	// tmp1306, _565, pretmp_1387
	fadd	s1, s1, s6	// tmp1307, _566, pretmp_1388
	stp	s5, s1, [x1]	// tmp1306, tmp1307, MEM[(float *)_428]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1463: 	  return *this;
	b	.L931		//
	.p2align 2,,3
.L1089:
// /probe/scatter-baseline-pitch.cpp:327:       if (j < 0) spectrum_[-j] += std::conj(value);
	cmp	w18, 0	// ivtmp.2372,
	blt	.L1093		//,
// /probe/scatter-baseline-pitch.cpp:328:       else if (j == 0 || j == half) spectrum_[j] += std::complex<float>{2 * value.real(), 0};
	ccmp	w25, w18, 4, ne	// _13, ivtmp.2372,,
	ldp	s2, s1, [x8]	// pretmp_1382, pretmp_1383, MEM[(float *)_667]
	bne	.L928		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmadd	s2, s4, s13, s2	// _900, _557, tmp1498, pretmp_1382
	movi	v0.2s, #0	// tmp1280
	fadd	s1, s1, s0	// tmp1279, pretmp_1383, tmp1280
	stp	s2, s1, [x8]	// _900, tmp1279, MEM[(float *)_667]
// /probe/scatter-baseline-pitch.cpp:328:       else if (j == 0 || j == half) spectrum_[j] += std::complex<float>{2 * value.real(), 0};
	b	.L929		//
	.p2align 2,,3
.L1003:
// /probe/scatter-baseline-pitch.cpp:284:     const float gain = high * fade * (ratio == 1 ? 1 : edge * edge * (3 - 2 * edge))
	movi	v1.2s, #0	// tmp1026
	fmul	s8, s8, s1	// gain, gain, tmp1026
	b	.L901		//
	.p2align 2,,3
.L1093:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	neg	w0, w18	// tmp1269, ivtmp.2372
	lsl	x0, x0, 3	// tmp1270, tmp1269,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x1, x26, x0	// _747, _381, tmp1270
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldr	s2, [x26, x0]	// MEM[(struct complex *)_747]._M_value, MEM[(struct complex *)_747]._M_value
	ldr	s1, [x1, 4]	// MEM[(struct complex *)_747]._M_value, MEM[(struct complex *)_747]._M_value
	fadd	s2, s2, s4	// tmp1272, MEM[(struct complex *)_747]._M_value, _557
	fsub	s0, s1, s0	// _337, MEM[(struct complex *)_747]._M_value, _558
	str	s2, [x26, x0]	// tmp1272, REALPART_EXPR <MEM[(struct complex *)_747]._M_value>
	str	s0, [x1, 4]	// _337, IMAGPART_EXPR <MEM[(struct complex *)_747]._M_value>
	b	.L929		//
	.p2align 2,,3
.L987:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	movi	v0.2s, #0	// edge
// /probe/scatter-baseline-pitch.cpp:282:     const float fade = ratio == 1 ? 1 : std::min(age * .5f, 1.0f);
	fmov	s8, s12	// gain, _348
// /probe/scatter-baseline-pitch.cpp:283:     const float high = lowAnalysis ? highWeight(region.frequencyBins * kSampleRate / spectrum_.size()) : 1;
	cbnz	x28, .L893	// lowAnalysis,
.L1084:
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	cbz	x21, .L894	// gains,
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	ldrh	w0, [x27, 6]	// MEM[(short unsigned int *)_696 + 6B], MEM[(short unsigned int *)_696 + 6B]
// /probe/scatter-baseline-pitch.cpp:285:       * (gains ? (*gains)[region.track] : 1);
	ldr	s8, [x21, x0, lsl 2]	// gain, MEM <const struct array> [(const value_type &)gains_422(D)]._M_elems[_948]
// /probe/scatter-baseline-pitch.cpp:286:     if (gain == 0) continue;
	fcmp	s8, #0.0	// gain
	beq	.L936		//,
.L894:
// /probe/scatter-baseline-pitch.cpp:287:     double rotationPhase = phase.offset;
	ldr	d3, [x1, 128]	// rotationPhase, MEM <double> [(struct Phase &)_1377 + 128]
	b	.L895		//
	.p2align 2,,3
.L1001:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:239: 	return __b;
	fmov	s0, s1	// edge, tmp1006
	b	.L891		//
.L1087:
	ldr	d15, [sp, 112]	// _18, %sfp
	mov	w27, w25	// _13, _13
	mov	x24, x26	// _381, _381
	ldp	x26, x21, [sp, 136]	// lowGains, held, %sfp
	mov	x25, x28	// lowAnalysis, lowAnalysis
	mov	x8, x23	// _374, _374
	ldp	x28, x12, [sp, 120]	// _388, frame, %sfp
	ldp	s8, s9, [sp, 152]	// heldMix, heldGain, %sfp
	ldr	x9, [sp, 104]	// _390, %sfp
.L866:
// /probe/scatter-baseline-pitch.cpp:353:   if (!fullyHeld && lowAnalysis && !lowAnalysis->spectrum().empty()) {
	cmp	x25, 0	// lowAnalysis,
// /probe/scatter-baseline-pitch.cpp:353:   if (!fullyHeld && lowAnalysis && !lowAnalysis->spectrum().empty()) {
	ldr	w0, [sp, 8]	//, %sfp
	eor	w1, w0, 1	// tmp950, _21,
// /probe/scatter-baseline-pitch.cpp:353:   if (!fullyHeld && lowAnalysis && !lowAnalysis->spectrum().empty()) {
	cset	w0, ne	// tmp952,
// /probe/scatter-baseline-pitch.cpp:353:   if (!fullyHeld && lowAnalysis && !lowAnalysis->spectrum().empty()) {
	tst	w0, w1	// tmp952, tmp950
	beq	.L884		//,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:69:   std::span<const std::complex<float>> spectrum() const noexcept { return spectrum_; }
	ldr	x1, [x25, 12384]	// SR.815, MEM <const size_t> [(const struct PitchFrame *)lowAnalysis_226 + 12384B]
// /probe/scatter-baseline-pitch.cpp:353:   if (!fullyHeld && lowAnalysis && !lowAnalysis->spectrum().empty()) {
	cbz	x1, .L884	// SR.815,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	ldr	x0, [x25, 12392]	// lowAnalysis_226->count_, lowAnalysis_226->count_
// /probe/scatter-baseline-pitch.cpp:355:     const double scale = static_cast<double>(spectrum_.size()) / lowInput.size();
	ucvtf	d6, x1	// tmp1308, SR.815
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:282:       { return static_cast<const_pointer>(_M_elems); }
	add	x11, x25, 88	// SR.740, lowAnalysis,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	add	x0, x0, x0, lsl 1	// tmp1312, lowAnalysis_226->count_, lowAnalysis_226->count_,
// /probe/scatter-baseline-pitch.cpp:355:     const double scale = static_cast<double>(spectrum_.size()) / lowInput.size();
	fdiv	d6, d15, d6	// scale, _18, tmp1308
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	lsl	x0, x0, 3	// tmp1313, tmp1312,
	add	x6, x11, x0	// _569, SR.740, tmp1313
// /probe/scatter-baseline-pitch.cpp:356:     for (const auto& region : lowAnalysis->regions()) {
	cbz	x0, .L884	// tmp1313,
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	mov	w3, 32768	// tmp1527,
	movk	w3, 0x473b, lsl 16	// tmp1527,,
// /probe/scatter-baseline-pitch.cpp:235:       if (frequency * kSampleRate / spectrum_.size() >= 400.0f) continue;
	ucvtf	s3, x8	// _1297, _374
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w2, 1128792064	// tmp1528,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	mov	w1, 1120403456	// tmp1529,
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v17.2s, #0	// _462
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	mov	w0, 2139095039	// tmp1530,
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	fmov	s13, w3	// tmp1318, tmp1527
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x5, x9, 32	// tmp1474, _390,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s5, w2	// tmp1321, tmp1528
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x7, x5, 32768	// tmp1481, tmp1474,
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s11, w1	// tmp1322, tmp1529
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fmov	s4, w0	// tmp1469, tmp1530
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmov	s15, 2.0e+0	// tmp1471,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	movi	v10.2s, 0x44, lsl 24	// tmp1472
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	movi	v7.2s, 0x46, lsl 24	// tmp1473
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	fmov	s14, 1.0e+0	// _203,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmov	s16, 3.0e+0	// tmp1484,
	.p2align 3,,7
.L943:
// /probe/scatter-baseline-pitch.cpp:357:       const float frequency = static_cast<float>(region.frequencyBins * scale);
	ldr	s2, [x11, 16]	// MEM[(float *)SR.740_934 + 16B], MEM[(float *)SR.740_934 + 16B]
	fcvt	d2, s2	// tmp1314, MEM[(float *)SR.740_934 + 16B]
// /probe/scatter-baseline-pitch.cpp:357:       const float frequency = static_cast<float>(region.frequencyBins * scale);
	fmul	d2, d2, d6	// tmp1316, tmp1314, scale
// /probe/scatter-baseline-pitch.cpp:357:       const float frequency = static_cast<float>(region.frequencyBins * scale);
	fcvt	s2, d2	// frequency, tmp1316
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	fmul	s0, s2, s13	// tmp1317, frequency, tmp1318
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	fdiv	s0, s0, s3	// tmp1319, tmp1317, _1297
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fsub	s0, s0, s5	// tmp1320, tmp1319, tmp1321
// /probe/scatter-baseline-pitch.cpp:26:   const float t = std::clamp((frequencyHz - 200.0f) / 100.0f, 0.0f, 1.0f);
	fdiv	s0, s0, s11	// _573, tmp1320, tmp1322
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// _573
	bmi	.L994		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fcmpe	s0, s14	// _573, _203
	bgt	.L944		//,
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmul	s18, s0, s0	// _578, _573, _573
// /probe/scatter-baseline-pitch.cpp:27:   return t * t * (3 - 2 * t);
	fmsub	s0, s0, s15, s16	// _580, _573, tmp1471, tmp1484
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	fmsub	s18, s18, s0, s14	// _203, _578, _580, _203
// /probe/scatter-baseline-pitch.cpp:359:       if (low == 0) continue;
	fcmp	s18, #0.0	// _203
	beq	.L944		//,
.L940:
// /probe/scatter-baseline-pitch.cpp:360:       auto amplitude = lowCarriers_[region.track] * low * (lowGains ? (*lowGains)[region.track] : 1);
	ldrh	w1, [x11, 6]	// _205, MEM[(short unsigned int *)SR.740_934 + 6B]
	add	x0, x20, x1, lsl 3	// _471, this, _205,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	add	x0, x0, 16384	// tmp1329, _471,
	ldr	s19, [x0, 632]	// MEM <float> [(const struct complex &)_471 + 17016], MEM <float> [(const struct complex &)_471 + 17016]
	ldr	s0, [x0, 636]	// MEM <float> [(const struct complex &)_471 + 17020], MEM <float> [(const struct complex &)_471 + 17020]
	fmul	s19, s18, s19	// _1317, _203, MEM <float> [(const struct complex &)_471 + 17016]
	fmul	s18, s18, s0	// _1319, _203, MEM <float> [(const struct complex &)_471 + 17020]
// /probe/scatter-baseline-pitch.cpp:360:       auto amplitude = lowCarriers_[region.track] * low * (lowGains ? (*lowGains)[region.track] : 1);
	cbz	x26, .L945	// lowGains,
// /probe/scatter-baseline-pitch.cpp:360:       auto amplitude = lowCarriers_[region.track] * low * (lowGains ? (*lowGains)[region.track] : 1);
	ldr	s0, [x26, x1, lsl 2]	// iftmp.245_360, MEM <const struct array> [(const value_type &)lowGains_358(D)]._M_elems[_205]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s19, s19, s0	// _1317, _1317, iftmp.245_360
	fmul	s18, s18, s0	// _1319, _1319, iftmp.245_360
.L945:
// /probe/scatter-baseline-pitch.cpp:361:       const float destination = frequency * ratio;
	fmul	s2, s2, s12	// destination, frequency, _348
// /probe/scatter-baseline-pitch.cpp:362:       const int first = static_cast<int>(std::floor(destination)) - 16;
	fcvtms	w0, s2	// tmp1333, destination
// /probe/scatter-baseline-pitch.cpp:363:       const int last = static_cast<int>(std::ceil(destination)) + 16;
	fcvtps	w2, s2	// _207, destination
// /probe/scatter-baseline-pitch.cpp:362:       const int first = static_cast<int>(std::floor(destination)) - 16;
	sub	w0, w0, #16	// first, tmp1333,
// /probe/scatter-baseline-pitch.cpp:363:       const int last = static_cast<int>(std::ceil(destination)) + 16;
	add	w3, w2, 16	// last, _207,
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	cmp	w0, w3	// first, last
	bgt	.L944		//,
	tbnz	w0, #31, .L1094	// first,
.L946:
	add	x1, x24, w0, sxtw 3	// ivtmp.2314, _381, first,
	b	.L962		//
	.p2align 2,,3
.L1096:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s1, s1	// value$_M_value$real, value$_M_value$real
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s0, s0	// value$_M_value$imag, value$_M_value$imag
.L960:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldp	s20, s21, [x1]	// MEM[(float *)_11], MEM[(float *)_11 + 4B], MEM[(float *)_11]
	fadd	s1, s20, s1	// tmp1404, MEM[(float *)_11], value$_M_value$real
	fadd	s0, s0, s21	// _1372, value$_M_value$imag, MEM[(float *)_11 + 4B]
	stp	s1, s0, [x1]	// tmp1404, _1372, MEM[(float *)_11]
.L954:
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	add	w0, w0, 1	// first, first,
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	add	x1, x1, 8	// ivtmp.2314, ivtmp.2314,
	cmp	w3, w0	// last, first
	blt	.L944		//,
.L962:
// /probe/scatter-baseline-pitch.cpp:365:         if (std::abs(j) >= half) continue;
	cmp	w0, 0	// first,
	csneg	w2, w0, w0, ge	// tmp1368, first, first,
// /probe/scatter-baseline-pitch.cpp:365:         if (std::abs(j) >= half) continue;
	cmp	w27, w2	// _13, tmp1368
	ble	.L954		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	scvtf	s1, w0	// tmp1369, first
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v0.2s, #0	// _462
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabd	s1, s1, s2	// _473, tmp1369, destination
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fcmp	s1, s4	// _473, tmp1469
	bhi	.L955		//,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	fmul	s1, s1, s10	// position, _473, tmp1472
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	fcmpe	s1, s7	// position, tmp1473
	bge	.L955		//,
// /probe/scatter-baseline-pitch.cpp:67:   const auto i = static_cast<std::size_t>(position);
	fcvtzu	x2, s1	// i, position
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x2, 8192	// i,
	beq	.L1095		//,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ucvtf	s20, x2	// tmp1384, i
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ubfiz	x8, x2, 4, 9	// tmp1382, i,,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	add	x4, x2, 1	// prephitmp_1326, i,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x2, x8, x2, lsr 9	// tmp1383, tmp1382, i,
	mov	x10, x5	// tmp1447, tmp1474
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	ubfiz	x8, x4, 4, 9	// tmp1386, prephitmp_1326,,
	add	x8, x8, x4, lsr 9	// tmp1457, tmp1386, prephitmp_1326,
	cmp	x4, 8192	// prephitmp_1326,
	csel	x4, x8, x4, ne	// prephitmp_1326, tmp1457, prephitmp_1326,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ldr	s0, [x5, x2, lsl 2]	// first, MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_1322]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s1, s1, s20	// _1327, position, tmp1384
.L958:
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ldr	s20, [x10, x4, lsl 2]	// MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_1335], MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_1335]
	fsub	s20, s20, s0	// tmp1390, MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_1335], first
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fmadd	s0, s20, s1, s0	// _462, tmp1390, _1327, first
.L955:
// /probe/scatter-baseline-pitch.cpp:366:         auto value = amplitude * (plan_->lobe(j - destination) * spectrum_.size());
	fmul	s0, s0, s3	// _287, _462, _1297
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s1, s0, s19	// value$_M_value$real, _287, _1317
	fmul	s0, s0, s18	// value$_M_value$imag, _287, _1319
// /probe/scatter-baseline-pitch.cpp:367:         if (j & 1) value = -value;
	tbnz	x0, 0, .L1096	// first,,
// /probe/scatter-baseline-pitch.cpp:368:         if (j < 0) spectrum_[-j] += std::conj(value);
	cmp	w0, 0	// first,
	blt	.L961		//,
// /probe/scatter-baseline-pitch.cpp:369:         else if (j == 0) spectrum_[0] += std::complex<float>{2 * value.real(), 0};
	bne	.L960		//,
	ldp	s0, s20, [x24]	// _381->_M_value, _1344, _381->_M_value
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	add	w0, w0, 1	// first, first,
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	add	x1, x1, 8	// ivtmp.2314, ivtmp.2314,
	cmp	w3, w0	// last, first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fmadd	s0, s1, s15, s0	// _1343, value$_M_value$real, tmp1471, _381->_M_value
	fadd	s1, s20, s17	// tmp1395, _1344, _462
	stp	s0, s1, [x24]	// _1343, tmp1395, REALPART_EXPR <_381->_M_value>
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	bge	.L962		//,
	.p2align 3,,7
.L944:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1111: 	++_M_current;
	add	x11, x11, 24	// SR.740, SR.740,
// /probe/scatter-baseline-pitch.cpp:356:     for (const auto& region : lowAnalysis->regions()) {
	cmp	x6, x11	// _569, SR.740
	bne	.L943		//,
.L884:
// /probe/scatter-baseline-pitch.cpp:374:   if (held && heldMix > 0 && !heldPhases_.empty()) {
	cbz	x21, .L969	// held,
// /probe/scatter-baseline-pitch.cpp:374:   if (held && heldMix > 0 && !heldPhases_.empty()) {
	fcmpe	s8, #0.0	// heldMix
	bgt	.L1008		//,
.L969:
// /probe/scatter-baseline-pitch.cpp:379:   for (int j = 1; j < half; ++j) spectrum_[spectrum_.size() - j] = std::conj(spectrum_[j]);
	ldr	w0, [sp, 88]	//, %sfp
	cmp	w0, 1	// tmp1799,
	ble	.L973		//,
	ldr	w1, [sp, 88]	//, %sfp
	add	x0, x24, 8	// ivtmp.2292, _381,
	add	x10, x24, 16	// tmp1422, _381,
	sub	w1, w1, #2	// tmp1421, tmp1797,
	add	x1, x10, w1, uxtw 3	// _1211, tmp1422, tmp1421,
	.p2align 3,,7
.L970:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:971:     { return complex<_Tp>(__z.real(), -__z.imag()); }
	ldp	s1, s0, [x0]	// _627, MEM[(float *)_979 + 4B], MEM[(float *)_979]
// /probe/scatter-baseline-pitch.cpp:379:   for (int j = 1; j < half; ++j) spectrum_[spectrum_.size() - j] = std::conj(spectrum_[j]);
	add	x0, x0, 8	// ivtmp.2292, ivtmp.2292,
	cmp	x0, x1	// ivtmp.2292, _1211
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:971:     { return complex<_Tp>(__z.real(), -__z.imag()); }
	fneg	s0, s0	// _629, MEM[(float *)_979 + 4B]
// /probe/scatter-baseline-pitch.cpp:379:   for (int j = 1; j < half; ++j) spectrum_[spectrum_.size() - j] = std::conj(spectrum_[j]);
	stp	s1, s0, [x28, -8]	// _627, _629, MEM[(float *)_862 + -8B]
// /probe/scatter-baseline-pitch.cpp:379:   for (int j = 1; j < half; ++j) spectrum_[spectrum_.size() - j] = std::conj(spectrum_[j]);
	sub	x28, x28, #8	// ivtmp.2295, ivtmp.2295,
	bne	.L970		//,
.L973:
// /probe/scatter-baseline-pitch.cpp:380:   return synthesis_.addFrameInPlace(spectrum_, startOffset);
	adrp	x0, :got:__stack_chk_guard	// tmp1425,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp1425,
	ldr	x2, [sp, 328]	// tmp1549, D.330101
	ldr	x1, [x0]	// tmp1550,
	subs	x2, x2, x1	// tmp1549, tmp1550
	mov	x1, 0	// tmp1550
	bne	.L1077		//,
	ldr	x2, [sp, 48]	//, %sfp
	add	x0, x20, 16	//, this,
// /probe/scatter-baseline-pitch.cpp:381: }
	ldp	x29, x30, [sp, 336]	//,,
	ldp	x19, x20, [sp, 352]	//,,
// /probe/scatter-baseline-pitch.cpp:380:   return synthesis_.addFrameInPlace(spectrum_, startOffset);
	ldp	x21, x22, [sp, 368]	//,,
	.cfi_remember_state
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 384]	//,,
	.cfi_restore 24
	.cfi_restore 23
	ldp	x25, x26, [sp, 400]	//,,
	.cfi_restore 26
	.cfi_restore 25
	ldp	x27, x28, [sp, 416]	//,,
	.cfi_restore 28
	.cfi_restore 27
	ldr	x1, [sp, 80]	//, %sfp
	ldp	d8, d9, [sp, 432]	//,,
	.cfi_restore 73
	.cfi_restore 72
	ldp	d10, d11, [sp, 448]	//,,
	.cfi_restore 75
	.cfi_restore 74
	ldp	d12, d13, [sp, 464]	//,,
	.cfi_restore 77
	.cfi_restore 76
	ldp	d14, d15, [sp, 480]	//,,
	.cfi_restore 79
	.cfi_restore 78
// /probe/scatter-baseline-pitch.cpp:381: }
	add	sp, sp, 496	//,,
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
// /probe/scatter-baseline-pitch.cpp:380:   return synthesis_.addFrameInPlace(spectrum_, startOffset);
	b	_ZN5ardor4pog317SpectralSynthesis15addFrameInPlaceERSt6vectorISt7complexIfESaIS4_EEm		//
.L1094:
	.cfi_restore_state
	add	w2, w2, 17	// _1298, _207,
	cmp	w2, 0	// _1298,
	csel	w2, w2, wzr, le	// _1298, _1298,,
.L953:
// /probe/scatter-baseline-pitch.cpp:365:         if (std::abs(j) >= half) continue;
	neg	w1, w0	// tmp1440, first
// /probe/scatter-baseline-pitch.cpp:365:         if (std::abs(j) >= half) continue;
	cmp	w27, w1	// _13, tmp1440
	ble	.L947		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	scvtf	s0, w0	// tmp1336, first
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	movi	v1.2s, #0	// _820
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabd	s0, s0, s2	// _800, tmp1336, destination
// /probe/scatter-baseline-pitch.cpp:64:   if (!std::isfinite(distance)) return 0;
	fcmp	s0, s4	// _800, tmp1469
	bhi	.L948		//,
// /probe/scatter-baseline-pitch.cpp:65:   const float position = std::fabs(distance) * kPhases;
	fmul	s0, s0, s10	// position, _800, tmp1472
// /probe/scatter-baseline-pitch.cpp:66:   if (position >= hannLobe_.size() - 1) return 0;
	fcmpe	s0, s7	// position, tmp1473
	bge	.L948		//,
// /probe/scatter-baseline-pitch.cpp:67:   const auto i = static_cast<std::size_t>(position);
	fcvtzu	x4, s0	// i, position
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x4, 8192	// i,
	beq	.L1097		//,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ucvtf	s20, x4	// tmp1351, i
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ubfiz	x10, x4, 4, 9	// tmp1349, i,,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	add	x8, x4, 1	// iftmp.24_816, i,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x4, x10, x4, lsr 9	// tmp1350, tmp1349, i,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	ubfiz	x10, x8, 4, 9	// tmp1353, iftmp.24_816,,
	cmp	x8, 8192	// iftmp.24_816,
	add	x10, x10, x8, lsr 9	// tmp1455, tmp1353, iftmp.24_816,
	csel	x8, x10, x8, ne	// iftmp.24_816, tmp1455, iftmp.24_816,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	mov	x10, x5	// tmp1447, tmp1474
	ldr	s1, [x5, x4, lsl 2]	// first, MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_806]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s0, s0, s20	// _674, position, tmp1351
.L951:
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	ldr	s20, [x10, x8, lsl 2]	// MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_816], MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_816]
	fsub	s20, s20, s1	// tmp1357, MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[iftmp.24_816], first
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fmadd	s1, s0, s20, s1	// _820, _674, tmp1357, first
.L948:
// /probe/scatter-baseline-pitch.cpp:366:         auto value = amplitude * (plan_->lobe(j - destination) * spectrum_.size());
	fmul	s0, s1, s3	// _212, _820, _1297
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	s21, s0, s19	// _594, _212, _1317
	fmul	s0, s0, s18	// _595, _212, _1319
// /probe/scatter-baseline-pitch.cpp:367:         if (j & 1) value = -value;
	tbz	x0, 0, .L952	// first,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s21, s21	// _594, _594
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s0, s0	// _595, _595
.L952:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	ubfiz	x1, x1, 3, 32	// tmp1362, tmp1440,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x4, x24, x1	// _604, _381, tmp1362
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldr	s20, [x24, x1]	// MEM[(struct complex *)_604]._M_value, MEM[(struct complex *)_604]._M_value
	ldr	s1, [x4, 4]	// MEM[(struct complex *)_604]._M_value, MEM[(struct complex *)_604]._M_value
	fadd	s20, s20, s21	// tmp1364, MEM[(struct complex *)_604]._M_value, _594
	fsub	s0, s1, s0	// _254, MEM[(struct complex *)_604]._M_value, _595
	str	s20, [x24, x1]	// tmp1364, REALPART_EXPR <MEM[(struct complex *)_604]._M_value>
	str	s0, [x4, 4]	// _254, IMAGPART_EXPR <MEM[(struct complex *)_604]._M_value>
.L947:
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	add	w0, w0, 1	// first, first,
// /probe/scatter-baseline-pitch.cpp:364:       for (int j = first; j <= last; ++j) {
	cmp	w0, w2	// first, _1298
	blt	.L953		//,
	cmp	w3, w0	// last, first
	bge	.L946		//,
	b	.L944		//
.L961:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	neg	w2, w0	// tmp1398, first
	lsl	x2, x2, 3	// tmp1399, tmp1398,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x4, x24, x2	// _1353, _381, tmp1399
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	ldr	s21, [x24, x2]	// MEM[(struct complex *)_1353]._M_value, MEM[(struct complex *)_1353]._M_value
	ldr	s20, [x4, 4]	// MEM[(struct complex *)_1353]._M_value, MEM[(struct complex *)_1353]._M_value
	fadd	s1, s21, s1	// tmp1401, MEM[(struct complex *)_1353]._M_value, value$_M_value$real
	fsub	s0, s20, s0	// _1349, MEM[(struct complex *)_1353]._M_value, value$_M_value$imag
	str	s1, [x24, x2]	// tmp1401, REALPART_EXPR <MEM[(struct complex *)_1353]._M_value>
	str	s0, [x4, 4]	// _1349, IMAGPART_EXPR <MEM[(struct complex *)_1353]._M_value>
	b	.L954		//
.L1000:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:239: 	return __b;
	fmov	s0, s12	// edge, _348
	b	.L888		//
.L988:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	movi	v0.2s, #0	// edge
	b	.L891		//
.L1004:
// /probe/scatter-baseline-pitch.cpp:290:       const float t = std::clamp((hz - 300.0f) / 100.0f, 0.0f, 1.0f);
	mov	w1, 1133903872	// tmp1537,
// /probe/scatter-baseline-pitch.cpp:290:       const float t = std::clamp((hz - 300.0f) / 100.0f, 0.0f, 1.0f);
	mov	w0, 1120403456	// tmp1538,
	fmov	s17, 1.0e+0	// _1231,
// /probe/scatter-baseline-pitch.cpp:290:       const float t = std::clamp((hz - 300.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s0, w1	// tmp1042, tmp1537
// /probe/scatter-baseline-pitch.cpp:290:       const float t = std::clamp((hz - 300.0f) / 100.0f, 0.0f, 1.0f);
	fmov	s1, w0	// tmp1043, tmp1538
// /probe/scatter-baseline-pitch.cpp:290:       const float t = std::clamp((hz - 300.0f) / 100.0f, 0.0f, 1.0f);
	fsub	s0, s9, s0	// tmp1041, _127, tmp1042
// /probe/scatter-baseline-pitch.cpp:290:       const float t = std::clamp((hz - 300.0f) / 100.0f, 0.0f, 1.0f);
	fdiv	s0, s0, s1	// _129, tmp1041, tmp1043
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// _129
	bmi	.L906		//,
// /probe/scatter-baseline-pitch.cpp:291:       const float alignment = 1 - t * t * (3 - 2 * t);
	fmov	s4, 2.0e+0	// tmp1044,
	fmov	s1, 3.0e+0	// tmp1045,
// /probe/scatter-baseline-pitch.cpp:291:       const float alignment = 1 - t * t * (3 - 2 * t);
	fmul	s2, s0, s0	// _1223, _129, _129
// /probe/scatter-baseline-pitch.cpp:291:       const float alignment = 1 - t * t * (3 - 2 * t);
	fmsub	s0, s0, s4, s1	// _1227, _129, tmp1044, tmp1045
// /probe/scatter-baseline-pitch.cpp:291:       const float alignment = 1 - t * t * (3 - 2 * t);
	fmsub	s17, s2, s0, s17	// _1231, _1223, _1227, _1231
.L906:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	ldr	x1, [x28, 12392]	// lowAnalysis_226->count_, lowAnalysis_226->count_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:282:       { return static_cast<const_pointer>(_M_elems); }
	add	x0, x28, 88	// SR.732, lowAnalysis,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	add	x1, x1, x1, lsl 1	// tmp1050, lowAnalysis_226->count_, lowAnalysis_226->count_,
	lsl	x1, x1, 3	// tmp1051, tmp1050,
	add	x4, x0, x1	// _508, SR.732, tmp1051
// /probe/scatter-baseline-pitch.cpp:294:       for (const auto& lowRegion : lowAnalysis->regions()) {
	cbz	x1, .L895	// tmp1051,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x2, [x28]	// match, MEM[(const struct __shared_ptr *)lowAnalysis_226]._M_ptr
	cbz	x2, .L1098	// match,
	ldr	x1, [x2]	// D___M_ptr_lsm0.2285, MEM[(const struct element_type * *)_515]
// /probe/scatter-baseline-pitch.cpp:293:       float distance = 23.4375f;
	mov	w6, 32768	// tmp1531,
	movk	w6, 0x41bb, lsl 16	// tmp1531,,
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	mov	w2, 32768	// tmp1532,
	movk	w2, 0x473b, lsl 16	// tmp1532,,
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	str	s8, [sp, 40]	// gain, %sfp
// /probe/scatter-baseline-pitch.cpp:293:       float distance = 23.4375f;
	fmov	s2, w6	// distance, tmp1531
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	mov	w6, 59135	// tmp1533,
	movk	w6, 0x2edb, lsl 16	// tmp1533,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1492:       _GLIBCXX_CONSTEXPR _ComplexT __rep() const { return _M_value; }
	ldr	x3, [sp, 160]	// tmp1443, %sfp
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	fmov	s8, s9	// _127, _127
	str	s11, [sp, 184]	// _1395, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x7, x1, [x1, 80]	// MEM[(const struct vector *)D___M_ptr_lsm0.2285_1001 + 80B].D.214282._M_impl.D.213625._M_start, MEM[(const struct vector *)D___M_ptr_lsm0.2285_1001 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)D___M_ptr_lsm0.2285_1001 + 80B].D.214282._M_impl.D.213625._M_start
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	fmov	s4, w2	// tmp1081, tmp1532
// /probe/scatter-baseline-pitch.cpp:292:       const PitchRegion* match = nullptr;
	mov	x2, 0	// match,
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	str	w6, [sp, 24]	// tmp1533, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1492:       _GLIBCXX_CONSTEXPR _ComplexT __rep() const { return _M_value; }
	sub	x6, x3, #392	// tmp1494, tmp1443,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x1, x1, x7	// tmp1074, MEM[(const struct vector *)D___M_ptr_lsm0.2285_1001 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)D___M_ptr_lsm0.2285_1001 + 80B].D.214282._M_impl.D.213625._M_start
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	stp	x20, x21, [sp, 168]	// this, gains, %sfp
	mov	x20, x2	// match, match
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	asr	x1, x1, 2	// tmp1078, tmp1074,
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	fmov	s9, s2	// distance, distance
	mov	x21, x0	// SR.732, SR.732
	ucvtf	s14, x1	// _1239, tmp1078
	stp	x22, x19, [sp, 192]	// tmp1442, tmp1445, %sfp
	mov	x19, x4	// _508, _508
	mov	x22, x6	// tmp1494, tmp1494
	str	d3, [sp, 32]	// rotationPhase, %sfp
	fmov	s11, s14	// _1239, _1239
	fmov	s14, s17	// _1231, _1231
	.p2align 3,,7
.L914:
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	ldr	s0, [x21, 16]	// MEM[(float *)SR.732_929 + 16B], MEM[(float *)SR.732_929 + 16B]
	fmul	s0, s0, s4	// tmp1079, MEM[(float *)SR.732_929 + 16B], tmp1081
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	fdiv	s0, s0, s11	// tmp1082, tmp1079, _1239
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:235:   { return __builtin_fabsf(__x); }
	fabd	s10, s8, s0	// _514, _127, tmp1082
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	fcmpe	s10, s9	// _514, distance
	bmi	.L1006		//,
.L912:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1111: 	++_M_current;
	add	x21, x21, 24	// SR.732, SR.732,
// /probe/scatter-baseline-pitch.cpp:294:       for (const auto& lowRegion : lowAnalysis->regions()) {
	cmp	x19, x21	// _508, SR.732
	bne	.L914		//,
	ldr	d3, [sp, 32]	// rotationPhase, %sfp
	mov	x2, x20	// match, match
	fmov	s17, s14	// _1231, _1231
	ldp	x20, x21, [sp, 168]	// this, gains, %sfp
	ldp	x22, x19, [sp, 192]	// tmp1442, tmp1445, %sfp
	ldr	s8, [sp, 40]	// gain, %sfp
	ldr	s11, [sp, 184]	// _1395, %sfp
.L911:
// /probe/scatter-baseline-pitch.cpp:298:       if (match && alignment > 0) {
	cbz	x2, .L895	// match,
// /probe/scatter-baseline-pitch.cpp:298:       if (match && alignment > 0) {
	fcmpe	s17, #0.0	// _1231
	bgt	.L1007		//,
	b	.L895		//
.L1007:
// /probe/scatter-baseline-pitch.cpp:299:         const auto centered = (region.bin & 1) ? -input[region.bin] : input[region.bin];
	ldrh	w0, [x27]	// _142, MEM[(short unsigned int *)_696]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:289: 	return *(this->_M_ptr + __idx);
	ldr	x3, [sp, 96]	// SR.761, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:289: 	return *(this->_M_ptr + __idx);
	ubfiz	x1, x0, 3, 16	// tmp1097, _142,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:289: 	return *(this->_M_ptr + __idx);
	add	x4, x3, x1	// _1392, SR.761, tmp1097
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1381:       real() const { return __real__ _M_value; }
	ldr	s4, [x3, x1]	// centered$_M_value$real, MEM[(const struct complex &)_1392]._M_value
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1385:       imag() const { return __imag__ _M_value; }
	ldr	s2, [x4, 4]	// centered$_M_value$imag, MEM[(const struct complex &)_1392]._M_value
// /probe/scatter-baseline-pitch.cpp:299:         const auto centered = (region.bin & 1) ? -input[region.bin] : input[region.bin];
	tbz	x0, 0, .L916	// _142,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s4, s4	// centered$_M_value$real, centered$_M_value$real
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:461:     { return complex<_Tp>(-__x.real(), -__x.imag()); }
	fneg	s2, s2	// centered$_M_value$imag, centered$_M_value$imag
.L916:
	ldrh	w0, [x2, 6]	// match_977->track, match_977->track
// /probe/scatter-baseline-pitch.cpp:301:         phase.alignment += principal(correction - phase.alignment);
	add	x22, x19, x22	// tmp1112, tmp1445, tmp1442
	str	d3, [sp, 24]	// rotationPhase, %sfp
	str	s4, [sp, 32]	// centered$_M_value$real, %sfp
	str	s2, [sp, 40]	// centered$_M_value$imag, %sfp
	str	s17, [sp, 168]	// _1231, %sfp
	add	x0, x20, x0, lsl 3	// _392, this, match_977->track,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:903:   __complex_arg(__complex__ float __z) { return __builtin_cargf(__z); }
	add	x0, x0, 16384	// tmp1105, _392,
	ldr	s1, [x0, 632]	//, MEM <float> [(const struct complex *)_392 + 17016B]
	ldr	s0, [x0, 636]	//, MEM <float> [(const struct complex *)_392 + 17020B]
	bl	atan2f		//
	ldr	s4, [sp, 32]	// centered$_M_value$real, %sfp
	fmov	s14, s0	// tmp1521,
	ldr	s2, [sp, 40]	// centered$_M_value$imag, %sfp
	fmov	s1, s4	//, centered$_M_value$real
	fmov	s0, s2	//, centered$_M_value$imag
	bl	atan2f		//
// /probe/scatter-baseline-pitch.cpp:300:         const double correction = std::arg(lowCarriers_[match->track]) - std::arg(centered) - phase.offset;
	fsub	s0, s14, s0	// tmp1114, _540, tmp1522
// /probe/scatter-baseline-pitch.cpp:300:         const double correction = std::arg(lowCarriers_[match->track]) - std::arg(centered) - phase.offset;
	ldr	d3, [sp, 24]	// rotationPhase, %sfp
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	adrp	x0, .LC2	// tmp1768,
// /probe/scatter-baseline-pitch.cpp:301:         phase.alignment += principal(correction - phase.alignment);
	ldr	d2, [x22, 16]	// _150, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].alignment
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	ldr	d1, [x0, #:lo12:.LC2]	//,
// /probe/scatter-baseline-pitch.cpp:300:         const double correction = std::arg(lowCarriers_[match->track]) - std::arg(centered) - phase.offset;
	fcvt	d0, s0	// tmp1115, tmp1114
// /probe/scatter-baseline-pitch.cpp:300:         const double correction = std::arg(lowCarriers_[match->track]) - std::arg(centered) - phase.offset;
	stp	d2, d3, [sp, 24]	// _150, rotationPhase, %sfp
	fsub	d0, d0, d3	// correction, tmp1115, rotationPhase
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fsub	d0, d0, d2	//, correction, _150
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:302:         rotationPhase += alignment * phase.alignment;
	ldp	d2, d3, [sp, 24]	// _150, rotationPhase, %sfp
// /probe/scatter-baseline-pitch.cpp:302:         rotationPhase += alignment * phase.alignment;
	ldr	s17, [sp, 168]	// _1231, %sfp
// /probe/scatter-baseline-pitch.cpp:301:         phase.alignment += principal(correction - phase.alignment);
	fadd	d2, d2, d0	// _152, _150, tmp1523
// /probe/scatter-baseline-pitch.cpp:302:         rotationPhase += alignment * phase.alignment;
	fcvt	d17, s17	// tmp1122, _1231
// /probe/scatter-baseline-pitch.cpp:301:         phase.alignment += principal(correction - phase.alignment);
	str	d2, [x22, 16]	// _152, MEM <struct array> [(struct Phase &)this_291(D) + 120]._M_elems[_80].alignment
// /probe/scatter-baseline-pitch.cpp:302:         rotationPhase += alignment * phase.alignment;
	fmadd	d3, d2, d17, d3	// rotationPhase, _152, tmp1122, rotationPhase
	b	.L895		//
	.p2align 2,,3
.L1006:
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	ldrh	w1, [x21, 6]	// MEM[(short unsigned int *)SR.732_929 + 6B], MEM[(short unsigned int *)SR.732_929 + 6B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:876:   __complex_abs(__complex__ float __z) { return __builtin_cabsf(__z); }
	lsl	x1, x1, 3	// tmp1090, MEM[(short unsigned int *)SR.732_929 + 6B],
	add	x3, x22, x1	// tmp1091, tmp1494, tmp1090
	ldr	s0, [x22, x1]	//, MEM <struct array> [(const struct complex *)this_291(D) + 17016B]._M_elems[_141]._M_value
	ldr	s1, [x3, 4]	//, MEM <struct array> [(const struct complex *)this_291(D) + 17016B]._M_elems[_141]._M_value
	bl	cabsf		//
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	ldr	s1, [sp, 24]	// tmp1495, %sfp
	adrp	x0, .LC10	// tmp1844,
	ldr	s4, [x0, #:lo12:.LC10]	// tmp1843,
	fcmpe	s0, s1	// tmp1520, tmp1495
	csel	x20, x21, x20, gt	// match, SR.732, match,
	fcsel	s9, s10, s9, gt	// distance, _514, distance,
	b	.L912		//
.L994:
// /probe/scatter-baseline-pitch.cpp:358:       const float low = 1 - highWeight(frequency * kSampleRate / spectrum_.size());
	fmov	s18, 1.0e+0	// _203,
	b	.L940		//
.L1085:
// /probe/scatter-baseline-pitch.cpp:286:     if (gain == 0) continue;
	fcmp	s8, #0.0	// gain
	beq	.L936		//,
// /probe/scatter-baseline-pitch.cpp:287:     double rotationPhase = phase.offset;
	ldr	d3, [x1, 128]	// rotationPhase, MEM <double> [(struct Phase &)_1377 + 128]
	b	.L903		//
.L977:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 72
	.cfi_restore 73
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 76
	.cfi_restore 77
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	mov	w0, 0	// _240,
	b	.L851		//
.L928:
	.cfi_offset 21, -128
	.cfi_offset 22, -120
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 25, -96
	.cfi_offset 26, -88
	.cfi_offset 27, -80
	.cfi_offset 28, -72
	.cfi_offset 72, -64
	.cfi_offset 73, -56
	.cfi_offset 74, -48
	.cfi_offset 75, -40
	.cfi_offset 76, -32
	.cfi_offset 77, -24
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1462: 	  _M_value += __z.__rep();
	fadd	s4, s4, s2	// tmp1281, _557, pretmp_1382
	fadd	s0, s0, s1	// tmp1282, _558, pretmp_1383
	stp	s4, s0, [x8]	// tmp1281, tmp1282, MEM[(float *)_667]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1463: 	  return *this;
	b	.L929		//
.L871:
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	mov	x0, 8312	//,
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	fmov	s6, 1.0e+0	// tmp860,
// /probe/scatter-baseline-pitch.cpp:243:         phase.offset = principal(phase.offset + .5 * hopPhase
	ldr	d4, [sp, 56]	// hopPhase, %sfp
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	add	x0, x24, x0	// tmp855, this,
// /probe/scatter-baseline-pitch.cpp:243:         phase.offset = principal(phase.offset + .5 * hopPhase
	fmov	d0, 5.0e-1	// tmp852,
	str	x7, [sp]	// _32, %sfp
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	add	x26, x0, x1	// tmp857, tmp855, tmp835
// /probe/scatter-baseline-pitch.cpp:243:         phase.offset = principal(phase.offset + .5 * hopPhase
	ldr	d7, [x28, 8320]	// _35, MEM <double> [(struct Phase &)_635 + 8320]
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	adrp	x0, .LC2	// tmp1748,
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	ldp	s16, s3, [x26, 24]	// MEM <struct array> [(struct Phase &)this_291(D) + 8312]._M_elems[_31].frequency, MEM <struct array> [(struct Phase &)this_291(D) + 8312]._M_elems[_31].ratio, MEM <struct array> [(struct Phase &)this_291(D) + 8312]._M_elems[_31].frequency
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	fsub	s2, s12, s6	// tmp866, _348, tmp860
// /probe/scatter-baseline-pitch.cpp:243:         phase.offset = principal(phase.offset + .5 * hopPhase
	fmul	d0, d4, d0	// _36, hopPhase, tmp852
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	ldr	d1, [x0, #:lo12:.LC2]	// tmp1747,
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	fsub	s3, s3, s6	// tmp858, MEM <struct array> [(struct Phase &)this_291(D) + 8312]._M_elems[_31].ratio, tmp860
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	fmul	s2, s2, s8	// tmp868, tmp866, frequency
// /probe/scatter-baseline-pitch.cpp:244:           * ((phase.ratio - 1) * phase.frequency + (ratio - 1) * frequency));
	fmadd	s2, s3, s16, s2	// _43, tmp858, MEM <struct array> [(struct Phase &)this_291(D) + 8312]._M_elems[_31].frequency, tmp868
	fcvt	d2, s2	// tmp870, _43
// /probe/scatter-baseline-pitch.cpp:11: double principal(double phase) noexcept { return std::remainder(phase, kTwoPi); }
	fmadd	d0, d0, d2, d7	//, _36, tmp870, _35
	bl	remainder		//
// /probe/scatter-baseline-pitch.cpp:248:       age = std::min<unsigned>(age + 1, 2);
	ldr	x7, [sp]	// _32, %sfp
	add	x1, x22, 120	// tmp884, tmp1448,
// /probe/scatter-baseline-pitch.cpp:243:         phase.offset = principal(phase.offset + .5 * hopPhase
	str	d0, [x28, 8320]	// tmp1515, MEM <double> [(struct Phase &)_635 + 8320]
// /probe/scatter-baseline-pitch.cpp:246:         phase.ratio = ratio;
	stp	s8, s12, [x26, 24]	// frequency, _348, MEM <struct array> [(struct Phase &)this_291(D) + 8312]._M_elems[_31].frequency
// /probe/scatter-baseline-pitch.cpp:248:       age = std::min<unsigned>(age + 1, 2);
	ldrb	w3, [x1, x7]	// _47, MEM <struct array> [(unsigned char &)this_291(D) + 16504]._M_elems[_32]
// /probe/scatter-baseline-pitch.cpp:248:       age = std::min<unsigned>(age + 1, 2);
	add	w26, w3, 1	// _49, _47,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	cmp	w26, 2	// _49,
// /probe/scatter-baseline-pitch.cpp:248:       age = std::min<unsigned>(age + 1, 2);
	and	w1, w26, 255	// prephitmp_1173, _49
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	ble	.L872		//,
	mov	w26, 2	// _49,
	mov	w1, w26	// prephitmp_1173, _49
	b	.L872		//
.L917:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x1, [sp, 104]	// _390, %sfp
// /probe/scatter-baseline-pitch.cpp:313:     const auto table = std::min(static_cast<std::size_t>(position), PitchPlan::kPhases - 1);
	fcvtzu	x0, s7	// _995, position
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	adrp	x2, .LC3	// tmp1773,
	dup	v0.4s, w6	// tmp1144, shiftCeil
	ldr	q26, [x2, #:lo12:.LC3]	// tmp1167,
	adrp	x2, .LC4	// tmp1774,
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	movi	v25.4s, 0x1	// tmp1152
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	ldr	q24, [x2, #:lo12:.LC4]	// tmp1150,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x4, [x1, 16]	// _545, MEM[(const struct __shared_ptr *)_390 + 16B]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	mov	x1, 511	// tmp1133,
	cmp	x0, x1	// _995,
	csel	x0, x0, x1, ls	// _995, _995, tmp1133,
	add	x2, x0, x0, lsl 1	// tmp1139, _995, _995,
// /probe/scatter-baseline-pitch.cpp:314:     const float fraction = position - table;
	scvtf	s18, x0	// tmp1134, _995
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	adrp	x1, .LC6	// tmp1776,
	adrp	x0, .LC5	// tmp1775,
	lsl	x2, x2, 5	// tmp1140, tmp1139,
	add	x5, x2, 96	// tmp1141, tmp1140,
	ldr	q22, [x0, #:lo12:.LC5]	// tmp1184,
	sub	v26.4s, v0.4s, v26.4s	// vect__173.2267, tmp1144, tmp1167
	add	x0, x4, x2	// vectp.2259, _545, tmp1140
	sub	v24.4s, v0.4s, v24.4s	// vect__173.2267, tmp1144, tmp1150
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldr	q23, [x4, x2]	// MEM <const vector(4) float> [(const value_type &)vectp.2259_1262], MEM <const vector(4) float> [(const value_type &)vectp.2259_1262]
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldr	q17, [x4, x5]	// vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2262_1267]
// /probe/scatter-baseline-pitch.cpp:314:     const float fraction = position - table;
	fsub	s18, s7, s18	// fraction, position, tmp1134
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	and	v26.16b, v26.16b, v25.16b	// vect__174.2268, vect__173.2267, tmp1152
	and	v24.16b, v24.16b, v25.16b	// vect__174.2268, vect__173.2267, tmp1152
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	ldr	q20, [x1, #:lo12:.LC6]	// tmp1201,
	add	x1, x4, x5	// vectp.2262, _545, tmp1141
	sub	v22.4s, v0.4s, v22.4s	// vect__173.2267, tmp1144, tmp1184
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldp	q2, q21, [x0, 16]	// MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 16], MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 32], MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 16]
	cmeq	v26.4s, v26.4s, #0	// tmp1171, vect__174.2268
	cmeq	v24.4s, v24.4s, #0	// tmp1154, vect__174.2268
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fsub	v17.4s, v17.4s, v23.4s	// vect__171.2264, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2259_1262]
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldr	q27, [x1, 80]	// vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2262_1267 + 80]
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	and	v22.16b, v22.16b, v25.16b	// vect__174.2268, vect__173.2267, tmp1152
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldp	q4, q29, [x1, 16]	// vect__170.2263, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2262_1267 + 16]
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	sub	v20.4s, v0.4s, v20.4s	// vect__173.2267, tmp1144, tmp1201
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldp	q1, q28, [x1, 48]	// vect__170.2263, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2262_1267 + 48]
	cmeq	v22.4s, v22.4s, #0	// tmp1188, vect__174.2268
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fmla	v23.4s, v17.4s, v18.s[0]	// vect_weight_453.2266, vect__171.2264, fraction
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldp	q19, q17, [x0, 48]	// MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 48], MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 64], MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 48]
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	and	v20.16b, v20.16b, v25.16b	// vect__174.2268, vect__173.2267, tmp1152
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fsub	v4.4s, v4.4s, v2.4s	// vect__171.2264, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 16]
	fsub	v29.4s, v29.4s, v21.4s	// vect__171.2264, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 32]
	cmeq	v20.4s, v20.4s, #0	// tmp1205, vect__174.2268
	fsub	v1.4s, v1.4s, v19.4s	// vect__171.2264, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 48]
	fsub	v28.4s, v28.4s, v17.4s	// vect__171.2264, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 64]
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fmla	v2.4s, v4.4s, v18.s[0]	// vect_weight_453.2266, vect__171.2264, fraction
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	ldr	q4, [x0, 80]	// MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 80], MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 80]
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	adrp	x0, .LC7	// tmp1777,
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fmla	v21.4s, v29.4s, v18.s[0]	// vect_weight_453.2266, vect__171.2264, fraction
	fmla	v19.4s, v1.4s, v18.s[0]	// vect_weight_453.2266, vect__171.2264, fraction
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	ldr	q1, [x0, #:lo12:.LC7]	// tmp1218,
	adrp	x0, .LC8	// tmp1778,
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fmla	v17.4s, v28.4s, v18.s[0]	// vect_weight_453.2266, vect__171.2264, fraction
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	ldr	q28, [x0, #:lo12:.LC8]	// tmp1235,
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	adrp	x0, .LC9	// tmp1779,
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	fneg	v29.4s, v2.4s	// vect_iftmp.235_454.2269, vect_weight_453.2266
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fsub	v27.4s, v27.4s, v4.4s	// vect__171.2264, vect__170.2263, MEM <const vector(4) float> [(const value_type &)vectp.2259_1262 + 80]
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	sub	v1.4s, v0.4s, v1.4s	// vect__173.2267, tmp1144, tmp1218
	bsl	v26.16b, v2.16b, v29.16b	// tmp1172, vect_weight_453.2266, vect_iftmp.235_454.2269
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	ldr	q2, [x0, #:lo12:.LC9]	// tmp1160,
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	sub	v0.4s, v0.4s, v28.4s	// vect__173.2267, tmp1144, tmp1235
// /probe/scatter-baseline-pitch.cpp:319:         + fraction * (plan_->interpolationWeights(table + 1)[tap] - plan_->interpolationWeights(table)[tap]);
	fmla	v4.4s, v27.4s, v18.s[0]	// vect_weight_453.2266, vect__171.2264, fraction
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	and	v18.16b, v1.16b, v25.16b	// vect__174.2268, vect__173.2267, tmp1152
	and	v0.16b, v0.16b, v25.16b	// vect__174.2268, vect__173.2267, tmp1152
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	fneg	v1.4s, v23.4s	// vect_iftmp.235_454.2269, vect_weight_453.2266
	fneg	v25.4s, v21.4s	// vect_iftmp.235_454.2269, vect_weight_453.2266
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	mov	v27.16b, v26.16b	//, tmp1172
	cmeq	v18.4s, v18.4s, #0	// tmp1222, vect__174.2268
	cmeq	v0.4s, v0.4s, #0	// tmp1239, vect__174.2268
	bsl	v24.16b, v23.16b, v1.16b	// tmp1155, vect_weight_453.2266, vect_iftmp.235_454.2269
	bsl	v22.16b, v21.16b, v25.16b	// tmp1189, vect_weight_453.2266, vect_iftmp.235_454.2269
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	fneg	v23.4s, v17.4s	// vect_iftmp.235_454.2269, vect_weight_453.2266
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	tbl	v26.16b, {v26.16b - v27.16b}, v2.16b	// tmp1174, tmp1178, tmp1160
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	fneg	v1.4s, v4.4s	// vect_iftmp.235_454.2269, vect_weight_453.2266
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	mov	v25.16b, v24.16b	//, tmp1155
	bsl	v18.16b, v17.16b, v23.16b	// tmp1223, vect_weight_453.2266, vect_iftmp.235_454.2269
	mov	v23.16b, v22.16b	//, tmp1189
	bsl	v0.16b, v4.16b, v1.16b	// tmp1240, vect_weight_453.2266, vect_iftmp.235_454.2269
	tbl	v24.16b, {v24.16b - v25.16b}, v2.16b	// tmp1157, tmp1161, tmp1160
	tbl	v22.16b, {v22.16b - v23.16b}, v2.16b	// tmp1191, tmp1195, tmp1160
	mov	v1.16b, v0.16b	//, tmp1240
	str	q24, [sp, 304]	// tmp1157, MEM <vector(4) float> [(value_type &)&weights + 80]
	stp	q22, q26, [sp, 272]	// tmp1191, tmp1174, MEM <vector(4) float> [(value_type &)&weights + 48]
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	fneg	v26.4s, v19.4s	// vect_iftmp.235_454.2269, vect_weight_453.2266
// /probe/scatter-baseline-pitch.cpp:322:       weights[2 * PitchPlan::kRadius - 1 - tap] = ((shiftCeil - i) & 1) ? -weight : weight;
	tbl	v0.16b, {v0.16b - v1.16b}, v2.16b	// tmp1242, tmp1246, tmp1160
	bsl	v20.16b, v19.16b, v26.16b	// tmp1206, vect_weight_453.2266, vect_iftmp.235_454.2269
	str	q0, [sp, 224]	// tmp1242, MEM <vector(4) float> [(value_type &)&weights]
	mov	v19.16b, v18.16b	//, tmp1223
	mov	v21.16b, v20.16b	//, tmp1206
	tbl	v18.16b, {v18.16b - v19.16b}, v2.16b	// tmp1225, tmp1229, tmp1160
	tbl	v20.16b, {v20.16b - v21.16b}, v2.16b	// tmp1208, tmp1212, tmp1160
	stp	q18, q20, [sp, 240]	// tmp1225, tmp1208, MEM <vector(4) float> [(value_type &)&weights + 16]
	b	.L920		//
.L979:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 76
	.cfi_restore 77
	.cfi_restore 78
	.cfi_restore 79
// /probe/scatter-baseline-pitch.cpp:217:   if (!plan_ || frame.spectrum().size() != spectrum_.size() || !std::isfinite(semitones)) return false;
	ldp	x23, x24, [sp, 384]	//,,
	.cfi_restore 24
	.cfi_restore 23
	mov	w0, 0	// _240,
	ldp	x27, x28, [sp, 416]	//,,
	.cfi_restore 28
	.cfi_restore 27
	ldp	d8, d9, [sp, 432]	//,,
	.cfi_restore 73
	.cfi_restore 72
	b	.L851		//
.L1008:
	.cfi_offset 21, -128
	.cfi_offset 22, -120
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 25, -96
	.cfi_offset 26, -88
	.cfi_offset 27, -80
	.cfi_offset 28, -72
	.cfi_offset 72, -64
	.cfi_offset 73, -56
	.cfi_offset 74, -48
	.cfi_offset 75, -40
	.cfi_offset 76, -32
	.cfi_offset 77, -24
	.cfi_offset 78, -16
	.cfi_offset 79, -8
// /probe/scatter-baseline-pitch.cpp:374:   if (held && heldMix > 0 && !heldPhases_.empty()) {
	ldr	x1, [x20, 19064]	// MEM[(const struct HeldPhase * const &)this_291(D) + 19064], MEM[(const struct HeldPhase * const &)this_291(D) + 19064]
	ldr	x0, [x20, 19072]	// MEM[(const struct HeldPhase * const &)this_291(D) + 19072], MEM[(const struct HeldPhase * const &)this_291(D) + 19072]
	cmp	x1, x0	// MEM[(const struct HeldPhase * const &)this_291(D) + 19064], MEM[(const struct HeldPhase * const &)this_291(D) + 19072]
	beq	.L969		//,
// /probe/scatter-baseline-pitch.cpp:375:     for (int j = 0; j <= half; ++j) spectrum_[j] *= 1 - heldMix;
	ldr	x0, [sp, 88]	// _12, %sfp
	cmp	w0, 0	// tmp1794,
	blt	.L965		//,
// /probe/scatter-baseline-pitch.cpp:375:     for (int j = 0; j <= half; ++j) spectrum_[j] *= 1 - heldMix;
	fmov	s0, 1.0e+0	// tmp1408,
	add	w0, w0, 1	// niters.2232, tmp1795,
	fsub	s0, s0, s8	// _1370, tmp1408, heldMix
	beq	.L999		//,
	dup	v2.4s, v0.s[0]	// _1165, _1370
	mov	x1, x24	// ivtmp.2304, _381
	lsr	w2, w0, 1	// bnd.2233, niters.2232,
	add	x2, x24, w2, uxtw 4	// _1368, _381, bnd.2233,
	.p2align 3,,7
.L967:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	ldr	q1, [x1]	// vect__619.2238, MEM <vector(4) float> [(float *)_1230]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	fmul	v1.4s, v1.4s, v2.4s	// vect__620.2239, vect__619.2238, _1165
	str	q1, [x1], 16	// vect__620.2239, MEM <vector(4) float> [(float *)_1230]
	cmp	x1, x2	// ivtmp.2304, _1368
	bne	.L967		//,
	tbz	x0, 0, .L968	// niters.2232,,
	and	w0, w0, -2	// tmp.2235, niters.2232,
.L966:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	sbfiz	x0, x0, 3, 32	// tmp1417, tmp.2235,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1129: 	return *(this->_M_impl._M_start + __n);
	add	x1, x24, x0	// _1144, _381, tmp1417
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1432: 	_M_value *= __f;
	ldr	s1, [x24, x0]	// MEM[(struct complex *)_1144]._M_value, MEM[(struct complex *)_1144]._M_value
	ldr	s2, [x1, 4]	// MEM[(struct complex *)_1144]._M_value, MEM[(struct complex *)_1144]._M_value
	fmul	s1, s1, s0	// tmp1419, MEM[(struct complex *)_1144]._M_value, _1370
	fmul	s0, s0, s2	// _1148, _1370, MEM[(struct complex *)_1144]._M_value
	str	s1, [x24, x0]	// tmp1419, REALPART_EXPR <MEM[(struct complex *)_1144]._M_value>
	str	s0, [x1, 4]	// _1148, IMAGPART_EXPR <MEM[(struct complex *)_1144]._M_value>
.L968:
// /probe/scatter-baseline-pitch.cpp:376:     renderHeld(*held, false, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	fmul	s8, s8, s9	// _221, heldMix, heldGain
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:71:   std::int64_t centerSamples() const noexcept { return centerSamples_; }
	ldr	x19, [x12, 12424]	// _624, frame_293(D)->centerSamples_
// /probe/scatter-baseline-pitch.cpp:376:     renderHeld(*held, false, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	mov	x0, x20	//, this
	fmov	s0, s12	//, _348
	mov	x1, x21	//, held
	mov	w2, 0	//,
	ldr	x4, [sp, 72]	//, %sfp
	mov	x3, x19	//, _624
	fmov	s1, s8	//, _221
	bl	_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_		//
// /probe/scatter-baseline-pitch.cpp:377:     if (heldLow) renderHeld(*heldLow, true, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	ldr	x0, [sp, 64]	// heldLow, %sfp
	cbz	x0, .L969	// heldLow,
.L974:
// /probe/scatter-baseline-pitch.cpp:377:     if (heldLow) renderHeld(*heldLow, true, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	ldp	x1, x4, [sp, 64]	//,, %sfp
	fmov	s1, s8	//, _221
	fmov	s0, s12	//, _348
	mov	x3, x19	//, _624
	mov	w2, 1	//,
	mov	x0, x20	//, this
	bl	_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_		//
	b	.L969		//
.L863:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	ldr	x0, [x12, 12392]	// frame_293(D)->count_, frame_293(D)->count_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:282:       { return static_cast<const_pointer>(_M_elems); }
	add	x2, x12, 88	// _489, frame,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:307:       { return iterator(this->_M_ptr + this->size()); }
	add	x0, x0, x0, lsl 1	// tmp1435, frame_293(D)->count_, frame_293(D)->count_,
	lsl	x0, x0, 3	// tmp1436, tmp1435,
	add	x1, x2, x0	// _488, _489, tmp1436
	str	x1, [sp]	// _488, %sfp
// /probe/scatter-baseline-pitch.cpp:265:   for (const auto& region : frame.regions()) {
	cbnz	x0, .L865	// tmp1436,
	b	.L884		//
.L1095:
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	ldr	s0, [x7]	// first, MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[8192]
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s1, s1, s7	// _1327, position, tmp1473
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	mov	x10, x5	// tmp1447, tmp1474
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	mov	x4, 32	// prephitmp_1326,
	b	.L958		//
.L1098:
// /probe/scatter-baseline-pitch.cpp:293:       float distance = 23.4375f;
	mov	w7, 32768	// tmp1534,
	movk	w7, 0x41bb, lsl 16	// tmp1534,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1492:       _GLIBCXX_CONSTEXPR _ComplexT __rep() const { return _M_value; }
	ldr	x3, [sp, 160]	// tmp1443, %sfp
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	mov	w6, 32768	// tmp1535,
	movk	w6, 0x473b, lsl 16	// tmp1535,,
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	movi	v7.2s, #0	// tmp1056
// /probe/scatter-baseline-pitch.cpp:293:       float distance = 23.4375f;
	fmov	s2, w7	// distance, tmp1534
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	mov	w1, 59135	// tmp1536,
	movk	w1, 0x2edb, lsl 16	// tmp1536,,
	str	s8, [sp, 40]	// gain, %sfp
	fmov	s8, s9	// _127, _127
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	fmov	s14, w6	// tmp1054, tmp1535
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1492:       _GLIBCXX_CONSTEXPR _ComplexT __rep() const { return _M_value; }
	sub	x6, x3, #392	// tmp1492, tmp1443,
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	stp	x20, x21, [sp, 176]	// this, gains, %sfp
	mov	x20, x2	// match, match
	mov	x21, x0	// SR.732, SR.732
	stp	x22, x19, [sp, 192]	// tmp1442, tmp1445, %sfp
	mov	x19, x4	// _508, _508
	mov	x22, x6	// tmp1492, tmp1492
	fmov	s9, s2	// distance, distance
	str	w1, [sp, 24]	// tmp1536, %sfp
	str	d3, [sp, 32]	// rotationPhase, %sfp
	str	s17, [sp, 168]	// _1231, %sfp
	.p2align 3,,7
.L910:
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	ldr	s0, [x21, 16]	// MEM[(float *)SR.732_689 + 16B], MEM[(float *)SR.732_689 + 16B]
	fmul	s0, s0, s14	// tmp1052, MEM[(float *)SR.732_689 + 16B], tmp1054
// /probe/scatter-baseline-pitch.cpp:295:         const float d = std::fabs(hz - lowRegion.frequencyBins * kSampleRate / lowAnalysis->frameSize());
	fdiv	s0, s0, s7	// tmp1055, tmp1052, tmp1056
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:235:   { return __builtin_fabsf(__x); }
	fabd	s10, s8, s0	// _960, _127, tmp1055
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	fcmpe	s9, s10	// distance, _960
	bgt	.L1005		//,
.L908:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1111: 	++_M_current;
	add	x21, x21, 24	// SR.732, SR.732,
// /probe/scatter-baseline-pitch.cpp:294:       for (const auto& lowRegion : lowAnalysis->regions()) {
	cmp	x21, x19	// SR.732, _508
	bne	.L910		//,
	ldr	d3, [sp, 32]	// rotationPhase, %sfp
	mov	x2, x20	// match, match
	ldp	x20, x21, [sp, 176]	// this, gains, %sfp
	ldp	x22, x19, [sp, 192]	// tmp1442, tmp1445, %sfp
	ldr	s8, [sp, 40]	// gain, %sfp
	ldr	s17, [sp, 168]	// _1231, %sfp
	b	.L911		//
.L1005:
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	ldrh	w1, [x21, 6]	// MEM[(short unsigned int *)SR.732_689 + 6B], MEM[(short unsigned int *)SR.732_689 + 6B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:876:   __complex_abs(__complex__ float __z) { return __builtin_cabsf(__z); }
	lsl	x1, x1, 3	// tmp1064, MEM[(short unsigned int *)SR.732_689 + 6B],
	add	x3, x22, x1	// tmp1065, tmp1492, tmp1064
	ldr	s0, [x22, x1]	//, MEM <struct array> [(const struct complex *)this_291(D) + 17016B]._M_elems[_880]._M_value
	ldr	s1, [x3, 4]	//, MEM <struct array> [(const struct complex *)this_291(D) + 17016B]._M_elems[_880]._M_value
	bl	cabsf		//
// /probe/scatter-baseline-pitch.cpp:296:         if (d < distance && std::abs(lowCarriers_[lowRegion.track]) > 1e-10f) { match = &lowRegion; distance = d; }
	ldr	s1, [sp, 24]	// tmp1493, %sfp
	movi	v7.2s, #0	// tmp1056
	fcmpe	s0, s1	// tmp1519, tmp1493
	csel	x20, x21, x20, gt	// match, SR.732, match,
	fcsel	s9, s10, s9, gt	// distance, _960, distance,
	b	.L908		//
.L1097:
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x10, x9, 32	// tmp1447, _390,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s0, s0, s7	// _674, position, tmp1473
	mov	x8, 32	// iftmp.24_816,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x4, x10, 32768	// tmp1343, tmp1447,
	ldr	s1, [x4]	// first, MEM <const struct array> [(const value_type &)_390 + 32]._M_elems[8192]
	b	.L951		//
.L1082:
	add	x7, x7, 32	// tmp1446, _345,
// /probe/scatter-baseline-pitch.cpp:69:   return first + (position - i) * (hannLobe_[lobeIndex(i + 1)] - first);
	fsub	s0, s0, s3	// _266, position, tmp1752
	mov	x0, 32	// iftmp.24_728,
// /probe/scatter-baseline-pitch.cpp:68:   const float first = hannLobe_[lobeIndex(i)];
	add	x8, x7, 32768	// tmp897, tmp1446,
	ldr	s1, [x8]	// first, MEM <const struct array> [(const value_type &)_345 + 32]._M_elems[8192]
	b	.L876		//
.L982:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	mov	x0, x24	// tmp.2278, _381
	b	.L858		//
.L965:
// /probe/scatter-baseline-pitch.cpp:376:     renderHeld(*held, false, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	fmul	s8, s8, s9	// _221, heldMix, heldGain
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:71:   std::int64_t centerSamples() const noexcept { return centerSamples_; }
	ldr	x19, [x12, 12424]	// _624, frame_293(D)->centerSamples_
// /probe/scatter-baseline-pitch.cpp:376:     renderHeld(*held, false, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	mov	x0, x20	//, this
	fmov	s0, s12	//, _348
	mov	x1, x21	//, held
	mov	w2, 0	//,
	ldr	x4, [sp, 72]	//, %sfp
	mov	x3, x19	//, _624
	fmov	s1, s8	//, _221
	bl	_ZN5ardor4pog313PitchRenderer10renderHeldERKNS0_10FrozenBandEbfflPKS1_		//
// /probe/scatter-baseline-pitch.cpp:377:     if (heldLow) renderHeld(*heldLow, true, ratio, heldMix * heldGain, frame.centerSamples(), heldReference);
	ldr	x0, [sp, 64]	// heldLow, %sfp
	cbnz	x0, .L974	// heldLow,
	b	.L973		//
.L999:
// /probe/scatter-baseline-pitch.cpp:375:     for (int j = 0; j <= half; ++j) spectrum_[j] *= 1 - heldMix;
	mov	w0, 0	// tmp.2235,
	b	.L966		//
.L1090:
	fmov	s2, s14	//, _157
	fmov	s3, s9	//, _160
	str	s20, [sp, 24]	// iftmp.237_250, %sfp
	str	w15, [sp, 32]	// _180, %sfp
	str	w6, [sp, 40]	// shiftCeil, %sfp
	str	x8, [sp, 168]	// ivtmp.2366, %sfp
	str	w4, [sp, 176]	// ivtmp.2371, %sfp
	str	w18, [sp, 184]	// ivtmp.2372, %sfp
	str	x7, [sp, 192]	// ivtmp.2375, %sfp
	str	w14, [sp, 200]	// _646, %sfp
	bl	__mulsc3		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1479: 	  _M_value *= __t;
	ldr	s20, [sp, 24]	// iftmp.237_250, %sfp
	fmov	s4, s0	// _229, tmp1524
	fmov	s2, s1	// _232, tmp1525
	movi	v17.2s, #0	// tmp1489
	fmov	s18, 1.0e+0	// tmp1453,
	ldr	x8, [sp, 168]	// ivtmp.2366, %sfp
	fmov	s19, 5.0e-1	// tmp1452,
	ldr	x7, [sp, 192]	// ivtmp.2375, %sfp
	ldr	w15, [sp, 32]	//, %sfp
	ldr	w6, [sp, 40]	//, %sfp
	ldr	w4, [sp, 176]	//, %sfp
	ldr	w18, [sp, 184]	//, %sfp
	ldr	w14, [sp, 200]	//, %sfp
	b	.L922		//
.L1079:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 72
	.cfi_restore 73
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 76
	.cfi_restore 77
	.cfi_restore 78
	.cfi_restore 79
	stp	x21, x22, [sp, 368]	//,,
	.cfi_offset 22, -120
	.cfi_offset 21, -128
	stp	x23, x24, [sp, 384]	//,,
	.cfi_offset 24, -104
	.cfi_offset 23, -112
	stp	x25, x26, [sp, 400]	//,,
	.cfi_offset 26, -88
	.cfi_offset 25, -96
	stp	x27, x28, [sp, 416]	//,,
	.cfi_offset 28, -72
	.cfi_offset 27, -80
	stp	d8, d9, [sp, 432]	//,,
	.cfi_offset 73, -56
	.cfi_offset 72, -64
	stp	d10, d11, [sp, 448]	//,,
	.cfi_offset 75, -40
	.cfi_offset 74, -48
	stp	d12, d13, [sp, 464]	//,,
	.cfi_offset 77, -24
	.cfi_offset 76, -32
	stp	d14, d15, [sp, 480]	//,,
	.cfi_offset 79, -8
	.cfi_offset 78, -16
.L1077:
// /probe/scatter-baseline-pitch.cpp:381: }
	bl	__stack_chk_fail		//
.L1080:
	fmov	s0, s9	//, amplitude$_M_value$real
	fmov	s1, s8	//, amplitude$_M_value$imag
	bl	__mulsc3		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1479: 	  _M_value *= __t;
	fmov	s6, s0	// _247, tmp1516
	b	.L880		//
	.cfi_endproc
.LFE9586:
	.size	_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_, .-_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog319PolyphonicPitchBank5resetEv
	.type	_ZN5ardor4pog319PolyphonicPitchBank5resetEv, %function
_ZN5ardor4pog319PolyphonicPitchBank5resetEv:
.LFB9617:
	.cfi_startproc
	adrp	x1, :got:__stack_chk_guard	// tmp212,
	ldr	x1, [x1, :got_lo12:__stack_chk_guard]	// tmp212,
	sub	sp, sp, #96	//,,
	.cfi_def_cfa_offset 96
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	mov	x16, 25472	//,
// /probe/scatter-baseline-pitch.cpp:449: void PolyphonicPitchBank::reset() noexcept {
	stp	x29, x30, [sp, 32]	//,,
	.cfi_offset 29, -64
	.cfi_offset 30, -56
	add	x29, sp, 32	//,,
	stp	x19, x20, [sp, 48]	//,,
	.cfi_offset 19, -48
	.cfi_offset 20, -40
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x19, x0, x16	// _84, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:277:       { return static_cast<pointer>(_M_elems); }
	add	x20, x0, 576	// _85, this,
// /probe/scatter-baseline-pitch.cpp:449: void PolyphonicPitchBank::reset() noexcept {
	stp	x21, x22, [sp, 64]	//,,
	.cfi_offset 21, -32
	.cfi_offset 22, -24
	mov	x21, x0	// this, tmp382
	str	x23, [sp, 80]	//,
	.cfi_offset 23, -16
// /probe/scatter-baseline-pitch.cpp:449: void PolyphonicPitchBank::reset() noexcept {
	ldr	x2, [x1]	// tmp383,
	str	x2, [sp, 24]	// tmp383, D.330249
	mov	x2, 0	// tmp383
// /probe/scatter-baseline-pitch.cpp:450:   for (auto& analysis : longAnalysis_) analysis.reset();
	bl	_ZN5ardor4pog316SpectralAnalysis5resetEv		//
	add	x0, x21, 96	//, this,
	bl	_ZN5ardor4pog316SpectralAnalysis5resetEv		//
// /probe/scatter-baseline-pitch.cpp:451:   for (auto& analysis : shortAnalysis_) analysis.reset();
	add	x0, x21, 192	//, this,
	bl	_ZN5ardor4pog316SpectralAnalysis5resetEv		//
	add	x0, x21, 288	//, this,
	bl	_ZN5ardor4pog316SpectralAnalysis5resetEv		//
// /probe/scatter-baseline-pitch.cpp:452:   for (auto& analysis : lowAnalysis_) analysis.reset();
	add	x0, x21, 384	//, this,
	bl	_ZN5ardor4pog316SpectralAnalysis5resetEv		//
	add	x0, x21, 480	//, this,
	bl	_ZN5ardor4pog316SpectralAnalysis5resetEv		//
// /probe/scatter-baseline-pitch.cpp:453:   for (auto& frame : longFrames_) frame.reset();
	cmp	x19, x20	// _84, _85
	beq	.L1100		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	movi	v0.4s, 0	// tmp381
// /probe/scatter-baseline-pitch.cpp:453:   for (auto& frame : longFrames_) frame.reset();
	mov	x22, 12448	// tmp249,
.L1106:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x0, x2, [x20, 16]	// _108, _109, MEM[(float * const &)__for_begin_237 + 16]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:930:       for (; __first != __last; ++__first)
	cmp	x0, x2	// _108, _109
	beq	.L1101		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	sub	x2, x2, x0	//, _109, _108
	mov	w1, 0	//,
	bl	memset		//
	movi	v0.4s, 0	// tmp381
.L1101:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x2, x4, [x20, 40]	// tmp.2453, _113, MEM[(struct complex * const &)__for_begin_237 + 40]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x2, x4	// tmp.2453, _113
	beq	.L1102		//,
	sub	x0, x4, #8	// tmp224, _113,
	mov	x1, x2	// ivtmp.2529, tmp.2453
	sub	x0, x0, x2	// _268, tmp224, tmp.2453
	cmp	x0, 16	// _268,
	lsr	x0, x0, 3	// tmp225, _268,
	add	x0, x0, 1	// niters.2450, tmp225,
	bls	.L1103		//,
	lsr	x3, x0, 1	// bnd.2451, niters.2450,
	add	x3, x2, x3, lsl 4	// _349, tmp.2453, bnd.2451,
	.p2align 3,,7
.L1104:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	q0, [x1], 16	// tmp381, MEM <vector(4) float> [(float *)_346]
	cmp	x1, x3	// ivtmp.2529, _349
	bne	.L1104		//,
	tbz	x0, 0, .L1102	// niters.2450,,
	and	x0, x0, -2	// niters_vector_mult_vf.2452, niters.2450,
	add	x2, x2, x0, lsl 3	// tmp.2453, tmp.2453, niters_vector_mult_vf.2452,
.L1103:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 8	// __first, tmp.2453,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2]	//, REALPART_EXPR <__first_280->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _113, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 4]	//, IMAGPART_EXPR <__first_280->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1102		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 16	// __first, tmp.2453,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_280 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _113, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_280 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1102		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_280 + 16B]._M_value>
.L1102:
// /probe/scatter-baseline-pitch.cpp:88:   tracks_ = {};
	mov	x13, 6232	//,
	mov	x2, 6144	//,
	add	x0, x20, x13	//, ivtmp.2540,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:89:   regions_ = {};
	add	x0, x20, 88	//, ivtmp.2540,
	mov	x2, 6144	//,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	add	x0, x20, 12288	// tmp246, ivtmp.2540,
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x20, 12376]	//, MEM[(const struct complex * *)__for_begin_237 + 12376B]
// /probe/scatter-baseline-pitch.cpp:453:   for (auto& frame : longFrames_) frame.reset();
	movi	v0.4s, 0	// tmp381
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x20, 12384]	//, MEM <size_t> [(struct PitchFrame *)__for_begin_237 + 12384B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x20, 12392]	//, MEM[(long unsigned int *)__for_begin_237 + 12392B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x20, 12400]	//, MEM[(long unsigned int *)__for_begin_237 + 12400B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x20, 12408]	//, MEM[(long unsigned int *)__for_begin_237 + 12408B]
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	strb	wzr, [x0, 128]	//, MEM[(bool *)__for_begin_237 + 12416B]
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x20, 12424]	//, MEM[(long int *)__for_begin_237 + 12424B]
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x20, 12432]	//, MEM[(long int *)__for_begin_237 + 12432B]
// /probe/scatter-baseline-pitch.cpp:453:   for (auto& frame : longFrames_) frame.reset();
	add	x20, x20, x22	// ivtmp.2540, ivtmp.2540, tmp249
	cmp	x20, x19	// ivtmp.2540, _84
	bne	.L1106		//,
.L1100:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	movi	v0.4s, 0	// tmp380
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	mov	x12, 50368	//,
// /probe/scatter-baseline-pitch.cpp:454:   for (auto& frame : shortFrames_) frame.reset();
	mov	x20, 12448	// tmp281,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x22, x21, x12	// _86, this,
.L1112:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x0, x2, [x19, 16]	// _116, _117, MEM[(float * const &)__for_begin_236 + 16]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:930:       for (; __first != __last; ++__first)
	cmp	x0, x2	// _116, _117
	beq	.L1107		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	sub	x2, x2, x0	//, _117, _116
	mov	w1, 0	//,
	bl	memset		//
	movi	v0.4s, 0	// tmp380
.L1107:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x2, x4, [x19, 40]	// tmp.2447, _121, MEM[(struct complex * const &)__for_begin_236 + 40]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x2, x4	// tmp.2447, _121
	beq	.L1108		//,
	sub	x0, x4, #8	// tmp256, _121,
	mov	x1, x2	// ivtmp.2513, tmp.2447
	sub	x0, x0, x2	// _179, tmp256, tmp.2447
	cmp	x0, 16	// _179,
	lsr	x0, x0, 3	// tmp257, _179,
	add	x0, x0, 1	// niters.2444, tmp257,
	bls	.L1109		//,
	lsr	x3, x0, 1	// bnd.2445, niters.2444,
	add	x3, x2, x3, lsl 4	// _324, tmp.2447, bnd.2445,
	.p2align 3,,7
.L1110:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	q0, [x1], 16	// tmp380, MEM <vector(4) float> [(float *)_321]
	cmp	x1, x3	// ivtmp.2513, _324
	bne	.L1110		//,
	tbz	x0, 0, .L1108	// niters.2444,,
	and	x0, x0, -2	// niters_vector_mult_vf.2446, niters.2444,
	add	x2, x2, x0, lsl 3	// tmp.2447, tmp.2447, niters_vector_mult_vf.2446,
.L1109:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 8	// __first, tmp.2447,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2]	//, REALPART_EXPR <__first_252->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _121, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 4]	//, IMAGPART_EXPR <__first_252->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1108		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 16	// __first, tmp.2447,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_252 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _121, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_252 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1108		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_252 + 16B]._M_value>
.L1108:
// /probe/scatter-baseline-pitch.cpp:88:   tracks_ = {};
	mov	x9, 6232	//,
	mov	x2, 6144	//,
	add	x0, x19, x9	//, ivtmp.2524,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:89:   regions_ = {};
	add	x0, x19, 88	//, ivtmp.2524,
	mov	x2, 6144	//,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	add	x0, x19, 12288	// tmp278, ivtmp.2524,
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x19, 12376]	//, MEM[(const struct complex * *)__for_begin_236 + 12376B]
// /probe/scatter-baseline-pitch.cpp:454:   for (auto& frame : shortFrames_) frame.reset();
	movi	v0.4s, 0	// tmp380
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x19, 12384]	//, MEM <size_t> [(struct PitchFrame *)__for_begin_236 + 12384B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12392]	//, MEM[(long unsigned int *)__for_begin_236 + 12392B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12400]	//, MEM[(long unsigned int *)__for_begin_236 + 12400B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12408]	//, MEM[(long unsigned int *)__for_begin_236 + 12408B]
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	strb	wzr, [x0, 128]	//, MEM[(bool *)__for_begin_236 + 12416B]
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12424]	//, MEM[(long int *)__for_begin_236 + 12424B]
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12432]	//, MEM[(long int *)__for_begin_236 + 12432B]
// /probe/scatter-baseline-pitch.cpp:454:   for (auto& frame : shortFrames_) frame.reset();
	add	x19, x19, x20	// ivtmp.2524, ivtmp.2524, tmp281
	cmp	x19, x22	// ivtmp.2524, _86
	bne	.L1112		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x22, x21, 73728	// _88, this,
// /probe/scatter-baseline-pitch.cpp:455:   for (auto& frame : lowFrames_) frame.reset();
	mov	x20, 12448	// tmp313,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x22, x22, 1536	// _88, _88,
.L1118:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x0, x2, [x19, 16]	// _124, _125, MEM[(float * const &)__for_begin_228 + 16]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:930:       for (; __first != __last; ++__first)
	cmp	x0, x2	// _124, _125
	beq	.L1113		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	sub	x2, x2, x0	//, _125, _124
	mov	w1, 0	//,
	bl	memset		//
	movi	v0.4s, 0	// tmp379
.L1113:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x2, x4, [x19, 40]	// tmp.2441, _129, MEM[(struct complex * const &)__for_begin_228 + 40]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x2, x4	// tmp.2441, _129
	beq	.L1114		//,
	sub	x0, x4, #8	// tmp288, _129,
	mov	x1, x2	// ivtmp.2497, tmp.2441
	sub	x0, x0, x2	// _24, tmp288, tmp.2441
	cmp	x0, 16	// _24,
	lsr	x0, x0, 3	// tmp289, _24,
	add	x0, x0, 1	// niters.2438, tmp289,
	bls	.L1115		//,
	lsr	x3, x0, 1	// bnd.2439, niters.2438,
	add	x3, x2, x3, lsl 4	// _299, tmp.2441, bnd.2439,
	.p2align 3,,7
.L1116:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	q0, [x1], 16	// tmp379, MEM <vector(4) float> [(float *)_296]
	cmp	x1, x3	// ivtmp.2497, _299
	bne	.L1116		//,
	tbz	x0, 0, .L1114	// niters.2438,,
	and	x0, x0, -2	// niters_vector_mult_vf.2440, niters.2438,
	add	x2, x2, x0, lsl 3	// tmp.2441, tmp.2441, niters_vector_mult_vf.2440,
.L1115:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 8	// __first, tmp.2441,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2]	//, REALPART_EXPR <__first_87->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _129, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 4]	//, IMAGPART_EXPR <__first_87->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1114		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 16	// __first, tmp.2441,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_87 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _129, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_87 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1114		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_87 + 16B]._M_value>
.L1114:
// /probe/scatter-baseline-pitch.cpp:88:   tracks_ = {};
	mov	x6, 6232	//,
	mov	x2, 6144	//,
	add	x0, x19, x6	//, ivtmp.2508,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:89:   regions_ = {};
	add	x0, x19, 88	//, ivtmp.2508,
	mov	x2, 6144	//,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	add	x0, x19, 12288	// tmp310, ivtmp.2508,
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x19, 12376]	//, MEM[(const struct complex * *)__for_begin_228 + 12376B]
// /probe/scatter-baseline-pitch.cpp:455:   for (auto& frame : lowFrames_) frame.reset();
	movi	v0.4s, 0	// tmp379
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x19, 12384]	//, MEM <size_t> [(struct PitchFrame *)__for_begin_228 + 12384B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12392]	//, MEM[(long unsigned int *)__for_begin_228 + 12392B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12400]	//, MEM[(long unsigned int *)__for_begin_228 + 12400B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12408]	//, MEM[(long unsigned int *)__for_begin_228 + 12408B]
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	strb	wzr, [x0, 128]	//, MEM[(bool *)__for_begin_228 + 12416B]
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12424]	//, MEM[(long int *)__for_begin_228 + 12424B]
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12432]	//, MEM[(long int *)__for_begin_228 + 12432B]
// /probe/scatter-baseline-pitch.cpp:455:   for (auto& frame : lowFrames_) frame.reset();
	add	x19, x19, x20	// ivtmp.2508, ivtmp.2508, tmp313
	cmp	x19, x22	// ivtmp.2508, _88
	bne	.L1118		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x23, x21, 303104	// _90, this,
// /probe/scatter-baseline-pitch.cpp:456:   for (auto& voice : longVoices_) for (auto& channel : voice) channel.reset();
	mov	x22, 19096	// tmp317,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x23, x23, 1312	// _90, _90,
// /probe/scatter-baseline-pitch.cpp:456:   for (auto& voice : longVoices_) for (auto& channel : voice) channel.reset();
	mov	x20, 38192	// tmp320,
	.p2align 3,,7
.L1119:
// /probe/scatter-baseline-pitch.cpp:456:   for (auto& voice : longVoices_) for (auto& channel : voice) channel.reset();
	mov	x0, x19	//, ivtmp.2492
	bl	_ZN5ardor4pog313PitchRenderer5resetEv		//
	add	x0, x19, x22	//, ivtmp.2492, tmp317
// /probe/scatter-baseline-pitch.cpp:456:   for (auto& voice : longVoices_) for (auto& channel : voice) channel.reset();
	add	x19, x19, x20	// ivtmp.2492, ivtmp.2492, tmp320
// /probe/scatter-baseline-pitch.cpp:456:   for (auto& voice : longVoices_) for (auto& channel : voice) channel.reset();
	bl	_ZN5ardor4pog313PitchRenderer5resetEv		//
// /probe/scatter-baseline-pitch.cpp:456:   for (auto& voice : longVoices_) for (auto& channel : voice) channel.reset();
	cmp	x19, x23	// ivtmp.2492, _90
	bne	.L1119		//,
// /probe/scatter-baseline-pitch.cpp:457:   for (auto& voice : shortVoices_) for (auto& channel : voice) channel.reset();
	mov	x0, x19	//, ivtmp.2492
// /probe/scatter-baseline-pitch.cpp:459:   focus_ = focusTarget_ ? 1 : 0;
	add	x20, x21, 536576	// tmp375, this,
// /probe/scatter-baseline-pitch.cpp:457:   for (auto& voice : shortVoices_) for (auto& channel : voice) channel.reset();
	bl	_ZN5ardor4pog313PitchRenderer5resetEv		//
	add	x0, x21, 319488	//, this,
// /probe/scatter-baseline-pitch.cpp:458:   warp_ = warpTarget_;
	add	x19, x21, 524288	// tmp373, this,
// /probe/scatter-baseline-pitch.cpp:457:   for (auto& voice : shortVoices_) for (auto& channel : voice) channel.reset();
	add	x0, x0, 4024	//,,
	bl	_ZN5ardor4pog313PitchRenderer5resetEv		//
	add	x0, x21, 339968	//, this,
	add	x0, x0, 2640	//,,
	bl	_ZN5ardor4pog313PitchRenderer5resetEv		//
	add	x0, x21, 360448	//, this,
	add	x0, x0, 1256	//,,
	bl	_ZN5ardor4pog313PitchRenderer5resetEv		//
// /probe/scatter-baseline-pitch.cpp:459:   focus_ = focusTarget_ ? 1 : 0;
	ldrb	w2, [x20, 2264]	// this_34(D)->focusTarget_, this_34(D)->focusTarget_
// /probe/scatter-baseline-pitch.cpp:459:   focus_ = focusTarget_ ? 1 : 0;
	fmov	s2, 1.0e+0	// tmp378,
	movi	v0.2s, #0	// tmp377
// /probe/scatter-baseline-pitch.cpp:462:   longJob_ = 12; shortJob_ = 4;
	mov	x3, 12	// tmp336,
// /probe/scatter-baseline-pitch.cpp:462:   longJob_ = 12; shortJob_ = 4;
	mov	x1, 4	// tmp338,
// /probe/scatter-baseline-pitch.cpp:460:   transforms_ = 0;
	str	xzr, [x19, 14576]	//, this_34(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:458:   warp_ = warpTarget_;
	ldr	s1, [x19, 14536]	// _1, this_34(D)->warpTarget_
// /probe/scatter-baseline-pitch.cpp:465:   attack_.reset();
	add	x0, x21, 376832	//, this,
	add	x0, x0, 3968	//,,
// /probe/scatter-baseline-pitch.cpp:462:   longJob_ = 12; shortJob_ = 4;
	str	x3, [x19, 14584]	// tmp336, this_34(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:462:   longJob_ = 12; shortJob_ = 4;
	str	x1, [x19, 14592]	// tmp338, this_34(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:459:   focus_ = focusTarget_ ? 1 : 0;
	tst	x2, 1	// this_34(D)->focusTarget_,
// /probe/scatter-baseline-pitch.cpp:463:   longAge_ = shortAge_ = 0;
	str	xzr, [x19, 14600]	//, this_34(D)->longAge_
// /probe/scatter-baseline-pitch.cpp:463:   longAge_ = shortAge_ = 0;
	str	xzr, [x19, 14608]	//, this_34(D)->shortAge_
// /probe/scatter-baseline-pitch.cpp:461:   deadlineMisses_ = 0;
	str	xzr, [x19, 14616]	//, this_34(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:459:   focus_ = focusTarget_ ? 1 : 0;
	fcsel	s0, s0, s2, eq	// iftmp.273_20, tmp377, tmp378,
// /probe/scatter-baseline-pitch.cpp:458:   warp_ = warpTarget_;
	str	s1, [x19, 14540]	// _1, this_34(D)->warp_
// /probe/scatter-baseline-pitch.cpp:464:   frameWarp_ = warp_;
	str	s1, [x19, 14548]	// _1, this_34(D)->frameWarp_
// /probe/scatter-baseline-pitch.cpp:459:   focus_ = focusTarget_ ? 1 : 0;
	str	s0, [x19, 14544]	// iftmp.273_20, this_34(D)->focus_
// /probe/scatter-baseline-pitch.cpp:465:   attack_.reset();
	bl	_ZN5ardor4pog316PolyphonicAttack5resetEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/unique_ptr.h:199:       pointer    _M_ptr() const noexcept { return std::get<0>(_M_t); }
	ldr	x0, [x19, 8360]	// _98, MEM[(struct SpectralFreeze * const &)this_34(D) + 532648]
// /probe/scatter-baseline-pitch.cpp:466:   if (freeze_) freeze_->reset();
	cbz	x0, .L1121	// _98,
// /probe/scatter-baseline-pitch.cpp:466:   if (freeze_) freeze_->reset();
	bl	_ZN5ardor4pog314SpectralFreeze5resetEv		//
.L1121:
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x1, x21, 524288	// tmp353, this,
// /probe/scatter-baseline-pitch.cpp:467:   freezeReady_ = true;
	add	x0, x21, 532480	// tmp345, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	fmov	v0.4s, 1.0e+0	// tmp367
// /probe/scatter-baseline-pitch.cpp:467:   freezeReady_ = true;
	mov	w3, 1	// tmp346,
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x1, x1, 3968	// tmp353, tmp353,
	ldr	s1, [x1, 4368]	// _99, MEM[(const struct PolyphonicAttack *)this_34(D) + 380800B].seconds_
// /probe/scatter-baseline-pitch.cpp:468:   longAttackReady_ = shortAttackReady_ = true;
	add	x2, x21, 536576	// tmp347, this,
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	add	x1, x21, 532480	// tmp361, this,
// /probe/scatter-baseline-pitch.cpp:468:   longAttackReady_ = shortAttackReady_ = true;
	add	x2, x2, 2048	// tmp347, tmp347,
	mov	w5, 257	// tmp349,
// /probe/scatter-baseline-pitch.cpp:467:   freezeReady_ = true;
	strb	w3, [x0, 185]	// tmp346, this_34(D)->freezeReady_
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	add	x0, x21, 532480	// tmp363, this,
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	add	x1, x1, 188	// tmp361, tmp361,
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	add	x0, x0, 2236	// tmp363, tmp363,
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	add	x21, x21, 536576	// tmp365, this,
// /probe/scatter-baseline-pitch.cpp:468:   longAttackReady_ = shortAttackReady_ = true;
	strh	w5, [x2, 219]	// tmp349, MEM <unsigned short> [(bool *)this_34(D) + 538843B]
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	add	x21, x21, 188	// tmp365, tmp365,
	mov	x4, sp	// ivtmp.2481,
// /probe/scatter-baseline-pitch.cpp:470:   lowAttackPending_ = false;
	strb	wzr, [x20, 2270]	//, this_34(D)->lowAttackPending_
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	mov	x3, 3	// ivtmp_176,
	stp	x1, x0, [sp]	// tmp361, tmp363, D.237328[0]
// /probe/scatter-baseline-pitch.cpp:469:   longAttackActive_ = attack_.seconds() > 0;
	fcmpe	s1, #0.0	// _99
	cset	w0, gt	// tmp355,
	strb	w0, [x20, 2269]	// tmp355, this_34(D)->longAttackActive_
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	str	x21, [sp, 16]	// tmp365, D.237328[2]
// /probe/scatter-baseline-pitch.cpp:473:   inputSamples_ = 0;
	str	xzr, [x19, 14528]	//, this_34(D)->inputSamples_
// /probe/scatter-baseline-pitch.cpp:471:   lowAttackSeconds_ = attack_.seconds();
	str	s1, [x19, 14560]	// _99, this_34(D)->lowAttackSeconds_
// /probe/scatter-baseline-pitch.cpp:472:   lowInputEnd_ = 0;
	str	xzr, [x19, 14568]	//, this_34(D)->lowInputEnd_
.L1125:
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	ldr	x2, [x4]	// pair, MEM[(struct array * const *)_178]
	add	x0, x2, 1024	// _181, pair,
	mov	x1, x2	// ivtmp.2476, pair
	.p2align 3,,7
.L1122:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	str	q0, [x1], 16	// tmp367, MEM <vector(4) float> [(float *)_16]
	cmp	x0, x1	// _181, ivtmp.2476
	bne	.L1122		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1128:       std::__fill_a(__first, __first + __n, __value);
	add	x1, x2, 2048	// _10, pair,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:930:       for (; __first != __last; ++__first)
	cmp	x0, x1	// _181, _10
	beq	.L1123		//,
	.p2align 3,,7
.L1124:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	str	q0, [x0], 16	// tmp367, MEM <vector(4) float> [(float *)_133]
	cmp	x1, x0	// _10, ivtmp.2467
	bne	.L1124		//,
.L1123:
// /probe/scatter-baseline-pitch.cpp:474:   for (auto* pair : {&longGains_, &shortGains_, &lowGains_}) for (auto& channel : *pair) channel.fill(1);
	subs	x3, x3, #1	// ivtmp_176, ivtmp_176,
	add	x4, x4, 8	// ivtmp.2481, ivtmp.2481,
	bne	.L1125		//,
// /probe/scatter-baseline-pitch.cpp:476: }
	adrp	x0, :got:__stack_chk_guard	// tmp372,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp372,
// /probe/scatter-baseline-pitch.cpp:475:   healthy_ = true;
	mov	w1, 1	// tmp371,
	strb	w1, [x20, 2266]	// tmp371, this_34(D)->healthy_
// /probe/scatter-baseline-pitch.cpp:476: }
	ldr	x2, [sp, 24]	// tmp384, D.330249
	ldr	x1, [x0]	// tmp385,
	subs	x2, x2, x1	// tmp384, tmp385
	mov	x1, 0	// tmp385
	bne	.L1151		//,
	ldp	x29, x30, [sp, 32]	//,,
	ldp	x19, x20, [sp, 48]	//,,
	ldp	x21, x22, [sp, 64]	//,,
	ldr	x23, [sp, 80]	//,
	add	sp, sp, 96	//,,
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 23
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
.L1151:
	.cfi_restore_state
	bl	__stack_chk_fail		//
	.cfi_endproc
.LFE9617:
	.size	_ZN5ardor4pog319PolyphonicPitchBank5resetEv, .-_ZN5ardor4pog319PolyphonicPitchBank5resetEv
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog319PolyphonicPitchBank7setWarpEf
	.type	_ZN5ardor4pog319PolyphonicPitchBank7setWarpEf, %function
_ZN5ardor4pog319PolyphonicPitchBank7setWarpEf:
.LFB9618:
	.cfi_startproc
// /probe/scatter-baseline-pitch.cpp:479:   if (!std::isfinite(normalized)) return false;
	mov	w1, 2139095039	// tmp104,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabs	s2, s0	// tmp97, normalized
// /probe/scatter-baseline-pitch.cpp:479:   if (!std::isfinite(normalized)) return false;
	fmov	s1, w1	// tmp98, tmp104
	fcmp	s2, s1	// tmp97, tmp98
	bhi	.L1155		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// normalized
	bmi	.L1156		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s1, 1.0e+0	// tmp99,
	fcmpe	s0, s1	// normalized, tmp99
	bgt	.L1157		//,
// /probe/scatter-baseline-pitch.cpp:480:   warpTarget_ = std::clamp(normalized, 0.0f, 1.0f);
	add	x1, x0, 524288	// tmp100, this,
// /probe/scatter-baseline-pitch.cpp:481:   return true;
	mov	w0, 1	// _3,
// /probe/scatter-baseline-pitch.cpp:480:   warpTarget_ = std::clamp(normalized, 0.0f, 1.0f);
	str	s0, [x1, 14536]	// normalized, this_9(D)->warpTarget_
// /probe/scatter-baseline-pitch.cpp:482: }
	ret	
	.p2align 2,,3
.L1157:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:239: 	return __b;
	fmov	s0, s1	// normalized, tmp99
.L1154:
// /probe/scatter-baseline-pitch.cpp:480:   warpTarget_ = std::clamp(normalized, 0.0f, 1.0f);
	add	x1, x0, 524288	// tmp100, this,
// /probe/scatter-baseline-pitch.cpp:481:   return true;
	mov	w0, 1	// _3,
// /probe/scatter-baseline-pitch.cpp:480:   warpTarget_ = std::clamp(normalized, 0.0f, 1.0f);
	str	s0, [x1, 14536]	// normalized, this_9(D)->warpTarget_
// /probe/scatter-baseline-pitch.cpp:482: }
	ret	
	.p2align 2,,3
.L1156:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	movi	v0.2s, #0	// normalized
	b	.L1154		//
	.p2align 2,,3
.L1155:
// /probe/scatter-baseline-pitch.cpp:479:   if (!std::isfinite(normalized)) return false;
	mov	w0, 0	// _3,
// /probe/scatter-baseline-pitch.cpp:482: }
	ret	
	.cfi_endproc
.LFE9618:
	.size	_ZN5ardor4pog319PolyphonicPitchBank7setWarpEf, .-_ZN5ardor4pog319PolyphonicPitchBank7setWarpEf
	.align	2
	.p2align 4,,15
	.global	_ZNK5ardor4pog319PolyphonicPitchBank6freezeEv
	.type	_ZNK5ardor4pog319PolyphonicPitchBank6freezeEv, %function
_ZNK5ardor4pog319PolyphonicPitchBank6freezeEv:
.LFB9619:
	.cfi_startproc
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/unique_ptr.h:199:       pointer    _M_ptr() const noexcept { return std::get<0>(_M_t); }
	add	x0, x0, 524288	// tmp95, tmp99,
// /probe/scatter-baseline-pitch.cpp:487:   return freeze_ ? *freeze_ : inactive;
	adrp	x1, _ZZNK5ardor4pog319PolyphonicPitchBank6freezeEvE8inactive	// tmp94,
	add	x1, x1, :lo12:_ZZNK5ardor4pog319PolyphonicPitchBank6freezeEvE8inactive	// tmp98, tmp94,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/unique_ptr.h:199:       pointer    _M_ptr() const noexcept { return std::get<0>(_M_t); }
	ldr	x0, [x0, 8360]	// <retval>, MEM[(struct SpectralFreeze * const &)this_2(D) + 532648]
// /probe/scatter-baseline-pitch.cpp:487:   return freeze_ ? *freeze_ : inactive;
	cmp	x0, 0	// <retval>,
// /probe/scatter-baseline-pitch.cpp:488: }
	csel	x0, x1, x0, eq	//, tmp98, <retval>,
	ret	
	.cfi_endproc
.LFE9619:
	.size	_ZNK5ardor4pog319PolyphonicPitchBank6freezeEv, .-_ZNK5ardor4pog319PolyphonicPitchBank6freezeEv
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog319PolyphonicPitchBank9setFreezeENS0_14ExpressionModeEfb
	.type	_ZN5ardor4pog319PolyphonicPitchBank9setFreezeENS0_14ExpressionModeEfb, %function
_ZN5ardor4pog319PolyphonicPitchBank9setFreezeENS0_14ExpressionModeEfb:
.LFB9623:
	.cfi_startproc
// /probe/scatter-baseline-pitch.cpp:491:   if (!std::isfinite(position) || static_cast<int>(mode) < 0 || static_cast<int>(mode) > 6) return false;
	mov	w3, 2139095039	// tmp115,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabs	s2, s0	// tmp101, position
// /probe/scatter-baseline-pitch.cpp:490: bool PolyphonicPitchBank::setFreeze(ExpressionMode mode, float position, bool dryEligible) noexcept {
	and	w2, w2, 255	// dryEligible, dryEligible
// /probe/scatter-baseline-pitch.cpp:491:   if (!std::isfinite(position) || static_cast<int>(mode) < 0 || static_cast<int>(mode) > 6) return false;
	fmov	s1, w3	// tmp102, tmp115
	fcmp	s2, s1	// tmp101, tmp102
	bhi	.L1164		//,
// /probe/scatter-baseline-pitch.cpp:491:   if (!std::isfinite(position) || static_cast<int>(mode) < 0 || static_cast<int>(mode) > 6) return false;
	cmp	w1, 4	// mode,
	bhi	.L1164		//,
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	add	x4, x0, 524288	// tmp111, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	fcmpe	s0, #0.0	// position
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	str	w1, [x4, 8368]	// mode, this_11(D)->freezeMode_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	bmi	.L1165		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s1, 1.0e+0	// tmp104,
	fcmpe	s0, s1	// position, tmp104
	bgt	.L1166		//,
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	add	x3, x0, 532480	// tmp106, this,
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	str	s0, [x4, 8372]	// position, this_11(D)->freezePosition_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/unique_ptr.h:199:       pointer    _M_ptr() const noexcept { return std::get<0>(_M_t); }
	ldr	x0, [x4, 8360]	// _9, MEM[(struct SpectralFreeze * const &)this_11(D) + 532648]
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	strb	w2, [x3, 184]	// dryEligible, this_11(D)->freezeDry_
// /probe/scatter-baseline-pitch.cpp:495:   return !freeze_ || freeze_->setControls(mode, freezePosition_, dryEligible);
	cbz	x0, .L1167	// _9,
.L1168:
// /probe/scatter-baseline-pitch.cpp:495:   return !freeze_ || freeze_->setControls(mode, freezePosition_, dryEligible);
	b	_ZN5ardor4pog314SpectralFreeze11setControlsENS0_14ExpressionModeEfb		//
	.p2align 2,,3
.L1164:
// /probe/scatter-baseline-pitch.cpp:491:   if (!std::isfinite(position) || static_cast<int>(mode) < 0 || static_cast<int>(mode) > 6) return false;
	mov	w0, 0	// _5,
// /probe/scatter-baseline-pitch.cpp:496: }
	ret	
	.p2align 2,,3
.L1167:
// /probe/scatter-baseline-pitch.cpp:495:   return !freeze_ || freeze_->setControls(mode, freezePosition_, dryEligible);
	mov	w0, 1	// _5,
// /probe/scatter-baseline-pitch.cpp:496: }
	ret	
	.p2align 2,,3
.L1166:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:239: 	return __b;
	fmov	s0, s1	// position, tmp104
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	add	x3, x0, 532480	// tmp106, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/unique_ptr.h:199:       pointer    _M_ptr() const noexcept { return std::get<0>(_M_t); }
	ldr	x0, [x4, 8360]	// _9, MEM[(struct SpectralFreeze * const &)this_11(D) + 532648]
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	str	s0, [x4, 8372]	// position, this_11(D)->freezePosition_
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	strb	w2, [x3, 184]	// dryEligible, this_11(D)->freezeDry_
// /probe/scatter-baseline-pitch.cpp:495:   return !freeze_ || freeze_->setControls(mode, freezePosition_, dryEligible);
	cbnz	x0, .L1168	// _9,
	b	.L1167		//
	.p2align 2,,3
.L1165:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	movi	v0.2s, #0	// position
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	add	x3, x0, 532480	// tmp106, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/unique_ptr.h:199:       pointer    _M_ptr() const noexcept { return std::get<0>(_M_t); }
	ldr	x0, [x4, 8360]	// _9, MEM[(struct SpectralFreeze * const &)this_11(D) + 532648]
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	str	s0, [x4, 8372]	// position, this_11(D)->freezePosition_
// /probe/scatter-baseline-pitch.cpp:494:   freezeMode_ = mode; freezePosition_ = std::clamp(position, 0.0f, 1.0f); freezeDry_ = dryEligible;
	strb	w2, [x3, 184]	// dryEligible, this_11(D)->freezeDry_
// /probe/scatter-baseline-pitch.cpp:495:   return !freeze_ || freeze_->setControls(mode, freezePosition_, dryEligible);
	cbnz	x0, .L1168	// _9,
	b	.L1167		//
	.cfi_endproc
.LFE9623:
	.size	_ZN5ardor4pog319PolyphonicPitchBank9setFreezeENS0_14ExpressionModeEfb, .-_ZN5ardor4pog319PolyphonicPitchBank9setFreezeENS0_14ExpressionModeEfb
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoE
	.type	_ZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoE, %function
_ZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoE:
.LFB9624:
	.cfi_startproc
	stp	x29, x30, [sp, -128]!	//,,,
	.cfi_def_cfa_offset 128
	.cfi_offset 29, -128
	.cfi_offset 30, -120
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -112
	.cfi_offset 20, -104
// /probe/scatter-baseline-pitch.cpp:500:   if (!prepared_) return result;
	add	x19, x0, 536576	// tmp733, this,
// /probe/scatter-baseline-pitch.cpp:498: PitchVoices PolyphonicPitchBank::process(PitchStereo input) noexcept {
	stp	x27, x28, [sp, 80]	//,,
	sub	sp, sp, #2160	//,,
	.cfi_def_cfa_offset 2288
	.cfi_offset 27, -48
	.cfi_offset 28, -40
	mov	x28, x0	// this, tmp759
	adrp	x2, :got:__stack_chk_guard	// tmp318,
	ldr	x2, [x2, :got_lo12:__stack_chk_guard]	// tmp318,
	fmov	w1, s1	// input, tmp761
// /probe/scatter-baseline-pitch.cpp:500:   if (!prepared_) return result;
	ldrb	w3, [x19, 2265]	// rightLowReady, this_142(D)->prepared_
	str	w3, [sp, 64]	// rightLowReady, %sfp
// /probe/scatter-baseline-pitch.cpp:498: PitchVoices PolyphonicPitchBank::process(PitchStereo input) noexcept {
	ldr	x0, [x2]	// tmp776,
	str	x0, [sp, 2152]	// tmp776, D.330338
	mov	x0, 0	// tmp776
	fmov	x0, d0	// input, tmp760
// /probe/scatter-baseline-pitch.cpp:499:   PitchVoices result{};
	stp	xzr, xzr, [x8]	// <retval>
	stp	xzr, xzr, [x8, 16]	// <retval>
// /probe/scatter-baseline-pitch.cpp:498: PitchVoices PolyphonicPitchBank::process(PitchStereo input) noexcept {
	bfi	x0, x1, 32, 32	// input, input,,
// /probe/scatter-baseline-pitch.cpp:500:   if (!prepared_) return result;
	mov	x1, x3	// tmp794, rightLowReady
// /probe/scatter-baseline-pitch.cpp:499:   PitchVoices result{};
	stp	xzr, xzr, [x8, 32]	// <retval>
// /probe/scatter-baseline-pitch.cpp:500:   if (!prepared_) return result;
	tbz	x1, 0, .L1169	// tmp794,,
	mov	x20, x8	// tmp310, tmp758
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	ldrb	w2, [x19, 2264]	// this_142(D)->focusTarget_, this_142(D)->focusTarget_
	str	x26, [sp, 2232]	//,
	.cfi_offset 26, -56
// /probe/scatter-baseline-pitch.cpp:501:   ++inputSamples_;
	add	x26, x28, 524288	// tmp732, this,
	ldr	x1, [x26, 14528]	// this_142(D)->inputSamples_, this_142(D)->inputSamples_
	str	x21, [sp, 2192]	//,
	.cfi_offset 21, -96
	str	x22, [sp, 2200]	//,
	.cfi_offset 22, -88
	str	x23, [sp, 2208]	//,
	.cfi_offset 23, -80
	str	x24, [sp, 2216]	//,
	.cfi_offset 24, -72
	add	x1, x1, 1	// tmp323, this_142(D)->inputSamples_,
	str	x25, [sp, 2224]	//,
	.cfi_offset 25, -64
	str	d8, [sp, 2256]	//,
	.cfi_offset 72, -32
	str	d9, [sp, 2264]	//,
	.cfi_offset 73, -24
	str	d10, [sp, 2272]	//,
	.cfi_offset 74, -16
	str	d11, [sp, 2280]	//,
	.cfi_offset 75, -8
	str	x1, [x26, 14528]	// tmp323, this_142(D)->inputSamples_
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	mov	w1, 29710	// tmp775,
	movk	w1, 0x3a5a, lsl 16	// tmp775,,
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	ldr	s1, [x26, 14544]	// pretmp_416, this_142(D)->focus_
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	tbnz	x2, 0, .L1282	// this_142(D)->focusTarget_,,
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	fmov	s0, w1	// tmp331, tmp774
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:264:       return __a;
	movi	v2.2s, #0	// tmp736
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	fsub	s1, s1, s0	// _7, pretmp_416, tmp331
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:264:       return __a;
	fcmpe	s1, s2	// _7,
	fcsel	s1, s1, s2, gt	// _7, _7, tmp736,
.L1173:
// /probe/scatter-baseline-pitch.cpp:506:   const std::array<float, 2> source{input.left, input.right};
	fmov	d0, x0	// tmp795, input
// /probe/scatter-baseline-pitch.cpp:504:   warp_ += .0020811647f * (warpTarget_ - warp_); // 10 ms, sample-rate based.
	mov	w2, 25638	// tmp772,
	movk	w2, 0x3b08, lsl 16	// tmp772,,
// /probe/scatter-baseline-pitch.cpp:504:   warp_ += .0020811647f * (warpTarget_ - warp_); // 10 ms, sample-rate based.
	ldr	s2, [x26, 14536]	// _12, this_142(D)->warpTarget_
// /probe/scatter-baseline-pitch.cpp:505:   if (std::fabs(warpTarget_ - warp_) < 1e-6f) warp_ = warpTarget_;
	mov	w1, 14269	// tmp773,
	movk	w1, 0x3586, lsl 16	// tmp773,,
// /probe/scatter-baseline-pitch.cpp:504:   warp_ += .0020811647f * (warpTarget_ - warp_); // 10 ms, sample-rate based.
	fmov	s4, w2	// tmp336, tmp772
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	str	s1, [x26, 14544]	// _7, this_142(D)->focus_
// /probe/scatter-baseline-pitch.cpp:505:   if (std::fabs(warpTarget_ - warp_) < 1e-6f) warp_ = warpTarget_;
	fmov	s3, w1	// tmp339, tmp773
// /probe/scatter-baseline-pitch.cpp:507:   if (longJob_ < 12) ++longAge_;
	ldr	x0, [x26, 14584]	// this_142(D)->longJob_, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:506:   const std::array<float, 2> source{input.left, input.right};
	str	d0, [sp, 2144]	// tmp795, MEM <vector(2) float> [(float *)&source]
// /probe/scatter-baseline-pitch.cpp:504:   warp_ += .0020811647f * (warpTarget_ - warp_); // 10 ms, sample-rate based.
	ldr	s0, [x26, 14540]	// _11, this_142(D)->warp_
// /probe/scatter-baseline-pitch.cpp:504:   warp_ += .0020811647f * (warpTarget_ - warp_); // 10 ms, sample-rate based.
	fsub	s1, s2, s0	// tmp335, _12, _11
// /probe/scatter-baseline-pitch.cpp:504:   warp_ += .0020811647f * (warpTarget_ - warp_); // 10 ms, sample-rate based.
	fmadd	s0, s1, s4, s0	// _15, tmp335, tmp336, _11
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:235:   { return __builtin_fabsf(__x); }
	fabd	s1, s2, s0	// tmp338, _12, _15
// /probe/scatter-baseline-pitch.cpp:505:   if (std::fabs(warpTarget_ - warp_) < 1e-6f) warp_ = warpTarget_;
	fcmpe	s1, s3	// tmp338, tmp339
	fcsel	s0, s2, s0, mi	// _15, _12, _15,
// /probe/scatter-baseline-pitch.cpp:507:   if (longJob_ < 12) ++longAge_;
	cmp	x0, 11	// this_142(D)->longJob_,
	str	s0, [x26, 14540]	// _15, MEM <struct PolyphonicPitchBank> [(void *)this_142(D)].warp_
	bhi	.L1178		//,
// /probe/scatter-baseline-pitch.cpp:507:   if (longJob_ < 12) ++longAge_;
	ldr	x0, [x26, 14600]	// this_142(D)->longAge_, this_142(D)->longAge_
	add	x0, x0, 1	// tmp346, this_142(D)->longAge_,
	str	x0, [x26, 14600]	// tmp346, this_142(D)->longAge_
.L1178:
// /probe/scatter-baseline-pitch.cpp:508:   if (shortJob_ < 4) ++shortAge_;
	ldr	x0, [x26, 14592]	// this_142(D)->shortJob_, this_142(D)->shortJob_
	cmp	x0, 3	// this_142(D)->shortJob_,
	bhi	.L1179		//,
// /probe/scatter-baseline-pitch.cpp:508:   if (shortJob_ < 4) ++shortAge_;
	ldr	x0, [x26, 14608]	// this_142(D)->shortAge_, this_142(D)->shortAge_
	add	x0, x0, 1	// tmp352, this_142(D)->shortAge_,
	str	x0, [x26, 14608]	// tmp352, this_142(D)->shortAge_
.L1179:
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	mov	x0, 9744	// ivtmp.2612,
	movk	x0, 0x1, lsl 16	// ivtmp.2612,,
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fmov	s10, 1.0e+0	// tmp754,
	mov	x17, 50368	//,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	add	x24, x0, 1104	// tmp755, ivtmp.2612,
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	str	wzr, [sp, 56]	//, %sfp
	add	x1, x28, x17	// tmp734, this,
	add	x25, x28, x0	// ivtmp.2570, this, ivtmp.2612
	str	x0, [sp, 48]	// ivtmp.2612, %sfp
	mov	x21, x28	// ivtmp.2597, this
	add	x0, sp, 2144	// ivtmp.2605,,
	str	wzr, [sp, 72]	//, %sfp
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	mov	x22, 38192	// tmp753,
	mov	x23, x20	// ivtmp.2572, tmp310
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	stp	x1, xzr, [sp, 24]	// tmp734,, %sfp
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	mov	x27, 0	// voice,
	str	x0, [sp, 40]	// ivtmp.2605, %sfp
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	str	wzr, [sp, 80]	//, %sfp
	str	x1, [sp, 88]	// tmp734, %sfp
.L1198:
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	mov	x0, x25	//, ivtmp.2570
	bl	_ZN5ardor4pog317SpectralSynthesis3popEv		//
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	cmp	x27, 3	// voice,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	fmov	s8, s0	// _365, tmp767
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	bls	.L1196		//,
.L1283:
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	ldr	s9, [x26, 14544]	// _364, this_142(D)->focus_
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	add	x0, x25, x24	//, ivtmp.2570, tmp755
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	add	x25, x25, x22	// ivtmp.2570, ivtmp.2570, tmp753
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fsub	s11, s10, s9	// _362, tmp754, _364
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	bl	_ZN5ardor4pog317SpectralSynthesis3popEv		//
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fmul	s0, s0, s11	// tmp420, tmp768, _362
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	cmp	x27, 5	// voice,
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fmadd	s0, s9, s8, s0	// value, _364, _365, tmp420
// /probe/scatter-baseline-pitch.cpp:514:       (channel ? result[voice].right : result[voice].left) = value;
	str	s0, [x23], 8	// value, MEM <float> [(struct value_type &)_405]
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	beq	.L1183		//,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	mov	x0, x25	//, ivtmp.2570
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	mov	x27, 5	// voice,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	bl	_ZN5ardor4pog317SpectralSynthesis3popEv		//
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	cmp	x27, 3	// voice,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	fmov	s8, s0	// _365, tmp767
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	bhi	.L1283		//,
.L1196:
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	add	x27, x27, 1	// voice, voice,
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	add	x25, x25, x22	// ivtmp.2570, ivtmp.2570, tmp753
// /probe/scatter-baseline-pitch.cpp:514:       (channel ? result[voice].right : result[voice].left) = value;
	str	s0, [x23], 8	// _365, MEM <float> [(struct value_type &)_355]
	b	.L1198		//
	.p2align 2,,3
.L1295:
// /probe/scatter-baseline-pitch.cpp:597:     if (shortAge_ >= 128) { ++deadlineMisses_; healthy_ = false; break; }
	ldr	x0, [x26, 14616]	// this_142(D)->deadlineMisses_, this_142(D)->deadlineMisses_
	add	x0, x0, 1	// tmp651, this_142(D)->deadlineMisses_,
	str	x0, [x26, 14616]	// tmp651, this_142(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:597:     if (shortAge_ >= 128) { ++deadlineMisses_; healthy_ = false; break; }
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
.L1278:
	ldr	d8, [sp, 2256]	//,
	.cfi_restore 72
	ldr	d9, [sp, 2264]	//,
	.cfi_restore 73
	ldr	d10, [sp, 2272]	//,
	.cfi_restore 74
	ldr	d11, [sp, 2280]	//,
	.cfi_restore 75
	ldr	x21, [sp, 2192]	//,
	.cfi_restore 21
	ldr	x22, [sp, 2200]	//,
	.cfi_restore 22
	ldr	x23, [sp, 2208]	//,
	.cfi_restore 23
	ldr	x24, [sp, 2216]	//,
	.cfi_restore 24
	ldr	x25, [sp, 2224]	//,
	.cfi_restore 25
	ldr	x26, [sp, 2232]	//,
	.cfi_restore 26
.L1169:
// /probe/scatter-baseline-pitch.cpp:604: }
	adrp	x0, :got:__stack_chk_guard	// tmp725,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp725,
	ldr	x2, [sp, 2152]	// tmp777, D.330338
	ldr	x1, [x0]	// tmp778,
	subs	x2, x2, x1	// tmp777, tmp778
	mov	x1, 0	// tmp778
	bne	.L1284		//,
	add	sp, sp, 2160	//,,
	.cfi_def_cfa_offset 128
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x27, x28, [sp, 80]	//,,
	ldp	x29, x30, [sp], 128	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1183:
	.cfi_def_cfa_offset 2288
	.cfi_offset 19, -112
	.cfi_offset 20, -104
	.cfi_offset 21, -96
	.cfi_offset 22, -88
	.cfi_offset 23, -80
	.cfi_offset 24, -72
	.cfi_offset 25, -64
	.cfi_offset 26, -56
	.cfi_offset 27, -48
	.cfi_offset 28, -40
	.cfi_offset 29, -128
	.cfi_offset 30, -120
	.cfi_offset 72, -32
	.cfi_offset 73, -24
	.cfi_offset 74, -16
	.cfi_offset 75, -8
// /probe/scatter-baseline-pitch.cpp:516:     if (longAnalysis_[channel].push(source[channel])) {
	ldr	x0, [sp, 40]	// ivtmp.2605, %sfp
	ldr	s8, [x0]	// _32, MEM[(const value_type &)_474]
	mov	x0, x21	//, ivtmp.2597
	fmov	s0, s8	//, _32
	bl	_ZN5ardor4pog316SpectralAnalysis4pushEf		//
	and	w23, w0, 255	// retval.288_236, tmp764
// /probe/scatter-baseline-pitch.cpp:516:     if (longAnalysis_[channel].push(source[channel])) {
	tbz	x0, 0, .L1186	// tmp764,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	ldr	x0, [sp, 24]	// ivtmp.2598, %sfp
	mov	x16, -49792	//,
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:56:     return pending_ ? std::span<const std::complex<float>>{} : spectrum_;
	ldrb	w1, [x21, 89]	// MEM <const bool> [(const struct SpectralAnalysis *)_198 + 89B], MEM <const bool> [(const struct SpectralAnalysis *)_198 + 89B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x0, x0, x16	// _188, ivtmp.2598,
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:56:     return pending_ ? std::span<const std::complex<float>>{} : spectrum_;
	tbnz	x1, 0, .L1237	// MEM <const bool> [(const struct SpectralAnalysis *)_198 + 89B],,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x1, x2, [x21, 40]	// SR.1480, MEM[(struct complex * *)_198 + 48B], MEM[(struct complex * *)_198 + 40B]
	sub	x2, x2, x1	// tmp375, MEM[(struct complex * *)_198 + 48B], SR.1480
	asr	x2, x2, 3	// SR.1481, tmp375,
.L1185:
// /probe/scatter-baseline-pitch.cpp:517:       longFrames_[channel].update(longAnalysis_[channel].spectrum());
	bl	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE		//
// /probe/scatter-baseline-pitch.cpp:518:       ++transforms_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:519:       if (channel == 0) newLong = true;
	ldr	x1, [sp, 32]	// channel, %sfp
// /probe/scatter-baseline-pitch.cpp:518:       ++transforms_;
	add	x0, x0, 1	// tmp380, this_142(D)->transforms_,
// /probe/scatter-baseline-pitch.cpp:519:       if (channel == 0) newLong = true;
	cmp	x1, 0	// channel,
	ldr	w1, [sp, 56]	//, %sfp
	csel	w1, w1, w23, ne	// newLong, newLong, retval.288_236,
	str	w1, [sp, 56]	// newLong, %sfp
// /probe/scatter-baseline-pitch.cpp:518:       ++transforms_;
	str	x0, [x26, 14576]	// tmp380, this_142(D)->transforms_
.L1186:
// /probe/scatter-baseline-pitch.cpp:521:     if (shortAnalysis_[channel].push(source[channel])) {
	fmov	s0, s8	//, _32
	add	x0, x21, 192	//, ivtmp.2597,
	bl	_ZN5ardor4pog316SpectralAnalysis4pushEf		//
	and	w23, w0, 255	// retval.289_244, tmp765
// /probe/scatter-baseline-pitch.cpp:521:     if (shortAnalysis_[channel].push(source[channel])) {
	tbz	x0, 0, .L1187	// tmp765,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	ldr	x0, [sp, 24]	// ivtmp.2598, %sfp
	mov	x15, -24896	//,
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:56:     return pending_ ? std::span<const std::complex<float>>{} : spectrum_;
	ldrb	w1, [x21, 281]	// MEM <const bool> [(const struct SpectralAnalysis *)_198 + 281B], MEM <const bool> [(const struct SpectralAnalysis *)_198 + 281B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x0, x0, x15	// _246, ivtmp.2598,
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:56:     return pending_ ? std::span<const std::complex<float>>{} : spectrum_;
	tbnz	x1, 0, .L1239	// MEM <const bool> [(const struct SpectralAnalysis *)_198 + 281B],,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x1, x2, [x21, 232]	// SR.1482, MEM[(struct complex * *)_198 + 240B], MEM[(struct complex * *)_198 + 232B]
	sub	x2, x2, x1	// tmp388, MEM[(struct complex * *)_198 + 240B], SR.1482
	asr	x2, x2, 3	// SR.1483, tmp388,
.L1188:
// /probe/scatter-baseline-pitch.cpp:522:       shortFrames_[channel].update(shortAnalysis_[channel].spectrum());
	bl	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE		//
// /probe/scatter-baseline-pitch.cpp:523:       ++transforms_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
	add	x0, x0, 1	// tmp393, this_142(D)->transforms_,
	str	x0, [x26, 14576]	// tmp393, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:524:       if (channel == 0) newShort = true;
	ldr	x0, [sp, 32]	// channel, %sfp
	cbz	x0, .L1285	// channel,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x23, x21, 384	// _314, ivtmp.2597,
// /probe/scatter-baseline-pitch.cpp:526:     if (lowAnalysis_[channel].push(source[channel])) {
	fmov	s0, s8	//, _32
	mov	x0, x23	//, _314
	bl	_ZN5ardor4pog316SpectralAnalysis4pushEf		//
	and	w1, w0, 255	// retval.290_316, tmp771
// /probe/scatter-baseline-pitch.cpp:526:     if (lowAnalysis_[channel].push(source[channel])) {
	tbz	x0, 0, .L1241	// tmp771,,
.L1231:
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:56:     return pending_ ? std::span<const std::complex<float>>{} : spectrum_;
	ldrb	w0, [x21, 473]	// MEM <const bool> [(const struct SpectralAnalysis *)_198 + 473B], MEM <const bool> [(const struct SpectralAnalysis *)_198 + 473B]
	tbnz	x0, 0, .L1240	// MEM <const bool> [(const struct SpectralAnalysis *)_198 + 473B],,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x1, x2, [x23, 40]	// SR.1484, MEM[(const struct vector *)_327 + 40B].D.212165._M_impl.D.211503._M_finish, MEM[(const struct vector *)_327 + 40B].D.212165._M_impl.D.211503._M_start
// /probe/scatter-baseline-pitch.cpp:527:       lowFrames_[channel].update(lowAnalysis_[channel].spectrum());
	ldr	x0, [sp, 24]	//, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x2, x2, x1	// tmp403, MEM[(const struct vector *)_327 + 40B].D.212165._M_impl.D.211503._M_finish, SR.1484
	asr	x2, x2, 3	// SR.1485, tmp403,
// /probe/scatter-baseline-pitch.cpp:527:       lowFrames_[channel].update(lowAnalysis_[channel].spectrum());
	bl	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE		//
// /probe/scatter-baseline-pitch.cpp:528:       ++transforms_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
	add	x0, x0, 1	// tmp408, this_142(D)->transforms_,
	str	x0, [x26, 14576]	// tmp408, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	ldr	x0, [sp, 32]	// channel, %sfp
	cbz	x0, .L1286	// channel,
.L1193:
// /probe/scatter-baseline-pitch.cpp:536:   if (newLow) {
	ldr	x0, [sp, 80]	// tmp819, %sfp
	tbz	x0, 0, .L1287	// tmp819,,
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x0, x28, 524288	// tmp440, this,
// /probe/scatter-baseline-pitch.cpp:538:     lowInputEnd_ = inputSamples_;
	ldr	x1, [x26, 14528]	// this_142(D)->inputSamples_, this_142(D)->inputSamples_
// /probe/scatter-baseline-pitch.cpp:537:     lowAttackPending_ = true;
	mov	w2, 1	// tmp432,
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x0, x0, 3968	// tmp440, tmp440,
// /probe/scatter-baseline-pitch.cpp:539:     lowAttackSeconds_ = attack_.seconds();
	ldr	s0, [x0, 4368]	// MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_, MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_
// /probe/scatter-baseline-pitch.cpp:537:     lowAttackPending_ = true;
	strb	w2, [x19, 2270]	// tmp432, this_142(D)->lowAttackPending_
// /probe/scatter-baseline-pitch.cpp:538:     lowInputEnd_ = inputSamples_;
	str	x1, [x26, 14568]	// this_142(D)->inputSamples_, this_142(D)->lowInputEnd_
// /probe/scatter-baseline-pitch.cpp:539:     lowAttackSeconds_ = attack_.seconds();
	str	s0, [x26, 14560]	// MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_, this_142(D)->lowAttackSeconds_
.L1200:
// /probe/scatter-baseline-pitch.cpp:541:   if (lowAttackPending_ && rightLowReady) {
	ldr	x0, [sp, 64]	// tmp822, %sfp
	tbnz	x0, 0, .L1288	// tmp822,,
.L1201:
// /probe/scatter-baseline-pitch.cpp:548:   if (newLong) {
	ldr	x0, [sp, 56]	// tmp824, %sfp
	tbz	x0, 0, .L1202	// tmp824,,
// /probe/scatter-baseline-pitch.cpp:549:     if (longJob_ != 12) { ++deadlineMisses_; healthy_ = false; }
	ldr	x0, [x26, 14584]	// this_142(D)->longJob_, this_142(D)->longJob_
	cmp	x0, 12	// this_142(D)->longJob_,
	beq	.L1203		//,
// /probe/scatter-baseline-pitch.cpp:549:     if (longJob_ != 12) { ++deadlineMisses_; healthy_ = false; }
	ldr	x0, [x26, 14616]	// this_142(D)->deadlineMisses_, this_142(D)->deadlineMisses_
	add	x0, x0, 1	// tmp470, this_142(D)->deadlineMisses_,
	str	x0, [x26, 14616]	// tmp470, this_142(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:549:     if (longJob_ != 12) { ++deadlineMisses_; healthy_ = false; }
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
.L1203:
// /probe/scatter-baseline-pitch.cpp:553:     frameWarp_ = warp_; // Every renderer uses controls at this frame's timestamp.
	ldr	s0, [x26, 14540]	// this_142(D)->warp_, this_142(D)->warp_
// /probe/scatter-baseline-pitch.cpp:552:     freezeReady_ = false;
	add	x0, x28, 532480	// tmp476, this,
// /probe/scatter-baseline-pitch.cpp:550:     longJob_ = longAge_ = 0;
	str	xzr, [x26, 14584]	//, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:550:     longJob_ = longAge_ = 0;
	str	xzr, [x26, 14600]	//, this_142(D)->longAge_
// /probe/scatter-baseline-pitch.cpp:551:     longAttackReady_ = false;
	strb	wzr, [x19, 2267]	//, this_142(D)->longAttackReady_
// /probe/scatter-baseline-pitch.cpp:552:     freezeReady_ = false;
	strb	wzr, [x0, 185]	//, this_142(D)->freezeReady_
// /probe/scatter-baseline-pitch.cpp:555:   if (newShort) {
	ldr	x0, [sp, 72]	// tmp825, %sfp
// /probe/scatter-baseline-pitch.cpp:553:     frameWarp_ = warp_; // Every renderer uses controls at this frame's timestamp.
	str	s0, [x26, 14548]	// this_142(D)->warp_, this_142(D)->frameWarp_
// /probe/scatter-baseline-pitch.cpp:555:   if (newShort) {
	tbz	x0, 0, .L1204	// tmp825,,
// /probe/scatter-baseline-pitch.cpp:556:     if (shortJob_ != 4) { ++deadlineMisses_; healthy_ = false; }
	ldr	x0, [x26, 14592]	// this_142(D)->shortJob_, this_142(D)->shortJob_
	cmp	x0, 4	// this_142(D)->shortJob_,
	beq	.L1205		//,
// /probe/scatter-baseline-pitch.cpp:556:     if (shortJob_ != 4) { ++deadlineMisses_; healthy_ = false; }
	ldr	x0, [x26, 14616]	// this_142(D)->deadlineMisses_, this_142(D)->deadlineMisses_
	add	x0, x0, 1	// tmp485, this_142(D)->deadlineMisses_,
	str	x0, [x26, 14616]	// tmp485, this_142(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:556:     if (shortJob_ != 4) { ++deadlineMisses_; healthy_ = false; }
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
// /probe/scatter-baseline-pitch.cpp:557:     shortJob_ = shortAge_ = 0;
	str	xzr, [x26, 14592]	//, this_142(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:557:     shortJob_ = shortAge_ = 0;
	str	xzr, [x26, 14608]	//, this_142(D)->shortAge_
// /probe/scatter-baseline-pitch.cpp:558:     shortAttackReady_ = false;
	strb	wzr, [x19, 2268]	//, this_142(D)->shortAttackReady_
.L1279:
// /probe/scatter-baseline-pitch.cpp:560:   if (!longAttackReady_ && longAge_ >= 1
	ldr	x4, [x26, 14600]	// pretmp_379, this_142(D)->longAge_
// /probe/scatter-baseline-pitch.cpp:560:   if (!longAttackReady_ && longAge_ >= 1
	cbz	x4, .L1204	// pretmp_379,
// /probe/scatter-baseline-pitch.cpp:561:       && longAnalysis_[0].frameCount() == longAnalysis_[1].frameCount()) {
	ldr	x0, [x28, 80]	// MEM[(const struct SpectralAnalysis *)this_142(D)].frameCount_, MEM[(const struct SpectralAnalysis *)this_142(D)].frameCount_
	ldr	x1, [x28, 176]	// MEM[(const struct SpectralAnalysis *)this_142(D) + 96B].frameCount_, MEM[(const struct SpectralAnalysis *)this_142(D) + 96B].frameCount_
	cmp	x1, x0	// MEM[(const struct SpectralAnalysis *)this_142(D) + 96B].frameCount_, MEM[(const struct SpectralAnalysis *)this_142(D)].frameCount_
	beq	.L1289		//,
.L1204:
// /probe/scatter-baseline-pitch.cpp:567:       && shortAnalysis_[0].frameCount() == shortAnalysis_[1].frameCount()) {
	ldrb	w0, [x19, 2268]	// this_142(D)->shortAttackReady_, this_142(D)->shortAttackReady_
	tbnz	x0, 0, .L1214	// this_142(D)->shortAttackReady_,,
.L1213:
// /probe/scatter-baseline-pitch.cpp:566:   if (!shortAttackReady_ && shortAge_ >= 8
	ldr	x4, [x26, 14608]	// pretmp_386, this_142(D)->shortAge_
// /probe/scatter-baseline-pitch.cpp:566:   if (!shortAttackReady_ && shortAge_ >= 8
	cmp	x4, 7	// pretmp_386,
	bls	.L1209		//,
// /probe/scatter-baseline-pitch.cpp:567:       && shortAnalysis_[0].frameCount() == shortAnalysis_[1].frameCount()) {
	ldr	x0, [x28, 272]	// MEM[(const struct SpectralAnalysis *)this_142(D) + 192B].frameCount_, MEM[(const struct SpectralAnalysis *)this_142(D) + 192B].frameCount_
	ldr	x1, [x28, 368]	// MEM[(const struct SpectralAnalysis *)this_142(D) + 288B].frameCount_, MEM[(const struct SpectralAnalysis *)this_142(D) + 288B].frameCount_
	cmp	x1, x0	// MEM[(const struct SpectralAnalysis *)this_142(D) + 288B].frameCount_, MEM[(const struct SpectralAnalysis *)this_142(D) + 192B].frameCount_
	beq	.L1290		//,
.L1209:
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldrb	w0, [x19, 2267]	// this_142(D)->longAttackReady_, this_142(D)->longAttackReady_
	tbnz	x0, 0, .L1212	// this_142(D)->longAttackReady_,,
	b	.L1278		//
	.p2align 2,,3
.L1282:
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	fmov	s0, w1	// tmp329, tmp775
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	fmov	s2, 1.0e+0	// tmp330,
// /probe/scatter-baseline-pitch.cpp:503:   focus_ = focusTarget_ ? std::min(1.0f, focus_ + step) : std::max(0.0f, focus_ - step);
	fadd	s1, s1, s0	// _7, pretmp_416, tmp329
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:240:       return __a;
	fcmpe	s1, s2	// _7, tmp330
	fcsel	s1, s1, s2, mi	// _7, _7, tmp330,
	b	.L1173		//
	.p2align 2,,3
.L1285:
// /probe/scatter-baseline-pitch.cpp:524:       if (channel == 0) newShort = true;
	str	w23, [sp, 72]	// retval.289_244, %sfp
.L1187:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x23, x21, 384	// _314, ivtmp.2597,
// /probe/scatter-baseline-pitch.cpp:526:     if (lowAnalysis_[channel].push(source[channel])) {
	fmov	s0, s8	//, _32
	mov	x0, x23	//, _314
	bl	_ZN5ardor4pog316SpectralAnalysis4pushEf		//
	and	w1, w0, 255	// retval.290_251, tmp766
// /probe/scatter-baseline-pitch.cpp:526:     if (lowAnalysis_[channel].push(source[channel])) {
	tbnz	x0, 0, .L1231	// tmp766,,
// /probe/scatter-baseline-pitch.cpp:510:   for (std::size_t channel = 0; channel < 2; ++channel) {
	ldr	x0, [sp, 24]	// ivtmp.2598, %sfp
	mov	x13, 12448	//,
	mov	x14, 19096	//,
	add	x21, x21, 96	// ivtmp.2597, ivtmp.2597,
	add	x0, x0, x13	// ivtmp.2598, ivtmp.2598,
	str	x0, [sp, 24]	// ivtmp.2598, %sfp
	ldr	x0, [sp, 40]	// ivtmp.2605, %sfp
	add	x0, x0, 4	// ivtmp.2605, ivtmp.2605,
	str	x0, [sp, 40]	// ivtmp.2605, %sfp
	ldr	x0, [sp, 48]	// ivtmp.2612, %sfp
	add	x0, x0, x14	// ivtmp.2612, ivtmp.2612,
	str	x0, [sp, 48]	// ivtmp.2612, %sfp
	ldr	x0, [sp, 32]	// channel, %sfp
	cbnz	x0, .L1241	// channel,
.L1232:
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	mov	x0, 1	// channel,
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	mov	x23, 0	// voice,
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	str	x0, [sp, 32]	// channel, %sfp
	ldr	x0, [sp, 48]	// ivtmp.2612, %sfp
	add	x25, x28, x0	// ivtmp.2582, this, ivtmp.2612
.L1195:
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	mov	x0, x25	//, ivtmp.2582
	bl	_ZN5ardor4pog317SpectralSynthesis3popEv		//
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	cmp	x23, 3	// voice,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	fmov	s8, s0	// _209, tmp762
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	bls	.L1181		//,
.L1291:
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	ldr	s11, [x26, 14544]	// _25, this_142(D)->focus_
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	add	x0, x25, x24	//, ivtmp.2582, tmp755
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	add	x25, x25, x22	// ivtmp.2582, ivtmp.2582, tmp753
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fsub	s9, s10, s11	// _27, tmp754, _25
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	bl	_ZN5ardor4pog317SpectralSynthesis3popEv		//
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fmul	s9, s9, s0	// tmp359, _27, tmp763
// /probe/scatter-baseline-pitch.cpp:514:       (channel ? result[voice].right : result[voice].left) = value;
	add	x0, x20, x23, lsl 3	// tmp361, tmp310, voice,
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	cmp	x23, 5	// voice,
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	fmadd	s9, s11, s8, s9	// value, _25, _209, tmp359
// /probe/scatter-baseline-pitch.cpp:514:       (channel ? result[voice].right : result[voice].left) = value;
	str	s9, [x0, 4]	// value, MEM <float> [(struct value_type &)&<retval> + 4 + _506 * 1]
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	beq	.L1183		//,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	mov	x0, x25	//, ivtmp.2582
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	mov	x23, 5	// voice,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	bl	_ZN5ardor4pog317SpectralSynthesis3popEv		//
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	cmp	x23, 3	// voice,
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:97:   float pop() noexcept { return synthesis_.pop(); }
	fmov	s8, s0	// _209, tmp762
// /probe/scatter-baseline-pitch.cpp:513:       if (voice >= 4) value = focus_ * value + (1 - focus_) * shortVoices_[voice - 4][channel].pop();
	bhi	.L1291		//,
.L1181:
// /probe/scatter-baseline-pitch.cpp:514:       (channel ? result[voice].right : result[voice].left) = value;
	add	x0, x20, x23, lsl 3	// tmp366, tmp310, voice,
// /probe/scatter-baseline-pitch.cpp:511:     for (std::size_t voice = 0; voice < kVoiceCount; ++voice) {
	add	x25, x25, x22	// ivtmp.2582, ivtmp.2582, tmp753
// /probe/scatter-baseline-pitch.cpp:514:       (channel ? result[voice].right : result[voice].left) = value;
	add	x23, x23, 1	// voice, voice,
	str	s0, [x0, 4]	// _209, MEM <float> [(struct value_type &)&<retval> + 4 + _507 * 1]
	b	.L1195		//
	.p2align 2,,3
.L1237:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:91: 	: _M_extent_value(__extent)
	mov	x2, 0	// SR.1481,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:153:       : _M_ptr(nullptr), _M_extent(0)
	mov	x1, 0	// SR.1480,
	b	.L1185		//
	.p2align 2,,3
.L1202:
// /probe/scatter-baseline-pitch.cpp:555:   if (newShort) {
	ldr	x1, [sp, 72]	// tmp826, %sfp
// /probe/scatter-baseline-pitch.cpp:560:   if (!longAttackReady_ && longAge_ >= 1
	ldrb	w0, [x19, 2267]	// pretmp_414, this_142(D)->longAttackReady_
// /probe/scatter-baseline-pitch.cpp:555:   if (newShort) {
	tbnz	x1, 0, .L1292	// tmp826,,
// /probe/scatter-baseline-pitch.cpp:561:       && longAnalysis_[0].frameCount() == longAnalysis_[1].frameCount()) {
	tbz	x0, 0, .L1279	// pretmp_414,,
// /probe/scatter-baseline-pitch.cpp:567:       && shortAnalysis_[0].frameCount() == shortAnalysis_[1].frameCount()) {
	ldrb	w0, [x19, 2268]	// this_142(D)->shortAttackReady_, this_142(D)->shortAttackReady_
	tbz	x0, 0, .L1213	// this_142(D)->shortAttackReady_,,
.L1212:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x20, 12476	// tmp744,
	movk	x20, 0x8, lsl 16	// tmp744,,
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldr	x4, [x26, 14584]	// _94, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	adrp	x23, .LANCHOR0	// tmp742,
	add	x23, x23, :lo12:.LANCHOR0	// tmp743, tmp742,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x21, 9728	// tmp746,
	movk	x21, 0x1, lsl 16	// tmp746,,
	sub	x22, x20, #4096	// tmp745, tmp744,
	b	.L1215		//
	.p2align 2,,3
.L1294:
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:593:                                            kExperimentalFreezeEnabled && channel ? &longVoices_[voice][0] : nullptr)) healthy_ = false;
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	ldr	x4, [x26, 14584]	// this_142(D)->longJob_, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldrb	w1, [x19, 2267]	// this_142(D)->longAttackReady_, this_142(D)->longAttackReady_
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	add	x0, x0, 1	// tmp635, this_142(D)->transforms_,
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	add	x4, x4, 1	// _94, this_142(D)->longJob_,
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	str	x0, [x26, 14576]	// tmp635, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	str	x4, [x26, 14584]	// _94, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	tbz	x1, 0, .L1223	// this_142(D)->longAttackReady_,,
.L1215:
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	cmp	x4, 11	// _94,
	bhi	.L1223		//,
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldr	x0, [x23, x4, lsl 3]	// MEM <const struct array> [(const value_type &)&longDue]._M_elems[prephitmp_394], MEM <const struct array> [(const value_type &)&longDue]._M_elems[prephitmp_394]
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldr	x3, [x26, 14600]	// _98, this_142(D)->longAge_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	cmp	x0, x3	// MEM <const struct array> [(const value_type &)&longDue]._M_elems[prephitmp_394], _98
	bhi	.L1223		//,
// /probe/scatter-baseline-pitch.cpp:585:     if (longAge_ >= 256) { ++deadlineMisses_; healthy_ = false; break; }
	cmp	x3, 255	// _98,
	bhi	.L1293		//,
// /probe/scatter-baseline-pitch.cpp:586:     const auto voice = longJob_ / 2, channel = longJob_ % 2;
	lsr	x0, x4, 1	// voice, _94,
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	adrp	x5, _ZN5ardor4pog315kVoiceSemitonesE	// tmp604,
	add	x5, x5, :lo12:_ZN5ardor4pog315kVoiceSemitonesE	// tmp603, tmp604,
	sbfx	x1, x4, 0, 1	// tmp588, _94,,
	ldr	s0, [x26, 14548]	// this_142(D)->frameWarp_, this_142(D)->frameWarp_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x2, 19096	// tmp615,
	mov	x6, 38192	// tmp612,
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	fmov	s2, 1.0e+0	//,
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	ldr	s3, [x5, x0, lsl 2]	// MEM <const struct array> [(const value_type &)&kVoiceSemitones]._M_elems[voice_202], MEM <const struct array> [(const value_type &)&kVoiceSemitones]._M_elems[voice_202]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	and	x2, x1, x2	// tmp614, tmp588, tmp615
	mov	x5, 12448	// tmp589,
	and	x1, x1, x5	// _73, tmp588, tmp589
	ubfiz	x4, x4, 10, 1	// _304, _94,,
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	movi	v1.2s, #0	//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	madd	x0, x0, x6, x2	// tmp616, voice, tmp612, tmp614
	mov	x7, 50368	//,
	add	x5, x4, x20	// tmp592, _304, tmp744
	add	x2, x1, x7	// tmp600, _73,
	add	x4, x4, x22	// tmp595, _304, tmp745
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	ldrb	w6, [x19, 2269]	//, this_142(D)->longAttackActive_
	mov	x7, 256	// tmp599,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x1, x1, 576	// tmp609, _73,
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	stp	xzr, xzr, [sp]	//,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x0, x0, x21	// tmp617, tmp616, tmp746
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	sub	x3, x7, x3	//, tmp599, _98
	fmul	s0, s3, s0	//, MEM <const struct array> [(const value_type &)&kVoiceSemitones]._M_elems[voice_202], this_142(D)->frameWarp_
	add	x2, x28, x2	//, this, tmp600
	add	x1, x28, x1	//, this, tmp609
	add	x0, x28, x0	//, this, tmp617
	add	x5, x28, x5	//, this, tmp592
	add	x4, x28, x4	//, this, tmp595
	mov	x7, 0	//,
	bl	_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_		//
// /probe/scatter-baseline-pitch.cpp:587:     if (!longVoices_[voice][channel].render(longFrames_[channel], kVoiceSemitones[voice] * frameWarp_, &lowFrames_[channel],
	tbz	x0, 0, .L1294	// tmp769,,
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	ldr	x4, [x26, 14584]	// this_142(D)->longJob_, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldrb	w1, [x19, 2267]	// this_142(D)->longAttackReady_, this_142(D)->longAttackReady_
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	add	x0, x0, 1	// tmp635, this_142(D)->transforms_,
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	add	x4, x4, 1	// _94, this_142(D)->longJob_,
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	str	x0, [x26, 14576]	// tmp635, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:594:     ++transforms_; ++longJob_;
	str	x4, [x26, 14584]	// _94, this_142(D)->longJob_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	tbnz	x1, 0, .L1215	// this_142(D)->longAttackReady_,,
	.p2align 3,,7
.L1223:
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	ldrb	w0, [x19, 2268]	// pretmp_395, this_142(D)->shortAttackReady_
.L1221:
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	tbz	x0, 0, .L1278	// pretmp_395,,
.L1214:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x21, 12476	// tmp737,
	movk	x21, 0x8, lsl 16	// tmp737,,
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	ldr	x4, [x26, 14592]	// _108, this_142(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	adrp	x20, _ZN5ardor4pog315kVoiceSemitonesE	// tmp739,
	add	x20, x20, :lo12:_ZN5ardor4pog315kVoiceSemitonesE	// tmp740, tmp739,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x22, 42272	// tmp741,
	movk	x22, 0x4, lsl 16	// tmp741,,
	sub	x23, x21, #2048	// tmp738, tmp737,
	b	.L1217		//
	.p2align 2,,3
.L1296:
// /probe/scatter-baseline-pitch.cpp:601:     ++transforms_; ++shortJob_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:600:                                             128 - shortAge_, &shortGains_[channel], &lowGains_[channel])) healthy_ = false;
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
.L1281:
// /probe/scatter-baseline-pitch.cpp:601:     ++transforms_; ++shortJob_;
	ldr	x4, [x26, 14592]	// this_142(D)->shortJob_, this_142(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:601:     ++transforms_; ++shortJob_;
	add	x0, x0, 1	// tmp699, this_142(D)->transforms_,
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	ldrb	w1, [x19, 2268]	// this_142(D)->shortAttackReady_, this_142(D)->shortAttackReady_
// /probe/scatter-baseline-pitch.cpp:601:     ++transforms_; ++shortJob_;
	str	x0, [x26, 14576]	// tmp699, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:601:     ++transforms_; ++shortJob_;
	add	x4, x4, 1	// _108, this_142(D)->shortJob_,
	str	x4, [x26, 14592]	// _108, this_142(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	tbz	x1, 0, .L1278	// this_142(D)->shortAttackReady_,,
.L1217:
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	cmp	x4, 3	// _108,
	bhi	.L1278		//,
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	ldr	x3, [x26, 14608]	// _113, this_142(D)->shortAge_
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	lsl	x0, x4, 4	// tmp708, _108,
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	add	x0, x0, 65	// tmp709, tmp708,
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	cmp	x0, x3	// tmp709, _113
	bhi	.L1278		//,
// /probe/scatter-baseline-pitch.cpp:597:     if (shortAge_ >= 128) { ++deadlineMisses_; healthy_ = false; break; }
	cmp	x3, 127	// _113,
	bhi	.L1295		//,
// /probe/scatter-baseline-pitch.cpp:598:     const auto voice = shortJob_ / 2, channel = shortJob_ % 2;
	lsr	x2, x4, 1	// voice, _108,
	sbfx	x1, x4, 0, 1	// tmp654, _108,,
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	fmov	s2, 1.0e+0	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x6, 38192	// tmp679,
	neg	x5, x2	// tmp677, voice
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	movi	v1.2s, #0	//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	mov	x0, 19096	// tmp676,
	and	x5, x5, x6	// tmp678, tmp677, tmp679
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	stp	xzr, xzr, [sp]	//,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	and	x0, x1, x0	// tmp675, tmp654, tmp676
	mov	x6, 12448	// tmp655,
	and	x1, x1, x6	// _76, tmp654, tmp655
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	add	x2, x2, 4	// tmp669, voice,
	ubfiz	x4, x4, 10, 1	// _299, _108,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x0, x0, x5	// tmp680, tmp675, tmp678
	mov	x6, 25472	//,
	mov	x5, 50368	//,
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	ldr	s0, [x20, x2, lsl 2]	//, MEM <const struct array> [(const value_type &)&kVoiceSemitones]._M_elems[_101]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x7, x1, x5	// tmp664, _76,
	add	x0, x0, x22	// tmp681, tmp680, tmp741
	add	x1, x1, x6	// tmp671, _76,
	add	x5, x4, x21	// tmp656, _299, tmp737
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	mov	x6, 128	// tmp663,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x4, x4, x23	// tmp659, _299, tmp738
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	add	x2, x28, x7	//, this, tmp664
	sub	x3, x6, x3	//, tmp663, _113
	add	x0, x28, x0	//, this, tmp681
	add	x1, x28, x1	//, this, tmp671
	add	x5, x28, x5	//, this, tmp656
	add	x4, x28, x4	//, this, tmp659
	mov	x7, 0	//,
	mov	w6, 0	//,
	bl	_ZN5ardor4pog313PitchRenderer6renderERKNS0_10PitchFrameEfPS3_mPKSt5arrayIfLm256EES9_bPKNS0_10FrozenBandESC_ffPKS1_		//
// /probe/scatter-baseline-pitch.cpp:599:     if (!shortVoices_[voice][channel].render(shortFrames_[channel], kVoiceSemitones[voice + 4], &lowFrames_[channel],
	tbz	x0, 0, .L1296	// tmp770,,
// /probe/scatter-baseline-pitch.cpp:601:     ++transforms_; ++shortJob_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
	b	.L1281		//
	.p2align 2,,3
.L1240:
// /probe/scatter-baseline-pitch.cpp:527:       lowFrames_[channel].update(lowAnalysis_[channel].spectrum());
	ldr	x0, [sp, 24]	//, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:91: 	: _M_extent_value(__extent)
	mov	x2, 0	// SR.1485,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:153:       : _M_ptr(nullptr), _M_extent(0)
	mov	x1, 0	// SR.1484,
// /probe/scatter-baseline-pitch.cpp:527:       lowFrames_[channel].update(lowAnalysis_[channel].spectrum());
	bl	_ZN5ardor4pog310PitchFrame6updateESt4spanIKSt7complexIfELm18446744073709551615EE		//
// /probe/scatter-baseline-pitch.cpp:528:       ++transforms_;
	ldr	x0, [x26, 14576]	// this_142(D)->transforms_, this_142(D)->transforms_
	add	x0, x0, 1	// tmp408, this_142(D)->transforms_,
	str	x0, [x26, 14576]	// tmp408, this_142(D)->transforms_
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	ldr	x0, [sp, 32]	// channel, %sfp
	cbnz	x0, .L1193	// channel,
.L1286:
// /probe/scatter-baseline-pitch.cpp:510:   for (std::size_t channel = 0; channel < 2; ++channel) {
	ldr	x0, [sp, 24]	// ivtmp.2598, %sfp
	mov	x1, 12448	//,
	mov	x2, 19096	//,
	add	x21, x21, 96	// ivtmp.2597, ivtmp.2597,
	add	x0, x0, x1	// ivtmp.2598, ivtmp.2598,
	str	x0, [sp, 24]	// ivtmp.2598, %sfp
	ldr	x0, [sp, 40]	// ivtmp.2605, %sfp
	add	x0, x0, 4	// ivtmp.2605, ivtmp.2605,
	str	x0, [sp, 40]	// ivtmp.2605, %sfp
	ldr	x0, [sp, 48]	// ivtmp.2612, %sfp
	add	x0, x0, x2	// ivtmp.2612, ivtmp.2612,
	str	x0, [sp, 48]	// ivtmp.2612, %sfp
// /probe/scatter-baseline-pitch.cpp:529:       if (channel == 0) newLow = true;
	ldr	w0, [sp, 64]	//, %sfp
	str	w0, [sp, 80]	// rightLowReady, %sfp
	b	.L1232		//
	.p2align 2,,3
.L1239:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:91: 	: _M_extent_value(__extent)
	mov	x2, 0	// SR.1483,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/span:153:       : _M_ptr(nullptr), _M_extent(0)
	mov	x1, 0	// SR.1482,
	b	.L1188		//
	.p2align 2,,3
.L1205:
// /probe/scatter-baseline-pitch.cpp:557:     shortJob_ = shortAge_ = 0;
	str	xzr, [x26, 14592]	//, this_142(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:557:     shortJob_ = shortAge_ = 0;
	str	xzr, [x26, 14608]	//, this_142(D)->shortAge_
// /probe/scatter-baseline-pitch.cpp:558:     shortAttackReady_ = false;
	strb	wzr, [x19, 2268]	//, this_142(D)->shortAttackReady_
	b	.L1279		//
	.p2align 2,,3
.L1293:
// /probe/scatter-baseline-pitch.cpp:585:     if (longAge_ >= 256) { ++deadlineMisses_; healthy_ = false; break; }
	ldr	x1, [x26, 14616]	// this_142(D)->deadlineMisses_, this_142(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:596:   while (shortAttackReady_ && shortJob_ < 4 && 65 + shortJob_ * 16 <= shortAge_) {
	ldrb	w0, [x19, 2268]	// pretmp_395, this_142(D)->shortAttackReady_
// /probe/scatter-baseline-pitch.cpp:585:     if (longAge_ >= 256) { ++deadlineMisses_; healthy_ = false; break; }
	add	x1, x1, 1	// tmp582, this_142(D)->deadlineMisses_,
	str	x1, [x26, 14616]	// tmp582, this_142(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:585:     if (longAge_ >= 256) { ++deadlineMisses_; healthy_ = false; break; }
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
// /probe/scatter-baseline-pitch.cpp:585:     if (longAge_ >= 256) { ++deadlineMisses_; healthy_ = false; break; }
	b	.L1221		//
	.p2align 2,,3
.L1288:
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x1, x28, 524288	// tmp446, this,
// /probe/scatter-baseline-pitch.cpp:543:     attack_.setSeconds(lowAttackSeconds_);
	add	x20, x28, 376832	// _43, this,
	ldr	s0, [x26, 14560]	//, this_142(D)->lowAttackSeconds_
	add	x20, x20, 3968	// _43, _43,
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x1, x1, 3968	// tmp446, tmp446,
	ldr	s8, [x1, 4368]	// _157, MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_
// /probe/scatter-baseline-pitch.cpp:543:     attack_.setSeconds(lowAttackSeconds_);
	mov	x0, x20	//, _43
// /probe/scatter-baseline-pitch.cpp:544:     lowGains_ = attack_.update(lowFrames_[0], lowFrames_[1], 2, lowInputEnd_);
	add	x21, sp, 96	// tmp459,,
	add	x22, x19, 188	// tmp452, tmp733,
// /probe/scatter-baseline-pitch.cpp:543:     attack_.setSeconds(lowAttackSeconds_);
	bl	_ZN5ardor4pog316PolyphonicAttack10setSecondsEf		//
// /probe/scatter-baseline-pitch.cpp:544:     lowGains_ = attack_.update(lowFrames_[0], lowFrames_[1], 2, lowInputEnd_);
	ldr	x1, [sp, 88]	// tmp734, %sfp
	mov	x12, 12448	//,
	mov	x8, x21	//, tmp459
	mov	x3, 2	//,
	mov	x0, x20	//, _43
	ldr	x4, [x26, 14568]	//, this_142(D)->lowInputEnd_
	add	x2, x1, x12	//, tmp734,
	bl	_ZN5ardor4pog316PolyphonicAttack6updateERKNS0_10PitchFrameES4_ml		//
	mov	x1, x21	//, tmp459
	mov	x2, 2048	//,
	mov	x0, x22	// tmp452, tmp452
	bl	memcpy		//
// /probe/scatter-baseline-pitch.cpp:545:     attack_.setSeconds(currentSeconds);
	fmov	s0, s8	//, _157
	mov	x0, x20	//, _43
	bl	_ZN5ardor4pog316PolyphonicAttack10setSecondsEf		//
// /probe/scatter-baseline-pitch.cpp:546:     lowAttackPending_ = false;
	strb	wzr, [x19, 2270]	//, this_142(D)->lowAttackPending_
	b	.L1201		//
.L1290:
// /probe/scatter-baseline-pitch.cpp:568:     shortGains_ = attack_.update(shortFrames_[0], shortFrames_[1], 1, inputSamples_ - shortAge_);
	ldr	x5, [x26, 14528]	// this_142(D)->inputSamples_, this_142(D)->inputSamples_
// /probe/scatter-baseline-pitch.cpp:568:     shortGains_ = attack_.update(shortFrames_[0], shortFrames_[1], 1, inputSamples_ - shortAge_);
	mov	x9, 37920	//,
	mov	x10, 25472	//,
	add	x20, sp, 96	// tmp569,,
	add	x0, x28, 376832	//, this,
	add	x2, x28, x9	//, this,
	add	x1, x28, x10	//, this,
	mov	x3, 1	//,
	mov	x8, x20	//, tmp569
	add	x0, x0, 3968	//,,
	add	x21, x28, 532480	// tmp557, this,
	sub	x4, x5, x4	//, this_142(D)->inputSamples_, pretmp_386
	add	x21, x21, 2236	// tmp557, tmp557,
	bl	_ZN5ardor4pog316PolyphonicAttack6updateERKNS0_10PitchFrameES4_ml		//
	mov	x1, x20	//, tmp569
	mov	x0, x21	// tmp557, tmp557
	mov	x2, 2048	//,
	bl	memcpy		//
// /probe/scatter-baseline-pitch.cpp:569:     shortAttackReady_ = true;
	mov	w1, 1	// tmp575,
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	ldrb	w0, [x19, 2267]	// this_142(D)->longAttackReady_, this_142(D)->longAttackReady_
// /probe/scatter-baseline-pitch.cpp:569:     shortAttackReady_ = true;
	strb	w1, [x19, 2268]	// tmp575, this_142(D)->shortAttackReady_
// /probe/scatter-baseline-pitch.cpp:584:   while (longAttackReady_ && longJob_ < 12 && longDue[longJob_] <= longAge_) {
	tbnz	x0, 0, .L1212	// this_142(D)->longAttackReady_,,
	b	.L1214		//
	.p2align 2,,3
.L1289:
// /probe/scatter-baseline-pitch.cpp:562:     longGains_ = attack_.update(longFrames_[0], longFrames_[1], 0, inputSamples_ - longAge_);
	ldr	x5, [x26, 14528]	// this_142(D)->inputSamples_, this_142(D)->inputSamples_
// /probe/scatter-baseline-pitch.cpp:562:     longGains_ = attack_.update(longFrames_[0], longFrames_[1], 0, inputSamples_ - longAge_);
	mov	x11, 13024	//,
	add	x20, sp, 96	// tmp526,,
	add	x0, x28, 376832	//, this,
	add	x2, x28, x11	//, this,
	mov	x3, 0	//,
	mov	x8, x20	//, tmp526
	add	x1, x28, 576	//, this,
	add	x0, x0, 3968	//,,
	add	x21, x28, 532480	// tmp516, this,
	sub	x4, x5, x4	//, this_142(D)->inputSamples_, pretmp_379
	add	x21, x21, 188	// tmp516, tmp516,
	bl	_ZN5ardor4pog316PolyphonicAttack6updateERKNS0_10PitchFrameES4_ml		//
	mov	x1, x20	//, tmp526
	mov	x2, 2048	//,
	mov	x0, x21	// tmp516, tmp516
	bl	memcpy		//
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x0, x28, 524288	// tmp535, this,
// /probe/scatter-baseline-pitch.cpp:564:     longAttackReady_ = true;
	mov	w2, 1	// tmp540,
// /probe/scatter-baseline-pitch.cpp:567:       && shortAnalysis_[0].frameCount() == shortAnalysis_[1].frameCount()) {
	ldrb	w1, [x19, 2268]	// this_142(D)->shortAttackReady_, this_142(D)->shortAttackReady_
// /ardor/src/daisyfx/pog3/PolyphonicAttack.h:22:   float seconds() const noexcept { return seconds_; }
	add	x0, x0, 3968	// tmp535, tmp535,
// /probe/scatter-baseline-pitch.cpp:563:     longAttackActive_ = attack_.seconds() > 0;
	ldr	s0, [x0, 4368]	// MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_, MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_
// /probe/scatter-baseline-pitch.cpp:564:     longAttackReady_ = true;
	strb	w2, [x19, 2267]	// tmp540, this_142(D)->longAttackReady_
// /probe/scatter-baseline-pitch.cpp:563:     longAttackActive_ = attack_.seconds() > 0;
	fcmpe	s0, #0.0	// MEM[(const struct PolyphonicAttack *)this_142(D) + 380800B].seconds_
	cset	w0, gt	// tmp537,
	strb	w0, [x19, 2269]	// tmp537, this_142(D)->longAttackActive_
// /probe/scatter-baseline-pitch.cpp:567:       && shortAnalysis_[0].frameCount() == shortAnalysis_[1].frameCount()) {
	tbnz	x1, 0, .L1212	// this_142(D)->shortAttackReady_,,
	b	.L1213		//
	.p2align 2,,3
.L1292:
// /probe/scatter-baseline-pitch.cpp:556:     if (shortJob_ != 4) { ++deadlineMisses_; healthy_ = false; }
	ldr	x1, [x26, 14592]	// this_142(D)->shortJob_, this_142(D)->shortJob_
	cmp	x1, 4	// this_142(D)->shortJob_,
	beq	.L1208		//,
// /probe/scatter-baseline-pitch.cpp:556:     if (shortJob_ != 4) { ++deadlineMisses_; healthy_ = false; }
	ldr	x1, [x26, 14616]	// this_142(D)->deadlineMisses_, this_142(D)->deadlineMisses_
	add	x1, x1, 1	// tmp500, this_142(D)->deadlineMisses_,
	str	x1, [x26, 14616]	// tmp500, this_142(D)->deadlineMisses_
// /probe/scatter-baseline-pitch.cpp:556:     if (shortJob_ != 4) { ++deadlineMisses_; healthy_ = false; }
	strb	wzr, [x19, 2266]	//, this_142(D)->healthy_
.L1208:
// /probe/scatter-baseline-pitch.cpp:557:     shortJob_ = shortAge_ = 0;
	str	xzr, [x26, 14592]	//, this_142(D)->shortJob_
// /probe/scatter-baseline-pitch.cpp:557:     shortJob_ = shortAge_ = 0;
	str	xzr, [x26, 14608]	//, this_142(D)->shortAge_
// /probe/scatter-baseline-pitch.cpp:558:     shortAttackReady_ = false;
	strb	wzr, [x19, 2268]	//, this_142(D)->shortAttackReady_
// /probe/scatter-baseline-pitch.cpp:561:       && longAnalysis_[0].frameCount() == longAnalysis_[1].frameCount()) {
	tbnz	x0, 0, .L1209	// pretmp_414,,
	b	.L1279		//
.L1241:
	str	w1, [sp, 64]	// retval.290_251, %sfp
	b	.L1193		//
.L1284:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 72
	.cfi_restore 73
	.cfi_restore 74
	.cfi_restore 75
	str	x21, [sp, 2192]	//,
	.cfi_offset 21, -96
	str	x22, [sp, 2200]	//,
	.cfi_offset 22, -88
	str	x23, [sp, 2208]	//,
	.cfi_offset 23, -80
	str	x24, [sp, 2216]	//,
	.cfi_offset 24, -72
	str	x25, [sp, 2224]	//,
	.cfi_offset 25, -64
	str	x26, [sp, 2232]	//,
	.cfi_offset 26, -56
	str	d8, [sp, 2256]	//,
	.cfi_offset 72, -32
	str	d9, [sp, 2264]	//,
	.cfi_offset 73, -24
	str	d10, [sp, 2272]	//,
	.cfi_offset 74, -16
	str	d11, [sp, 2280]	//,
	.cfi_offset 75, -8
// /probe/scatter-baseline-pitch.cpp:604: }
	bl	__stack_chk_fail		//
.L1287:
// /probe/scatter-baseline-pitch.cpp:541:   if (lowAttackPending_ && rightLowReady) {
	ldr	w1, [sp, 64]	//, %sfp
	ldrb	w0, [x19, 2270]	//, this_142(D)->lowAttackPending_
	and	w0, w1, w0	// rightLowReady, rightLowReady, this_142(D)->lowAttackPending_
	str	w0, [sp, 64]	// rightLowReady, %sfp
	b	.L1200		//
	.cfi_endproc
.LFE9624:
	.size	_ZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoE, .-_ZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoE
	.align	2
	.p2align 4,,15
	.global	_ZNK5ardor4pog319PolyphonicPitchBank14capacityEventsEv
	.type	_ZNK5ardor4pog319PolyphonicPitchBank14capacityEventsEv, %function
_ZNK5ardor4pog319PolyphonicPitchBank14capacityEventsEv:
.LFB9625:
	.cfi_startproc
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:70:   std::size_t capacityEvents() const noexcept { return capacityEvents_; }
	mov	x1, 25472	//,
	mov	x3, 37920	//,
	add	x4, x0, x3	// tmp122, this,
	add	x2, x0, x1	// tmp118, this,
// /probe/scatter-baseline-pitch.cpp:610:   for (const auto& frame : lowFrames_) result += frame.capacityEvents();
	ldr	x1, [x0, 12976]	// MEM[(const struct PitchFrame *)this_10(D) + 576B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 576B].capacityEvents_
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:70:   std::size_t capacityEvents() const noexcept { return capacityEvents_; }
	mov	x5, 50368	//,
	mov	x7, 62816	//,
// /probe/scatter-baseline-pitch.cpp:610:   for (const auto& frame : lowFrames_) result += frame.capacityEvents();
	ldr	x2, [x2, 12400]	// MEM[(const struct PitchFrame *)this_10(D) + 25472B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 25472B].capacityEvents_
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:70:   std::size_t capacityEvents() const noexcept { return capacityEvents_; }
	add	x6, x0, x5	// tmp130, this,
	add	x3, x0, x7	// tmp134, this,
// /probe/scatter-baseline-pitch.cpp:610:   for (const auto& frame : lowFrames_) result += frame.capacityEvents();
	ldr	x5, [x4, 12400]	// MEM[(const struct PitchFrame *)this_10(D) + 37920B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 37920B].capacityEvents_
	ldr	x4, [x0, 25424]	// MEM[(const struct PitchFrame *)this_10(D) + 13024B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 13024B].capacityEvents_
	ldr	x3, [x3, 12400]	// MEM[(const struct PitchFrame *)this_10(D) + 62816B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 62816B].capacityEvents_
	add	x2, x2, x5	// tmp123, MEM[(const struct PitchFrame *)this_10(D) + 25472B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 37920B].capacityEvents_
	ldr	x0, [x6, 12400]	// MEM[(const struct PitchFrame *)this_10(D) + 50368B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 50368B].capacityEvents_
	add	x1, x1, x4	// tmp112, MEM[(const struct PitchFrame *)this_10(D) + 576B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 13024B].capacityEvents_
	add	x1, x1, x2	// tmp126, tmp112, tmp123
	add	x0, x0, x3	// tmp135, MEM[(const struct PitchFrame *)this_10(D) + 50368B].capacityEvents_, MEM[(const struct PitchFrame *)this_10(D) + 62816B].capacityEvents_
// /probe/scatter-baseline-pitch.cpp:612: }
	add	x0, x1, x0	//, tmp126, tmp135
	ret	
	.cfi_endproc
.LFE9625:
	.size	_ZNK5ardor4pog319PolyphonicPitchBank14capacityEventsEv, .-_ZNK5ardor4pog319PolyphonicPitchBank14capacityEventsEv
	.global	__aarch64_ldadd4_acq_rel
	.section	.text._ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv,"axG",@progbits,_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv
	.type	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv, %function
_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv:
.LFB9932:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:175: 	_M_dispose();
	ldr	x1, [x0]	// this_2(D)->_vptr._Sp_counted_base, this_2(D)->_vptr._Sp_counted_base
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_4 + 16B], MEM[(int (*) () *)_4 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:198:       _M_release_last_use_cold() noexcept
	str	x19, [sp, 16]	//,
	.cfi_offset 19, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:198:       _M_release_last_use_cold() noexcept
	mov	x19, x0	// this, tmp110
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:175: 	_M_dispose();
	blr	x1		// MEM[(int (*) () *)_4 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp104,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp104,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1299	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x19, 12]	//, MEM[(_Atomic_word *)this_2(D) + 12B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp106, __result,
	str	w1, [x19, 12]	// tmp106, MEM[(_Atomic_word *)this_2(D) + 12B]
.L1300:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:187: 	if (__gnu_cxx::__exchange_and_add_dispatch(&_M_weak_count,
	cmp	w0, 1	// __result,
	beq	.L1303		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:199:       { _M_release_last_use(); }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1303:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:191: 	    _M_destroy();
	ldr	x1, [x19]	// this_2(D)->_vptr._Sp_counted_base, this_2(D)->_vptr._Sp_counted_base
	mov	x0, x19	//, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:199:       { _M_release_last_use(); }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:191: 	    _M_destroy();
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_13 + 24B], MEM[(int (*) () *)_13 + 24B]
	mov	x16, x1	// MEM[(int (*) () *)_13 + 24B], MEM[(int (*) () *)_13 + 24B]
	br	x16		// MEM[(int (*) () *)_13 + 24B]
	.p2align 2,,3
.L1299:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x19, 12	//, this,
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1300		//
	.cfi_endproc
.LFE9932:
	.size	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv, .-_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv
	.section	.text._ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv,"axG",@progbits,_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv
	.type	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv, %function
_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv:
.LFB3962:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x0, 8	// __both_counts, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:318:     {
	str	x19, [sp, 16]	//,
	.cfi_offset 19, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:318:     {
	mov	x19, x0	// this, tmp111
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x3, [x1]	// _1,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x2, 4294967297	// tmp103,
	cmp	x3, x2	// _1, tmp103
	beq	.L1310		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp108,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp108,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1306	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x19, 8]	//, MEM[(_Atomic_word *)this_2(D) + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp110, __result,
	str	w1, [x19, 8]	// tmp110, MEM[(_Atomic_word *)this_2(D) + 8B]
.L1307:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1311		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:363:     }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1306:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1307		//
	.p2align 2,,3
.L1310:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x0]	// this_2(D)->_vptr._Sp_counted_base, this_2(D)->_vptr._Sp_counted_base
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_18 + 16B], MEM[(int (*) () *)_18 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x0, 8]	//, MEM <unsigned long> [(int *)this_2(D) + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_18 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x19]	// this_2(D)->_vptr._Sp_counted_base, this_2(D)->_vptr._Sp_counted_base
	mov	x0, x19	//, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:363:     }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_20 + 24B], MEM[(int (*) () *)_20 + 24B]
	mov	x16, x1	// MEM[(int (*) () *)_20 + 24B], MEM[(int (*) () *)_20 + 24B]
	br	x16		// MEM[(int (*) () *)_20 + 24B]
	.p2align 2,,3
.L1311:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x19	//, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:363:     }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	b	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	.cfi_endproc
.LFE3962:
	.size	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv, .-_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv:
.LFB13585:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp	//,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -16
	.cfi_offset 20, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:611:       _M_dispose() noexcept
	mov	x19, x0	// this, tmp135
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x20, [x0, 40]	// _5, MEM[(struct __shared_count *)this_1(D) + 40B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1314	// _5,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, _5,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _8,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp117,
	cmp	x2, x0	// _8, tmp117
	beq	.L1326		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp122,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp122,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1316	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)_5 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp124, __result,
	str	w1, [x20, 8]	// tmp124, MEM[(_Atomic_word *)_5 + 8B]
.L1317:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1327		//,
.L1314:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x19, [x19, 24]	// _6, MEM[(struct __shared_count *)this_1(D) + 24B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x19, .L1312	// _6,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x19, 8	// __both_counts, _6,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _20,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp127,
	cmp	x2, x0	// _20, tmp127
	beq	.L1328		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp132,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp132,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1322	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x19, 8]	//, MEM[(_Atomic_word *)_6 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp134, __result,
	str	w1, [x19, 8]	// tmp134, MEM[(_Atomic_word *)_6 + 8B]
.L1323:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1329		//,
.L1312:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1328:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x19]	// _6->_vptr._Sp_counted_base, _6->_vptr._Sp_counted_base
	mov	x0, x19	//, _6
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_27 + 16B], MEM[(int (*) () *)_27 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x19, 8]	//, MEM <unsigned long> [(int *)_6 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_27 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x19]	// _6->_vptr._Sp_counted_base, _6->_vptr._Sp_counted_base
	mov	x0, x19	//, _6
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_29 + 24B], MEM[(int (*) () *)_29 + 24B]
	mov	x16, x1	// MEM[(int (*) () *)_29 + 24B], MEM[(int (*) () *)_29 + 24B]
	br	x16		// MEM[(int (*) () *)_29 + 24B]
	.p2align 2,,3
.L1326:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// _5->_vptr._Sp_counted_base, _5->_vptr._Sp_counted_base
	mov	x0, x20	//, _5
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_15 + 16B], MEM[(int (*) () *)_15 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)_5 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_15 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// _5->_vptr._Sp_counted_base, _5->_vptr._Sp_counted_base
	mov	x0, x20	//, _5
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_17 + 24B], MEM[(int (*) () *)_17 + 24B]
	blr	x1		// MEM[(int (*) () *)_17 + 24B]
	b	.L1314		//
	.p2align 2,,3
.L1322:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1323		//
	.p2align 2,,3
.L1316:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1317		//
	.p2align 2,,3
.L1327:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, _5
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1314		//
	.p2align 2,,3
.L1329:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x19	//, _6
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	b	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	.cfi_endproc
.LFE13585:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.section	.text._ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv,"axG",@progbits,_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv,comdat
	.align	2
	.p2align 4,,15
	.weak	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.type	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv, %function
_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv:
.LFB13592:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!	//,,,
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp	//,
	str	x19, [sp, 16]	//,
	.cfi_offset 19, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:611:       _M_dispose() noexcept
	mov	x19, x0	// this, tmp154
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:369: 	_M_deallocate(_M_impl._M_start,
	ldr	x0, [x0, 120]	// _5, MEM[(struct _Vector_base *)this_1(D) + 120B]._M_impl.D.213625._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x0, .L1331	// _5,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:370: 		      _M_impl._M_end_of_storage - _M_impl._M_start);
	ldr	x1, [x19, 136]	// MEM[(struct _Vector_base *)this_1(D) + 120B]._M_impl.D.213625._M_end_of_storage, MEM[(struct _Vector_base *)this_1(D) + 120B]._M_impl.D.213625._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	sub	x1, x1, x0	//, MEM[(struct _Vector_base *)this_1(D) + 120B]._M_impl.D.213625._M_end_of_storage, _5
	bl	_ZdlPvm		//
.L1331:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:369: 	_M_deallocate(_M_impl._M_start,
	ldr	x0, [x19, 96]	// _11, MEM[(struct _Vector_base *)this_1(D) + 96B]._M_impl.D.213625._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x0, .L1332	// _11,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:370: 		      _M_impl._M_end_of_storage - _M_impl._M_start);
	ldr	x1, [x19, 112]	// MEM[(struct _Vector_base *)this_1(D) + 96B]._M_impl.D.213625._M_end_of_storage, MEM[(struct _Vector_base *)this_1(D) + 96B]._M_impl.D.213625._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	sub	x1, x1, x0	//, MEM[(struct _Vector_base *)this_1(D) + 96B]._M_impl.D.213625._M_end_of_storage, _11
	bl	_ZdlPvm		//
.L1332:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:369: 	_M_deallocate(_M_impl._M_start,
	ldr	x0, [x19, 64]	// _21, MEM[(struct _Vector_base *)this_1(D) + 64B]._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x0, .L1333	// _21,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:370: 		      _M_impl._M_end_of_storage - _M_impl._M_start);
	ldr	x1, [x19, 80]	// MEM[(struct _Vector_base *)this_1(D) + 64B]._M_impl.D.211503._M_end_of_storage, MEM[(struct _Vector_base *)this_1(D) + 64B]._M_impl.D.211503._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	sub	x1, x1, x0	//, MEM[(struct _Vector_base *)this_1(D) + 64B]._M_impl.D.211503._M_end_of_storage, _21
	bl	_ZdlPvm		//
.L1333:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:369: 	_M_deallocate(_M_impl._M_start,
	ldr	x0, [x19, 40]	// _31, MEM[(struct _Vector_base *)this_1(D) + 40B]._M_impl.D.180160._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x0, .L1334	// _31,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:370: 		      _M_impl._M_end_of_storage - _M_impl._M_start);
	ldr	x1, [x19, 56]	// MEM[(struct _Vector_base *)this_1(D) + 40B]._M_impl.D.180160._M_end_of_storage, MEM[(struct _Vector_base *)this_1(D) + 40B]._M_impl.D.180160._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	sub	x1, x1, x0	//, MEM[(struct _Vector_base *)this_1(D) + 40B]._M_impl.D.180160._M_end_of_storage, _31
	bl	_ZdlPvm		//
.L1334:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x19, [x19, 24]	// _18, MEM[(struct __shared_count *)this_1(D) + 24B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x19, .L1330	// _18,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x19, 8	// __both_counts, _18,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _36,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp146,
	cmp	x2, x0	// _36, tmp146
	beq	.L1354		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp151,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp151,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1338	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x19, 8]	//, MEM[(_Atomic_word *)_18 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp153, __result,
	str	w1, [x19, 8]	// tmp153, MEM[(_Atomic_word *)_18 + 8B]
.L1339:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1355		//,
.L1330:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1354:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x19]	// _18->_vptr._Sp_counted_base, _18->_vptr._Sp_counted_base
	mov	x0, x19	//, _18
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_43 + 16B], MEM[(int (*) () *)_43 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x19, 8]	//, MEM <unsigned long> [(int *)_18 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_43 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x19]	// _18->_vptr._Sp_counted_base, _18->_vptr._Sp_counted_base
	mov	x0, x19	//, _18
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_45 + 24B], MEM[(int (*) () *)_45 + 24B]
	mov	x16, x1	// MEM[(int (*) () *)_45 + 24B], MEM[(int (*) () *)_45 + 24B]
	br	x16		// MEM[(int (*) () *)_45 + 24B]
	.p2align 2,,3
.L1338:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1339		//
	.p2align 2,,3
.L1355:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x19	//, _18
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:614:       }
	ldr	x19, [sp, 16]	//,
	ldp	x29, x30, [sp], 32	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	b	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	.cfi_endproc
.LFE13592:
	.size	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv, .-_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC11:
	.string	"pitch renderer requires a plan"
	.align	3
.LC12:
	.string	"vector::_M_default_append"
	.text
	.align	2
	.p2align 4,,15
	.type	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb.constprop.0, %function
_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb.constprop.0:
.LFB13716:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA13716
	adrp	x2, :got:__stack_chk_guard	// tmp194,
	ldr	x2, [x2, :got_lo12:__stack_chk_guard]	// tmp194,
	sub	sp, sp, #128	//,,
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, 32]	//,,
	.cfi_offset 29, -96
	.cfi_offset 30, -88
	add	x29, sp, 32	//,,
	stp	x19, x20, [sp, 48]	//,,
	.cfi_offset 19, -80
	.cfi_offset 20, -72
	mov	x19, x0	// this, tmp312
	ldr	x0, [x2]	// tmp322,
	str	x0, [sp, 24]	// tmp322, D.330601
	mov	x0, 0	// tmp322
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x3, [x1]	// _2, MEM[(const struct __shared_ptr *)plan_1(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	cbz	x3, .L1434	// _2,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x0, [x1, 8]	// __tmp, MEM[(struct __shared_count &)plan_1(D) + 8]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	xzr, xzr, [x1]	//,, MEM[(struct __shared_ptr &)plan_1(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x20, [x19, 8]	// __tmp, MEM[(struct __shared_count &)this_5(D) + 8]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	x3, x0, [x19]	// _2, __tmp, MEM[(const struct PitchPlan * &)this_5(D)]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1359	// __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _52,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp209,
	cmp	x2, x0	// _52, tmp209
	beq	.L1435		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp214,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp214,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1361	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)__tmp_6 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp216, __result,
	str	w1, [x20, 8]	// tmp216, MEM[(_Atomic_word *)__tmp_6 + 8B]
.L1362:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1363		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _2, MEM[(const struct __shared_ptr *)this_5(D)]._M_ptr
.L1359:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldp	x0, x1, [x3]	// MEM[(const struct __shared_ptr &)prephitmp_141]._M_ptr, _63, MEM[(const struct __shared_ptr &)prephitmp_141]._M_ptr
// /probe/scatter-baseline-pitch.cpp:196:   synthesis_.prepare(plan_->spectral, true, plan_->spectral->hopSize());
	add	x20, x19, 16	// _7, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x1, [sp, 8]	// MEM[(const struct __shared_ptr &)prephitmp_141]._M_ptr, _63, MEM[(struct __shared_ptr *)&D.330464]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1077: 	if (_M_pi != nullptr)
	cbz	x1, .L1365	// _63,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp220,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp220,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1366	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_63 + 8B]
	add	w0, w0, 1	// tmp222, MEM[(_Atomic_word *)_63 + 8B],
	str	w0, [x1, 8]	// tmp222, MEM[(_Atomic_word *)_63 + 8B]
.L1365:
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:24:   std::size_t hopSize() const noexcept { return hopSize_; }
	ldr	x3, [x3]	// MEM[(const struct __shared_ptr *)prephitmp_106]._M_ptr, MEM[(const struct __shared_ptr *)prephitmp_106]._M_ptr
// /probe/scatter-baseline-pitch.cpp:196:   synthesis_.prepare(plan_->spectral, true, plan_->spectral->hopSize());
	mov	x0, x20	//, _7
	mov	w2, 1	//,
	add	x1, sp, 8	//,,
	ldr	x3, [x3, 72]	//, MEM[(const struct SpectralPlan *)_12].hopSize_
.LEHB0:
	bl	_ZN5ardor4pog317SpectralSynthesis7prepareESt10shared_ptrIKNS0_12SpectralPlanEEbm		//
.LEHE0:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x20, [sp, 16]	// _14, MEM[(struct __shared_count *)&D.330464 + 8B]._M_pi
	stp	x21, x22, [sp, 64]	//,,
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1369	// _14,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, _14,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _69,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp228,
	cmp	x2, x0	// _69, tmp228
	beq	.L1436		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp233,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp233,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1371	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)_14 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp235, __result,
	str	w1, [x20, 8]	// tmp235, MEM[(_Atomic_word *)_14 + 8B]
.L1372:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1437		//,
.L1369:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	mov	x21, x19	// tmp309, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x25, [x19, 96]	// _81, MEM[(const struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x0, [x21], 96	// MEM[(const struct __shared_ptr *)this_5(D)]._M_ptr, MEM[(const struct __shared_ptr *)this_5(D)]._M_ptr
	ldr	x0, [x0]	// _17, MEM[(const struct __shared_ptr *)_16]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x22, [x21, 8]	// _80, MEM[(const struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x1, x20, [x0, 80]	// MEM[(const struct vector *)_17 + 80B].D.214282._M_impl.D.213625._M_start, MEM[(const struct vector *)_17 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_17 + 80B].D.214282._M_impl.D.213625._M_start
	sub	x24, x22, x25	// tmp308, _80, _81
	asr	x0, x24, 3	// tmp249, tmp308,
	sub	x20, x20, x1	// tmp241, MEM[(const struct vector *)_17 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_17 + 80B].D.214282._M_impl.D.213625._M_start
	asr	x20, x20, 2	// _22, tmp241,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x20, x0	// _22, tmp249
	bhi	.L1438		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1017: 	else if (__new_size < size())
	bcc	.L1439		//,
.L1379:
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	adrp	x0, :got:__stack_chk_guard	// tmp302,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp302,
	ldr	x2, [sp, 24]	// tmp327, D.330601
	ldr	x1, [x0]	// tmp328,
	subs	x2, x2, x1	// tmp327, tmp328
	mov	x1, 0	// tmp328
	bne	.L1440		//,
// /probe/scatter-baseline-pitch.cpp:200: }
	ldp	x29, x30, [sp, 32]	//,,
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	mov	x0, x19	//, this
// /probe/scatter-baseline-pitch.cpp:200: }
	ldp	x19, x20, [sp, 48]	//,,
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	ldp	x21, x22, [sp, 64]	//,,
	.cfi_remember_state
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 80]	//,,
	.cfi_restore 24
	.cfi_restore 23
	ldp	x25, x26, [sp, 96]	//,,
	.cfi_restore 26
	.cfi_restore 25
// /probe/scatter-baseline-pitch.cpp:200: }
	add	sp, sp, 128	//,,
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	b	_ZN5ardor4pog313PitchRenderer5resetEv		//
	.p2align 2,,3
.L1439:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x20, x25, x20, lsl 3	// _87, _81, _22,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1935: 	if (size_type __n = this->_M_impl._M_finish - __pos)
	cmp	x22, x20	// _80, _87
	beq	.L1379		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1939: 	    this->_M_impl._M_finish = __pos;
	str	x20, [x21, 8]	// _87, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_finish
	b	.L1379		//
	.p2align 2,,3
.L1366:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x1, 8	//, _63,
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _2, MEM[(const struct __shared_ptr *)this_5(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1365		//
	.p2align 2,,3
.L1438:
	.cfi_offset 21, -64
	.cfi_offset 22, -56
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	ldr	x1, [x21, 16]	// MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	sub	x26, x20, x0	// __n, _22, tmp249
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	sub	x1, x1, x22	// tmp252, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, _80
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:646: 	  if (__navail >= __n)
	cmp	x26, x1, asr 3	// __n, tmp252,
	bhi	.L1375		//,
	sub	x0, x26, #1	// tmp256, __n,
	cmp	x0, 2	// tmp256,
	bls	.L1399		//,
	lsr	x1, x26, 1	// bnd.2639, __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	movi	v0.4s, 0	// tmp259
	mov	x0, x22	// ivtmp.2660, _80
	add	x1, x22, x1, lsl 4	// _265, _80, bnd.2639,
	.p2align 3,,7
.L1377:
	str	q0, [x0], 16	// tmp259, MEM <vector(4) float> [(float *)_268]
	cmp	x1, x0	// _265, ivtmp.2660
	bne	.L1377		//,
	tbz	x26, 0, .L1378	// __n,,
	and	x1, x26, -2	// niters_vector_mult_vf.2640, __n,
	add	x0, x22, x1, lsl 3	// tmp.2641, _80, niters_vector_mult_vf.2640,
	sub	x1, x26, x1	// __n, __n, niters_vector_mult_vf.2640
.L1376:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x1, 1	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0]	//,, REALPART_EXPR <*__cur_187._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1378		//,
	cmp	x1, 2	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0, 8]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_187 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1378		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_187 + 16B]._M_value>
.L1378:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:649: 	      this->_M_impl._M_finish =
	add	x26, x22, x26, lsl 3	// __cur, _80, __n,
	str	x26, [x21, 8]	// __cur, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_finish
	b	.L1379		//
	.p2align 2,,3
.L1436:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// _14->_vptr._Sp_counted_base, _14->_vptr._Sp_counted_base
	mov	x0, x20	//, _14
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_76 + 16B], MEM[(int (*) () *)_76 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)_14 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_76 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// _14->_vptr._Sp_counted_base, _14->_vptr._Sp_counted_base
	mov	x0, x20	//, _14
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_78 + 24B], MEM[(int (*) () *)_78 + 24B]
	blr	x1		// MEM[(int (*) () *)_78 + 24B]
	b	.L1369		//
	.p2align 2,,3
.L1435:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// __tmp_6->_vptr._Sp_counted_base, __tmp_6->_vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_59 + 16B], MEM[(int (*) () *)_59 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)__tmp_6 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_59 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// __tmp_6->_vptr._Sp_counted_base, __tmp_6->_vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_61 + 24B], MEM[(int (*) () *)_61 + 24B]
	blr	x1		// MEM[(int (*) () *)_61 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _2, MEM[(const struct __shared_ptr *)this_5(D)]._M_ptr
	b	.L1359		//
	.p2align 2,,3
.L1371:
	.cfi_offset 21, -64
	.cfi_offset 22, -56
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1372		//
	.p2align 2,,3
.L1361:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1362		//
	.p2align 2,,3
.L1375:
	.cfi_offset 21, -64
	.cfi_offset 22, -56
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:643: 	  if (__size > max_size() || __navail > max_size() - __size)
	mov	x1, 1152921504606846975	// tmp267,
	str	x27, [sp, 112]	//,
	.cfi_offset 27, -16
	sub	x2, x1, x0	// tmp266, tmp267, tmp249
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1898: 	if (max_size() - size() < __n)
	cmp	x2, x26	// tmp266, __n
	bcc	.L1441		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	cmp	x0, x26	// tmp249, __n
	bcc	.L1442		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1901: 	const size_type __len = size() + (std::max)(size(), __n);
	lsl	x0, x0, 1	// __len, tmp249,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x0, x1	// __len, tmp267
	csel	x0, x0, x1, ls	// __len, __len, tmp267,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x23, x0, 3	// _99, __len,
	mov	x0, x23	//, _99
.LEHB1:
	bl	_Znwm		//
	mov	x27, x0	// _89, tmp318
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x2, x0, x24	// __cur, _89, tmp308
.L1383:
	sub	x0, x26, #1	// tmp279, __n,
	cmp	x0, 2	// tmp279,
	bls	.L1384		//,
	lsr	x0, x26, 1	// bnd.2646, __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	movi	v0.4s, 0	// tmp282
	mov	x1, x2	// ivtmp.2670, __cur
	add	x0, x2, x0, lsl 4	// _254, __cur, bnd.2646,
	.p2align 3,,7
.L1385:
	str	q0, [x1], 16	// tmp282, MEM <vector(4) float> [(float *)_257]
	cmp	x0, x1	// _254, ivtmp.2670
	bne	.L1385		//,
	tbz	x26, 0, .L1386	// __n,,
	and	x0, x26, -2	// niters_vector_mult_vf.2647, __n,
	add	x2, x2, x0, lsl 3	// __cur, __cur, niters_vector_mult_vf.2647,
	sub	x26, x26, x0	// __n, __n, niters_vector_mult_vf.2647
.L1384:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x26, 1	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x2]	//,, REALPART_EXPR <*__cur_46._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1386		//,
	cmp	x26, 2	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x2, 8]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_46 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1386		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_46 + 16B]._M_value>
.L1386:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x22, x25	// _80, _81
	add	x24, x27, x24	// _261, _89, tmp308
	mov	x2, x25	// __first, _81
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1103:       _ForwardIterator __cur = __result;
	mov	x1, x27	// __cur, _89
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	beq	.L1391		//,
	.p2align 3,,7
.L1390:
	ldp	s1, s0, [x2]	// SR.2636, SR.2636, MEM[(const struct complex &)__first_128]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x2, x2, 8	// __first, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	stp	s1, s0, [x1]	// SR.2636, SR.2636, MEM[(struct complex *)__cur_121]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x1, x1, 8	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x1, x24	// __cur, _261
	bne	.L1390		//,
.L1391:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x25, .L1389	// _81,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x21, 16]	// MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x25	//, _81
	sub	x1, x1, x25	//, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, _81
	bl	_ZdlPvm		//
.L1389:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x20, x27, x20, lsl 3	// tmp295, _89, _22,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	add	x0, x27, x23	// tmp298, _89, _99
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:705: 	      this->_M_impl._M_start = __new_start;
	str	x27, [x19, 96]	// _89, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_start
	ldr	x27, [sp, 112]	//,
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	stp	x20, x0, [x21, 8]	// tmp295, tmp298, MEM[(struct vector *)this_5(D) + 96B].D.212165._M_impl.D.211503._M_finish
	b	.L1379		//
	.p2align 2,,3
.L1437:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, _14
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1369		//
	.p2align 2,,3
.L1363:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, __tmp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _2, MEM[(const struct __shared_ptr *)this_5(D)]._M_ptr
	b	.L1359		//
	.p2align 2,,3
.L1442:
	.cfi_offset 21, -64
	.cfi_offset 22, -56
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
	.cfi_offset 27, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x20, x1	// _22, tmp267
	csel	x1, x20, x1, ls	// tmp271, _22, tmp267,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x23, x1, 3	// _99, tmp271,
	mov	x0, x23	//, _99
	bl	_Znwm		//
	mov	x27, x0	// _89, tmp317
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x2, x0, x24	// __cur, _89, tmp308
	b	.L1383		//
	.p2align 2,,3
.L1399:
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	mov	x1, x26	// __n, __n
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:639: 	  _ForwardIterator __cur = __first;
	mov	x0, x22	// tmp.2641, _80
	b	.L1376		//
.L1440:
	str	x27, [sp, 112]	//,
	.cfi_offset 27, -16
.L1433:
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	bl	__stack_chk_fail		//
.L1441:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1899: 	  __throw_length_error(__N(__s));
	adrp	x0, :got:__stack_chk_guard	// tmp268,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp268,
	ldr	x2, [sp, 24]	// tmp325, D.330601
	ldr	x1, [x0]	// tmp326,
	subs	x2, x2, x1	// tmp325, tmp326
	mov	x1, 0	// tmp326
	bne	.L1433		//,
	adrp	x0, .LC12	// tmp270,
	add	x0, x0, :lo12:.LC12	//, tmp270,
	bl	_ZSt20__throw_length_errorPKc		//
.L1400:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 16]	// _24, MEM[(struct __shared_count *)&D.330464 + 8B]._M_pi
	mov	x19, x0	// tmp305, tmp320
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x1, .L1396	// _24,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x1	//, _24
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1396:
	adrp	x0, :got:__stack_chk_guard	// tmp306,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp306,
	ldr	x2, [sp, 24]	// tmp331, D.330601
	ldr	x1, [x0]	// tmp332,
	subs	x2, x2, x1	// tmp331, tmp332
	mov	x1, 0	// tmp332
	stp	x21, x22, [sp, 64]	//,,
	.cfi_remember_state
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	str	x27, [sp, 112]	//,
	.cfi_offset 27, -16
	bne	.L1433		//,
	mov	x0, x19	//, tmp305
	bl	_Unwind_Resume		//
.LEHE1:
.L1434:
	.cfi_restore_state
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	mov	x0, 16	//,
	bl	__cxa_allocate_exception		//
	adrp	x1, .LC11	// tmp197,
	add	x1, x1, :lo12:.LC11	//, tmp197,
	mov	x19, x0	// _3, tmp314
.LEHB2:
	bl	_ZNSt16invalid_argumentC1EPKc		//
.LEHE2:
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	adrp	x0, :got:__stack_chk_guard	// tmp198,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp198,
	ldr	x2, [sp, 24]	// tmp323, D.330601
	ldr	x1, [x0]	// tmp324,
	subs	x2, x2, x1	// tmp323, tmp324
	mov	x1, 0	// tmp324
	stp	x21, x22, [sp, 64]	//,,
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	str	x27, [sp, 112]	//,
	.cfi_offset 27, -16
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	bne	.L1433		//,
	adrp	x2, :got:_ZNSt16invalid_argumentD1Ev	//,
	ldr	x2, [x2, :got_lo12:_ZNSt16invalid_argumentD1Ev]	//,
	mov	x0, x19	//, _3
	adrp	x1, :got:_ZTISt16invalid_argument	//,
	ldr	x1, [x1, :got_lo12:_ZTISt16invalid_argument]	//,
.LEHB3:
	bl	__cxa_throw		//
.LEHE3:
.L1401:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	mov	x1, x0	// tmp319,
	mov	x0, x19	//, _3
	mov	x19, x1	// tmp303, tmp319
	bl	__cxa_free_exception		//
	b	.L1396		//
	.cfi_endproc
.LFE13716:
	.global	__gxx_personality_v0
	.section	.gcc_except_table,"a",@progbits
.LLSDA13716:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE13716-.LLSDACSB13716
.LLSDACSB13716:
	.uleb128 .LEHB0-.LFB13716
	.uleb128 .LEHE0-.LEHB0
	.uleb128 .L1400-.LFB13716
	.uleb128 0
	.uleb128 .LEHB1-.LFB13716
	.uleb128 .LEHE1-.LEHB1
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB2-.LFB13716
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L1401-.LFB13716
	.uleb128 0
	.uleb128 .LEHB3-.LFB13716
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE13716:
	.text
	.size	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb.constprop.0, .-_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb.constprop.0
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb
	.type	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb, %function
_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb:
.LFB9578:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9578
	adrp	x4, :got:__stack_chk_guard	// tmp217,
	ldr	x4, [x4, :got_lo12:__stack_chk_guard]	// tmp217,
	sub	sp, sp, #128	//,,
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, 32]	//,,
	.cfi_offset 29, -96
	.cfi_offset 30, -88
	add	x29, sp, 32	//,,
	stp	x19, x20, [sp, 48]	//,,
	.cfi_offset 19, -80
	.cfi_offset 20, -72
	mov	x19, x0	// this, tmp392
	ldr	x0, [x4]	// tmp405,
	str	x0, [sp, 24]	// tmp405, D.330804
	mov	x0, 0	// tmp405
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x3, [x1]	// _15, MEM[(const struct __shared_ptr *)plan_5(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	cbz	x3, .L1540	// _15,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x0, [x1, 8]	// __tmp, MEM[(struct __shared_count &)plan_5(D) + 8]._M_pi
	stp	x21, x22, [sp, 64]	//,,
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	and	w21, w2, 255	// allowHeld, allowHeld
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	xzr, xzr, [x1]	//,, MEM[(struct __shared_ptr &)plan_5(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x20, [x19, 8]	// __tmp, MEM[(struct __shared_count &)this_8(D) + 8]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	x3, x0, [x19]	// _15, __tmp, MEM[(const struct PitchPlan * &)this_8(D)]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1446	// __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _53,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp232,
	cmp	x2, x0	// _53, tmp232
	beq	.L1541		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp237,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp237,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1448	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)__tmp_27 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp239, __result,
	str	w1, [x20, 8]	// tmp239, MEM[(_Atomic_word *)__tmp_27 + 8B]
.L1449:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1450		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _15, MEM[(const struct __shared_ptr *)this_8(D)]._M_ptr
.L1446:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldp	x0, x1, [x3]	// MEM[(const struct __shared_ptr &)prephitmp_142]._M_ptr, _64, MEM[(const struct __shared_ptr &)prephitmp_142]._M_ptr
// /probe/scatter-baseline-pitch.cpp:196:   synthesis_.prepare(plan_->spectral, true, plan_->spectral->hopSize());
	add	x20, x19, 16	// _1, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x1, [sp, 8]	// MEM[(const struct __shared_ptr &)prephitmp_142]._M_ptr, _64, MEM[(struct __shared_ptr *)&D.234067]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1077: 	if (_M_pi != nullptr)
	cbz	x1, .L1452	// _64,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp243,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp243,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1453	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_64 + 8B]
	add	w0, w0, 1	// tmp245, MEM[(_Atomic_word *)_64 + 8B],
	str	w0, [x1, 8]	// tmp245, MEM[(_Atomic_word *)_64 + 8B]
.L1452:
// /ardor/src/daisyfx/pog3/SpectralFrameStream.h:24:   std::size_t hopSize() const noexcept { return hopSize_; }
	ldr	x3, [x3]	// MEM[(const struct __shared_ptr *)prephitmp_107]._M_ptr, MEM[(const struct __shared_ptr *)prephitmp_107]._M_ptr
// /probe/scatter-baseline-pitch.cpp:196:   synthesis_.prepare(plan_->spectral, true, plan_->spectral->hopSize());
	mov	x0, x20	//, _1
	mov	w2, 1	//,
	add	x1, sp, 8	//,,
	ldr	x3, [x3, 72]	//, MEM[(const struct SpectralPlan *)_11].hopSize_
.LEHB4:
	bl	_ZN5ardor4pog317SpectralSynthesis7prepareESt10shared_ptrIKNS0_12SpectralPlanEEbm		//
.LEHE4:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x20, [sp, 16]	// _35, MEM[(struct __shared_count *)&D.234067 + 8B]._M_pi
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1456	// _35,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, _35,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _70,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp251,
	cmp	x2, x0	// _70, tmp251
	beq	.L1542		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp256,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp256,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1458	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)_35 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp258, __result,
	str	w1, [x20, 8]	// tmp258, MEM[(_Atomic_word *)_35 + 8B]
.L1459:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1543		//,
.L1456:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	mov	x22, x19	// tmp386, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x25, [x19, 96]	// _82, MEM[(const struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x0, [x22], 96	// MEM[(const struct __shared_ptr *)this_8(D)]._M_ptr, MEM[(const struct __shared_ptr *)this_8(D)]._M_ptr
	ldr	x0, [x0]	// _33, MEM[(const struct __shared_ptr *)_34]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x23, [x22, 8]	// _81, MEM[(const struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x1, x20, [x0, 80]	// MEM[(const struct vector *)_33 + 80B].D.214282._M_impl.D.213625._M_start, MEM[(const struct vector *)_33 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_33 + 80B].D.214282._M_impl.D.213625._M_start
	sub	x26, x23, x25	// _83, _81, _82
	asr	x0, x26, 3	// tmp272, _83,
	sub	x20, x20, x1	// tmp264, MEM[(const struct vector *)_33 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_33 + 80B].D.214282._M_impl.D.213625._M_start
	asr	x20, x20, 2	// _32, tmp264,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x20, x0	// _32, tmp272
	bhi	.L1544		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1017: 	else if (__new_size < size())
	bcc	.L1545		//,
.L1466:
// /probe/scatter-baseline-pitch.cpp:198:   if (allowHeld) heldPhases_.resize(2 * kMaxPitchPartials);
	tbnz	x21, 0, .L1546	// allowHeld,,
.L1478:
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	adrp	x0, :got:__stack_chk_guard	// tmp380,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp380,
	ldr	x2, [sp, 24]	// tmp410, D.330804
	ldr	x1, [x0]	// tmp411,
	subs	x2, x2, x1	// tmp410, tmp411
	mov	x1, 0	// tmp411
	bne	.L1547		//,
// /probe/scatter-baseline-pitch.cpp:200: }
	ldp	x29, x30, [sp, 32]	//,,
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	mov	x0, x19	//, this
// /probe/scatter-baseline-pitch.cpp:200: }
	ldp	x19, x20, [sp, 48]	//,,
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	ldp	x21, x22, [sp, 64]	//,,
	.cfi_remember_state
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 80]	//,,
	.cfi_restore 24
	.cfi_restore 23
	ldp	x25, x26, [sp, 96]	//,,
	.cfi_restore 26
	.cfi_restore 25
// /probe/scatter-baseline-pitch.cpp:200: }
	add	sp, sp, 128	//,,
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	b	_ZN5ardor4pog313PitchRenderer5resetEv		//
	.p2align 2,,3
.L1545:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x20, x25, x20, lsl 3	// _88, _82, _32,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1935: 	if (size_type __n = this->_M_impl._M_finish - __pos)
	cmp	x23, x20	// _81, _88
	beq	.L1466		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1939: 	    this->_M_impl._M_finish = __pos;
	str	x20, [x22, 8]	// _88, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_finish
// /probe/scatter-baseline-pitch.cpp:198:   if (allowHeld) heldPhases_.resize(2 * kMaxPitchPartials);
	tbz	x21, 0, .L1478	// allowHeld,,
	.p2align 3,,7
.L1546:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	mov	x0, 19456	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	mov	x1, 16352	// tmp333,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	add	x24, x19, x0	// tmp387, this,
	sub	x0, x24, #392	// tmp328, tmp387,
	ldp	x22, x20, [x0]	// _149, __cur, MEM[(const struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x21, x20, x22	// _150, __cur, _149
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x21, x1	// _150, tmp333
	bls	.L1548		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1017: 	else if (__new_size < size())
	cmp	x21, 16384	// _150,
	bls	.L1478		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x22, x22, 16384	// _155, _149,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1935: 	if (size_type __n = this->_M_impl._M_finish - __pos)
	cmp	x20, x22	// __cur, _155
	beq	.L1478		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1939: 	    this->_M_impl._M_finish = __pos;
	str	x22, [x0, 8]	// _155, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_finish
	b	.L1478		//
	.p2align 2,,3
.L1453:
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x1, 8	//, _64,
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _15, MEM[(const struct __shared_ptr *)this_8(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1452		//
	.p2align 2,,3
.L1544:
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	ldr	x1, [x22, 16]	// MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage
	stp	x27, x28, [sp, 112]	//,,
	.cfi_offset 28, -8
	.cfi_offset 27, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	sub	x27, x20, x0	// __n, _32, tmp272
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	sub	x1, x1, x23	// tmp275, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, _81
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:646: 	  if (__navail >= __n)
	cmp	x27, x1, asr 3	// __n, tmp275,
	bhi	.L1462		//,
	sub	x0, x27, #1	// tmp279, __n,
	cmp	x0, 2	// tmp279,
	bls	.L1496		//,
	lsr	x1, x27, 1	// bnd.2687, __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	movi	v0.4s, 0	// tmp282
	mov	x0, x23	// ivtmp.2731, _81
	add	x1, x23, x1, lsl 4	// _355, _81, bnd.2687,
	.p2align 3,,7
.L1464:
	str	q0, [x0], 16	// tmp282, MEM <vector(4) float> [(float *)_358]
	cmp	x1, x0	// _355, ivtmp.2731
	bne	.L1464		//,
	tbz	x27, 0, .L1465	// __n,,
	and	x1, x27, -2	// niters_vector_mult_vf.2688, __n,
	add	x0, x23, x1, lsl 3	// tmp.2689, _81, niters_vector_mult_vf.2688,
	sub	x1, x27, x1	// __n, __n, niters_vector_mult_vf.2688
.L1463:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x1, 1	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0]	//,, REALPART_EXPR <*__cur_319._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1465		//,
	cmp	x1, 2	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0, 8]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_319 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1465		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_319 + 16B]._M_value>
.L1465:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:649: 	      this->_M_impl._M_finish =
	add	x27, x23, x27, lsl 3	// __cur, _81, __n,
	str	x27, [x22, 8]	// __cur, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_finish
	ldp	x27, x28, [sp, 112]	//,,
	.cfi_restore 28
	.cfi_restore 27
	b	.L1466		//
	.p2align 2,,3
.L1542:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// _35->_vptr._Sp_counted_base, _35->_vptr._Sp_counted_base
	mov	x0, x20	//, _35
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_77 + 16B], MEM[(int (*) () *)_77 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)_35 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_77 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// _35->_vptr._Sp_counted_base, _35->_vptr._Sp_counted_base
	mov	x0, x20	//, _35
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_79 + 24B], MEM[(int (*) () *)_79 + 24B]
	blr	x1		// MEM[(int (*) () *)_79 + 24B]
	b	.L1456		//
	.p2align 2,,3
.L1541:
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// __tmp_27->_vptr._Sp_counted_base, __tmp_27->_vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_60 + 16B], MEM[(int (*) () *)_60 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)__tmp_27 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_60 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// __tmp_27->_vptr._Sp_counted_base, __tmp_27->_vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_62 + 24B], MEM[(int (*) () *)_62 + 24B]
	blr	x1		// MEM[(int (*) () *)_62 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _15, MEM[(const struct __shared_ptr *)this_8(D)]._M_ptr
	b	.L1446		//
	.p2align 2,,3
.L1458:
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1459		//
	.p2align 2,,3
.L1448:
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1449		//
	.p2align 2,,3
.L1548:
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	ldr	x1, [x0, 16]	// MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	asr	x2, x21, 5	// tmp334, _150,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	mov	x0, 512	// tmp335,
	sub	x23, x0, x2	// _153, tmp335, tmp334
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	sub	x0, x1, x20	// tmp340, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage, __cur
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:646: 	  if (__navail >= __n)
	cmp	x23, x0, asr 5	// _153, tmp340,
	bhi	.L1480		//,
	add	x0, x20, x23, lsl 5	// _364, __cur, _153,
	.p2align 3,,7
.L1481:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	add	x20, x20, 32	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	str	xzr, [x20, -32]	//, MEM[(long unsigned int *)__cur_287]
	str	xzr, [x20, -24]	//, MEM[(double *)__cur_287 + 8B]
	str	xzr, [x20, -16]	//, MEM[(long int *)__cur_287 + 16B]
	str	wzr, [x20, -8]	//, MEM[(float *)__cur_287 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x20, x0	// __cur, _364
	bne	.L1481		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:649: 	      this->_M_impl._M_finish =
	sub	x24, x24, #392	// tmp348, tmp387,
	str	x20, [x24, 8]	// __cur, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_finish
	b	.L1478		//
	.p2align 2,,3
.L1462:
	.cfi_offset 27, -16
	.cfi_offset 28, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:643: 	  if (__size > max_size() || __navail > max_size() - __size)
	mov	x1, 1152921504606846975	// tmp290,
	sub	x2, x1, x0	// tmp289, tmp290, tmp272
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1898: 	if (max_size() - size() < __n)
	cmp	x2, x27	// tmp289, __n
	bcc	.L1549		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	cmp	x0, x27	// tmp272, __n
	bcc	.L1550		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1901: 	const size_type __len = size() + (std::max)(size(), __n);
	lsl	x0, x0, 1	// __len, tmp272,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x0, x1	// __len, tmp290
	csel	x0, x0, x1, ls	// __len, __len, tmp290,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x24, x0, 3	// _100, __len,
	mov	x0, x24	//, _100
.LEHB5:
	bl	_Znwm		//
	mov	x28, x0	// _141, tmp398
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x26, x0, x26	// __cur, _141, _83
.L1470:
	sub	x0, x27, #1	// tmp302, __n,
	cmp	x0, 2	// tmp302,
	bls	.L1471		//,
	lsr	x2, x27, 1	// bnd.2694, __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	movi	v0.4s, 0	// tmp305
	mov	x1, x26	// ivtmp.2744, __cur
	add	x2, x26, x2, lsl 4	// _348, __cur, bnd.2694,
	.p2align 3,,7
.L1472:
	str	q0, [x1], 16	// tmp305, MEM <vector(4) float> [(float *)_351]
	cmp	x2, x1	// _348, ivtmp.2744
	bne	.L1472		//,
	tbz	x27, 0, .L1473	// __n,,
	and	x0, x27, -2	// niters_vector_mult_vf.2695, __n,
	add	x26, x26, x0, lsl 3	// __cur, __cur, niters_vector_mult_vf.2695,
	sub	x27, x27, x0	// __n, __n, niters_vector_mult_vf.2695
.L1471:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x27, 1	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x26]	//,, REALPART_EXPR <*__cur_263._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1473		//,
	cmp	x27, 2	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x26, 8]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_263 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1473		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x26, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_263 + 16B]._M_value>
.L1473:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x23, x25	// _81, _82
	mov	x1, x25	// __first, _82
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1103:       _ForwardIterator __cur = __result;
	mov	x2, x28	// __cur, _141
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	beq	.L1477		//,
	.p2align 3,,7
.L1474:
	ldp	s1, s0, [x1]	// SR.2684, SR.2684, MEM[(const struct complex &)__first_3]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x1, x1, 8	// __first, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x23, x1	// _81, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	stp	s1, s0, [x2]	// SR.2684, SR.2684, MEM[(struct complex *)__cur_122]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x2, x2, 8	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	bne	.L1474		//,
.L1477:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x25, .L1476	// _82,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x22, 16]	// MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x25	//, _82
	sub	x1, x1, x25	//, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_end_of_storage, _82
	bl	_ZdlPvm		//
.L1476:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x20, x28, x20, lsl 3	// tmp317, _141, _32,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	add	x0, x28, x24	// tmp320, _141, _100
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:705: 	      this->_M_impl._M_start = __new_start;
	str	x28, [x19, 96]	// _141, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_start
	ldp	x27, x28, [sp, 112]	//,,
	.cfi_restore 28
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	stp	x20, x0, [x22, 8]	// tmp317, tmp320, MEM[(struct vector *)this_8(D) + 96B].D.212165._M_impl.D.211503._M_finish
	b	.L1466		//
	.p2align 2,,3
.L1543:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, _35
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1456		//
	.p2align 2,,3
.L1450:
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, __tmp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x3, [x19]	// _15, MEM[(const struct __shared_ptr *)this_8(D)]._M_ptr
	b	.L1446		//
	.p2align 2,,3
.L1550:
	.cfi_offset 23, -48
	.cfi_offset 24, -40
	.cfi_offset 25, -32
	.cfi_offset 26, -24
	.cfi_offset 27, -16
	.cfi_offset 28, -8
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x20, x1	// _32, tmp290
	csel	x1, x20, x1, ls	// tmp294, _32, tmp290,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x24, x1, 3	// _100, tmp294,
	mov	x0, x24	//, _100
	bl	_Znwm		//
	mov	x28, x0	// _141, tmp397
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x26, x0, x26	// __cur, _141, _83
	b	.L1470		//
	.p2align 2,,3
.L1496:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	mov	x1, x27	// __n, __n
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:639: 	  _ForwardIterator __cur = __first;
	mov	x0, x23	// tmp.2689, _81
	b	.L1463		//
	.p2align 2,,3
.L1480:
	.cfi_restore 27
	.cfi_restore 28
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	cmp	x2, x23	// tmp334, _153
	bcc	.L1551		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x25, x2, 6	// _178, tmp334,
	mov	x0, x25	//, _178
	bl	_Znwm		//
	mov	x26, x0	// _132, tmp400
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x21, x0, x21	// __cur, _132, _150
.L1483:
	add	x23, x21, x23, lsl 5	// _362, __cur, _153,
	.p2align 3,,7
.L1484:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	add	x21, x21, 32	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	str	xzr, [x21, -32]	//, MEM[(long unsigned int *)__cur_188]
	str	xzr, [x21, -24]	//, MEM[(double *)__cur_188 + 8B]
	str	xzr, [x21, -16]	//, MEM[(long int *)__cur_188 + 16B]
	str	wzr, [x21, -8]	//, MEM[(float *)__cur_188 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x21, x23	// __cur, _362
	bne	.L1484		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x20, x22	// __cur, _149
	mov	x1, x22	// __first, _149
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1103:       _ForwardIterator __cur = __result;
	mov	x2, x26	// __cur, _132
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	beq	.L1488		//,
	.p2align 3,,7
.L1485:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	ldp	q0, q1, [x1]	// MEM[(struct HeldPhase &)__first_157], MEM[(struct HeldPhase &)__first_157], MEM[(struct HeldPhase &)__first_157]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x1, x1, 32	// __first, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x20, x1	// __cur, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	stp	q0, q1, [x2]	// MEM[(struct HeldPhase &)__first_157], MEM[(struct HeldPhase &)__first_157], MEM[(struct HeldPhase *)__cur_165]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x2, x2, 32	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	bne	.L1485		//,
.L1488:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x22, .L1487	// _149,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	sub	x1, x24, #392	// tmp359, tmp387,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x22	//, _149
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x1, 16]	// MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	sub	x1, x1, x22	//, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage, _149
	bl	_ZdlPvm		//
.L1487:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:705: 	      this->_M_impl._M_start = __new_start;
	sub	x24, x24, #392	// tmp365, tmp387,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	add	x2, x26, x25	// tmp375, _132, _178
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x0, x26, 16384	// tmp370, _132,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	str	x2, [x24, 16]	// tmp375, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	stp	x26, x0, [x24]	// _132, tmp370, MEM[(struct vector *)this_8(D) + 19064B].D.226303._M_impl.D.225641._M_start
	b	.L1478		//
.L1551:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 16384	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	mov	x25, 16384	// _178,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	bl	_Znwm		//
	mov	x26, x0	// _132, tmp399
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x21, x0, x21	// __cur, _132, _150
	b	.L1483		//
.L1547:
	stp	x27, x28, [sp, 112]	//,,
	.cfi_offset 28, -8
	.cfi_offset 27, -16
.L1539:
// /probe/scatter-baseline-pitch.cpp:199:   reset();
	bl	__stack_chk_fail		//
.L1549:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1899: 	  __throw_length_error(__N(__s));
	adrp	x0, :got:__stack_chk_guard	// tmp291,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp291,
	ldr	x2, [sp, 24]	// tmp408, D.330804
	ldr	x1, [x0]	// tmp409,
	subs	x2, x2, x1	// tmp408, tmp409
	mov	x1, 0	// tmp409
	bne	.L1539		//,
	adrp	x0, .LC12	// tmp293,
	add	x0, x0, :lo12:.LC12	//, tmp293,
	bl	_ZSt20__throw_length_errorPKc		//
.L1500:
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
	.cfi_restore 28
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 16]	// _36, MEM[(struct __shared_count *)&D.234067 + 8B]._M_pi
	mov	x19, x0	// tmp383, tmp402
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x1, .L1493	// _36,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x1	//, _36
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1493:
	adrp	x0, :got:__stack_chk_guard	// tmp384,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp384,
	ldr	x2, [sp, 24]	// tmp414, D.330804
	ldr	x1, [x0]	// tmp415,
	subs	x2, x2, x1	// tmp414, tmp415
	mov	x1, 0	// tmp415
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	stp	x27, x28, [sp, 112]	//,,
	.cfi_offset 28, -8
	.cfi_offset 27, -16
	bne	.L1539		//,
.L1494:
	mov	x0, x19	//, tmp383
	bl	_Unwind_Resume		//
.LEHE5:
.L1540:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
	.cfi_restore 28
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	mov	x0, 16	//,
	bl	__cxa_allocate_exception		//
	adrp	x1, .LC11	// tmp220,
	add	x1, x1, :lo12:.LC11	//, tmp220,
	mov	x19, x0	// _21, tmp394
.LEHB6:
	bl	_ZNSt16invalid_argumentC1EPKc		//
.LEHE6:
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	adrp	x0, :got:__stack_chk_guard	// tmp221,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp221,
	ldr	x2, [sp, 24]	// tmp406, D.330804
	ldr	x1, [x0]	// tmp407,
	subs	x2, x2, x1	// tmp406, tmp407
	mov	x1, 0	// tmp407
	stp	x21, x22, [sp, 64]	//,,
	.cfi_remember_state
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	stp	x27, x28, [sp, 112]	//,,
	.cfi_offset 28, -8
	.cfi_offset 27, -16
	bne	.L1539		//,
	mov	x0, x19	//, _21
	adrp	x2, :got:_ZNSt16invalid_argumentD1Ev	//,
	ldr	x2, [x2, :got_lo12:_ZNSt16invalid_argumentD1Ev]	//,
	adrp	x1, :got:_ZTISt16invalid_argument	//,
	ldr	x1, [x1, :got_lo12:_ZTISt16invalid_argument]	//,
.LEHB7:
	bl	__cxa_throw		//
.LEHE7:
.L1499:
	.cfi_restore_state
// /probe/scatter-baseline-pitch.cpp:194:   if (!plan) throw std::invalid_argument("pitch renderer requires a plan");
	mov	x1, x0	// tmp401,
	mov	x0, x19	//, _21
	mov	x19, x1	// tmp381, tmp401
	bl	__cxa_free_exception		//
	adrp	x0, :got:__stack_chk_guard	// tmp382,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp382,
	ldr	x2, [sp, 24]	// tmp412, D.330804
	ldr	x1, [x0]	// tmp413,
	subs	x2, x2, x1	// tmp412, tmp413
	mov	x1, 0	// tmp413
	stp	x21, x22, [sp, 64]	//,,
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	stp	x23, x24, [sp, 80]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 96]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	stp	x27, x28, [sp, 112]	//,,
	.cfi_offset 28, -8
	.cfi_offset 27, -16
	beq	.L1494		//,
	b	.L1539		//
	.cfi_endproc
.LFE9578:
	.section	.gcc_except_table
.LLSDA9578:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE9578-.LLSDACSB9578
.LLSDACSB9578:
	.uleb128 .LEHB4-.LFB9578
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L1500-.LFB9578
	.uleb128 0
	.uleb128 .LEHB5-.LFB9578
	.uleb128 .LEHE5-.LEHB5
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB6-.LFB9578
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L1499-.LFB9578
	.uleb128 0
	.uleb128 .LEHB7-.LFB9578
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
.LLSDACSE9578:
	.text
	.size	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb, .-_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb
	.section	.rodata.str1.8
	.align	3
.LC13:
	.string	"pitch frame requires a plan and a valid frequency ceiling"
	.text
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf
	.type	_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf, %function
_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf:
.LFB9556:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9556
	stp	x29, x30, [sp, -96]!	//,,,
	.cfi_def_cfa_offset 96
	.cfi_offset 29, -96
	.cfi_offset 30, -88
	mov	x29, sp	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x2, [x1]	// _25, MEM[(const struct __shared_ptr *)plan_12(D)]._M_ptr
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 20, -72
	.cfi_offset 19, -80
// /probe/scatter-baseline-pitch.cpp:73:   if (!plan || !std::isfinite(frequencyCeiling) || frequencyCeiling <= 0 || frequencyCeiling > kSampleRate / 2)
	cbz	x2, .L1553	// _25,
	mov	x19, x0	// this, tmp544
// /probe/scatter-baseline-pitch.cpp:73:   if (!plan || !std::isfinite(frequencyCeiling) || frequencyCeiling <= 0 || frequencyCeiling > kSampleRate / 2)
	mov	w0, 2139095039	// tmp561,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/cmath:1123:   { return __builtin_isfinite(__x); }
	fabs	s1, s0	// tmp277, frequencyCeiling
	str	d8, [sp, 88]	//,
	.cfi_offset 72, -8
	fmov	s8, s0	// frequencyCeiling, tmp546
// /probe/scatter-baseline-pitch.cpp:73:   if (!plan || !std::isfinite(frequencyCeiling) || frequencyCeiling <= 0 || frequencyCeiling > kSampleRate / 2)
	fmov	s0, w0	// tmp278, tmp561
	fcmp	s1, s0	// tmp277, tmp278
	bhi	.L1661		//,
// /probe/scatter-baseline-pitch.cpp:73:   if (!plan || !std::isfinite(frequencyCeiling) || frequencyCeiling <= 0 || frequencyCeiling > kSampleRate / 2)
	fcmpe	s8, #0.0	// frequencyCeiling
	bls	.L1661		//,
// /probe/scatter-baseline-pitch.cpp:73:   if (!plan || !std::isfinite(frequencyCeiling) || frequencyCeiling <= 0 || frequencyCeiling > kSampleRate / 2)
	mov	w0, 32768	// tmp560,
	movk	w0, 0x46bb, lsl 16	// tmp560,,
	fmov	s0, w0	// tmp279, tmp560
	fcmpe	s8, s0	// frequencyCeiling, tmp279
	bgt	.L1661		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x0, [x1, 8]	// __tmp, MEM[(struct __shared_count &)plan_12(D) + 8]._M_pi
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	stp	x23, x24, [sp, 48]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 64]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	xzr, xzr, [x1]	//,, MEM[(struct __shared_ptr &)plan_12(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x20, [x19, 8]	// __tmp, MEM[(struct __shared_count &)this_16(D) + 8]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	x2, x0, [x19]	// _25, __tmp, MEM[(const struct PitchPlan * &)this_16(D)]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1558	// __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _56,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp293,
	cmp	x2, x0	// _56, tmp293
	beq	.L1665		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp298,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp298,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1560	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)__tmp_48 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp300, __result,
	str	w1, [x20, 8]	// tmp300, MEM[(_Atomic_word *)__tmp_48 + 8B]
.L1561:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1562		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x2, [x19]	// _25, MEM[(const struct __shared_ptr *)this_16(D)]._M_ptr
.L1558:
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	mov	w0, 32768	// tmp559,
	movk	w0, 0x473b, lsl 16	// tmp559,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x1, [x2]	// _45, MEM[(const struct __shared_ptr *)prephitmp_450]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	add	x23, x19, 16	// tmp534, this,
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	fmov	s1, w0	// tmp312, tmp559
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x2, [x23, 8]	// _91, MEM[(const struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x21, [x19, 16]	// _92, MEM[(const struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x4, x0, [x1, 80]	// MEM[(const struct vector *)_45 + 80B].D.214282._M_impl.D.213625._M_start, MEM[(const struct vector *)_45 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_45 + 80B].D.214282._M_impl.D.213625._M_start
	sub	x25, x2, x21	// _93, _91, _92
	sub	x0, x0, x4	// tmp305, MEM[(const struct vector *)_45 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)_45 + 80B].D.214282._M_impl.D.213625._M_start
	asr	x3, x25, 2	// tmp320, _93,
	asr	x0, x0, 2	// tmp308, tmp305,
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	lsr	x1, x0, 1	// _1, tmp308,
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	ucvtf	s0, x0	// tmp309, tmp308
// /probe/scatter-baseline-pitch.cpp:78:   const auto bins = std::min(n / 2 + 1, peakLimit_ + 2);
	add	x20, x1, 1	// tmp314, _1,
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	fmul	s0, s0, s8	// tmp310, tmp309, frequencyCeiling
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	fdiv	s0, s0, s1	// tmp311, tmp310, tmp312
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	fcvtpu	x0, s0	// tmp313, tmp311
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	cmp	x0, x1	// tmp313, _1
	csel	x0, x0, x1, ls	// _148, tmp313, _1,
// /probe/scatter-baseline-pitch.cpp:78:   const auto bins = std::min(n / 2 + 1, peakLimit_ + 2);
	add	x1, x0, 2	// tmp315, _148,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:238:       if (__b < __a)
	cmp	x20, x1	// tmp314, tmp315
	csel	x20, x20, x1, ls	// _111, tmp314, tmp315,
// /probe/scatter-baseline-pitch.cpp:77:   peakLimit_ = std::min(n / 2, static_cast<std::size_t>(std::ceil(frequencyCeiling * n / kSampleRate)));
	str	x0, [x19, 12440]	// _148, this_16(D)->peakLimit_
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x3, x20	// tmp320, _111
	bcc	.L1666		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1017: 	else if (__new_size < size())
	bhi	.L1667		//,
.L1566:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x21, [x19, 40]	// _84, MEM[(const struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	add	x22, x19, 40	// tmp536, this,
	ldr	x26, [x22, 8]	// _83, MEM[(const struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x24, x26, x21	// tmp535, _83, _84
	asr	x0, x24, 3	// tmp380, tmp535,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x0, x20	// tmp380, _111
	bcc	.L1668		//,
.L1576:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1017: 	else if (__new_size < size())
	bhi	.L1669		//,
.L1581:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x24, [x19, 64]	// _76, MEM[(const struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	mov	x2, -6148914691236517206	// tmp436,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	add	x23, x19, 64	// tmp537, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	movk	x2, 0xaaab, lsl 0	// tmp436,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x22, [x23, 8]	// _75, MEM[(const struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x25, x22, x24	// _77, _75, _76
	asr	x0, x25, 3	// tmp434, _77,
	mul	x0, x0, x2	// tmp435, tmp434, tmp436
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x0, x20	// tmp435, _111
	bcc	.L1670		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1017: 	else if (__new_size < size())
	bhi	.L1671		//,
.L1595:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x0, x2, [x19, 16]	// _67, _68, MEM[(float * const &)this_16(D) + 16]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:930:       for (; __first != __last; ++__first)
	cmp	x0, x2	// _67, _68
	beq	.L1605		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	sub	x2, x2, x0	//, _68, _67
	mov	w1, 0	//,
	bl	memset		//
.L1605:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_iterator.h:1077:       : _M_current(__i) { }
	ldp	x2, x4, [x19, 40]	// tmp.2766, _72, MEM[(struct complex * const &)this_16(D) + 40]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x2, x4	// tmp.2766, _72
	beq	.L1604		//,
	sub	x1, x4, #8	// tmp523, _72,
	mov	x0, x2	// ivtmp.2791, tmp.2766
	sub	x1, x1, x2	// _191, tmp523, tmp.2766
	cmp	x1, 16	// _191,
	lsr	x1, x1, 3	// tmp524, _191,
	add	x1, x1, 1	// niters.2763, tmp524,
	bls	.L1606		//,
	lsr	x3, x1, 1	// bnd.2764, niters.2763,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	movi	v0.4s, 0	// tmp527
	add	x3, x2, x3, lsl 4	// _340, tmp.2766, bnd.2764,
	.p2align 3,,7
.L1607:
	str	q0, [x0], 16	// tmp527, MEM <vector(4) float> [(float *)_153]
	cmp	x0, x3	// ivtmp.2791, _340
	bne	.L1607		//,
	tbz	x1, 0, .L1604	// niters.2763,,
	and	x1, x1, -2	// niters_vector_mult_vf.2765, niters.2763,
	add	x2, x2, x1, lsl 3	// tmp.2766, tmp.2766, niters_vector_mult_vf.2765,
.L1606:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 8	// __first, tmp.2766,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2]	//, REALPART_EXPR <__first_233->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _72, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 4]	//, IMAGPART_EXPR <__first_233->_M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1604		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	add	x0, x2, 16	// __first, tmp.2766,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 8]	//, REALPART_EXPR <MEM[(struct complex *)__first_233 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	cmp	x4, x0	// _72, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	str	wzr, [x2, 12]	//, IMAGPART_EXPR <MEM[(struct complex *)__first_233 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:918:       for (; __first != __last; ++__first)
	beq	.L1604		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:919: 	*__first = __value;
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__first_233 + 16B]._M_value>
.L1604:
// /probe/scatter-baseline-pitch.cpp:88:   tracks_ = {};
	mov	x20, 6144	// tmp511,
	mov	x0, 6232	//,
	mov	x2, x20	//, tmp511
	mov	w1, 0	//,
	add	x0, x19, x0	//, this,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:89:   regions_ = {};
	mov	x2, x20	//, tmp511
	add	x0, x19, 88	//, this,
	mov	w1, 0	//,
	bl	memset		//
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	add	x0, x19, 12288	// tmp522, this,
	ldp	x21, x22, [sp, 32]	//,,
	.cfi_remember_state
	.cfi_restore 22
	.cfi_restore 21
	ldp	x23, x24, [sp, 48]	//,,
	.cfi_restore 24
	.cfi_restore 23
	ldp	x25, x26, [sp, 64]	//,,
	.cfi_restore 26
	.cfi_restore 25
	ldr	d8, [sp, 88]	//,
	.cfi_restore 72
// /probe/scatter-baseline-pitch.cpp:90:   spectrum_ = {};
	str	xzr, [x19, 12376]	//, this_16(D)->spectrum_._M_ptr
	str	xzr, [x19, 12384]	//, MEM <size_t> [(struct PitchFrame *)this_16(D) + 12384B]
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12392]	//, this_16(D)->count_
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12400]	//, this_16(D)->capacityEvents_
// /probe/scatter-baseline-pitch.cpp:91:   count_ = capacityEvents_ = generation_ = 0;
	str	xzr, [x19, 12408]	//, this_16(D)->generation_
// /probe/scatter-baseline-pitch.cpp:92:   previous_ = false;
	strb	wzr, [x0, 128]	//, this_16(D)->previous_
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12424]	//, this_16(D)->centerSamples_
// /probe/scatter-baseline-pitch.cpp:93:   centerSamples_ = samples_ = 0;
	str	xzr, [x19, 12432]	//, this_16(D)->samples_
	ldp	x19, x20, [sp, 16]	//,,
	.cfi_restore 20
	.cfi_restore 19
// /probe/scatter-baseline-pitch.cpp:83: }
	ldp	x29, x30, [sp], 96	//,,,
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1667:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x21, x21, x20, lsl 2	// _98, _92, _111,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1935: 	if (size_type __n = this->_M_impl._M_finish - __pos)
	cmp	x2, x21	// _91, _98
	beq	.L1566		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x26, [x19, 48]	// _83, MEM[(const struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_finish
	add	x22, x19, 40	// tmp536, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1939: 	    this->_M_impl._M_finish = __pos;
	str	x21, [x23, 8]	// _98, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_finish
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldr	x21, [x19, 40]	// _84, MEM[(const struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x24, x26, x21	// tmp535, _83, _84
	asr	x0, x24, 3	// tmp380, tmp535,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1015: 	if (__new_size > size())
	cmp	x0, x20	// tmp380, _111
	bcs	.L1576		//,
	.p2align 3,,7
.L1668:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	ldr	x1, [x22, 16]	// MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_end_of_storage, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_end_of_storage
	str	x27, [sp, 80]	//,
	.cfi_offset 27, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	sub	x27, x20, x0	// __n, _111, tmp380
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	sub	x1, x1, x26	// tmp383, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_end_of_storage, _83
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:646: 	  if (__navail >= __n)
	cmp	x27, x1, asr 3	// __n, tmp383,
	bhi	.L1577		//,
	sub	x0, x27, #1	// tmp387, __n,
	cmp	x0, 2	// tmp387,
	bls	.L1611		//,
	lsr	x1, x27, 1	// bnd.2770, __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	movi	v0.4s, 0	// tmp390
	mov	x0, x26	// ivtmp.2805, _83
	add	x1, x26, x1, lsl 4	// _30, _83, bnd.2770,
	.p2align 3,,7
.L1579:
	str	q0, [x0], 16	// tmp390, MEM <vector(4) float> [(float *)_27]
	cmp	x0, x1	// ivtmp.2805, _30
	bne	.L1579		//,
	tbz	x27, 0, .L1580	// __n,,
	and	x1, x27, -2	// niters_vector_mult_vf.2771, __n,
	add	x0, x26, x1, lsl 3	// tmp.2772, _83, niters_vector_mult_vf.2771,
	sub	x1, x27, x1	// __n, __n, niters_vector_mult_vf.2771
.L1578:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x1, 1	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0]	//,, REALPART_EXPR <*__cur_472._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1580		//,
	cmp	x1, 2	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0, 8]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_472 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1580		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x0, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_472 + 16B]._M_value>
.L1580:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:649: 	      this->_M_impl._M_finish =
	add	x27, x26, x27, lsl 3	// __cur, _83, __n,
	str	x27, [x22, 8]	// __cur, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_finish
	ldr	x27, [sp, 80]	//,
	.cfi_restore 27
	b	.L1581		//
	.p2align 2,,3
.L1669:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x21, x21, x20, lsl 3	// _90, _84, _111,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1935: 	if (size_type __n = this->_M_impl._M_finish - __pos)
	cmp	x26, x21	// _83, _90
	beq	.L1581		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1939: 	    this->_M_impl._M_finish = __pos;
	str	x21, [x22, 8]	// _90, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_finish
	b	.L1581		//
	.p2align 2,,3
.L1671:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x20, x20, x20, lsl 1	// tmp502, _111, _111,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1018: 	  _M_erase_at_end(this->_M_impl._M_start + __new_size);
	add	x20, x24, x20, lsl 3	// _82, _76, tmp502,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1935: 	if (size_type __n = this->_M_impl._M_finish - __pos)
	cmp	x22, x20	// _75, _82
	beq	.L1595		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1939: 	    this->_M_impl._M_finish = __pos;
	str	x20, [x23, 8]	// _82, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_finish
	b	.L1595		//
	.p2align 2,,3
.L1666:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	ldr	x0, [x23, 16]	// MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	sub	x24, x20, x3	// _279, _111, tmp320
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	sub	x0, x0, x2	// tmp323, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage, _91
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:646: 	  if (__navail >= __n)
	cmp	x24, x0, asr 2	// _279, tmp323,
	bls	.L1672		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:643: 	  if (__size > max_size() || __navail > max_size() - __size)
	mov	x0, 2305843009213693951	// tmp337,
	sub	x1, x0, x3	// tmp336, tmp337, tmp320
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1898: 	if (max_size() - size() < __n)
	cmp	x1, x24	// tmp336, _279
	bcc	.L1673		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	cmp	x3, x24	// tmp320, _279
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:668: 	      __first = std::fill_n(__first, __n - 1, *__val);
	sub	x26, x24, #1	// _514, _279,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	bcc	.L1674		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1901: 	const size_type __len = size() + (std::max)(size(), __n);
	lsl	x3, x3, 1	// __len, tmp320,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x3, x0	// __len, tmp337
	csel	x3, x3, x0, ls	// __len, __len, tmp337,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x22, x3, 2	// _150, __len,
	mov	x0, x22	//, _150
.LEHB8:
	bl	_Znwm		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1123:       if (__n <= 0)
	cmp	x24, 1	// _279,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x24, x0	// _151, tmp550
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x0, x0, x25	// _206, _151, _93
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	str	wzr, [x24, x25]	//, *_206
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1123:       if (__n <= 0)
	beq	.L1571		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	lsl	x2, x26, 2	//, _514,
	add	x0, x0, 4	//, _206,
	mov	w1, 0	//,
	bl	memset		//
.L1571:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1131: 	  __builtin_memmove(__result, __first, __count * sizeof(_Tp));
	mov	x1, x21	//, _92
	mov	x2, x25	//, _93
	mov	x0, x24	//, _151
	bl	memmove		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x23, 16]	// MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage
	sub	x1, x1, x21	// _223, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage, _92
.L1574:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x21	//, _92
	bl	_ZdlPvm		//
.L1575:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x0, x24, x20, lsl 2	// tmp369, _151, _111,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	add	x3, x24, x22	// tmp372, _151, _150
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:705: 	      this->_M_impl._M_start = __new_start;
	str	x24, [x19, 16]	// _151, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	str	x3, [x23, 16]	// tmp372, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage
.L1664:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	str	x0, [x23, 8]	// tmp369, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_finish
	b	.L1566		//
	.p2align 2,,3
.L1670:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	ldr	x1, [x23, 16]	// MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_end_of_storage, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	sub	x26, x20, x0	// _135, _111, tmp435
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:641: 					 - this->_M_impl._M_finish);
	sub	x1, x1, x22	// tmp439, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_end_of_storage, _75
	asr	x1, x1, 3	// tmp442, tmp439,
	mul	x1, x1, x2	// __navail, tmp442, tmp436
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:646: 	  if (__navail >= __n)
	cmp	x26, x1	// _135, __navail
	bhi	.L1594		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	add	x26, x26, x26, lsl 1	// tmp447, _135, _135,
	mov	w1, 0	//,
	mov	x0, x22	//, _75
	lsl	x20, x26, 3	// tmp448, tmp447,
	mov	x2, x20	//, tmp448
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:649: 	      this->_M_impl._M_finish =
	add	x20, x22, x20	// __cur, _75, tmp448
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	bl	memset		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:649: 	      this->_M_impl._M_finish =
	str	x20, [x23, 8]	// __cur, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_finish
	b	.L1595		//
	.p2align 2,,3
.L1672:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x0, x2	// __first, _91
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1123:       if (__n <= 0)
	subs	x21, x24, #1	// _129, _279,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	str	wzr, [x0], 4	//, *_91
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1123:       if (__n <= 0)
	beq	.L1664		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1128:       std::__fill_a(__first, __first + __n, __value);
	add	x21, x0, x21, lsl 2	// _131, __first, _129,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	mov	w1, 0	//,
	sub	x2, x21, x2	// tmp328, _131, _91
	sub	x2, x2, #4	//, tmp328,
	bl	memset		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1129:       return __first + __n;
	mov	x0, x21	// __first, _131
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	str	x0, [x23, 8]	// tmp369, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_finish
	b	.L1566		//
	.p2align 2,,3
.L1665:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// __tmp_48->_vptr._Sp_counted_base, __tmp_48->_vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_63 + 16B], MEM[(int (*) () *)_63 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)__tmp_48 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_63 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// __tmp_48->_vptr._Sp_counted_base, __tmp_48->_vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_65 + 24B], MEM[(int (*) () *)_65 + 24B]
	blr	x1		// MEM[(int (*) () *)_65 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x2, [x19]	// _25, MEM[(const struct __shared_ptr *)this_16(D)]._M_ptr
	b	.L1558		//
	.p2align 2,,3
.L1560:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1561		//
	.p2align 2,,3
.L1577:
	.cfi_offset 27, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:643: 	  if (__size > max_size() || __navail > max_size() - __size)
	mov	x1, 1152921504606846975	// tmp398,
	sub	x2, x1, x0	// tmp397, tmp398, tmp380
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1898: 	if (max_size() - size() < __n)
	cmp	x2, x27	// tmp397, __n
	bcc	.L1582		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	cmp	x0, x27	// tmp380, __n
	bcc	.L1675		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1901: 	const size_type __len = size() + (std::max)(size(), __n);
	lsl	x0, x0, 1	// __len, tmp380,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x0, x1	// __len, tmp398
	csel	x0, x0, x1, ls	// __len, __len, tmp398,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x23, x0, 3	// _182, __len,
	mov	x0, x23	//, _182
	bl	_Znwm		//
	mov	x25, x0	// _121, tmp552
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x2, x0, x24	// __cur, _121, tmp535
.L1584:
	sub	x0, x27, #1	// tmp407, __n,
	cmp	x0, 2	// tmp407,
	bls	.L1585		//,
	lsr	x0, x27, 1	// bnd.2777, __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	movi	v0.4s, 0	// tmp410
	mov	x1, x2	// ivtmp.2818, __cur
	add	x0, x2, x0, lsl 4	// _102, __cur, bnd.2777,
	.p2align 3,,7
.L1586:
	str	q0, [x1], 16	// tmp410, MEM <vector(4) float> [(float *)_99]
	cmp	x1, x0	// ivtmp.2818, _102
	bne	.L1586		//,
	tbz	x27, 0, .L1587	// __n,,
	and	x0, x27, -2	// niters_vector_mult_vf.2778, __n,
	add	x2, x2, x0, lsl 3	// __cur, __cur, niters_vector_mult_vf.2778,
	sub	x27, x27, x0	// __n, __n, niters_vector_mult_vf.2778
.L1585:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	cmp	x27, 1	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x2]	//,, REALPART_EXPR <*__cur_444._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1587		//,
	cmp	x27, 2	// __n,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x2, 8]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_444 + 8B]._M_value>
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:642: 	      for (; __n > 0; --__n, (void) ++__cur)
	beq	.L1587		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/complex:1354:       : _M_value{ __r, __i } { }
	stp	wzr, wzr, [x2, 16]	//,, REALPART_EXPR <MEM[(struct complex *)__cur_444 + 16B]._M_value>
.L1587:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x26, x21	// _83, _84
	add	x24, x25, x24	// _69, _121, tmp535
	mov	x2, x21	// __first, _84
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1103:       _ForwardIterator __cur = __result;
	mov	x1, x25	// __cur, _121
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	beq	.L1592		//,
	.p2align 3,,7
.L1591:
	ldp	s1, s0, [x2]	// SR.2761, SR.2761, MEM[(const struct complex &)__first_158]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x2, x2, 8	// __first, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	stp	s1, s0, [x1]	// SR.2761, SR.2761, MEM[(struct complex *)__cur_112]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x1, x1, 8	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x24, x1	// _69, __cur
	bne	.L1591		//,
.L1592:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x21, .L1590	// _84,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x22, 16]	// MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_end_of_storage, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x21	//, _84
	sub	x1, x1, x21	//, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_end_of_storage, _84
	bl	_ZdlPvm		//
.L1590:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x1, x25, x20, lsl 3	// tmp423, _121, _111,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	add	x0, x25, x23	// tmp426, _121, _182
	ldr	x27, [sp, 80]	//,
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:705: 	      this->_M_impl._M_start = __new_start;
	str	x25, [x19, 40]	// _121, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	stp	x1, x0, [x22, 8]	// tmp423, tmp426, MEM[(struct vector *)this_16(D) + 40B].D.212165._M_impl.D.211503._M_finish
	b	.L1581		//
	.p2align 2,,3
.L1594:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:643: 	  if (__size > max_size() || __navail > max_size() - __size)
	mov	x1, 6148914691236517205	// tmp456,
	str	x27, [sp, 80]	//,
	.cfi_offset 27, -16
	movk	x1, 0x555, lsl 48	// tmp456,,
	sub	x2, x1, x0	// tmp455, tmp456, tmp435
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1898: 	if (max_size() - size() < __n)
	cmp	x26, x2	// _135, tmp455
	bhi	.L1582		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:262:       if (__a < __b)
	cmp	x0, x26	// tmp435, _135
	bcc	.L1676		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1901: 	const size_type __len = size() + (std::max)(size(), __n);
	lsl	x0, x0, 1	// __len, tmp435,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x0, x1	// __len, tmp456
	csel	x0, x0, x1, ls	// __len, __len, tmp456,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	add	x0, x0, x0, lsl 1	// tmp470, __len, __len,
	lsl	x21, x0, 3	// _302, tmp470,
	mov	x0, x21	//, _302
	bl	_Znwm		//
	mov	x27, x0	// _245, tmp554
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x0, x0, x25	// _291, _245, _77
.L1597:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	add	x26, x26, x26, lsl 1	// tmp475, _135, _135,
	mov	w1, 0	//,
	lsl	x2, x26, 3	//, tmp475,
	bl	memset		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x22, x24	// _75, _76
	mov	x1, x24	// __first, _76
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1103:       _ForwardIterator __cur = __result;
	mov	x4, x27	// __cur, _245
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	beq	.L1601		//,
	.p2align 3,,7
.L1598:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	ldp	x2, x3, [x1]	// MEM[(struct PitchRegion &)__first_341], MEM[(struct PitchRegion &)__first_341]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x1, x1, 24	// __first, __first,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	add	x4, x4, 24	// __cur, __cur,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	stp	x2, x3, [x4, -24]	// MEM[(struct PitchRegion &)__first_341], MEM[(struct PitchRegion *)__cur_10]
	ldr	x2, [x1, -8]	// MEM[(struct PitchRegion &)__first_341], MEM[(struct PitchRegion &)__first_341]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	cmp	x22, x1	// _75, __first
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:97:     { return ::new((void*)__location) _Tp(std::forward<_Args>(__args)...); }
	str	x2, [x4, -8]	// MEM[(struct PitchRegion &)__first_341], MEM[(struct PitchRegion *)__cur_10]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1104:       for (; __first != __last; ++__first, (void)++__cur)
	bne	.L1598		//,
.L1601:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x24, .L1600	// _76,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x23, 16]	// MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_end_of_storage, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_end_of_storage
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x24	//, _76
	sub	x1, x1, x24	//, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_end_of_storage, _76
	bl	_ZdlPvm		//
.L1600:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x20, x20, x20, lsl 1	// tmp494, _111, _111,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	add	x21, x27, x21	// tmp499, _245, _302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:705: 	      this->_M_impl._M_start = __new_start;
	str	x27, [x19, 64]	// _245, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_start
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:706: 	      this->_M_impl._M_finish = __new_start + __size + __n;
	add	x0, x27, x20, lsl 3	// tmp496, _245, tmp494,
	ldr	x27, [sp, 80]	//,
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:707: 	      this->_M_impl._M_end_of_storage = __new_start + __len;
	stp	x0, x21, [x23, 8]	// tmp496, tmp499, MEM[(struct vector *)this_16(D) + 64B].D.223596._M_impl.D.222934._M_finish
	b	.L1595		//
.L1562:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, __tmp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x2, [x19]	// _25, MEM[(const struct __shared_ptr *)this_16(D)]._M_ptr
	b	.L1558		//
.L1676:
	.cfi_offset 27, -16
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x20, x1	// _111, tmp456
	csel	x1, x20, x1, ls	// tmp457, _111, tmp456,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	add	x1, x1, x1, lsl 1	// tmp462, tmp457, tmp457,
	lsl	x21, x1, 3	// _302, tmp462,
	mov	x0, x21	//, _302
	bl	_Znwm		//
	mov	x27, x0	// _245, tmp553
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x0, x0, x25	// _291, _245, _77
	b	.L1597		//
.L1675:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x20, x1	// _111, tmp398
	csel	x1, x20, x1, ls	// tmp399, _111, tmp398,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x23, x1, 3	// _182, tmp399,
	mov	x0, x23	//, _182
	bl	_Znwm		//
	mov	x25, x0	// _121, tmp551
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x2, x0, x24	// __cur, _121, tmp535
	b	.L1584		//
.L1611:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1016: 	  _M_default_append(__new_size - size());
	mov	x1, x27	// __n, __n
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:639: 	  _ForwardIterator __cur = __first;
	mov	x0, x26	// tmp.2772, _83
	b	.L1578		//
.L1674:
	.cfi_restore 27
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1902: 	return (__len < size() || __len > max_size()) ? max_size() : __len;
	cmp	x20, x0	// _111, tmp337
	csel	x0, x20, x0, ls	// tmp340, _111, tmp337,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	lsl	x22, x0, 2	// _150, tmp340,
	mov	x0, x22	//, _150
	bl	_Znwm		//
	mov	x24, x0	// _151, tmp549
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:668: 		      std::__uninitialized_default_n_a(__new_start + __size,
	add	x0, x0, x25	// _115, _151, _93
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	str	wzr, [x24, x25]	//, *_115
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:1123:       if (__n <= 0)
	cbz	x26, .L1569	// _514,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_algobase.h:931: 	*__first = __tmp;
	lsl	x2, x26, 2	//, _514,
	add	x0, x0, 4	//, _115,
	mov	w1, 0	//,
	bl	memset		//
.L1569:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_uninitialized.h:1119:       if (__count > 0)
	cbnz	x25, .L1571	// _93,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:389: 	if (__p)
	cbz	x21, .L1575	// _92,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/vector.tcc:704: 			    this->_M_impl._M_end_of_storage - __old_start);
	ldr	x1, [x23, 16]	// MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage
	sub	x1, x1, x21	// _223, MEM[(struct vector *)this_16(D) + 16B].D.214282._M_impl.D.213625._M_end_of_storage, _92
	b	.L1574		//
.L1673:
	str	x27, [sp, 80]	//,
	.cfi_offset 27, -16
.L1582:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:1899: 	  __throw_length_error(__N(__s));
	adrp	x0, .LC12	// tmp339,
	add	x0, x0, :lo12:.LC12	//, tmp339,
	bl	_ZSt20__throw_length_errorPKc		//
.LEHE8:
.L1661:
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 27
	ldr	d8, [sp, 88]	//,
	.cfi_restore 72
.L1553:
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	mov	x0, 16	//,
	bl	__cxa_allocate_exception		//
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	adrp	x1, .LC13	// tmp282,
	add	x1, x1, :lo12:.LC13	//, tmp282,
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	mov	x19, x0	// _34, tmp547
.LEHB9:
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	bl	_ZNSt16invalid_argumentC1EPKc		//
.LEHE9:
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	adrp	x2, :got:_ZNSt16invalid_argumentD1Ev	//,
	ldr	x2, [x2, :got_lo12:_ZNSt16invalid_argumentD1Ev]	//,
	mov	x0, x19	//, _34
	stp	x21, x22, [sp, 32]	//,,
	.cfi_remember_state
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	adrp	x1, :got:_ZTISt16invalid_argument	//,
	ldr	x1, [x1, :got_lo12:_ZTISt16invalid_argument]	//,
	stp	x23, x24, [sp, 48]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 64]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	str	x27, [sp, 80]	//,
	.cfi_offset 27, -16
	str	d8, [sp, 88]	//,
	.cfi_offset 72, -8
.LEHB10:
	bl	__cxa_throw		//
.L1613:
	.cfi_restore_state
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	mov	x1, x0	// tmp555,
	mov	x0, x19	//, _34
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 22, -56
	.cfi_offset 21, -64
	mov	x19, x1	// tmp533, tmp555
	stp	x23, x24, [sp, 48]	//,,
	.cfi_offset 24, -40
	.cfi_offset 23, -48
	stp	x25, x26, [sp, 64]	//,,
	.cfi_offset 26, -24
	.cfi_offset 25, -32
	str	x27, [sp, 80]	//,
	.cfi_offset 27, -16
	str	d8, [sp, 88]	//,
	.cfi_offset 72, -8
// /probe/scatter-baseline-pitch.cpp:74:     throw std::invalid_argument("pitch frame requires a plan and a valid frequency ceiling");
	bl	__cxa_free_exception		//
	mov	x0, x19	//, tmp533
	bl	_Unwind_Resume		//
.LEHE10:
	.cfi_endproc
.LFE9556:
	.section	.gcc_except_table
.LLSDA9556:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE9556-.LLSDACSB9556
.LLSDACSB9556:
	.uleb128 .LEHB8-.LFB9556
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LFB9556
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L1613-.LFB9556
	.uleb128 0
	.uleb128 .LEHB10-.LFB9556
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
.LLSDACSE9556:
	.text
	.size	_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf, .-_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf
	.section	.rodata.str1.8
	.align	3
.LC14:
	.string	"pitch plan requires a spectral plan"
	.text
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog39PitchPlanC2ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE
	.type	_ZN5ardor4pog39PitchPlanC2ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE, %function
_ZN5ardor4pog39PitchPlanC2ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE:
.LFB9553:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9553
	stp	x29, x30, [sp, -160]!	//,,,
	.cfi_def_cfa_offset 160
	.cfi_offset 29, -160
	.cfi_offset 30, -152
	mov	x29, sp	//,
	mov	x3, x2	// interpolation, tmp300
	mov	x4, x1	// spectralPlan, tmp299
// /probe/scatter-baseline-pitch.cpp:50:     : spectral(std::move(spectralPlan)), interpolation_(std::move(interpolation)) {
	mov	x2, 32772	//,
// /probe/scatter-baseline-pitch.cpp:48: PitchPlan::PitchPlan(std::shared_ptr<const SpectralPlan> spectralPlan,
	stp	x19, x20, [sp, 16]	//,,
	.cfi_offset 19, -144
	.cfi_offset 20, -136
	mov	x19, x0	// this, tmp298
	stp	x21, x22, [sp, 32]	//,,
	.cfi_offset 21, -128
	.cfi_offset 22, -120
// /probe/scatter-baseline-pitch.cpp:50:     : spectral(std::move(spectralPlan)), interpolation_(std::move(interpolation)) {
	add	x22, x0, 32	// tmp293, this,
// /probe/scatter-baseline-pitch.cpp:48: PitchPlan::PitchPlan(std::shared_ptr<const SpectralPlan> spectralPlan,
	stp	x23, x24, [sp, 48]	//,,
	stp	d8, d9, [sp, 64]	//,,
	stp	d10, d11, [sp, 80]	//,,
	stp	d12, d13, [sp, 96]	//,,
	stp	d14, d15, [sp, 112]	//,,
	.cfi_offset 23, -112
	.cfi_offset 24, -104
	.cfi_offset 72, -96
	.cfi_offset 73, -88
	.cfi_offset 74, -80
	.cfi_offset 75, -72
	.cfi_offset 76, -64
	.cfi_offset 77, -56
	.cfi_offset 78, -48
	.cfi_offset 79, -40
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1532:       : _M_ptr(__r._M_ptr), _M_refcount()
	ldr	x6, [x1]	// MEM[(struct __shared_ptr &)spectralPlan_18(D)]._M_ptr, MEM[(struct __shared_ptr &)spectralPlan_18(D)]._M_ptr
	ldr	x5, [x3]	// MEM[(struct __shared_ptr &)interpolation_19(D)]._M_ptr, MEM[(struct __shared_ptr &)interpolation_19(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:908:       constexpr __shared_count() noexcept : _M_pi(0)
	str	xzr, [x0, 8]	//, MEM[(struct __shared_count *)this_16(D) + 8B]._M_pi
// /probe/scatter-baseline-pitch.cpp:50:     : spectral(std::move(spectralPlan)), interpolation_(std::move(interpolation)) {
	mov	x0, x22	//, tmp293
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x7, [x1, 8]	// __tmp, MEM[(struct __shared_count &)spectralPlan_18(D) + 8]._M_pi
// /probe/scatter-baseline-pitch.cpp:50:     : spectral(std::move(spectralPlan)), interpolation_(std::move(interpolation)) {
	mov	w1, 0	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	xzr, xzr, [x4]	//,, MEM[(struct __shared_ptr &)spectralPlan_18(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:908:       constexpr __shared_count() noexcept : _M_pi(0)
	str	xzr, [x19, 24]	//, MEM[(struct __shared_count *)this_16(D) + 24B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1532:       : _M_ptr(__r._M_ptr), _M_refcount()
	stp	x7, x5, [x19, 8]	// __tmp, MEM[(struct __shared_ptr &)interpolation_19(D)]._M_ptr, MEM[(struct __shared_count *)this_16(D) + 8B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x4, [x3, 8]	// __tmp, MEM[(struct __shared_count &)interpolation_19(D) + 8]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1532:       : _M_ptr(__r._M_ptr), _M_refcount()
	str	x6, [x19]	// MEM[(struct __shared_ptr &)spectralPlan_18(D)]._M_ptr, MEM[(struct __shared_ptr *)this_16(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	xzr, xzr, [x3]	//,, MEM[(struct __shared_ptr &)interpolation_19(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1101: 	_M_pi = __tmp;
	str	x4, [x19, 24]	// __tmp, MEM[(struct __shared_count *)this_16(D) + 24B]._M_pi
// /probe/scatter-baseline-pitch.cpp:50:     : spectral(std::move(spectralPlan)), interpolation_(std::move(interpolation)) {
	bl	memset		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1670:       { return _M_ptr != nullptr; }
	ldr	x0, [x19]	// _32, MEM[(const struct __shared_ptr *)this_16(D)]._M_ptr
// /probe/scatter-baseline-pitch.cpp:51:   if (!spectral) throw std::invalid_argument("pitch plan requires a spectral plan");
	cbz	x0, .L1713	// _32,
// /probe/scatter-baseline-pitch.cpp:52:   if (!interpolation_) interpolation_ = std::make_shared<PitchInterpolation>();
	ldr	x1, [x19, 16]	// MEM[(const struct __shared_ptr *)this_16(D) + 16B]._M_ptr, MEM[(const struct __shared_ptr *)this_16(D) + 16B]._M_ptr
	cbz	x1, .L1714	// MEM[(const struct __shared_ptr *)this_16(D) + 16B]._M_ptr,
.L1679:
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	adrp	x1, .LC0	// tmp312,
// /probe/scatter-baseline-pitch.cpp:58:     const double x = static_cast<double>(i) / kPhases;
	mov	x2, 4566650022153682944	// tmp310,
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmov	d11, 1.0e+0	// tmp237,
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmov	d10, 2.5e-1	// tmp297,
// /probe/scatter-baseline-pitch.cpp:57:   for (std::size_t i = 0; i < hannLobe_.size(); ++i) {
	mov	x19, 0	// i,
	add	x21, sp, 152	// tmp295,,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	ldr	d12, [x1, #:lo12:.LC0]	// tmp239,
	add	x20, sp, 144	// tmp294,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	ldp	x1, x0, [x0, 80]	// MEM[(const struct vector *)prephitmp_201 + 80B].D.214282._M_impl.D.213625._M_start, MEM[(const struct vector *)prephitmp_201 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)prephitmp_201 + 80B].D.214282._M_impl.D.213625._M_start
// /probe/scatter-baseline-pitch.cpp:58:     const double x = static_cast<double>(i) / kPhases;
	fmov	d14, x2	// tmp236, tmp310
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	adrp	x2, .LC1	// tmp313,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	sub	x0, x0, x1	// tmp230, MEM[(const struct vector *)prephitmp_201 + 80B].D.214282._M_impl.D.213625._M_finish, MEM[(const struct vector *)prephitmp_201 + 80B].D.214282._M_impl.D.213625._M_start
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	ldr	d13, [x2, #:lo12:.LC1]	// tmp296,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_vector.h:993:       { return size_type(this->_M_impl._M_finish - this->_M_impl._M_start); }
	fmov	d0, x0	// tmp230, tmp230
	sshr	d9, d0, 2	// tmp234, tmp230,
// /probe/scatter-baseline-pitch.cpp:53:   const double n = spectral->frameSize();
	ucvtf	d9, d9	// n, tmp234
	.p2align 3,,7
.L1692:
// /probe/scatter-baseline-pitch.cpp:58:     const double x = static_cast<double>(i) / kPhases;
	scvtf	d1, x19	// tmp235, i
// /probe/scatter-baseline-pitch.cpp:58:     const double x = static_cast<double>(i) / kPhases;
	fmul	d1, d1, d14	// x, tmp235, tmp236
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fcmpe	d1, d12	// x, tmp239
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fsub	d2, d1, d11	// _235, x, tmp237
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fadd	d15, d1, d11	// _236, x, tmp237
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	bmi	.L1700		//,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d8, d1, d13	// _117, x, tmp296
	str	d2, [sp, 136]	// _235, %sfp
	fmov	d0, d8	//, _117
	bl	sin		//
	fmov	d1, d0	// tmp305,
	fdiv	d0, d8, d9	//, _117, n
	mov	x1, x20	//, tmp294
	mov	x0, x21	//, tmp295
	fmov	d8, d1	// _118, tmp305
	bl	sincos		//
	ldp	d2, d1, [sp, 136]	// _235, sincostmp_233, %sfp
	ldr	d3, [sp, 152]	// sincostmp_233,
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmov	d0, 5.0e-1	// tmp256,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d8, d1, d8	// tmp254, sincostmp_233, _118
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fabs	d4, d2	// tmp257, _235
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fcmpe	d4, d12	// tmp257, tmp239
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fdiv	d8, d8, d3	// tmp255, tmp254, sincostmp_233
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmul	d8, d8, d0	// _2, tmp255, tmp256
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	bmi	.L1701		//,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d2, d2, d13	// _27, _235, tmp296
	fmov	d0, d2	//, _27
	str	d2, [sp, 136]	// _27, %sfp
	bl	sin		//
	ldr	d2, [sp, 136]	// _27, %sfp
	fmov	d1, d0	// tmp309,
	mov	x1, x20	//, tmp294
	mov	x0, x21	//, tmp295
	str	d1, [sp, 136]	// _21, %sfp
	fdiv	d0, d2, d9	//, _27, n
	bl	sincos		//
	ldr	d2, [sp, 152]	// sincostmp_230,
	ldp	d1, d0, [sp, 136]	// _21, sincostmp_230, %sfp
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d0, d0, d1	// tmp290, sincostmp_230, _21
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fdiv	d0, d0, d2	// tmp291, tmp290, sincostmp_230
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmadd	d8, d0, d10, d8	// _5, tmp291, tmp297, _2
	b	.L1688		//
	.p2align 2,,3
.L1701:
	fmadd	d8, d9, d10, d8	// _5, n, tmp297, _2
.L1688:
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d15, d15, d13	// _135, _236, tmp296
	fmov	d0, d15	//, _135
	bl	sin		//
	fmov	d1, d0	// tmp306,
	fdiv	d0, d15, d9	//, _135, n
	mov	x1, x20	//, tmp294
	mov	x0, x21	//, tmp295
	fmov	d15, d1	// _136, tmp306
	bl	sincos		//
	ldp	d1, d0, [sp, 144]	// sincostmp_231, sincostmp_231,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d1, d1, d15	// tmp264, sincostmp_231, _136
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fdiv	d1, d1, d0	// iftmp.23_56, tmp264, sincostmp_231
.L1687:
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmadd	d8, d1, d10, d8	// _8, iftmp.23_56, tmp297, _5
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	cmp	x19, 8192	// i,
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fdiv	d8, d8, d9	// tmp266, _8, n
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fcvt	s8, d8	// _10, tmp266
// /ardor/src/daisyfx/pog3/PolyphonicPitchBank.h:52:     return logical == 16 * kPhases ? logical : (logical % kPhases) * 16 + logical / kPhases;
	beq	.L1715		//,
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	ubfiz	x0, x19, 4, 9	// tmp274, i,,
	add	x0, x0, x19, lsr 9	// tmp275, tmp274, i,
	add	x19, x19, 1	// i, i,
	str	s8, [x22, x0, lsl 2]	// _10, MEM <struct array> [(value_type &)this_16(D) + 32]._M_elems[iftmp.24_53]
	b	.L1692		//
	.p2align 2,,3
.L1700:
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d8, d2, d13	// _126, _235, tmp296
	fmov	d0, d8	//, _126
	bl	sin		//
	fmov	d2, d0	// tmp304,
	fdiv	d0, d8, d9	//, _126, n
	mov	x1, x20	//, tmp294
	mov	x0, x21	//, tmp295
	fmov	d8, d2	// _127, tmp304
	bl	sincos		//
	ldp	d2, d3, [sp, 144]	// sincostmp_232, sincostmp_232,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fcmpe	d15, d12	// _236, tmp239
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmov	d1, d9	// iftmp.23_56, n
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmov	d0, 5.0e-1	// tmp248,
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fmul	d8, d2, d8	// tmp244, sincostmp_232, _127
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	fdiv	d8, d8, d3	// tmp245, tmp244, sincostmp_232
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmul	d8, d8, d10	// tmp246, tmp245, tmp297
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	fmadd	d8, d9, d0, d8	// _5, n, tmp248, tmp246
// /probe/scatter-baseline-pitch.cpp:55:     return std::fabs(x) < 1e-12 ? n : std::sin(kPi * x) * std::cos(kPi * x / n) / std::sin(kPi * x / n);
	bmi	.L1687		//,
	b	.L1688		//
	.p2align 2,,3
.L1715:
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	add	x22, x22, 32768	// tmp269, tmp293,
// /probe/scatter-baseline-pitch.cpp:61: }
	ldp	x19, x20, [sp, 16]	//,,
	ldp	x23, x24, [sp, 48]	//,,
	ldp	d10, d11, [sp, 80]	//,,
	ldp	d12, d13, [sp, 96]	//,,
	ldp	d14, d15, [sp, 112]	//,,
// /probe/scatter-baseline-pitch.cpp:59:     hannLobe_[lobeIndex(i)] = static_cast<float>((.5 * dirichlet(x) + .25 * dirichlet(x - 1) + .25 * dirichlet(x + 1)) / n);
	str	s8, [x22]	// _10, MEM <struct array> [(value_type &)this_16(D) + 32]._M_elems[8192]
// /probe/scatter-baseline-pitch.cpp:61: }
	ldp	x21, x22, [sp, 32]	//,,
	ldp	d8, d9, [sp, 64]	//,,
	ldp	x29, x30, [sp], 160	//,,,
	.cfi_remember_state
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_restore 78
	.cfi_restore 79
	.cfi_restore 76
	.cfi_restore 77
	.cfi_restore 74
	.cfi_restore 75
	.cfi_restore 72
	.cfi_restore 73
	.cfi_def_cfa_offset 0
	ret	
.L1714:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 49264	//,
.LEHB11:
	bl	_Znwm		//
.LEHE11:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x23, 4294967297	// tmp211,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x24, x0	// _99, tmp210
	adrp	x1, _ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp213,
	add	x1, x1, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp212, tmp213,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x21, x0	// tmp210, tmp302
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x23, [x0, 8]	// tmp211, MEM <unsigned long> [(int *)_104 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x1, [x24], 16	// tmp212, *_104.D.269132._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x0, x24	//, _99
	bl	_ZN5ardor4pog318PitchInterpolationC1Ev		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1099: 	_Sp_counted_base<_Lp>* __tmp = __r._M_pi;
	ldr	x20, [x19, 24]	// __tmp, MEM[(struct __shared_count &)this_16(D) + 24]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1100: 	__r._M_pi = _M_pi;
	stp	x24, x21, [x19, 16]	// _99, tmp210, MEM[(const struct PitchInterpolation * &)this_16(D) + 16]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x20, .L1712	// __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x20, 8	// __both_counts, __tmp,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _106,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x23	// _106, tmp211
	beq	.L1716		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x0, :got:__libc_single_threaded	// tmp223,
	ldr	x0, [x0, :got_lo12:__libc_single_threaded]	// tmp223,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x0]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1682	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)__tmp_43 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp225, __result,
	str	w1, [x20, 8]	// tmp225, MEM[(_Atomic_word *)__tmp_43 + 8B]
.L1683:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	bne	.L1712		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x20	//, __tmp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
.L1712:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x0, [x19]	// _32, MEM[(const struct __shared_ptr *)this_16(D)]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1679		//
.L1682:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1683		//
.L1716:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// *__tmp_43._vptr._Sp_counted_base, *__tmp_43._vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_113 + 16B], MEM[(int (*) () *)_113 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)__tmp_43 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_113 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// *__tmp_43._vptr._Sp_counted_base, *__tmp_43._vptr._Sp_counted_base
	mov	x0, x20	//, __tmp
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_115 + 24B], MEM[(int (*) () *)_115 + 24B]
	blr	x1		// MEM[(int (*) () *)_115 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1666:       { return _M_ptr; }
	ldr	x0, [x19]	// _32, MEM[(const struct __shared_ptr *)this_16(D)]._M_ptr
	b	.L1679		//
.L1713:
// /probe/scatter-baseline-pitch.cpp:51:   if (!spectral) throw std::invalid_argument("pitch plan requires a spectral plan");
	mov	x0, 16	//,
	bl	__cxa_allocate_exception		//
	adrp	x1, .LC14	// tmp204,
	add	x1, x1, :lo12:.LC14	//, tmp204,
	mov	x21, x0	// _36, tmp301
.LEHB12:
	bl	_ZNSt16invalid_argumentC1EPKc		//
.LEHE12:
// /probe/scatter-baseline-pitch.cpp:51:   if (!spectral) throw std::invalid_argument("pitch plan requires a spectral plan");
	adrp	x2, :got:_ZNSt16invalid_argumentD1Ev	//,
	ldr	x2, [x2, :got_lo12:_ZNSt16invalid_argumentD1Ev]	//,
	mov	x0, x21	//, _36
	adrp	x1, :got:_ZTISt16invalid_argument	//,
	ldr	x1, [x1, :got_lo12:_ZTISt16invalid_argument]	//,
.LEHB13:
	bl	__cxa_throw		//
.LEHE13:
.L1699:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	mov	x20, x0	// tmp276, tmp308
	b	.L1694		//
.L1698:
// /probe/scatter-baseline-pitch.cpp:51:   if (!spectral) throw std::invalid_argument("pitch plan requires a spectral plan");
	mov	x20, x0	// tmp307,
	mov	x0, x21	//, _36
	bl	__cxa_free_exception		//
.L1694:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x0, [x19, 24]	// _62, MEM[(struct __shared_count *)this_16(D) + 24B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x0, .L1695	// _62,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1695:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x0, [x19, 8]	// _63, MEM[(struct __shared_count *)this_16(D) + 8B]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x0, .L1696	// _63,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1696:
	mov	x0, x20	//, tmp276
.LEHB14:
	bl	_Unwind_Resume		//
.LEHE14:
	.cfi_endproc
.LFE9553:
	.section	.gcc_except_table
.LLSDA9553:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE9553-.LLSDACSB9553
.LLSDACSB9553:
	.uleb128 .LEHB11-.LFB9553
	.uleb128 .LEHE11-.LEHB11
	.uleb128 .L1699-.LFB9553
	.uleb128 0
	.uleb128 .LEHB12-.LFB9553
	.uleb128 .LEHE12-.LEHB12
	.uleb128 .L1698-.LFB9553
	.uleb128 0
	.uleb128 .LEHB13-.LFB9553
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L1699-.LFB9553
	.uleb128 0
	.uleb128 .LEHB14-.LFB9553
	.uleb128 .LEHE14-.LEHB14
	.uleb128 0
	.uleb128 0
.LLSDACSE9553:
	.text
	.size	_ZN5ardor4pog39PitchPlanC2ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE, .-_ZN5ardor4pog39PitchPlanC2ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE
	.global	_ZN5ardor4pog39PitchPlanC1ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE
	.set	_ZN5ardor4pog39PitchPlanC1ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE,_ZN5ardor4pog39PitchPlanC2ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE
	.align	2
	.p2align 4,,15
	.global	_ZN5ardor4pog319PolyphonicPitchBank7prepareEv
	.type	_ZN5ardor4pog319PolyphonicPitchBank7prepareEv, %function
_ZN5ardor4pog319PolyphonicPitchBank7prepareEv:
.LFB9597:
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gxx_personality_v0
	.cfi_lsda 0x1b,.LLSDA9597
	adrp	x1, :got:__stack_chk_guard	// tmp388,
	ldr	x1, [x1, :got_lo12:__stack_chk_guard]	// tmp388,
	sub	sp, sp, #304	//,,
	.cfi_def_cfa_offset 304
	mov	x2, x0	// tmp743, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 49264	//,
// /probe/scatter-baseline-pitch.cpp:424: void PolyphonicPitchBank::prepare() {
	stp	x29, x30, [sp, 192]	//,,
	.cfi_offset 29, -112
	.cfi_offset 30, -104
	add	x29, sp, 192	//,,
	str	x2, [sp, 80]	// tmp743, %sfp
	stp	x19, x20, [sp, 208]	//,,
	stp	x21, x22, [sp, 224]	//,,
	stp	x23, x24, [sp, 240]	//,,
	stp	x25, x26, [sp, 256]	//,,
	stp	x27, x28, [sp, 272]	//,,
	stp	d8, d9, [sp, 288]	//,,
	.cfi_offset 19, -96
	.cfi_offset 20, -88
	.cfi_offset 21, -80
	.cfi_offset 22, -72
	.cfi_offset 23, -64
	.cfi_offset 24, -56
	.cfi_offset 25, -48
	.cfi_offset 26, -40
	.cfi_offset 27, -32
	.cfi_offset 28, -24
	.cfi_offset 72, -16
	.cfi_offset 73, -8
// /probe/scatter-baseline-pitch.cpp:424: void PolyphonicPitchBank::prepare() {
	ldr	x2, [x1]	// tmp791,
	str	x2, [sp, 184]	// tmp791, D.331676
	mov	x2, 0	// tmp791
.LEHB15:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	bl	_Znwm		//
.LEHE15:
	mov	x26, x0	// _283, tmp744
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x1, 4294967297	// tmp390,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x23, x26	// _278, _283
	adrp	x0, _ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp392,
	add	x0, x0, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp391, tmp392,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x1, [x26, 8]	// tmp390, MEM <unsigned long> [(int *)_283 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	str	x26, [sp, 40]	// _283, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x0, [x23], 16	// tmp391, *_283.D.269132._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x0, x23	//, _278
	bl	_ZN5ardor4pog318PitchInterpolationC1Ev		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 144	//,
.LEHB16:
	bl	_Znwm		//
.LEHE16:
	mov	x21, x0	// _288, tmp745
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x1, 4294967297	// tmp394,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x25, x21	// _272, _288
	adrp	x24, _ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp727,
	add	x0, x24, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp395, tmp727,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x1, [x21, 8]	// tmp394, MEM <unsigned long> [(int *)_288 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x2, 256	//,
	mov	x1, 2048	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x0, [x25], 16	// tmp395, *_288.D.271214._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x0, x25	//, _272
.LEHB17:
	bl	_ZN5ardor4pog312SpectralPlanC1Emm		//
.LEHE17:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 32824	//,
.LEHB18:
	bl	_Znwm		//
.LEHE18:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:52:     return ::__libc_single_threaded;
	adrp	x19, :got:__libc_single_threaded	// tmp726,
	ldr	x19, [x19, :got_lo12:__libc_single_threaded]	// tmp726,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x20, x0	// _296, tmp746
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x2, 4294967297	// tmp402,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x22, x0	// tmp730, _296
	adrp	x28, _ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp725,
	add	x1, x28, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp403, tmp725,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	add	x0, x26, 8	// _306, _283,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x2, [x20, 8]	// tmp402, MEM <unsigned long> [(int *)_296 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x23, x26, [sp, 152]	// _278, _283, MEM[(struct __shared_ptr *)_4]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x1, [x22], 16	// tmp403, *_296.D.271819._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	str	x0, [sp, 96]	// _306, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1101: 	_M_pi = __tmp;
	stp	x25, x21, [sp, 168]	// _272, _288, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w0, .L1984	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	x1, [sp, 40]	// _283, %sfp
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_283 + 8B]
	add	w0, w0, 1	// tmp407, MEM[(_Atomic_word *)_283 + 8B],
	str	w0, [x1, 8]	// tmp407, MEM[(_Atomic_word *)_283 + 8B]
.L1722:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	add	x26, sp, 152	// tmp728,,
	add	x21, sp, 168	// tmp729,,
	mov	x2, x26	//, tmp728
	mov	x1, x21	//, tmp729
	mov	x0, x22	//, tmp730
.LEHB19:
	bl	_ZN5ardor4pog39PitchPlanC1ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE		//
.LEHE19:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x25, [sp, 160]	// _301, MEM[(struct __shared_count *)_4]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x25, .L1724	// _301,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x25, 8	// __both_counts, _301,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _311,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp411,
	cmp	x2, x0	// _311, tmp411
	beq	.L1985		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1726	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x25, 8]	//, MEM[(_Atomic_word *)_301 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp418, __result,
	str	w1, [x25, 8]	// tmp418, MEM[(_Atomic_word *)_301 + 8B]
.L1727:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1986		//,
.L1724:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x25, [sp, 176]	// _302, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x25, .L1730	// _302,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x25, 8	// __both_counts, _302,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _323,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp419,
	cmp	x2, x0	// _323, tmp419
	beq	.L1987		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1732	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x25, 8]	//, MEM[(_Atomic_word *)_302 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp426, __result,
	str	w1, [x25, 8]	// tmp426, MEM[(_Atomic_word *)_302 + 8B]
.L1733:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1988		//,
.L1730:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 144	//,
.LEHB20:
	bl	_Znwm		//
.LEHE20:
	mov	x25, x0	// _357, tmp750
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x1, 4294967297	// tmp436,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	add	x0, x24, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp437, tmp727,
	mov	x27, x25	// _348, _357
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x1, [x25, 8]	// tmp436, MEM <unsigned long> [(int *)_357 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x2, 128	//,
	mov	x1, 1024	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x0, [x27], 16	// tmp437, *_357.D.271214._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x0, x27	//, _348
.LEHB21:
	bl	_ZN5ardor4pog312SpectralPlanC1Emm		//
.LEHE21:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 32824	//,
.LEHB22:
	bl	_Znwm		//
.LEHE22:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x5, [sp, 40]	// _283, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x4, x0	// _365, tmp752
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x2, 4294967297	// tmp444,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x3, x4	// _365, _365
	add	x0, x28, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp445, tmp725,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1101: 	_M_pi = __tmp;
	stp	x27, x25, [sp, 168]	// _348, _357, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x2, [x4, 8]	// tmp444, MEM <unsigned long> [(int *)_365 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w1, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x0, [x3], 16	// tmp445, *_365.D.271819._vptr._Sp_counted_base
	str	x3, [sp, 24]	// tmp732, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	str	x4, [sp, 136]	// _365, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x23, x5, [sp, 152]	// _278, _283, MEM[(struct __shared_ptr *)_4]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w1, .L1989	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x5, 8]	//, MEM[(_Atomic_word *)_283 + 8B]
	add	w0, w0, 1	// tmp449, MEM[(_Atomic_word *)_283 + 8B],
	str	w0, [x5, 8]	// tmp449, MEM[(_Atomic_word *)_283 + 8B]
.L1744:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	ldr	x0, [sp, 24]	//, %sfp
	mov	x2, x26	//, tmp728
	mov	x1, x21	//, tmp729
.LEHB23:
	bl	_ZN5ardor4pog39PitchPlanC1ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE		//
.LEHE23:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x25, [sp, 160]	// _370, MEM[(struct __shared_count *)_4]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x25, .L1746	// _370,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x25, 8	// __both_counts, _370,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _380,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp453,
	cmp	x2, x0	// _380, tmp453
	beq	.L1990		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1748	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x25, 8]	//, MEM[(_Atomic_word *)_370 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp460, __result,
	str	w1, [x25, 8]	// tmp460, MEM[(_Atomic_word *)_370 + 8B]
.L1749:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1991		//,
.L1746:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x25, [sp, 176]	// _371, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x25, .L1752	// _371,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x25, 8	// __both_counts, _371,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _392,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp461,
	cmp	x2, x0	// _392, tmp461
	beq	.L1992		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1754	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x25, 8]	//, MEM[(_Atomic_word *)_371 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp468, __result,
	str	w1, [x25, 8]	// tmp468, MEM[(_Atomic_word *)_371 + 8B]
.L1755:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1993		//,
.L1752:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 144	//,
.LEHB24:
	bl	_Znwm		//
.LEHE24:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x1, 4294967297	// tmp478,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x27, x0	// _417, _426
	add	x24, x24, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp479, tmp727,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x25, x0	// _426, tmp756
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x1, [x0, 8]	// tmp478, MEM <unsigned long> [(int *)_426 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x2, 512	//,
	mov	x1, 4096	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x24, [x27], 16	// tmp479, *_426.D.271214._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	mov	x0, x27	//, _417
.LEHB25:
	bl	_ZN5ardor4pog312SpectralPlanC1Emm		//
.LEHE25:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x0, 32824	//,
.LEHB26:
	bl	_Znwm		//
.LEHE26:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x5, [sp, 40]	// _283, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	mov	x4, x0	// _434, tmp758
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	mov	x2, 4294967297	// tmp486,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	mov	x3, x4	// _434, _434
	add	x0, x28, :lo12:_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE+16	// tmp487, tmp725,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1101: 	_M_pi = __tmp;
	stp	x27, x25, [sp, 168]	// _417, _426, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:130:       : _M_use_count(1), _M_weak_count(1) { }
	str	x2, [x4, 8]	// tmp486, MEM <unsigned long> [(int *)_434 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w1, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x0, [x3], 16	// tmp487, *_434.D.271819._vptr._Sp_counted_base
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:151: 	return static_cast<_Tp*>(_GLIBCXX_OPERATOR_NEW(__n * sizeof(_Tp)));
	str	x4, [sp, 32]	// _434, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:600: 	: _M_impl(__a)
	str	x3, [sp, 56]	// tmp724, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x23, x5, [sp, 152]	// _278, _283, MEM[(struct __shared_ptr *)_4]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w1, .L1994	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x5, 8]	//, MEM[(_Atomic_word *)_283 + 8B]
	add	w0, w0, 1	// tmp491, MEM[(_Atomic_word *)_283 + 8B],
	str	w0, [x5, 8]	// tmp491, MEM[(_Atomic_word *)_283 + 8B]
.L1766:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/stl_construct.h:119:       ::new((void*)__p) _Tp(std::forward<_Args>(__args)...);
	ldr	x0, [sp, 56]	//, %sfp
	mov	x2, x26	//, tmp728
	mov	x1, x21	//, tmp729
.LEHB27:
	bl	_ZN5ardor4pog39PitchPlanC1ESt10shared_ptrIKNS0_12SpectralPlanEES2_IKNS0_18PitchInterpolationEE		//
.LEHE27:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x23, [sp, 160]	// _439, MEM[(struct __shared_count *)_4]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x23, .L1768	// _439,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x23, 8	// __both_counts, _439,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _449,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp495,
	cmp	x2, x0	// _449, tmp495
	beq	.L1995		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1770	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x23, 8]	//, MEM[(_Atomic_word *)_439 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp502, __result,
	str	w1, [x23, 8]	// tmp502, MEM[(_Atomic_word *)_439 + 8B]
.L1771:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1996		//,
.L1768:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x23, [sp, 176]	// _440, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x23, .L1774	// _440,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x23, 8	// __both_counts, _440,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x2, [x1]	// _461,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp503,
	cmp	x2, x0	// _461, tmp503
	beq	.L1997		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1776	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x23, 8]	//, MEM[(_Atomic_word *)_440 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp510, __result,
	str	w1, [x23, 8]	// tmp510, MEM[(_Atomic_word *)_440 + 8B]
.L1777:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L1998		//,
.L1774:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:277:       { return static_cast<pointer>(_M_elems); }
	ldr	x2, [sp, 80]	// this, %sfp
// /probe/scatter-baseline-pitch.cpp:434:     longFrames_[channel].prepare(longPlan);
	mov	w0, 32768	// tmp789,
	movk	w0, 0x46bb, lsl 16	// tmp789,,
	mov	x5, 50368	//,
// /probe/scatter-baseline-pitch.cpp:437:     lowFrames_[channel].prepare(lowPlan, 400);
	mov	w1, 1137180672	// tmp790,
// /probe/scatter-baseline-pitch.cpp:429:   for (std::size_t channel = 0; channel < 2; ++channel) {
	str	xzr, [sp, 48]	//, %sfp
	ldr	x26, [sp, 136]	// _365, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	mov	x24, 0	// ivtmp.2871,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x27, 4294967297	// tmp738,
// /probe/scatter-baseline-pitch.cpp:434:     longFrames_[channel].prepare(longPlan);
	fmov	s8, w0	// tmp739, tmp789
// /probe/scatter-baseline-pitch.cpp:437:     lowFrames_[channel].prepare(lowPlan, 400);
	fmov	s9, w1	// tmp740, tmp790
	add	x1, x20, 24	// tmp731, _296,
	mov	x0, x2	// this, this
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:277:       { return static_cast<pointer>(_M_elems); }
	add	x3, x2, 73728	// _95, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x25, x2, 303104	// _94, this,
	add	x2, x2, x5	// ivtmp.2872, this,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:277:       { return static_cast<pointer>(_M_elems); }
	add	x3, x3, 1536	// _95, _95,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:137:       { return iterator(data() + _Nm); }
	add	x25, x25, 1312	// _94, _94,
	str	x2, [sp, 8]	// ivtmp.2872, %sfp
	add	x2, x0, 384	// ivtmp.2874, this,
	add	x0, x0, 376832	// _178, this,
	add	x0, x0, 3968	// _178, _178,
	stp	x3, x1, [sp, 120]	// _95, tmp731, %sfp
	str	x2, [sp, 16]	// ivtmp.2874, %sfp
	str	x0, [sp, 64]	// _178, %sfp
.L1779:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	ldr	x1, [sp, 16]	// ivtmp.2874, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1522:       __shared_ptr(const __shared_ptr&) noexcept = default;
	ldr	x0, [x22]	// MEM[(const struct __shared_ptr &)_296 + 16]._M_ptr, MEM[(const struct __shared_ptr &)_296 + 16]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	sub	x28, x1, #384	// _77, ivtmp.2874,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x1, [sp, 128]	// tmp731, %sfp
	ldr	x1, [x1]	// _485, MEM[(const struct __shared_count &)_296 + 24]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x1, [sp, 168]	// MEM[(const struct __shared_ptr &)_296 + 16]._M_ptr, _485, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1077: 	if (_M_pi != nullptr)
	cbz	x1, .L1784	// _485,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1785	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_485 + 8B]
	add	w0, w0, 1	// tmp529, MEM[(_Atomic_word *)_485 + 8B],
	str	w0, [x1, 8]	// tmp529, MEM[(_Atomic_word *)_485 + 8B]
.L1784:
	ldr	w23, [sp, 48]	//, %sfp
// /probe/scatter-baseline-pitch.cpp:432:     longAnalysis_[channel].prepare(longPlan->spectral, channel == 1);
	mov	x0, x28	//, _77
	mov	x1, x21	//, tmp729
	mov	w2, w23	//, _281
.LEHB28:
	bl	_ZN5ardor4pog316SpectralAnalysis7prepareESt10shared_ptrIKNS0_12SpectralPlanEEb		//
.LEHE28:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x28, [sp, 176]	// _82, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x28, .L1787	// _82,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x28, 8	// __both_counts, _82,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _491,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _491, tmp738
	beq	.L1999		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1789	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x28, 8]	//, MEM[(_Atomic_word *)_82 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp546, __result,
	str	w1, [x28, 8]	// tmp546, MEM[(_Atomic_word *)_82 + 8B]
.L1790:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2000		//,
.L1787:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1522:       __shared_ptr(const __shared_ptr&) noexcept = default;
	ldp	x1, x0, [sp, 16]	// ivtmp.2874, tmp732, %sfp
	ldr	x0, [x0]	// MEM[(const struct __shared_ptr &)_365 + 16]._M_ptr, MEM[(const struct __shared_ptr &)_365 + 16]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	sub	x28, x1, #192	// _81, ivtmp.2874,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x1, [x26, 24]	// _502, MEM[(const struct __shared_count &)_365 + 24]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x1, [sp, 168]	// MEM[(const struct __shared_ptr &)_365 + 16]._M_ptr, _502, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1077: 	if (_M_pi != nullptr)
	cbz	x1, .L1792	// _502,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1793	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_502 + 8B]
	add	w0, w0, 1	// tmp554, MEM[(_Atomic_word *)_502 + 8B],
	str	w0, [x1, 8]	// tmp554, MEM[(_Atomic_word *)_502 + 8B]
.L1792:
// /probe/scatter-baseline-pitch.cpp:433:     shortAnalysis_[channel].prepare(shortPlan->spectral, channel == 1);
	mov	x0, x28	//, _81
	mov	w2, w23	//, _281
	mov	x1, x21	//, tmp729
.LEHB29:
	bl	_ZN5ardor4pog316SpectralAnalysis7prepareESt10shared_ptrIKNS0_12SpectralPlanEEb		//
.LEHE29:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	ldr	x0, [sp, 8]	// ivtmp.2872, %sfp
	mov	x4, -49792	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x28, [sp, 176]	// _84, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x2, x0, x4	// _162, ivtmp.2872,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x28, .L1799	// _84,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x28, 8	// __both_counts, _84,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _508,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _508, tmp738
	beq	.L2001		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1797	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x28, 8]	//, MEM[(_Atomic_word *)_84 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp566, __result,
	str	w1, [x28, 8]	// tmp566, MEM[(_Atomic_word *)_84 + 8B]
.L1798:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2002		//,
.L1799:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x22, x20, [sp, 168]	// tmp730, _296, MEM[(struct __shared_ptr *)_5]._M_ptr
.L1795:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	add	x1, x20, 8	// _520, _296,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	str	x1, [sp, 72]	// _520, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w0, .L1800	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)_296 + 8B]
	add	w0, w0, 1	// tmp569, MEM[(_Atomic_word *)_296 + 8B],
	str	w0, [x20, 8]	// tmp569, MEM[(_Atomic_word *)_296 + 8B]
.L1801:
// /probe/scatter-baseline-pitch.cpp:434:     longFrames_[channel].prepare(longPlan);
	fmov	s0, s8	//, tmp739
	mov	x0, x2	//, _162
	mov	x1, x21	//, tmp729
.LEHB30:
	bl	_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf		//
.LEHE30:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	ldr	x0, [sp, 8]	// ivtmp.2872, %sfp
	mov	x3, -24896	//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x28, [sp, 176]	// _86, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x2, x0, x3	// _155, ivtmp.2872,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x28, .L1802	// _86,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x28, 8	// __both_counts, _86,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _525,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _525, tmp738
	beq	.L2003		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1805	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x28, 8]	//, MEM[(_Atomic_word *)_86 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp581, __result,
	str	w1, [x28, 8]	// tmp581, MEM[(_Atomic_word *)_86 + 8B]
.L1806:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2004		//,
.L1802:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1528: 	: _M_ptr(__r._M_ptr), _M_refcount(__r._M_refcount)
	ldr	x0, [sp, 24]	// tmp732, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x26, [sp, 168]	// tmp732, _365, MEM[(struct __shared_ptr *)_5]._M_ptr
.L1804:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	add	x1, x26, 8	// _537, _365,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	str	x1, [sp, 104]	// _537, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w0, .L1808	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x26, 8]	//, MEM[(_Atomic_word *)_365 + 8B]
	add	w0, w0, 1	// tmp584, MEM[(_Atomic_word *)_365 + 8B],
	str	w0, [x26, 8]	// tmp584, MEM[(_Atomic_word *)_365 + 8B]
.L1809:
// /probe/scatter-baseline-pitch.cpp:435:     shortFrames_[channel].prepare(shortPlan);
	fmov	s0, s8	//, tmp739
	mov	x0, x2	//, _155
	mov	x1, x21	//, tmp729
.LEHB31:
	bl	_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf		//
.LEHE31:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x28, [sp, 176]	// _91, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x28, .L1811	// _91,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x28, 8	// __both_counts, _91,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _542,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _542, tmp738
	beq	.L2005		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1813	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x28, 8]	//, MEM[(_Atomic_word *)_91 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp595, __result,
	str	w1, [x28, 8]	// tmp595, MEM[(_Atomic_word *)_91 + 8B]
.L1814:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2006		//,
.L1811:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x1, [sp, 32]	// _434, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1522:       __shared_ptr(const __shared_ptr&) noexcept = default;
	ldr	x0, [sp, 56]	// tmp724, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x1, [x1, 24]	// _553, MEM[(const struct __shared_count &)_434 + 24]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1522:       __shared_ptr(const __shared_ptr&) noexcept = default;
	ldr	x0, [x0]	// MEM[(const struct __shared_ptr &)_434 + 16]._M_ptr, MEM[(const struct __shared_ptr &)_434 + 16]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x1, [sp, 168]	// MEM[(const struct __shared_ptr &)_434 + 16]._M_ptr, _553, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1077: 	if (_M_pi != nullptr)
	cbz	x1, .L1816	// _553,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1817	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_553 + 8B]
	add	w0, w0, 1	// tmp603, MEM[(_Atomic_word *)_553 + 8B],
	str	w0, [x1, 8]	// tmp603, MEM[(_Atomic_word *)_553 + 8B]
.L1816:
// /probe/scatter-baseline-pitch.cpp:436:     lowAnalysis_[channel].prepare(lowPlan->spectral, channel == 1);
	ldr	x0, [sp, 16]	//, %sfp
	mov	w2, w23	//, _281
	mov	x1, x21	//, tmp729
.LEHB32:
	bl	_ZN5ardor4pog316SpectralAnalysis7prepareESt10shared_ptrIKNS0_12SpectralPlanEEb		//
.LEHE32:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x23, [sp, 176]	// _93, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x23, .L1818	// _93,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x23, 8	// __both_counts, _93,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _559,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _559, tmp738
	beq	.L2007		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1821	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x23, 8]	//, MEM[(_Atomic_word *)_93 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp614, __result,
	str	w1, [x23, 8]	// tmp614, MEM[(_Atomic_word *)_93 + 8B]
.L1822:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2008		//,
.L1818:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1528: 	: _M_ptr(__r._M_ptr), _M_refcount(__r._M_refcount)
	ldr	x0, [sp, 56]	// tmp724, %sfp
	str	x0, [sp, 168]	// tmp724, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	ldr	x0, [sp, 32]	// _434, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	add	x2, x0, 8	// _571, _434,
	mov	x1, x0	// _434, _434
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	str	x0, [sp, 176]	// _434, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:152:       { __gnu_cxx::__atomic_add_dispatch(&_M_use_count, 1); }
	str	x2, [sp, 112]	// _571, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w0, .L1824	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x1, 8]	//, MEM[(_Atomic_word *)_434 + 8B]
	add	w0, w0, 1	// tmp617, MEM[(_Atomic_word *)_434 + 8B],
	str	w0, [x1, 8]	// tmp617, MEM[(_Atomic_word *)_434 + 8B]
.L1825:
// /probe/scatter-baseline-pitch.cpp:437:     lowFrames_[channel].prepare(lowPlan, 400);
	ldr	x0, [sp, 8]	//, %sfp
	fmov	s0, s9	//, tmp740
	mov	x1, x21	//, tmp729
.LEHB33:
	bl	_ZN5ardor4pog310PitchFrame7prepareESt10shared_ptrIKNS0_9PitchPlanEEf		//
.LEHE33:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x23, [sp, 176]	// _96, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x23, .L1827	// _96,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x23, 8	// __both_counts, _96,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _576,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _576, tmp738
	beq	.L2009		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1829	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x23, 8]	//, MEM[(_Atomic_word *)_96 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp628, __result,
	str	w1, [x23, 8]	// tmp628, MEM[(_Atomic_word *)_96 + 8B]
.L1830:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2010		//,
.L1827:
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	ldr	x0, [sp, 120]	// _95, %sfp
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	mov	x28, 38192	// tmp737,
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	cmp	x25, x0	// _94, _95
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	mov	x23, x0	// __for_begin, _95
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	beq	.L1842		//,
	str	x26, [sp, 88]	// _365, %sfp
	b	.L1832		//
	.p2align 2,,3
.L2014:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)_296 + 8B]
	add	w0, w0, 1	// tmp632, MEM[(_Atomic_word *)_296 + 8B],
	str	w0, [x20, 8]	// tmp632, MEM[(_Atomic_word *)_296 + 8B]
.L1835:
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	mov	x0, x26	//, _483
	mov	x1, x21	//, tmp729
.LEHB34:
	bl	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb.constprop.0		//
.LEHE34:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x26, [sp, 176]	// _98, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x26, .L1837	// _98,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x26, 8	// __both_counts, _98,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _593,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _593, tmp738
	beq	.L2011		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1839	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x26, 8]	//, MEM[(_Atomic_word *)_98 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp642, __result,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	str	w1, [x26, 8]	// tmp642, MEM[(_Atomic_word *)_98 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	beq	.L2012		//,
.L1837:
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	add	x23, x23, x28	// __for_begin, __for_begin, tmp737
// /probe/scatter-baseline-pitch.cpp:438:     for (auto& voice : longVoices_) voice[channel].prepare(longPlan, kExperimentalFreezeEnabled);
	cmp	x23, x25	// __for_begin, _94
	beq	.L2013		//,
.L1832:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x26, x23, x24	// _483, __for_begin, ivtmp.2871
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x22, x20, [sp, 168]	// tmp730, _296, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbnz	w0, .L2014	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, 1	//,
	ldr	x1, [sp, 72]	//, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1835		//
	.p2align 2,,3
.L2013:
	ldr	x26, [sp, 88]	// _365, %sfp
.L1842:
// /probe/scatter-baseline-pitch.cpp:439:     for (auto& voice : shortVoices_) voice[channel].prepare(shortPlan);
	mov	x23, x25	// __for_begin, _94
// /probe/scatter-baseline-pitch.cpp:439:     for (auto& voice : shortVoices_) voice[channel].prepare(shortPlan);
	mov	x28, 38192	// tmp734,
.L1833:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1528: 	: _M_ptr(__r._M_ptr), _M_refcount(__r._M_refcount)
	ldr	x1, [sp, 24]	// tmp732, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/array:203: 	return _M_elems[__n];
	add	x2, x23, x24	// _959, __for_begin, ivtmp.2871
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x1, x26, [sp, 168]	// tmp732, _365, MEM[(struct __shared_ptr *)_5]._M_ptr
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:108:     if (__is_single_threaded())
	cbz	w0, .L1843	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:92:   { *__mem += __val; }
	ldr	w0, [x26, 8]	//, MEM[(_Atomic_word *)_365 + 8B]
	add	w0, w0, 1	// tmp648, MEM[(_Atomic_word *)_365 + 8B],
	str	w0, [x26, 8]	// tmp648, MEM[(_Atomic_word *)_365 + 8B]
.L1844:
// /probe/scatter-baseline-pitch.cpp:439:     for (auto& voice : shortVoices_) voice[channel].prepare(shortPlan);
	mov	x0, x2	//, _959
	mov	x1, x21	//, tmp729
.LEHB35:
	bl	_ZN5ardor4pog313PitchRenderer7prepareESt10shared_ptrIKNS0_9PitchPlanEEb.constprop.0		//
.LEHE35:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x2, [sp, 176]	// _102, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x2, .L1846	// _102,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:334: 	  auto __both_counts = reinterpret_cast<long long*>(&_M_use_count);
	add	x1, x2, 8	// __both_counts, _102,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldar	x0, [x1]	// _610,* __both_counts
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	cmp	x0, x27	// _610, tmp738
	beq	.L2015		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1848	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x2, 8]	//, MEM[(_Atomic_word *)_102 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp658, __result,
	str	w1, [x2, 8]	// tmp658, MEM[(_Atomic_word *)_102 + 8B]
.L1849:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2016		//,
.L1846:
// /probe/scatter-baseline-pitch.cpp:439:     for (auto& voice : shortVoices_) voice[channel].prepare(shortPlan);
	ldr	x0, [sp, 64]	// _178, %sfp
// /probe/scatter-baseline-pitch.cpp:439:     for (auto& voice : shortVoices_) voice[channel].prepare(shortPlan);
	add	x23, x23, x28	// __for_begin, __for_begin, tmp734
// /probe/scatter-baseline-pitch.cpp:439:     for (auto& voice : shortVoices_) voice[channel].prepare(shortPlan);
	cmp	x23, x0	// __for_begin, _178
	bne	.L1833		//,
// /probe/scatter-baseline-pitch.cpp:429:   for (std::size_t channel = 0; channel < 2; ++channel) {
	mov	x0, 19096	//,
	mov	x2, 12448	//,
	add	x24, x24, x0	// ivtmp.2871, ivtmp.2871,
	ldr	x0, [sp, 8]	// ivtmp.2872, %sfp
	mov	x1, 1	// channel,
	add	x0, x0, x2	// ivtmp.2872, ivtmp.2872,
	str	x0, [sp, 8]	// ivtmp.2872, %sfp
	ldr	x0, [sp, 16]	// ivtmp.2874, %sfp
	add	x0, x0, 96	// ivtmp.2874, ivtmp.2874,
	str	x0, [sp, 16]	// ivtmp.2874, %sfp
	ldr	x0, [sp, 48]	// channel, %sfp
	cbnz	x0, .L2017	// channel,
	str	x1, [sp, 48]	// channel, %sfp
	b	.L1779		//
	.p2align 2,,3
.L1839:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	bne	.L1837		//,
.L2012:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x26	//, _98
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1837		//
	.p2align 2,,3
.L2011:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x26]	// _98->_vptr._Sp_counted_base, _98->_vptr._Sp_counted_base
	mov	x0, x26	//, _98
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_600 + 16B], MEM[(int (*) () *)_600 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x26, 8]	//, MEM <unsigned long> [(int *)_98 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_600 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x26]	// _98->_vptr._Sp_counted_base, _98->_vptr._Sp_counted_base
	mov	x0, x26	//, _98
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_602 + 24B], MEM[(int (*) () *)_602 + 24B]
	blr	x1		// MEM[(int (*) () *)_602 + 24B]
	b	.L1837		//
	.p2align 2,,3
.L2017:
// /probe/scatter-baseline-pitch.cpp:445:   prepared_ = true;
	ldr	x0, [sp, 80]	// this, %sfp
	add	x2, x0, 536576	// tmp668, this,
	strb	w1, [x2, 2265]	// channel, this_28(D)->prepared_
// /probe/scatter-baseline-pitch.cpp:446:   reset();
	bl	_ZN5ardor4pog319PolyphonicPitchBank5resetEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldr	x0, [sp, 112]	// _571, %sfp
	ldar	x1, [x0]	// _622,* _571
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp670,
	cmp	x1, x0	// _622, tmp670
	beq	.L2018		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1853	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	x2, [sp, 32]	// _434, %sfp
	ldr	w0, [x2, 8]	//, MEM[(_Atomic_word *)_434 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp677, __result,
	str	w1, [x2, 8]	// tmp677, MEM[(_Atomic_word *)_434 + 8B]
.L1854:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2019		//,
.L1852:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldr	x0, [sp, 104]	// _537, %sfp
	ldar	x1, [x0]	// _634,* _537
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp678,
	cmp	x1, x0	// _634, tmp678
	beq	.L2020		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1857	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	x2, [sp, 136]	// _365, %sfp
	ldr	w0, [x2, 8]	//, MEM[(_Atomic_word *)_365 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp685, __result,
	str	w1, [x2, 8]	// tmp685, MEM[(_Atomic_word *)_365 + 8B]
.L1858:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2021		//,
.L1856:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldr	x0, [sp, 72]	// _520, %sfp
	ldar	x1, [x0]	// _646,* _520
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp686,
	cmp	x1, x0	// _646, tmp686
	beq	.L2022		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1861	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	w0, [x20, 8]	//, MEM[(_Atomic_word *)_296 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp693, __result,
	str	w1, [x20, 8]	// tmp693, MEM[(_Atomic_word *)_296 + 8B]
.L1862:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
	beq	.L2023		//,
.L1860:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	ldr	x0, [sp, 96]	// _306, %sfp
	ldar	x1, [x0]	// _658,* _306
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:337: 	  if (__atomic_load_n(__both_counts, __ATOMIC_ACQUIRE) == __unique_ref)
	mov	x0, 4294967297	// tmp694,
	cmp	x1, x0	// _658, tmp694
	beq	.L2024		//,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:98:     if (__is_single_threaded())
	ldrb	w0, [x19]	// __libc_single_threaded, __libc_single_threaded
	cbz	w0, .L1865	// __libc_single_threaded,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:84:     _Atomic_word __result = *__mem;
	ldr	x2, [sp, 40]	// _283, %sfp
	ldr	w0, [x2, 8]	//, MEM[(_Atomic_word *)_283 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:85:     *__mem += __val;
	sub	w1, w0, #1	// tmp702, __result,
	str	w1, [x2, 8]	// tmp702, MEM[(_Atomic_word *)_283 + 8B]
.L1866:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	cmp	w0, 1	// __result,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	adrp	x0, :got:__stack_chk_guard	// tmp703,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp703,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:350: 	  if (__gnu_cxx::__exchange_and_add_dispatch(&_M_use_count, -1) == 1)
	beq	.L2025		//,
// /probe/scatter-baseline-pitch.cpp:447: }
	ldr	x2, [sp, 184]	// tmp798, D.331676
	ldr	x1, [x0]	// tmp799,
	subs	x2, x2, x1	// tmp798, tmp799
	mov	x1, 0	// tmp799
	bne	.L1976		//,
	ldp	x29, x30, [sp, 192]	//,,
	ldp	x19, x20, [sp, 208]	//,,
	ldp	x21, x22, [sp, 224]	//,,
	ldp	x23, x24, [sp, 240]	//,,
	ldp	x25, x26, [sp, 256]	//,,
	ldp	x27, x28, [sp, 272]	//,,
	ldp	d8, d9, [sp, 288]	//,,
	add	sp, sp, 304	//,,
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_restore 72
	.cfi_restore 73
	.cfi_def_cfa_offset 0
	ret	
	.p2align 2,,3
.L1843:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 104]	//, %sfp
	mov	w0, 1	//,
	str	x2, [sp, 88]	// _959, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
	ldr	x2, [sp, 88]	// _959, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1844		//
	.p2align 2,,3
.L1848:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	str	x2, [sp, 88]	// _102, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
	ldr	x2, [sp, 88]	// _102, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1849		//
	.p2align 2,,3
.L1824:
	mov	x1, x2	//, _571
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1825		//
	.p2align 2,,3
.L1817:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x1, 8	//, _553,
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1816		//
	.p2align 2,,3
.L1808:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x26, 8	//, _365,
	mov	w0, 1	//,
	str	x2, [sp, 88]	// _155, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
	ldr	x2, [sp, 88]	// _155, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1809		//
	.p2align 2,,3
.L1800:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x20, 8	//, _296,
	mov	w0, 1	//,
	str	x2, [sp, 88]	// _162, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
	ldr	x2, [sp, 88]	// _162, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1801		//
	.p2align 2,,3
.L1785:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x1, 8	//, _485,
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1784		//
	.p2align 2,,3
.L1793:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	add	x1, x1, 8	//, _502,
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1792		//
	.p2align 2,,3
.L2015:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x2]	// _102->_vptr._Sp_counted_base, _102->_vptr._Sp_counted_base
	mov	x0, x2	//, _102
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	x2, [sp, 88]	// _102, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_617 + 16B], MEM[(int (*) () *)_617 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x2, 8]	//, MEM <unsigned long> [(int *)_102 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_617 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x2, [sp, 88]	// _102, %sfp
	ldr	x1, [x2]	// _102->_vptr._Sp_counted_base, _102->_vptr._Sp_counted_base
	mov	x0, x2	//, _102
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_619 + 24B], MEM[(int (*) () *)_619 + 24B]
	blr	x1		// MEM[(int (*) () *)_619 + 24B]
	b	.L1846		//
	.p2align 2,,3
.L1989:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 96]	//, %sfp
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1744		//
	.p2align 2,,3
.L1748:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1749		//
	.p2align 2,,3
.L1754:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1755		//
.L1853:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 112]	//, %sfp
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1854		//
.L1776:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1777		//
.L1770:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1771		//
	.p2align 2,,3
.L1984:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 96]	//, %sfp
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1722		//
	.p2align 2,,3
.L1797:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	str	x2, [sp, 72]	// _162, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
	ldr	x2, [sp, 72]	// _162, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1798		//
	.p2align 2,,3
.L1829:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1830		//
	.p2align 2,,3
.L1821:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1822		//
	.p2align 2,,3
.L1789:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1790		//
	.p2align 2,,3
.L1813:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1814		//
	.p2align 2,,3
.L1805:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	str	x2, [sp, 88]	// _155, %sfp
	bl	__aarch64_ldadd4_acq_rel		//
	ldr	x2, [sp, 88]	// _155, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1806		//
	.p2align 2,,3
.L1994:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 96]	//, %sfp
	mov	w0, 1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:71:   { __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	b	.L1766		//
	.p2align 2,,3
.L1999:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x28]	// _82->_vptr._Sp_counted_base, _82->_vptr._Sp_counted_base
	mov	x0, x28	//, _82
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_498 + 16B], MEM[(int (*) () *)_498 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x28, 8]	//, MEM <unsigned long> [(int *)_82 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_498 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x28]	// _82->_vptr._Sp_counted_base, _82->_vptr._Sp_counted_base
	mov	x0, x28	//, _82
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_500 + 24B], MEM[(int (*) () *)_500 + 24B]
	blr	x1		// MEM[(int (*) () *)_500 + 24B]
	b	.L1787		//
	.p2align 2,,3
.L2005:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x28]	// _91->_vptr._Sp_counted_base, _91->_vptr._Sp_counted_base
	mov	x0, x28	//, _91
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_549 + 16B], MEM[(int (*) () *)_549 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x28, 8]	//, MEM <unsigned long> [(int *)_91 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_549 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x28]	// _91->_vptr._Sp_counted_base, _91->_vptr._Sp_counted_base
	mov	x0, x28	//, _91
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_551 + 24B], MEM[(int (*) () *)_551 + 24B]
	blr	x1		// MEM[(int (*) () *)_551 + 24B]
	b	.L1811		//
	.p2align 2,,3
.L2009:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x23]	// _96->_vptr._Sp_counted_base, _96->_vptr._Sp_counted_base
	mov	x0, x23	//, _96
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_583 + 16B], MEM[(int (*) () *)_583 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x23, 8]	//, MEM <unsigned long> [(int *)_96 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_583 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x23]	// _96->_vptr._Sp_counted_base, _96->_vptr._Sp_counted_base
	mov	x0, x23	//, _96
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_585 + 24B], MEM[(int (*) () *)_585 + 24B]
	blr	x1		// MEM[(int (*) () *)_585 + 24B]
	b	.L1827		//
	.p2align 2,,3
.L2007:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x23]	// _93->_vptr._Sp_counted_base, _93->_vptr._Sp_counted_base
	mov	x0, x23	//, _93
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_566 + 16B], MEM[(int (*) () *)_566 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x23, 8]	//, MEM <unsigned long> [(int *)_93 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_566 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x23]	// _93->_vptr._Sp_counted_base, _93->_vptr._Sp_counted_base
	mov	x0, x23	//, _93
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_568 + 24B], MEM[(int (*) () *)_568 + 24B]
	blr	x1		// MEM[(int (*) () *)_568 + 24B]
	b	.L1818		//
	.p2align 2,,3
.L2001:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x28]	// _84->_vptr._Sp_counted_base, _84->_vptr._Sp_counted_base
	mov	x0, x28	//, _84
	str	x2, [sp, 72]	// _162, %sfp
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_515 + 16B], MEM[(int (*) () *)_515 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x28, 8]	//, MEM <unsigned long> [(int *)_84 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_515 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x28]	// _84->_vptr._Sp_counted_base, _84->_vptr._Sp_counted_base
	mov	x0, x28	//, _84
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_517 + 24B], MEM[(int (*) () *)_517 + 24B]
	blr	x1		// MEM[(int (*) () *)_517 + 24B]
	ldr	x2, [sp, 72]	// _162, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x22, x20, [sp, 168]	// tmp730, _296, MEM[(struct __shared_ptr *)_5]._M_ptr
	b	.L1795		//
	.p2align 2,,3
.L2003:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x28]	// _86->_vptr._Sp_counted_base, _86->_vptr._Sp_counted_base
	mov	x0, x28	//, _86
	str	x2, [sp, 88]	// _155, %sfp
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_532 + 16B], MEM[(int (*) () *)_532 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x28, 8]	//, MEM <unsigned long> [(int *)_86 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_532 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x28]	// _86->_vptr._Sp_counted_base, _86->_vptr._Sp_counted_base
	mov	x0, x28	//, _86
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_534 + 24B], MEM[(int (*) () *)_534 + 24B]
	blr	x1		// MEM[(int (*) () *)_534 + 24B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1528: 	: _M_ptr(__r._M_ptr), _M_refcount(__r._M_refcount)
	ldr	x0, [sp, 24]	// tmp732, %sfp
	ldr	x2, [sp, 88]	// _155, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x26, [sp, 168]	// tmp732, _365, MEM[(struct __shared_ptr *)_5]._M_ptr
	b	.L1804		//
	.p2align 2,,3
.L1726:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1727		//
	.p2align 2,,3
.L1732:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1733		//
	.p2align 2,,3
.L1987:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x25]	// _302->_vptr._Sp_counted_base, _302->_vptr._Sp_counted_base
	mov	x0, x25	//, _302
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_330 + 16B], MEM[(int (*) () *)_330 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x25, 8]	//, MEM <unsigned long> [(int *)_302 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_330 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x25]	// _302->_vptr._Sp_counted_base, _302->_vptr._Sp_counted_base
	mov	x0, x25	//, _302
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_332 + 24B], MEM[(int (*) () *)_332 + 24B]
	blr	x1		// MEM[(int (*) () *)_332 + 24B]
	b	.L1730		//
	.p2align 2,,3
.L1985:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x25]	// _301->_vptr._Sp_counted_base, _301->_vptr._Sp_counted_base
	mov	x0, x25	//, _301
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_318 + 16B], MEM[(int (*) () *)_318 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x25, 8]	//, MEM <unsigned long> [(int *)_301 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_318 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x25]	// _301->_vptr._Sp_counted_base, _301->_vptr._Sp_counted_base
	mov	x0, x25	//, _301
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_320 + 24B], MEM[(int (*) () *)_320 + 24B]
	blr	x1		// MEM[(int (*) () *)_320 + 24B]
	b	.L1724		//
	.p2align 2,,3
.L2016:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x2	//, _102
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1846		//
.L1865:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 96]	//, %sfp
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1866		//
.L1861:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 72]	//, %sfp
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1862		//
.L1857:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:66:   { return __atomic_fetch_add(__mem, __val, __ATOMIC_ACQ_REL); }
	ldr	x1, [sp, 104]	//, %sfp
	mov	w0, -1	//,
	bl	__aarch64_ldadd4_acq_rel		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/ext/atomicity.h:101:       return __exchange_and_add(__mem, __val);
	b	.L1858		//
.L1990:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x25]	// _370->_vptr._Sp_counted_base, _370->_vptr._Sp_counted_base
	mov	x0, x25	//, _370
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_387 + 16B], MEM[(int (*) () *)_387 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x25, 8]	//, MEM <unsigned long> [(int *)_370 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_387 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x25]	// _370->_vptr._Sp_counted_base, _370->_vptr._Sp_counted_base
	mov	x0, x25	//, _370
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_389 + 24B], MEM[(int (*) () *)_389 + 24B]
	blr	x1		// MEM[(int (*) () *)_389 + 24B]
	b	.L1746		//
.L1992:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x25]	// _371->_vptr._Sp_counted_base, _371->_vptr._Sp_counted_base
	mov	x0, x25	//, _371
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_399 + 16B], MEM[(int (*) () *)_399 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x25, 8]	//, MEM <unsigned long> [(int *)_371 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_399 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x25]	// _371->_vptr._Sp_counted_base, _371->_vptr._Sp_counted_base
	mov	x0, x25	//, _371
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_401 + 24B], MEM[(int (*) () *)_401 + 24B]
	blr	x1		// MEM[(int (*) () *)_401 + 24B]
	b	.L1752		//
.L1995:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x23]	// _439->_vptr._Sp_counted_base, _439->_vptr._Sp_counted_base
	mov	x0, x23	//, _439
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_456 + 16B], MEM[(int (*) () *)_456 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x23, 8]	//, MEM <unsigned long> [(int *)_439 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_456 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x23]	// _439->_vptr._Sp_counted_base, _439->_vptr._Sp_counted_base
	mov	x0, x23	//, _439
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_458 + 24B], MEM[(int (*) () *)_458 + 24B]
	blr	x1		// MEM[(int (*) () *)_458 + 24B]
	b	.L1768		//
.L1997:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x23]	// _440->_vptr._Sp_counted_base, _440->_vptr._Sp_counted_base
	mov	x0, x23	//, _440
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_468 + 16B], MEM[(int (*) () *)_468 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x23, 8]	//, MEM <unsigned long> [(int *)_440 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_468 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x23]	// _440->_vptr._Sp_counted_base, _440->_vptr._Sp_counted_base
	mov	x0, x23	//, _440
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_470 + 24B], MEM[(int (*) () *)_470 + 24B]
	blr	x1		// MEM[(int (*) () *)_470 + 24B]
	b	.L1774		//
	.p2align 2,,3
.L2018:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x21, [sp, 32]	// _434, %sfp
	ldr	x1, [x21]	// MEM[(struct _Sp_counted_base *)_434]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_434]._vptr._Sp_counted_base
	mov	x0, x21	//, _434
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_629 + 16B], MEM[(int (*) () *)_629 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x21, 8]	//, MEM <unsigned long> [(int *)_434 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_629 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x21]	// MEM[(struct _Sp_counted_base *)_434]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_434]._vptr._Sp_counted_base
	mov	x0, x21	// _434, _434
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_631 + 24B], MEM[(int (*) () *)_631 + 24B]
	blr	x1		// MEM[(int (*) () *)_631 + 24B]
	b	.L1852		//
.L2020:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x21, [sp, 136]	// _365, %sfp
	ldr	x1, [x21]	// MEM[(struct _Sp_counted_base *)_365]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_365]._vptr._Sp_counted_base
	mov	x0, x21	//, _365
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_641 + 16B], MEM[(int (*) () *)_641 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x21, 8]	//, MEM <unsigned long> [(int *)_365 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_641 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x21]	// MEM[(struct _Sp_counted_base *)_365]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_365]._vptr._Sp_counted_base
	mov	x0, x21	// _365, _365
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_643 + 24B], MEM[(int (*) () *)_643 + 24B]
	blr	x1		// MEM[(int (*) () *)_643 + 24B]
	b	.L1856		//
.L2024:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x0, [sp, 40]	// _283, %sfp
	ldr	x1, [x0]	// MEM[(struct _Sp_counted_base *)_283]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_283]._vptr._Sp_counted_base
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_665 + 16B], MEM[(int (*) () *)_665 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x0, 8]	//, MEM <unsigned long> [(int *)_283 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_665 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	adrp	x0, :got:__stack_chk_guard	// tmp697,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp697,
	ldr	x2, [sp, 184]	// tmp792, D.331676
	ldr	x1, [x0]	// tmp793,
	subs	x2, x2, x1	// tmp792, tmp793
	mov	x1, 0	// tmp793
	bne	.L1976		//,
	ldr	x0, [sp, 40]	// _283, %sfp
// /probe/scatter-baseline-pitch.cpp:447: }
	ldp	x29, x30, [sp, 192]	//,,
	ldp	x19, x20, [sp, 208]	//,,
	ldp	x21, x22, [sp, 224]	//,,
	ldp	x23, x24, [sp, 240]	//,,
	ldp	x25, x26, [sp, 256]	//,,
	ldp	x27, x28, [sp, 272]	//,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x0]	// MEM[(struct _Sp_counted_base *)_283]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_283]._vptr._Sp_counted_base
// /probe/scatter-baseline-pitch.cpp:447: }
	ldp	d8, d9, [sp, 288]	//,,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_667 + 24B], MEM[(int (*) () *)_667 + 24B]
// /probe/scatter-baseline-pitch.cpp:447: }
	add	sp, sp, 304	//,,
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_restore 72
	.cfi_restore 73
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	mov	x16, x1	// MEM[(int (*) () *)_667 + 24B], MEM[(int (*) () *)_667 + 24B]
	br	x16		// MEM[(int (*) () *)_667 + 24B]
.L2022:
	.cfi_restore_state
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	ldr	x1, [x20]	// MEM[(struct _Sp_counted_base *)_296]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_296]._vptr._Sp_counted_base
	mov	x0, x20	//, _296
	ldr	x1, [x1, 16]	// MEM[(int (*) () *)_653 + 16B], MEM[(int (*) () *)_653 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:343: 	      _M_weak_count = _M_use_count = 0;
	str	xzr, [x20, 8]	//, MEM <unsigned long> [(int *)_296 + 8B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:346: 	      _M_dispose();
	blr	x1		// MEM[(int (*) () *)_653 + 16B]
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:347: 	      _M_destroy();
	ldr	x1, [x20]	// MEM[(struct _Sp_counted_base *)_296]._vptr._Sp_counted_base, MEM[(struct _Sp_counted_base *)_296]._vptr._Sp_counted_base
	mov	x0, x20	//, _296
	ldr	x1, [x1, 24]	// MEM[(int (*) () *)_655 + 24B], MEM[(int (*) () *)_655 + 24B]
	blr	x1		// MEM[(int (*) () *)_655 + 24B]
	b	.L1860		//
.L2002:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x28	//, _84
	str	x2, [sp, 72]	// _162, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	ldr	x2, [sp, 72]	// _162, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x22, x20, [sp, 168]	// tmp730, _296, MEM[(struct __shared_ptr *)_5]._M_ptr
	b	.L1795		//
.L1988:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x25	//, _302
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1730		//
.L1986:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x25	//, _301
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1724		//
.L1993:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x25	//, _371
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1752		//
.L1991:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x25	//, _370
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1746		//
.L1996:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x23	//, _439
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1768		//
.L1998:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x23	//, _440
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1774		//
.L2010:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x23	//, _96
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1827		//
.L2004:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x28	//, _86
	str	x2, [sp, 88]	// _155, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1528: 	: _M_ptr(__r._M_ptr), _M_refcount(__r._M_refcount)
	ldr	x0, [sp, 24]	// tmp732, %sfp
	ldr	x2, [sp, 88]	// _155, %sfp
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1075:       : _M_pi(__r._M_pi)
	stp	x0, x26, [sp, 168]	// tmp732, _365, MEM[(struct __shared_ptr *)_5]._M_ptr
	b	.L1804		//
.L2006:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x28	//, _91
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1811		//
.L2000:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x28	//, _82
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:354: 	      return;
	b	.L1787		//
.L2008:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	mov	x0, x23	//, _93
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	b	.L1818		//
.L2025:
	ldr	x2, [sp, 184]	// tmp794, D.331676
	ldr	x1, [x0]	// tmp795,
	subs	x2, x2, x1	// tmp794, tmp795
	mov	x1, 0	// tmp795
	bne	.L1976		//,
	ldr	x0, [sp, 40]	//, %sfp
// /probe/scatter-baseline-pitch.cpp:447: }
	ldp	x29, x30, [sp, 192]	//,,
	ldp	x19, x20, [sp, 208]	//,,
	ldp	x21, x22, [sp, 224]	//,,
	ldp	x23, x24, [sp, 240]	//,,
	ldp	x25, x26, [sp, 256]	//,,
	ldp	x27, x28, [sp, 272]	//,,
	ldp	d8, d9, [sp, 288]	//,,
	add	sp, sp, 304	//,,
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 27
	.cfi_restore 28
	.cfi_restore 25
	.cfi_restore 26
	.cfi_restore 23
	.cfi_restore 24
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_restore 72
	.cfi_restore 73
	.cfi_def_cfa_offset 0
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:353: 	      _M_release_last_use_cold();
	b	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
.L2023:
	.cfi_restore_state
	mov	x0, x20	//, _296
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	b	.L1860		//
.L2021:
	ldr	x0, [sp, 136]	//, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	b	.L1856		//
.L2019:
	ldr	x0, [sp, 32]	//, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE24_M_release_last_use_coldEv		//
	b	.L1852		//
.L1906:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x19, x0	// tmp753,
	mov	x1, 144	//,
	mov	x0, x25	//, _357
	bl	_ZdlPvm		//
.L1742:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x20	//, _296
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1720:
	ldr	x0, [sp, 40]	//, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
	adrp	x0, :got:__stack_chk_guard	// tmp722,
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]	// tmp722,
	ldr	x2, [sp, 184]	// tmp796, D.331676
	ldr	x1, [x0]	// tmp797,
	subs	x2, x2, x1	// tmp796, tmp797
	mov	x1, 0	// tmp797
	beq	.L1889		//,
.L1976:
// /probe/scatter-baseline-pitch.cpp:447: }
	bl	__stack_chk_fail		//
.L1895:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x19, x0	// tmp482, tmp786
.L1764:
	ldr	x0, [sp, 136]	//, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
	b	.L1742		//
.L1889:
	mov	x0, x19	//, tmp398
.LEHB36:
	bl	_Unwind_Resume		//
.LEHE36:
.L1894:
	mov	x19, x0	// tmp440, tmp787
	b	.L1742		//
.L1910:
	mov	x19, x0	// tmp775,
	mov	x0, x21	//, _288
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
	b	.L1720		//
.L1900:
.L1978:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 176]	// _117, MEM[(struct __shared_count *)_5]._M_pi
	mov	x19, x0	// tmp720, tmp785
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x1, .L1874	// _117,
.L1974:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x1	//, _117
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1874:
	ldr	x0, [sp, 32]	//, %sfp
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
	b	.L1764		//
.L1902:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 88]	// _365, %sfp
	mov	x19, x0	// tmp718, tmp784
	str	x1, [sp, 136]	// _365, %sfp
	ldr	x1, [sp, 176]	// _116, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbnz	x1, .L1974	// _116,
	b	.L1874		//
.L1903:
	b	.L1978		//
.L1898:
	b	.L1978		//
.L1907:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 160]	// _372, MEM[(struct __shared_count *)_4]._M_pi
	mov	x19, x0	// tmp471, tmp757
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x1, .L1759	// _372,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x1	//, _372
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1759:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x0, [sp, 176]	// _373, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x0, .L1760	// _373,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1760:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	ldr	x0, [sp, 136]	//, %sfp
	mov	x1, 32824	//,
	bl	_ZdlPvm		//
	b	.L1742		//
.L1901:
	b	.L1978		//
.L1899:
	b	.L1978		//
.L1905:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 160]	// _303, MEM[(struct __shared_count *)_4]._M_pi
	mov	x19, x0	// tmp429, tmp751
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x1, .L1737	// _303,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x1	//, _303
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1737:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x0, [sp, 176]	// _304, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x0, .L1738	// _304,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1738:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x0, x20	//, _296
	mov	x1, 32824	//,
	bl	_ZdlPvm		//
	b	.L1720		//
.L1904:
	mov	x19, x0	// tmp747,
	mov	x1, 144	//,
	mov	x0, x21	//, _288
	bl	_ZdlPvm		//
	b	.L1720		//
.L1896:
	b	.L1978		//
.L1911:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x19, x0	// tmp776,
	mov	x0, x25	//, _357
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
	b	.L1742		//
.L1908:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	mov	x19, x0	// tmp759,
	mov	x1, 144	//,
	mov	x0, x25	//, _426
	bl	_ZdlPvm		//
	b	.L1764		//
.L1912:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x19, x0	// tmp777,
	mov	x0, x25	//, _426
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
	b	.L1764		//
.L1897:
	b	.L1978		//
.L1909:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x1, [sp, 160]	// _441, MEM[(struct __shared_count *)_4]._M_pi
	mov	x19, x0	// tmp515, tmp762
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x1, .L1781	// _441,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x0, x1	//, _441
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1781:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	ldr	x0, [sp, 176]	// _442, MEM[(struct __shared_count *)_5]._M_pi
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1070: 	if (_M_pi != nullptr)
	cbz	x0, .L1782	// _442,
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	bl	_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv		//
.L1782:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/new_allocator.h:172: 	_GLIBCXX_OPERATOR_DELETE(_GLIBCXX_SIZED_DEALLOC(__p, __n));
	ldr	x0, [sp, 32]	//, %sfp
	mov	x1, 32824	//,
	bl	_ZdlPvm		//
	b	.L1764		//
.L1893:
// /buildroot/output/host/aarch64-buildroot-linux-gnu/include/c++/13.4.0/bits/shared_ptr_base.h:1071: 	  _M_pi->_M_release();
	mov	x19, x0	// tmp398, tmp788
	b	.L1720		//
	.cfi_endproc
.LFE9597:
	.section	.gcc_except_table
.LLSDA9597:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE9597-.LLSDACSB9597
.LLSDACSB9597:
	.uleb128 .LEHB15-.LFB9597
	.uleb128 .LEHE15-.LEHB15
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB16-.LFB9597
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L1893-.LFB9597
	.uleb128 0
	.uleb128 .LEHB17-.LFB9597
	.uleb128 .LEHE17-.LEHB17
	.uleb128 .L1904-.LFB9597
	.uleb128 0
	.uleb128 .LEHB18-.LFB9597
	.uleb128 .LEHE18-.LEHB18
	.uleb128 .L1910-.LFB9597
	.uleb128 0
	.uleb128 .LEHB19-.LFB9597
	.uleb128 .LEHE19-.LEHB19
	.uleb128 .L1905-.LFB9597
	.uleb128 0
	.uleb128 .LEHB20-.LFB9597
	.uleb128 .LEHE20-.LEHB20
	.uleb128 .L1894-.LFB9597
	.uleb128 0
	.uleb128 .LEHB21-.LFB9597
	.uleb128 .LEHE21-.LEHB21
	.uleb128 .L1906-.LFB9597
	.uleb128 0
	.uleb128 .LEHB22-.LFB9597
	.uleb128 .LEHE22-.LEHB22
	.uleb128 .L1911-.LFB9597
	.uleb128 0
	.uleb128 .LEHB23-.LFB9597
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L1907-.LFB9597
	.uleb128 0
	.uleb128 .LEHB24-.LFB9597
	.uleb128 .LEHE24-.LEHB24
	.uleb128 .L1895-.LFB9597
	.uleb128 0
	.uleb128 .LEHB25-.LFB9597
	.uleb128 .LEHE25-.LEHB25
	.uleb128 .L1908-.LFB9597
	.uleb128 0
	.uleb128 .LEHB26-.LFB9597
	.uleb128 .LEHE26-.LEHB26
	.uleb128 .L1912-.LFB9597
	.uleb128 0
	.uleb128 .LEHB27-.LFB9597
	.uleb128 .LEHE27-.LEHB27
	.uleb128 .L1909-.LFB9597
	.uleb128 0
	.uleb128 .LEHB28-.LFB9597
	.uleb128 .LEHE28-.LEHB28
	.uleb128 .L1896-.LFB9597
	.uleb128 0
	.uleb128 .LEHB29-.LFB9597
	.uleb128 .LEHE29-.LEHB29
	.uleb128 .L1897-.LFB9597
	.uleb128 0
	.uleb128 .LEHB30-.LFB9597
	.uleb128 .LEHE30-.LEHB30
	.uleb128 .L1898-.LFB9597
	.uleb128 0
	.uleb128 .LEHB31-.LFB9597
	.uleb128 .LEHE31-.LEHB31
	.uleb128 .L1899-.LFB9597
	.uleb128 0
	.uleb128 .LEHB32-.LFB9597
	.uleb128 .LEHE32-.LEHB32
	.uleb128 .L1900-.LFB9597
	.uleb128 0
	.uleb128 .LEHB33-.LFB9597
	.uleb128 .LEHE33-.LEHB33
	.uleb128 .L1901-.LFB9597
	.uleb128 0
	.uleb128 .LEHB34-.LFB9597
	.uleb128 .LEHE34-.LEHB34
	.uleb128 .L1902-.LFB9597
	.uleb128 0
	.uleb128 .LEHB35-.LFB9597
	.uleb128 .LEHE35-.LEHB35
	.uleb128 .L1903-.LFB9597
	.uleb128 0
	.uleb128 .LEHB36-.LFB9597
	.uleb128 .LEHE36-.LEHB36
	.uleb128 0
	.uleb128 0
.LLSDACSE9597:
	.text
	.size	_ZN5ardor4pog319PolyphonicPitchBank7prepareEv, .-_ZN5ardor4pog319PolyphonicPitchBank7prepareEv
	.weak	_ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE
	.section	.rodata._ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE,"aG",@progbits,_ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE, 47
_ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE:
	.string	"St11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE"
	.weak	_ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro._ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE, 16
_ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE:
// <anonymous>:
// <anonymous>:
	.xword	_ZTVN10__cxxabiv117__class_type_infoE+16
// <anonymous>:
	.xword	_ZTSSt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE
	.weak	_ZTSSt19_Sp_make_shared_tag
	.section	.rodata._ZTSSt19_Sp_make_shared_tag,"aG",@progbits,_ZTSSt19_Sp_make_shared_tag,comdat
	.align	3
	.type	_ZTSSt19_Sp_make_shared_tag, %object
	.size	_ZTSSt19_Sp_make_shared_tag, 24
_ZTSSt19_Sp_make_shared_tag:
	.string	"St19_Sp_make_shared_tag"
	.weak	_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE
	.section	.rodata._ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE,"aG",@progbits,_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE, 52
_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE:
	.string	"St16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE"
	.weak	_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro._ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE, 24
_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE:
// <anonymous>:
// <anonymous>:
	.xword	_ZTVN10__cxxabiv120__si_class_type_infoE+16
// <anonymous>:
	.xword	_ZTSSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE
// <anonymous>:
	.xword	_ZTISt11_Mutex_baseILN9__gnu_cxx12_Lock_policyE2EE
	.weak	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.rodata._ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE,"aG",@progbits,_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE, 97
_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE:
	.string	"St23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE"
	.weak	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro._ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE, 24
_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE:
// <anonymous>:
// <anonymous>:
	.xword	_ZTVN10__cxxabiv120__si_class_type_infoE+16
// <anonymous>:
	.xword	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE
// <anonymous>:
	.xword	_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE
	.weak	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.rodata._ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,"aG",@progbits,_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, 91
_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE:
	.string	"St23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE"
	.weak	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro._ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, 24
_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE:
// <anonymous>:
// <anonymous>:
	.xword	_ZTVN10__cxxabiv120__si_class_type_infoE+16
// <anonymous>:
	.xword	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
// <anonymous>:
	.xword	_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE
	.weak	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.rodata._ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,"aG",@progbits,_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, 87
_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE:
	.string	"St23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE"
	.weak	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro._ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, 24
_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE:
// <anonymous>:
// <anonymous>:
	.xword	_ZTVN10__cxxabiv120__si_class_type_infoE+16
// <anonymous>:
	.xword	_ZTSSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
// <anonymous>:
	.xword	_ZTISt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE
	.weak	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro.local._ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE, 56
_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE:
	.xword	0
	.xword	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog318PitchInterpolationESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.weak	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro.local._ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, 56
_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE:
	.xword	0
	.xword	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog312SpectralPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.weak	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.section	.data.rel.ro.local._ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,"awG",@progbits,_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE,comdat
	.align	3
	.type	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, %object
	.size	_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE, 56
_ZTVSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE:
	.xword	0
	.xword	_ZTISt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED1Ev
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EED0Ev
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv
	.xword	_ZNSt23_Sp_counted_ptr_inplaceIN5ardor4pog39PitchPlanESaIvELN9__gnu_cxx12_Lock_policyE2EE14_M_get_deleterERKSt9type_info
	.weak	_ZN5ardor4pog315kVoiceSemitonesE
	.section	.rodata._ZN5ardor4pog315kVoiceSemitonesE,"aG",@progbits,_ZN5ardor4pog315kVoiceSemitonesE,comdat
	.align	3
	.type	_ZN5ardor4pog315kVoiceSemitonesE, %gnu_unique_object
	.size	_ZN5ardor4pog315kVoiceSemitonesE, 24
_ZN5ardor4pog315kVoiceSemitonesE:
// _M_elems:
	.word	0
	.word	-1044381696
	.word	-1052770304
	.word	1088421888
	.word	1094713344
	.word	1103101952
	.weak	_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag
	.section	.rodata._ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag,"aG",@progbits,_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag,comdat
	.align	3
	.type	_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag, %gnu_unique_object
	.size	_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag, 16
_ZZNSt19_Sp_make_shared_tag5_S_tiEvE5__tag:
	.zero	16
	.section	.rodata.cst8,"aM",@progbits,8
	.align	3
.LC0:
	.word	-2127697391
	.word	1030854553
	.align	3
.LC1:
	.word	1413754136
	.word	1074340347
	.align	3
.LC2:
	.word	1413754136
	.word	1075388923
	.section	.rodata.cst16,"aM",@progbits,16
	.align	4
.LC3:
	.word	-7
	.word	-6
	.word	-5
	.word	-4
	.align	4
.LC4:
	.word	-11
	.word	-10
	.word	-9
	.word	-8
	.align	4
.LC5:
	.word	-3
	.word	-2
	.word	-1
	.word	0
	.align	4
.LC6:
	.word	1
	.word	2
	.word	3
	.word	4
	.align	4
.LC7:
	.word	5
	.word	6
	.word	7
	.word	8
	.align	4
.LC8:
	.word	9
	.word	10
	.word	11
	.word	12
	.align	4
.LC9:
	.byte	12
	.byte	13
	.byte	14
	.byte	15
	.byte	8
	.byte	9
	.byte	10
	.byte	11
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.section	.rodata.cst4,"aM",@progbits,4
	.align	2
.LC10:
	.word	1195081728
	.section	.rodata
	.align	4
	.set	.LANCHOR0,. + 0
	.type	_ZZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoEE7longDue, %object
	.size	_ZZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoEE7longDue, 96
_ZZN5ardor4pog319PolyphonicPitchBank7processENS0_11PitchStereoEE7longDue:
// _M_elems:
	.xword	17
	.xword	38
	.xword	81
	.xword	102
	.xword	129
	.xword	145
	.xword	161
	.xword	177
	.xword	193
	.xword	209
	.xword	225
	.xword	241
	.type	_ZZNK5ardor4pog319PolyphonicPitchBank6freezeEvE8inactive, %object
	.size	_ZZNK5ardor4pog319PolyphonicPitchBank6freezeEvE8inactive, 209640
_ZZNK5ardor4pog319PolyphonicPitchBank6freezeEvE8inactive:
// latest_:
// _M_elems:
	.zero	61536
// requested_:
// _M_elems:
	.zero	61536
// held_:
// _M_elems:
	.zero	61536
// previous_:
// _M_elems:
	.zero	12336
// goal_:
// _M_elems:
	.zero	12336
// used_:
	.zero	256
// mode_:
	.word	0
// state_:
	.word	0
// position_:
	.word	0
// mix_:
	.word	0
// dryMix_:
	.word	0
// gain_:
	.word	1065353216
// heel_:
	.byte	1
// latched_:
	.byte	0
// dryEligible_:
	.byte	0
// ready_:
	.byte	0
// requestedValid_:
	.byte	0
// initial_:
	.byte	0
// targetPending_:
	.byte	0
// initialAudibleAt_:
	.zero	1
	.xword	-1
// lastEvent_:
	.xword	-1920
// targetAt_:
	.xword	0
// remaining_:
	.xword	0
// duration_:
	.xword	960
// serial_:
	.xword	0
// captures_:
	.xword	0
// targets_:
	.xword	0
// capacityEvents_:
	.xword	0
	.hidden	DW.ref.__gxx_personality_v0
	.weak	DW.ref.__gxx_personality_v0
	.section	.data.rel.local.DW.ref.__gxx_personality_v0,"awG",@progbits,DW.ref.__gxx_personality_v0,comdat
	.align	3
	.type	DW.ref.__gxx_personality_v0, %object
	.size	DW.ref.__gxx_personality_v0, 8
DW.ref.__gxx_personality_v0:
	.xword	__gxx_personality_v0
	.ident	"GCC: (Buildroot 2025.02.15) 13.4.0"
	.section	.note.GNU-stack,"",@progbits
