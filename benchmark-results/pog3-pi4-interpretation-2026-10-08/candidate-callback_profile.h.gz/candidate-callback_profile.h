#pragma once
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string_view>
#include <vector>
namespace pog3_phase {
inline constexpr std::array<const char*,14> labels{
  "forward_fft", "inverse_fft", "interpretation", "low_attack",
  "long_attack", "short_attack", "long_render", "short_render",
  "frame_magnitudes", "frame_peak_frequency", "frame_candidate_sort",
  "frame_predictions", "frame_association", "frame_finalize"};
struct Event {
  std::uint64_t sample=0, frame=0, inclusive=0, exclusive=0;
  std::uint32_t size=0, stage=0, control=0;
  int channel=-1, voice=-1;
};
struct Total { std::uint64_t calls=0, inclusive=0, exclusive=0; };
// This executable has one processing owner. Fixed diagnostic BSS is outside
// the processor preparation counter; no event storage is allocated on callback.
inline std::array<Event,131072> events{};
inline std::size_t count=0;
inline bool enabled=false, overflow=false, bankContext=false;
inline std::uint64_t sample=0;
inline int bankChannel=-1;
inline void beginSample(std::uint64_t value) {
  sample=value; bankContext=false; bankChannel=-1;
}

struct FrameRecord {
  std::uint64_t sample=0, frame=0;
  std::uint32_t size=0, channel=0, bins=0, peaks=0, phase=0, logarithmic=0,
    phaseReuse=0, predicted=0, matched=0, births=0, firstSteps=0, fallbackSteps=0, selected=0, snapshots=0, snapshotReads=0;
};
inline std::array<FrameRecord,8192> frames{};
inline std::size_t frameCount=0;
inline FrameRecord* currentFrame=nullptr;
// Diagnostic shadow validity only, not cached DSP phase values. Max supported N=32768.
inline std::array<std::array<bool,16385>,6> previousPhase{};
inline void reset() {
  enabled=false; overflow=false; count=frameCount=0; currentFrame=nullptr; beginSample(0);
  events.fill(Event{}); frames.fill(FrameRecord{});
  for (auto& flags:previousPhase) flags.fill(false);
}
struct Scope {
  static inline Scope* current=nullptr;
  Scope* parent=nullptr;
  Event event{};
  std::uint64_t child=0;
  bool active=false;
  std::chrono::steady_clock::time_point start{};
  explicit Scope(unsigned stage, unsigned size=0, std::int64_t frame=-1,
                 int channel=-1, int voice=-1, std::uint32_t control=0):active(enabled) {
    if (!active) return;
    parent=current;
    if (parent) event=parent->event;
    else {
      event.sample=sample;
      event.frame=bankContext && bankChannel>=0 ? sample-bankChannel : sample;
      event.channel=bankContext ? bankChannel : -1;
    }
    event.stage=stage;
    if (size) event.size=size;
    if (frame>=0) event.frame=frame;
    if (channel!=-1) event.channel=channel;
    if (voice>=0) event.voice=voice;
    event.control=control;
    current=this;
    start=std::chrono::steady_clock::now();
  }
  ~Scope() {
    if (!active) return;
    event.inclusive=std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now()-start).count();
    event.exclusive=event.inclusive-child;
    current=parent;
    if (parent) parent->child+=event.inclusive;
    if (count<events.size()) events[count++]=event;
    else overflow=true;
  }
};

struct FrameScope {
  FrameRecord* record=nullptr;
  std::array<bool,16385>* validity=nullptr;
  explicit FrameScope(unsigned size) {
    if (!enabled) return;
    const auto* parent=Scope::current;
    if (!parent || parent->event.stage!=2 || parent->event.channel<0 || parent->event.channel>1
        || currentFrame || frameCount==frames.size() || (size!=1024 && size!=2048 && size!=4096)) {
      overflow=true; return;
    }
    record=&frames[frameCount++]; currentFrame=record;
    record->sample=sample; record->frame=parent->event.frame;
    record->size=size; record->channel=static_cast<unsigned>(parent->event.channel);
    const auto resolution=size==2048?0U:size==1024?1U:2U;
    validity=&previousPhase[resolution*2+record->channel];
  }
  bool visit(std::size_t bin) {
    if (!record) return false;
    if (bin>=validity->size()) { overflow=true; return false; }
    const bool old=(*validity)[bin]; (*validity)[bin]=false; return old;
  }
  void phase(std::size_t bin,bool reusable) {
    if (!record) return;
    ++record->phase; record->phaseReuse+=reusable;
    if (bin>=validity->size()) { overflow=true; return; }
    (*validity)[bin]=true;
  }
  ~FrameScope() { if (record) currentFrame=nullptr; }
};
inline void reportFrame(const char* workload,unsigned callback) {
  if (enabled || currentFrame || overflow) throw std::runtime_error("interpretation profile bounds/state failed");
  std::ostringstream log;
  if (std::string_view(workload)=="matched_freeze_off") for(std::size_t i=0;i<frameCount;++i) {
    const auto& r=frames[i];
    log<<"frame_counts,"<<workload<<','<<callback<<','<<r.sample<<','<<r.frame<<','<<r.size<<','<<r.channel<<','
      <<r.bins<<','<<r.peaks<<','<<r.phase<<','<<r.logarithmic<<','<<r.phaseReuse<<','<<r.predicted<<','
      <<r.matched<<','<<r.births<<','<<r.firstSteps<<','<<r.fallbackSteps<<','<<r.selected<<','<<r.snapshots<<','<<r.snapshotReads<<'\n';
  }
  log<<"frame_receipt,"<<workload<<','<<callback<<','<<frameCount<<",overflow=0\n";
  std::cerr<<log.str();
}

inline void report(const char* workload, unsigned frames, const std::vector<double>& times) {
  if (enabled || Scope::current || overflow) throw std::runtime_error("callback profile bounds/state failed");
  // Allocate, aggregate and format only after the callback allocation scope.
  std::vector<std::array<Total,14>> totals(times.size());
  std::ostringstream log;
  for (std::size_t i=0; i<count; ++i) {
    const auto& e=events[i];
    if (!e.sample || e.sample>times.size()*frames || e.stage>=labels.size()
        || e.exclusive>e.inclusive || e.frame>e.sample)
      throw std::runtime_error("callback profile event rejected");
    auto& t=totals[(e.sample-1)/frames][e.stage];
    ++t.calls; t.inclusive+=e.inclusive; t.exclusive+=e.exclusive;
    // Retain every real core event's entry/input timestamp and identity.
    if (std::string_view(workload)=="matched_freeze_off")
      log<<"phase_event,"<<workload<<','<<frames<<','<<labels[e.stage]<<','<<e.sample<<','
        <<e.frame<<','<<e.size<<','<<e.channel<<','<<e.voice<<','<<e.control<<','
        <<e.inclusive<<','<<e.exclusive<<'\n';
  }
  for (std::size_t block=0; block<times.size(); ++block) {
    const auto phase=((block+1)*frames)%512;
    std::uint64_t exclusive=0;
    for (unsigned stage=0; stage<labels.size(); ++stage) {
      const auto& t=totals[block][stage]; exclusive+=t.exclusive;
      if (t.calls) log<<"phase_stage,"<<workload<<','<<frames<<','<<block<<','<<phase<<','
        <<labels[stage]<<','<<t.calls<<','<<t.inclusive<<','<<t.exclusive<<'\n';
    }
    log<<"phase_callback,"<<workload<<','<<frames<<','<<block<<','<<phase<<','
      <<times[block]<<','<<(times[block]>frames/.048)<<','<<exclusive<<'\n';
  }
  log<<"phase_receipt,"<<workload<<','<<frames<<','<<count<<",overflow=0\n";
  std::cerr<<log.str();
}
}
